import json, sys, os, getopt, jsonpath, random, traceback

def main(argv):
    try:
        dc2_file,  esb_file , mwg_file = '','','',
        just_count=False
        opts, args = getopt.getopt(argv,"hd:e:m:",["d=","e=","m="])
        for opt, arg in opts:
            if opt == '-h':
                print ('perform_checks.py -d <dc2_json_file> -e <dc2_json_file> -m <mwg_json_file> \n ')
                sys.exit(1)
            elif opt ==  ("-d"):
                dc2_file = arg
            elif opt == ("-e"):
                esb_file = arg
            elif opt == ("-m"):
                mwg_file = arg
        if os.path.exists(dc2_file):
          if os.path.exists(esb_file):
            if os.path.exists(mwg_file):
              perform_checks(dc2_file, esb_file,mwg_file)
            else:
              print (mwg_file + ' does not exist')
          else:
              print (esb_file + ' does not exist')
        else:
            print (dc2_file + ' does not exist')
    except (Exception): traceback.print_exc()
     

def perform_checks(dc2_file, esb_file, mwg_file):
  try:
  
    fdc2 = open(dc2_file,'r', encoding="utf8")
    jdc2=json.load(fdc2)

    fesb = open(esb_file,'r', encoding="utf8")
    jesb=json.load(fesb)

    fmwg = open(mwg_file,'r', encoding="utf8")
    jmwg=json.load(fmwg)

    # now lets get the item counts from each file.
    dc2_items = set()
    lst_dc2_items = jsonpath.jsonpath(jdc2, '$.circularItems..id')
    
    if isinstance(lst_dc2_items, list):
      for each in lst_dc2_items:
        dc2_items.add(int(each))
      
    esb_items = set(jsonpath.jsonpath(jesb, '$.Items..Id'))
    lst_esb_items = jsonpath.jsonpath(jesb, '$.Items..Id')
    mwg_items = set(jsonpath.jsonpath(jmwg, '$..Id'))
    lst_mwg_items = set(jsonpath.jsonpath(jmwg, '$..Id'))
    
    #print the ids
    print('Item from DC2 : ' + str(dc2_items))
    print('Item from ESB : ' + str(esb_items))
    print('Item from MWG : ' + str(mwg_items))

    #check the counts
    print ('Item Counts from DC2 : ' + str(len(dc2_items)))
    print ('Item Counts from ESB : ' + str(len(esb_items)))
    print ('Item Counts from MWG : ' + str(len(mwg_items)))

    #check the item in dc2 is present in esb and mwg
    print('All items in DC2 is present in ESB? : ' + str(dc2_items.issubset(esb_items)))
    print('All items in DC2 is Present in MWG? : ' + str(dc2_items.issubset(mwg_items)))

    print ('Symmetrical Difference between ESB Items and MWG Items : ' + str(len(esb_items.symmetric_difference(mwg_items))))

    print ('ECSB = DC2 U (MWG-DC2) : ' + str(dc2_items.union(mwg_items.difference(dc2_items)) == esb_items) )

    #check the Rank Ordering
    if isinstance(lst_dc2_items, list):
      i = -1
      rank_order_fail = False
      for each in lst_dc2_items:
        i += 1
        if int(each) != lst_esb_items[i]:
          rank_order_fail = True
          print ('%s element in DC2 is %s , but found %s in ESB' %(i,each, lst_esb_items[i]))
          print ('Rank Ordering : Fail')
          break
      if not rank_order_fail: print ('Rank Ordering : Pass')
    else:
      print ('Rank Ordering : Not Checked')

    # now we will make sure the item information from mwg and ecsb matches
    sampling_idx = random.sample(range(0,len(lst_esb_items)),50)
    print ('Sampling Indexes : ' + str(sampling_idx))
    item_comp = True
    for sample in sampling_idx:
      seek_id = jesb['Items'][sample]['Id']
      for each in jmwg:
          if int(each['Id']) == seek_id:
            if not each['AreaCoordinates'] == jesb['Items'][sample]['AreaCoordinates']:
              item_comp = False          
              print ('AreaCoordinates Comparison for index : ' + str(seek_id))
            
            if not each['Brand'] == jesb['Items'][sample]['Brand']:
              item_comp = False          
              print ('Brand Comparison for index : ' + str(seek_id))
            
            if not each['CategoryId'] == jesb['Items'][sample]['CategoryId']:
              item_comp = False          
              print ('CategoryId Comparison for index : ' + str(seek_id))
            
            if not each['CategoryName'] == jesb['Items'][sample]['CategoryName']:
              item_comp = False          
              print ('CategoryName Comparison for index : ' + str(seek_id))
            
            #if not each['Description'].replace('\n','') == jesb['Items'][sample]['Description']:
            #  item_comp = False          
            #  print ('Description Comparison for index : ' + str(seek_id))
            
            
            if not each['DisplayEndDateShort'] == jesb['Items'][sample]['DisplayEndDateShort']:
              item_comp = False          
              print ('DisplayEndDateShort Comparison for index : ' + str(seek_id))
            
            if not each['Title'] == jesb['Items'][sample]['Title']:
              item_comp = False          
              print ('Title Comparison for index : ' + str(seek_id))
            
            if not each['CategoryName'] == jesb['Items'][sample]['CategoryName']:
              item_comp = False          
              print ('CategoryName Comparison for index : ' + str(seek_id))

            if not each['ImageFile'] == jesb['Items'][sample]['ImageFile']:
              item_comp = False          
              print ('ImageFile Comparison for index : ' + str(seek_id))
            break
    if item_comp == True:
      print ('Random Item Comparision : Pass')
    else: print ('Random Item Comparision : Fail')

    #check if InformationItem are presen at the last

    print ("\nTrace Information...")
    print ("DC2 File Used : " + dc2_file)
    print ("ESB File Used : " + esb_file)
    print ("MWG File Used : " + mwg_file)
  except (Exception): traceback.print_exc()
  
if __name__ == "__main__":
    main(sys.argv[1:])
