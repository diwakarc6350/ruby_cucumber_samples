import urllib.request
import prettytable
import traceback
import jsonpath
import random
import json
import http
import ssl

url_pattern_esd = 'http://ecsb-dev.kroger.com/personalization-rs/coupons/scored/kroger/%s/%s/%s'
url_pattern_usr = 'http://ecsb-dev.kroger.com/personalization-rs/coupons/kroger/ios/%s'
result=[]

def do_print_pretty(method,url,tot_coupons,coupon_id,added_to_card,can_be_removed):
    tmp_res=[]
    tmp_res.append(method)
    tmp_res.append(url)
    tmp_res.append(tot_coupons)
    tmp_res.append(coupon_id)
    tmp_res.append(added_to_card)
    tmp_res.append(can_be_removed)
    result.append(tmp_res)

def print_results():
  x = prettytable.PrettyTable(["Method", "URL", "Tot. Coupons", "Coupon Id", "Added To Card?", "Can Be Removed?"])
  x.align["URL"] = 'l' # Left align city names
  x.padding_width = 1  # One space between column edges and contents (default)
  for each in result:
    x.add_row(each)
  print (x)
  check_results()

def check_results():
  #check if add to card is good
  if (int(result[0][2])-1 == int(result[2][2])) and \
       (result[0][4] == 'False') and \
       (result[2][4] == 'Not Present'):
        print ("Add to Card: OK")
  else:
        print ("Add to Card: Fail")
  #check if remove from card is good
  if (int(result[5][2])-1 == int(result[2][2])) and \
       (result[5][4] == 'False'):
        print ("Remove from Card: OK")
  else:
        print ("Remove from Card: Fail")
  #check can be removed is good
  if (result[0][5] == 'True'):
    print ("Can Be Removed from Card: OK")
  else:
    print ("Can Be Removed Card: Fail")
          
  
def fetch_coupon(jresp,coupon_id):
    for each in jresp['coupons']:
        if each['id']==coupon_id:
            return each
            break

def do_call(url,data,method):
    try:
        opener = urllib.request.build_opener()
        urllib.request.install_opener(opener)
        if data is None:
            request = urllib.request.Request(url, data=None)
        else:
            request = urllib.request.Request(url, data=data.encode('UTF-8') )     
        request.add_header("Accept",'application/json')
        request.add_header("Content-Type",'application/json')
        request.get_method = lambda: method
        connection = opener.open(request)
        if connection.code == 200:
            data = connection.read()
            return (connection.code, data.decode('utf-8'))
            connection.close()
        else:
            print ('Execution failed')
            return (None, None)
    except (Exception):traceback.print_exc()

def check_add_to_card(url,couponid ):
    response = do_call(url,None,'GET')
    jresp = json.loads(response[1])
    for each in jresp['coupons']:
        if each['id']==couponid:
            do_print_pretty('GET',
                            url,
                            str(jresp['numberOfCoupons']),
                            str(couponid),
                            str(each['addedToCard']),
                            str(each['canBeRemoved']))
            break

def do_checks(division,store,user):
        response = do_call( url_pattern_esd % (division,store,user), None, 'GET')
        if response[0] == 200:
            jresponse = json.loads(response[1])            
            coupon = jresponse['coupons'][random.randrange(0, jresponse['numberOfCoupons'])] # Choose coupon
            couponid = jresponse['coupons'][random.randrange(0, jresponse['numberOfCoupons'])]['id']
            do_print_pretty('GET',
                            url_pattern_esd % (division,store,user),
                            str(jresponse['numberOfCoupons']),
                            str(couponid),
                            str(coupon['addedToCard']),
                            str(coupon['canBeRemoved']))
              
            response = do_call(url_pattern_usr % (user),'{"couponId":' + str(couponid)+ '}', 'POST') #load  coupon
            do_print_pretty('POST',
                            url_pattern_usr % (user),
                            '', str(couponid),'','')
            if response[0] == 200:
                response = do_call(url_pattern_esd % (division,store,user), None, 'GET')
                jresponse = json.loads(response[1])
                coupon = fetch_coupon(jresponse,couponid)
                if coupon is None:
                    do_print_pretty('GET',
                               url_pattern_esd % (division,store,user),
                            str(jresponse['numberOfCoupons']),
                            str(couponid),
                            'Not Present','Not Present')
                else:
                    do_print_pretty('GET',
                               url_pattern_esd % (division,store,user),
                            str(jresponse['numberOfCoupons']),
                            str(couponid),
                            str(coupon['addedToCard']),
                            str(coupon['canBeRemoved']))
                if response[0] == 200:
                    jresponse = json.loads(response[1])
                    check_add_to_card(url_pattern_esd % (division,store,user) + '/all',couponid)
            response = do_call(url_pattern_usr % (user),'{"couponId":' +str(couponid)+' }', 'DELETE') #delete coupon
            
            do_print_pretty('DELETE',
                            url_pattern_usr % (user),
                            '', str(couponid),'','')
            if response[0] == 200:
               response = do_call(url_pattern_esd % (division,store,user), None, 'GET')
               if response[0] == 200:
                    #Check the count
                    jresponse = json.loads(response[1])
                    coupon = fetch_coupon(jresponse,couponid)
                    if coupon is None:
                        do_print_pretty('GET',
                               url_pattern_esd % (division,store,user),
                            str(jresponse['numberOfCoupons']),
                            str(couponid),
                            'Not Present', 'Not Present')
                    else:
                        do_print_pretty('GET',
                               url_pattern_esd % (division,store,user),
                            str(jresponse['numberOfCoupons']),
                            str(couponid),
                            str(coupon['addedToCard']),
                            str(coupon['canBeRemoved']))
                    check_add_to_card(url_pattern_esd % (division,store,user) + '/all',couponid)
            else:
                print ('POST Failed')
        else:
            print ('Get Failed')

if __name__ == "__main__":
    try:
        do_checks('-','-','9edf6a1d-ecaf-8f21-e582-6d1d7052cbbb')
        print_results()
        result=[]
        do_checks('011','00002','9edf6a1d-ecaf-8f21-e582-6d1d7052cbbb')
        print_results()         
    except (Exception): traceback.print_exc()
