import java.util.Random;
import java.io.FileReader;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class CategoryCompare {
 
    	 public static void main(String[] args) {
    		 	Random r = new Random();
    		 	String nameECSB=""; String nameMWG="";
    		 	long NumberOfCategoriesECSB = 0l; long NumberOfCategoriesMWG = 0l;
				long idECSB = 0l; long idMWG = 0l; long itemcountECSB = 0l; long itemcountMWG = 0l;
				
				JSONParser parser = new JSONParser();
    			
    			try {
    				/*
    				 * Parse the ECSB GetCategory JSON, and store total count, name, id and item count.
    				 */
    				Object objECSB = parser.parse(new FileReader("S:\\iss\\QA\\LISA\\Personalization\\Release\\WeeklyAds\\InputAndOutputFiles\\OutputResultsFiles\\ECSB\\CategoriesFromECSB.txt"));
    				JSONObject jsonObjectECSB = (JSONObject) objECSB;
    				NumberOfCategoriesECSB = (Long) jsonObjectECSB.get("NumberOfCategories");
    				JSONArray CategoriesECSB = (JSONArray) jsonObjectECSB.get("Categories");
    				int randomIndex = r.nextInt(CategoriesECSB.size());
    			
    				if(CategoriesECSB != null && CategoriesECSB.size() > 0) 	{
	    				JSONObject ECSBCategory = (JSONObject) CategoriesECSB.get(randomIndex);
	    				if(ECSBCategory != null) 	{
		    				nameECSB = (String) ECSBCategory.get("Name");
		    				idECSB = (long) ECSBCategory.get("Id");
		    				itemcountECSB = (long) ECSBCategory.get("ItemCount");	
		    				
	    				}
	    				/*
	    				 * Parse the MWG GetCategory JSON, and store total count, name, id and item count.
	    				 */
	    				Object objMWG = parser.parse(new FileReader("S:\\iss\\QA\\LISA\\Personalization\\Release\\WeeklyAds\\InputAndOutputFiles\\OutputResultsFiles\\MWG\\getAllAvailCategoriesInCircularMWG.txt"));
	    				JSONArray jsonObjectMWG = (JSONArray) objMWG;
	    				if(jsonObjectMWG != null && jsonObjectMWG.size() > 0) 	{
	    						JSONObject MWGCategory = (JSONObject) jsonObjectMWG.get(randomIndex);
	    						NumberOfCategoriesMWG = jsonObjectMWG.size();
			    				nameMWG = (String) MWGCategory.get("Name");
			    				idMWG = (long) MWGCategory.get("Id");
			    				itemcountMWG = (long) MWGCategory.get("ItemCount");
			    				
	    				}
	    				/*
	    				 * Now we are ready to compare the data between ECSB and MWG
	    				 */
	    				if ( (!nameECSB.equalsIgnoreCase(nameMWG)) || 
	    					 (NumberOfCategoriesECSB != NumberOfCategoriesMWG) ||
	    					 (idMWG != idECSB) || 
	    					 (itemcountECSB != itemcountMWG) ) {
	    						System.out.println("Data between GetCategories ECSB and MWB failed, for index: " + randomIndex );
	    				}
    				}
    				
    			} catch (Exception e) {
    				e.printStackTrace();
    			}
    	 }
}