import json, sys, os, getopt

def main(argv):
  try:
    opts, args = getopt.getopt(argv,"hm:f:",["m=","f="])
    for opt, arg in opts:
      if opt == '-h':
        print ('get_circular_id.py -m <mwg_file> -f <force use a weekly ad circular id')
        sys.exit()
      elif opt in ("-m"):
        mwg_file = arg
      elif opt in ("-f"):   
        sys.stdout.write(arg)
        sys.exit()
    found=False            
    fmwg = open(mwg_file,"r", encoding='UTF-8')
    json_mwg = json.load(fmwg)
    for each_circular in json_mwg:
      if each_circular['Title'] == 'Weekly Ad':
        sys.stdout.write(str(each_circular['Id']))
        sys.exit()
        found=True
        break
    if not found: print ('FAIL: Did not find weekly ad')
    fmwg.close()
  except IOError:
    print ('Error: can\'t find files to read')
    sys.exit(3)
    
if __name__ == "__main__":
    main(sys.argv[1:])
