import java.util.Random;
import java.io.FileReader;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class CircularsCompare {

	public static void main(String[] args) {




		int seekIndex = 0;
				Random r = new Random();
				String idECSB = "";
				long idMWG = 0L;
				JSONParser parser = new JSONParser();
				JSONObject ECSBCircular = null;
				JSONObject MWGCircular = null;
				String ECSB_OUTPUT_FILE = "S:\\iss\\QA\\LISA\\Personalization\\Release\\WeeklyAds\\InputAndOutputFiles\\OutputResultsFiles\\ECSB\\CircularsFromECSB.txt";
				String MWG_OUTPUT_FILE = "S:\\iss\\QA\\LISA\\Personalization\\Release\\WeeklyAds\\InputAndOutputFiles\\OutputResultsFiles\\MWG\\getCircularsForStoreFromMWG.txt";

				/*
				 * The block of code gets the ECSB JSON for Category Items, validated
				 * the size and chooses a random block of information to be verified.
				 */
				try {
					//Object objECSB = parser.parse(new FileReader(ECSB_OUTPUT_FILE));
					Object objECSB = parser.parse(new FileReader(ECSB_OUTPUT_FILE));
					JSONObject jsonObjectECSB = (JSONObject) objECSB;
					JSONArray CircularsECSB = (JSONArray) jsonObjectECSB.get("Circulars");
					int randomIndex = r.nextInt(CircularsECSB.size());

					if (CircularsECSB != null && CircularsECSB.size() > 0) {
						ECSBCircular = (JSONObject) CircularsECSB.get(randomIndex);
						if (ECSBCircular != null) {
							idECSB = (String) ECSBCircular.get("Id");
						}
						/*
						 * The block of code gets the MWG JSON for Category Items,
						 * validated the size and finds the right JSON block of
						 * information to be verified.
						 */
						Object objMWG = parser.parse(new FileReader(MWG_OUTPUT_FILE));
						JSONArray jsonObjectMWG = (JSONArray) objMWG;

						if (jsonObjectMWG != null && jsonObjectMWG.size() > 0) {
							/*
							 * This piece of loop it to find the right set of data we
							 * want to get from My web grocer, as their sort order is
							 * different and keeps changing every time we them.
							 */
							for (int i = 0; i < CircularsECSB.size(); i++) {
								JSONObject tmpMWGItem = (JSONObject) jsonObjectMWG.get(i);
								idMWG = (long) tmpMWGItem.get("Id");
								long tmpidECSB = Long.parseLong(idECSB);

								if (tmpidECSB == idMWG) {
									seekIndex = i;
									break;
								}
							}
							// This is the JSON Block that needs to be verified.
							MWGCircular = (JSONObject) jsonObjectMWG.get(seekIndex);
						}
						/*
						 * Now we are ready to compare the data between ECSB and MWG
						 */
						

						if ((CircularsECSB.size() != jsonObjectMWG.size()) ||
							(!ECSBCircular.get("ImageFile").equals(MWGCircular.get("ImageFile"))) ||
							(!ECSBCircular.get("Thumbnail").equals(MWGCircular.get("Thumbnail"))) ||
							(!ECSBCircular.get("Title").equals(MWGCircular.get("Title")))) {
							System.out.println("false");
		                        //return false;
						}else {
							System.out.println("true");
		                    //return true;
		                }
					}
				} catch (Exception e) {
		                //return false;
					e.printStackTrace();
				}
	}
}
