
import java.util.Date;
import java.text.SimpleDateFormat;
public class testHarness {
	public static void main(String args[]) {
		/* 
		 * Format Date Example 
		 */
		/*
		// Instantiate a Date object 
		Date date = new Date(); 
		// display time and date using toString() 
		System.out.println(date.toString()); 
		Date dNow = new Date( ); 
		SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd hh.mm.ss a"); 
		System.out.println("Current Date: " + ft.format(dNow));
		 */
		 
		// String myJsonErr = "statusCode":400,"subStatusCode":100,"message":"Invalid banner name.";
		 Integer x = 400;
		 Integer y = 400;
		 if (x.toString().equals(y.toString()) ){
			 System.out.println("good");
		 
		 }
	}

}
