import json
f=open('S:\\iss\\QA\\LISA\\Personalization\\Release\\WeeklyAds\\InputAndOutputFiles\\OutputResultsFiles\\StoreUser\\Store Level_All Items Ranked_getAllCircularItemsFromMWG.txt', 'r')
fj=json.load(f,encoding='utf-8')

with open('C:\\Users\KON3285\\items.txt', 'w') as outfile:
  json.dump(fj, outfile)
f.close()
outfile.close()
