import http, urllib.request, sys, traceback, getopt
file_list = []

def main(argv):
  try:
    search_order = ''
    opts, args = getopt.getopt(argv,"ho:l:u:",["o=", "l=", "u="])
    for opt, arg in opts:
      if opt == '-h':
        print ('usuals_log_checks.py -o <searck_token> -l <log_location> \n ')
        sys.exit(1)
      elif opt ==  ("-o"):
        search_key = arg
      elif opt ==  ("-l"):
        log_location = arg
      elif opt ==  ("-u"):
        log_uri = arg
    if get_logs(log_location,log_uri):
      if open_logs(log_location,log_uri):
        if single_line_parser(search_key):
          pass
        else:
          print ('Parsing logs failed') 
    else:
      print ('Getting logs failed') 
  except (Exception): traceback.print_exc()

def get_logs(log_location,log_uri):
  try:
    opener = urllib.request.build_opener()
    urllib.request.install_opener(opener)
    request = urllib.request.Request(log_uri, data=None )
    request.add_header("Authorization"
                       , "Basic %s" % 'S09OMzI4NTpTdHJhbmQtNDk0Mg==')   
    request.get_method = lambda: 'GET'
    connection = opener.open(request)


    if connection.code == 200: #Check if we have 200 and then read the data
        data = connection.read()
        with open(log_location, 'w') as myFile:
            myFile.write(data.decode(encoding='UTF-8'))    
        myFile.close()
        return True
    else:
      return False
  except (Exception): traceback.print_exc()

def open_logs(log_location,log_uri):
  try:
    ems_formatter_json =''
    end_of_ems_formatter_json = True
    with open(log_location) as log_file:
      for each in log_file:
        file_list.append(each)
    return True
  except (Exception):
    traceback.print_exc()
    return False

def single_line_parser(search_key):
  try:
    for each in file_list:
      if search_key in each:
        print (each.rstrip('\n'))
    return True
  except (Exception):
    traceback.print_exc()
    return False

if __name__ == "__main__":
    main(sys.argv[1:])
