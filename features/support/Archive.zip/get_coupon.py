import json, sys, os, getopt

def main(argv):
  try:
    opts, args = getopt.getopt(argv,"hc:",["c="])
    for opt, arg in opts:
      if opt == '-h':
        print ('get_coupon.py -c <coupon_file>')
        sys.exit()
      elif opt in ("-c"):
        coupon_file = arg
      elif opt in ("-f"):   
        sys.stdout.write(arg)
        sys.exit()
    found=False            
    fcoupon = open(coupon_file,"r", encoding='UTF-8')
    json_coupon = json.load(fcoupon)
    if 'coupons' in json_coupon.keys():
      sys.stdout.write(json_coupon['coupons'][0]['id'])
      fcoupon.close()
    else:
      print ('Fail: unable to find coupon')
  except IOError:
    print (arg)
    print ('Fail: can\'t find files to read')
    sys.exit(3)
    
if __name__ == "__main__":
    main(sys.argv[1:])
