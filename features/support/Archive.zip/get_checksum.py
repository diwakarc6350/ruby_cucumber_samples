#!/usr/bin/env python
"""
Simple checksum calculator for QA to use with the Softcoin API in testing the
ECSB Coupons service.

DC, 11/20/2013, modified to include URL Encode

USAGE: get_checksum.py Kroger4230 (argument is concatination of retailer_name and site_id
       site_id=4230
       retailer_name=Kroger

       COUPON_IDS_BY_BANNER = Kroger4230

       COUPONS BY STORE = KrogerDIV|011,STORE|000024230
       
       COUPON_IDS_BY_CARD_AT_STORE  = "414640958889removableKrogerDIV|011,STORE|000024230"

       COUPONS_BY_IDS =   "1515414230" 
"""
import sys
import hashlib
import base64
import urllib.parse

# This is the private key for authoritation.
PRIVATE_KEY='ZCwUxSJ2pjNszeBK1g9S'

class ChecksumCalculator:
    """The chcecksum calculator - calculates checksums"""
    def __init__(self, private_key):
        self.private_key = private_key

    def get_checksum(self, args):
        """Calculate the checksum"""
        combined_data = ''.join(args) + self.private_key
        print ('Combined Data : ' + combined_data)
        combined_data = combined_data.encode('UTF-8')
        sha1 = hashlib.sha1(combined_data)
        digest = sha1.digest()
        encoded = base64.b64encode(digest)
        return encoded

if __name__ == '__main__':
    calculator = ChecksumCalculator(PRIVATE_KEY)
    #print (calculator.get_checksum(sys.argv[1:]))
    check_sum = calculator.get_checksum(sys.argv[1:])
    print ('Sha1 Checksum : ' + check_sum.decode('UTF-8'))
    print ('Sha1 Checksum URL Encoded : ' + urllib.parse.quote_plus(check_sum))
