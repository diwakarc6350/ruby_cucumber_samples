import java.io.FileReader;
import java.util.Random;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class CircularItemsForCircularPage {

	public static void main(String[] args) {
		
		int seekIndex=0;	
		Random r = new Random();	
		long idECSB = 0L; long idMWG = 0L;
		JSONParser parser = new JSONParser();
		JSONObject ECSBItem = null;
		JSONObject MWGItem = null;
		JSONArray ItemsECSB = null;
		JSONArray ItemsMWG = null;
				
		try {
		        /*
		         * The block of code gets the ECSB JSON for All Items for a page, validated the size
		         * and chooses a random block of information to be verified.
		         */
		        Object objECSB = parser.parse(new FileReader("S:\\iss\\QA\\LISA\\Personalization\\Release\\WeeklyAds\\InputAndOutputFiles\\OutputResultsFiles\\ECSB\\CircularItemsforCircularPageFromECSB.txt"));
		        JSONObject jsonObjectECSB = (JSONObject) objECSB;
		        ItemsECSB = (JSONArray) jsonObjectECSB.get("Items");
		        int randomIndex = r.nextInt(ItemsECSB.size());


		        if(ItemsECSB != null && ItemsECSB.size() > 0) 	{
		            ECSBItem = (JSONObject) ItemsECSB.get(randomIndex);
		            if(ECSBItem != null) 	{
		                idECSB = (long) ECSBItem.get("Id");
		        }

		        /*
		         * The block of code gets the MWG JSON for All Items for a page, validated the size
		         * and finds the right JSON block of information to be verified.
		        */	
		        Object objMWG = parser.parse(new FileReader("S:\\iss\\QA\\LISA\\Personalization\\Release\\WeeklyAds\\InputAndOutputFiles\\OutputResultsFiles\\MWG\\getAllCircularItemsForPageFromMWG.txt"));
		        JSONObject jsonObjectMWG = (JSONObject) objMWG;
		        ItemsMWG = (JSONArray) jsonObjectMWG.get("Items");

		        if(jsonObjectMWG != null && jsonObjectMWG.size() > 0) 	{
		                /* This piece of loop it to find the right set of data we want to get from
		                   My web grocer, as their sort order is different and keeps changing every time we them.*/
		                for ( int i=0;  i < ItemsECSB.size(); i++  ) {
		                    JSONObject tmpMWGItem = (JSONObject) ItemsMWG.get(i);
		                     idMWG = (long) tmpMWGItem.get("Id");
		                    if (idECSB == idMWG){
		                        seekIndex = i;
		                        break;
		                    }
		                }
		                //This is the JSON Block that needs to be verified.
		                MWGItem = (JSONObject) ItemsMWG.get(seekIndex);	
		        }

		        /*
		         * Now we are ready to compare the data between ECSB and MWG
		        */
		        
		       // System.out.println(ECSBItem.get("RawEndDate"));
		       // System.out.println(MWGItem.get("RawEndDate"));
		        
		        if ( (ECSBItem.size() != MWGItem.size()) || 
		             (ItemsECSB.size() != ItemsMWG.size()) ||
		             (!ECSBItem.get("Brand").equals(MWGItem.get("Brand"))) ||
		             (!ECSBItem.get("CategoryId").equals(MWGItem.get("CategoryId"))) ||
		             (!ECSBItem.get("CategoryName").equals(MWGItem.get("CategoryName"))) ||
		             (!ECSBItem.get("Description").equals(MWGItem.get("Description"))) ||
		             (!ECSBItem.get("DisplayEndDate").equals(MWGItem.get("DisplayEndDate"))) ||
		             (!ECSBItem.get("DisplayEndDateShort").equals(MWGItem.get("DisplayEndDateShort"))) ||
		             (!ECSBItem.get("EndDate").equals(MWGItem.get("EndDate"))) ||
		             (!ECSBItem.get("Id").equals(MWGItem.get("Id"))) ||
		             (!ECSBItem.get("ImageFile").equals(MWGItem.get("ImageFile"))) ||
		             (!ECSBItem.get("ItemType").equals(MWGItem.get("ItemType"))) ||
		             (!ECSBItem.get("PreviewStartDate").equals(MWGItem.get("PreviewStartDate"))) ||
		             (!ECSBItem.get("PriceString").equals(MWGItem.get("PriceString"))) ||
		             (!ECSBItem.get("RawEndDate").equals(MWGItem.get("RawEndDate"))) ||
		             (!ECSBItem.get("StartDate").equals(MWGItem.get("StartDate"))) ||
		             (!ECSBItem.get("ThumbnailFile").equals(MWGItem.get("ThumbnailFile"))) ||
		             (!ECSBItem.get("Title").equals(MWGItem.get("Title")))) {
		             //(!ECSBItem.get("Url").equals(MWGItem.get("Url")))  || 
		             //(!ECSBItem.get("UrlText").equals(MWGItem.get("UrlText")))
		                //testExec.setStateValue("testCaseStatus","Fail" );
		                //testExec.raiseEvent(TestEvent.EVENT_TRANSFAILED,"Test Results","Test Results FAILED");
		               System.out.print(false); System.out.print(seekIndex);
		        }
		        else {
		            // testExec.setStateValue("testCaseStatus","Pass" );
		        	   System.out.print(true);
		        }
		    }
		} catch (Exception e) {
		   // testExec.setStateValue("testCaseStatus","Fail" );
		   // testExec.raiseEvent(TestEvent.EVENT_TRANSFAILED,"Test Results","Test Results FAILED");
		    e.printStackTrace();
		}
	}

}
