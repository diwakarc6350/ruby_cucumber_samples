import json, sys, os, getopt

def main(argv):
  try:
    opts, args = getopt.getopt(argv,"hb:a:r:",["b=","a=","r="])
    for opt, arg in opts:
      if opt == '-h':
        print ('add_remove_coupon_checks.py -b <coupons_file_before_load> -a <coupons_file_after_load> -r <coupons_file_after_remove>')
        sys.exit()
      elif opt in ("-b"):
        coupons_file_before_load = arg
      elif opt in ("-a"):
        coupons_file_after_load = arg
      elif opt in ("-r"):
          coupons_file_after_remove = arg
    fcoupons_file_before_load = open(coupons_file_before_load,"r", encoding='UTF-8')
    fcoupons_file_after_load = open(coupons_file_after_load,"r", encoding='UTF-8')
    fcoupons_file_after_remove = open(coupons_file_after_remove,"r", encoding='UTF-8')
    
    json_coupons_file_before_load = json.load(fcoupons_file_before_load)
    json_coupons_file_after_load = json.load(fcoupons_file_after_load)
    json_coupons_file_after_remove = json.load(fcoupons_file_after_remove)

    bl = json_coupons_file_before_load['numberOfCoupons']
    al =json_coupons_file_after_load['numberOfCoupons']
    ar = json_coupons_file_after_remove['numberOfCoupons']

    if (al+1 == bl):
      if (al+1 == ar):
        print ('Pass: count match')
      else:
        print ('Fail: counts do not match')
    else:
      print ('Fail: counts do not match')
    
    print ('Total Coupons before Load : ' + str(bl))
    print ('Total Coupons after Load : ' + str(al))
    print ('Total Coupons after remove : ' + str(ar))

    
  except IOError:
    print (arg)
    print ('Fail: can\'t find files to read')
    sys.exit(3)
    
if __name__ == "__main__":
    main(sys.argv[1:])
