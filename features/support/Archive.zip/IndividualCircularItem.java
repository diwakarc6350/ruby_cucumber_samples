import java.io.FileReader;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class IndividualCircularItem {

	public static void main(String[] args) {
		
		JSONParser parser = new JSONParser();
		JSONObject ECSBItem = null;
		JSONObject MWGItem = null;
		
		 String ECSB_OUTPUT_FILE = "S:\\iss\\QA\\LISA\\Personalization\\Release\\WeeklyAds\\InputAndOutputFiles\\OutputResultsFiles\\ECSB\\individualCircularItemFromECSB.txt";
		 String MWG_OUTPUT_FILE = "S:\\iss\\QA\\LISA\\Personalization\\Release\\WeeklyAds\\InputAndOutputFiles\\OutputResultsFiles\\MWG\\getCircularItemDetailsMWG.txt";

		/*
		 * The block of code gets the ECSB JSON for Circular Page.
		 */
		try {
			Object objECSB = parser.parse(new FileReader(ECSB_OUTPUT_FILE));
			JSONObject jsonObjectECSB = (JSONObject) objECSB;
			ECSBItem = (JSONObject) jsonObjectECSB.get("Item");
			if (ECSBItem != null ) {
				/*
				 * The block of code gets the MWG JSON for Circular Item,
				 * validated the size and finds the right JSON block of
				 * information to be verified.
				 */
				Object objMWG = parser.parse(new FileReader(MWG_OUTPUT_FILE));
				MWGItem = (JSONObject) objMWG;
		
				/*
				 * Now we are ready to compare the data between ECSB and MWG
				 */
				
				if ( (ECSBItem.size() != MWGItem.size()) || 
		             (!ECSBItem.get("Brand").equals(MWGItem.get("Brand"))) ||
		             (!ECSBItem.get("CategoryId").equals(MWGItem.get("CategoryId"))) ||
		             (!ECSBItem.get("CategoryName").equals(MWGItem.get("CategoryName"))) ||
		             (!ECSBItem.get("Description").equals(MWGItem.get("Description"))) ||
		             (!ECSBItem.get("DisplayEndDate").equals(MWGItem.get("DisplayEndDate"))) ||
		             (!ECSBItem.get("DisplayEndDateShort").equals(MWGItem.get("DisplayEndDateShort"))) ||
		             (!ECSBItem.get("EndDate").equals(MWGItem.get("EndDate"))) ||
		             (!ECSBItem.get("Id").equals(MWGItem.get("Id"))) ||
		             (!ECSBItem.get("ImageFile").equals(MWGItem.get("ImageFile"))) ||
		             (!ECSBItem.get("ItemType").equals(MWGItem.get("ItemType"))) ||
		             (!ECSBItem.get("PreviewStartDate").equals(MWGItem.get("PreviewStartDate"))) ||
		             (!ECSBItem.get("PriceString").equals(MWGItem.get("PriceString"))) ||
		             (!ECSBItem.get("RawEndDate").equals(MWGItem.get("RawEndDate"))) ||
		             (!ECSBItem.get("StartDate").equals(MWGItem.get("StartDate"))) ||
		             (!ECSBItem.get("ThumbnailFile").equals(MWGItem.get("ThumbnailFile"))) ||
		             (!ECSBItem.get("Title").equals(MWGItem.get("Title")))) {
		             //(!ECSBItem.get("Url").equals(MWGItem.get("Url")))  || 
		             //(!ECSBItem.get("UrlText").equals(MWGItem.get("UrlText")))
							System.out.println("Fail");	
				}
				else {
					System.out.println("Pass");	
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
