import java.io.FileReader;
import java.util.Random;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


public class CircularPagesCompare {
	public static void main(String[] args) {

		
		Random r = new Random();
		
		JSONParser parser = new JSONParser();
		JSONObject ECSBPage = null;
		JSONObject MWGPage = null;
		
		 String ECSB_OUTPUT_FILE = "S:\\iss\\QA\\LISA\\Personalization\\Release\\WeeklyAds\\InputAndOutputFiles\\OutputResultsFiles\\ECSB\\CircularPagesFromECSB.txt";
		 String MWG_OUTPUT_FILE = "S:\\iss\\QA\\LISA\\Personalization\\Release\\WeeklyAds\\InputAndOutputFiles\\OutputResultsFiles\\MWG\\getAllPagesForCircularFromMWG.txt";

		/*
		 * The block of code gets the ECSB JSON for Category Items, validated
		 * the size and chooses a random block of information to be verified.
		 */
		try {
			Object objECSB = parser.parse(new FileReader(ECSB_OUTPUT_FILE));
			JSONObject jsonObjectECSB = (JSONObject) objECSB;
			JSONArray PagesECSB = (JSONArray) jsonObjectECSB.get("Pages");
			int randomIndex = r.nextInt(PagesECSB.size());

			if (PagesECSB != null && PagesECSB.size() > 0) {
				ECSBPage = (JSONObject) PagesECSB.get(randomIndex);
				/*
				 * The block of code gets the MWG JSON for Category Items,
				 * validated the size and finds the right JSON block of
				 * information to be verified.
				 */
				Object objMWG = parser.parse(new FileReader(MWG_OUTPUT_FILE));
				JSONObject jsonObjectMWG = (JSONObject) objECSB;
				JSONArray PagesMWG = (JSONArray) jsonObjectECSB.get("Pages");
				
				if (objMWG != null && jsonObjectMWG.size() > 0) {
					
					// This is the JSON Block that needs to be verified.
					MWGPage = (JSONObject) PagesMWG.get(randomIndex);
				}
				/*
				 * Now we are ready to compare the data between ECSB and MWG
				 */
				//System.out.println(ECSBPage.get("Number").getClass().toString());
				//System.out.println(MWGPage.get("Number").getClass().toString());
				if ((PagesECSB.size() != PagesMWG.size()) ||
					(!ECSBPage.get("Id").equals(MWGPage.get("Id"))) ||
					(!ECSBPage.get("ImageFile").equals(MWGPage.get("ImageFile"))) ||
					(!ECSBPage.get("ImageHeight").equals(MWGPage.get("ImageHeight"))) ||
					(!ECSBPage.get("ImageWidth").equals(MWGPage.get("ImageWidth"))) ||
					(!ECSBPage.get("Number").equals(MWGPage.get("Number")))){
					//(!ECSBPage.get("Title").equals(MWGPage.get("Title")))) {
					System.out.println("Data between GetCategories ECSB and MWB failed, for index: "
									+ randomIndex);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
