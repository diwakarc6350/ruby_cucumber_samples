import json, sys, os, getopt, traceback, http, urllib.request

def main(argv):
  usual_objects = []
  sorted_usual_objects = []
  service_type = ''
  try:
    opts, args = getopt.getopt(argv,"hd:e:t:",["d=","e="])
    for opt, arg in opts:
      if opt == '-h':
        print ('usuals_checks.py -d <dc2_file> -e <ecsb_file> -t <service_type>')
        print ('Valid values for <service_type> Upcs|Usuals|Cfic')
        sys.exit()
      elif opt in ("-d"):
        dc2_file = arg
      elif opt in ("-e"):
        ecsb_file = arg
      elif opt in ("-t"):
        #service_type will be set to Upcs|Usuals|Cfic
        service_type = arg
        print ('Service : ' + str(service_type))

    class switch(object):
      value = None
      def __new__(class_, value):
        class_.value = value
        return True

    def case(*args):
      return any((arg == switch.value for arg in args))
    
    class Usual:
            def __init__(self, GTIN, storeDesignDeptRank,
                         storeDesignDeptCode,subCommRank,
                         subCommCode, productRankOverall,
                         productRankSubComm):
                self.GTIN = GTIN
                self.storeDesignDeptRank = storeDesignDeptRank
                self.storeDesignDeptCode = storeDesignDeptCode
                self.subCommRank = subCommRank
                self.subCommCode = subCommCode
                self.productRankOverall = productRankOverall
                self.productRankSubComm = productRankSubComm
            def __repr__(self):
                return repr((self.GTIN, self.storeDesignDeptRank,
                             self.storeDesignDeptCode, self.subCommRank,
                             self.subCommCode, self.productRankOverall,
                             self.productRankSubComm))
            def get_upc(self):
                return self.GTIN
            def get_storeDesignDeptRank(self):
                return self.storeDesignDeptRank
            def get_storeDesignDeptCode(self):
                return self.storeDesignDeptCode
            def get_subCommRank(self):
                return self.subCommRank
            def get_subCommCode(self):
                return self.subCommCode
            def get_productRankOverall(self):
                return self.productRankOverall
            def get_productRankSubComm(self):
                return self.productRankSubComm
              
    fdc_2 = open(dc2_file,"r")
    fecsb = open(ecsb_file,"r")

    json_dc_2 = json.load(fdc_2)
    json_ecsb = json.load(fecsb)
    
    items = json_dc_2['items']
    
    for each in items:
      usual_objects.append(
        Usual(int(each['productGTIN']),
              int(each['storeDesignDeptRank']),
              int(each['storeDesignDeptCode']),
              int(each['subCommRank']),
              int(each['subCommCode']),
              int(each['productRankOverall']),
              int(each['productRankSubComm'])))
    
    sorted_usual_objects = sorted(usual_objects, key=lambda Usual:
                                   (Usual.storeDesignDeptRank,
                                    Usual.subCommRank,
                                    Usual.productRankSubComm))
    print ("Sorted Usuals Object : " + str(sorted_usual_objects) + '\n')

    def check_upcs():
        #sort and compare the data between dc2 and ecsb for UPCS
        i=-1
        for each_upc in json_ecsb['upcs']:
          i += 1
          print ('dc2_upc: %013d ecsb_upc: %s'%(sorted_usual_objects[i].get_upc(),each_upc))
          if not int(each_upc) == sorted_usual_objects[i].get_upc():
            print ('FAIL UPCs does not match at index: ' + str(i))
            return False
          else:
            return True
          
    
    while switch(service_type):
      if case('Upcs'):
        check_upcs
        break
      
      if case('Usuals'):
        #sort and compare the data between dc2 and ecsb for USUALS
        i=-1
        for each_item in json_ecsb['items']:
          i += 1          
          print('ecsb_item '+ str(each_item))
          print('dc2_sorted ' + str(sorted_usual_objects[i]) + '\n')
          if not int(each_item['productGTIN']) == sorted_usual_objects[i].get_upc() :
            print ('FAIL productGTIN does not match at index: ' + str(i))
          if not int(each_item['productRankSubComm']) == sorted_usual_objects[i].get_productRankSubComm() :
            print ('FAIL productRankSubComm does not match at index: ' + str(i))
          if not int(each_item['productRankOverall']) == sorted_usual_objects[i].get_productRankOverall() :
            print ('FAIL productRankOverall does not match at index: ' + str(i))
          if not int(each_item['storeDesignDeptCode']) == sorted_usual_objects[i].get_storeDesignDeptCode() :
            print ('FAIL storeDesignDeptCode does not match at index: ' + str(i))
          if not int(each_item['storeDesignDeptRank']) == sorted_usual_objects[i].get_storeDesignDeptRank() :
            print ('FAIL storeDesignDeptRank does not match at index: ' + str(i))
          if not int(each_item['subCommCode']) == sorted_usual_objects[i].get_subCommCode() :
            print ('FAIL subCommCode does not match at index: ' + str(i))
          if not int(each_item['subCommRank']) == sorted_usual_objects[i].get_subCommRank() :
            print ('FAIL subCommRank does not match at index: ' + str(i))
        break
        
      if case('Cfic'):
        #sort and compare the data between dc2 and ecsb for CFIC
        check_upcs
        for each_item in json_ecsb['items']:
          item_info = ''
          item_info_url = 'https://u060dcad81.kroger.com:9446/ic-v1.6/rest/items/%s'
          opener = urllib.request.build_opener()
          urllib.request.install_opener(opener)
          request = urllib.request.Request(item_info_url%each_item['upc'], data=None )
          request.add_header("Accept",'application/json')
          request.get_method = lambda: 'GET'
          connection = opener.open(request)
          if connection.code == 200:
            data = connection.read()
            items_data = json.loads(data.decode(encoding='UTF-8'))
            print('Item Info from ic-v1 :' + str(items_data['items'][0]))
            print('Item Info from ecsb  :' + str(each_item) + '\n')
            if not items_data['items'][0] == each_item:
              print('FAIL Item information dont match')
        break
    
  except (Exception): traceback.print_exc()

if __name__ == "__main__":
  main(sys.argv[1:])
