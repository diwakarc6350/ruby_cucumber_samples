require 'nj_salesforce'

# puts NjSalesforce::Opportunity.first

puts NjSalesforce::ProductConfiguration.first

# NjSalesforce::Proposal.connection.create(NjSalesforce::Proposal.object_name, Apttus_Proposal__Account__c: '001c000000iBjHk',
#                                                                                   Fuel_Rate_to_Use__c: 'Monthly Variable Rate',
#                                                                                   Apttus_Proposal__Proposal_Name__c: 'My Test Proposal',
#                                                                                   Apttus_Proposal__Opportunity__c: '006c000000Cld0w',
#                                                                                   Apttus_Proposal__Primary_Contact__c: '003c000000Zt9f9',
#                                                                                   Legal_Entity__c: 'a5jc00000009IUm',
#                                                                                   Delivery_Email__c: 'qatest1@netjets.com',
#                                                                                   Owner_Is__c: 'New',
#                                                                                   Method_of_Delivery__c: 'email')