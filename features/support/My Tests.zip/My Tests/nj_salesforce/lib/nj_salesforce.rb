require "nj_salesforce/version"
require 'nj_salesforce/patches/array'
require 'nj_salesforce/patches/string'
require 'nj_salesforce/models/base'
Dir["#{File.dirname(__FILE__)}/nj_salesforce/models/*.*"]. each {|model| require model}

module NjSalesforce
end
