module NjSalesforce
  class AirportCities < NjSalesforce::Base
    self.object_name = 'Airport_Cities__c'

    def self.city_information
      connection.query("  select State__c,
                          Country__c,
                          Name
                          from #{self.object_name}")
          .to_a
          .map { |obj| obj.to_h }
          .each { |obj| obj.delete('attributes') }
    end

  end
end