module NjSalesforce
  class PaymentEntry < NjSalesforce::Base
    self.object_name = 'Payment_Information__c'
  end
end