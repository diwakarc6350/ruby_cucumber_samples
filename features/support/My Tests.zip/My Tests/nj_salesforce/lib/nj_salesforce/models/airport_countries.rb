module NjSalesforce
  class AirportCountries < NjSalesforce::Base
    self.object_name = 'Airport_Countries__c'

    def self.country_information
      connection.query(" select Name
                         from #{self.object_name}")
          .to_a
          .map { |obj| obj.to_h }
          .each { |obj| obj.delete('attributes') }
    end

  end
end