module NjSalesforce
  class Agreement < NjSalesforce::Base
    self.object_name = 'Apttus__APTS_Agreement__c'

    def self.agreement_information
      connection.query("select Id, Name, Apttus__Status_Category__c, Apttus__Status__c, Apttus_Approval__Approval_Status__c,
                        Funding_State__c, Signing_State__c, CreatedDate
                        from #{self.object_name}")
          .to_a
          .map { |obj| obj.to_h }
          .each { |obj| obj.delete('attributes') }
    end



    def self.agreement_documents(agreement_id)
      connection.query("Select Id, (select Id, Name from Attachments) from #{self.object_name} WHERE Id = '#{agreement_id}'")
          .first['Attachments']
          .to_a
          .map { |obj| obj.to_h }
          .each { |obj| obj.delete('attributes') }
    end

  end
end