module NjSalesforce
  class InterchangeRate < NjSalesforce::Base
    self.object_name = 'Interchange_Rate__c'

    def self.interchange_rate_data
      connection.query("select Interchange_ID__c,
                        Name,
                        Rate_Type_ID__r.Rate_Type_Id__c,
                        Interchange_Rate__c,
                        From_Aircraft_Type__r.Name,
                        To_Aircraft_Type__r.Name,
                        Effective_Month__c
                        from #{self.object_name}")
      .to_a
      .map { |obj| obj.to_h }
      .each { |obj| obj.delete('attributes') }
    end

  end
end