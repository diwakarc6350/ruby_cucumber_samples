module NjSalesforce
  class Profile < NjSalesforce::Base
    self.object_name = 'Profile'

  end
end