module NjSalesforce
  class Template < NjSalesforce::Base
    self.object_name = 'Apttus__APTS_Template__c'
  end
end