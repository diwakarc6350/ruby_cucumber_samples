require 'restforce'

module NjSalesforce
  class Base
    class << self
      attr_accessor :object_name

      def connection(reset=false)
        if reset
          @connection = connect_to_salesforce
        else
          if @connection
            return @connection
          else
            @connection = connect_to_salesforce
          end
        end
      end

      def field_names
        connection.describe(self.object_name)['fields'].map(&:name)
      end

      def field_labels
        connection.describe(self.object_name)['fields'].map(&:label)
      end

      def describe_layouts
        connection.describe_layouts(self.object_name)
      end

      def all
        connection.query("select #{self.field_names.to_clean_string} from #{self.object_name} order by CreatedDate desc").to_a
      end

      def all_collection
        connection.query("select #{self.field_names.to_clean_string} from #{self.object_name} order by CreatedDate desc")
      end

      def first
        connection.query("select #{self.field_names.to_clean_string} from #{self.object_name} order by CreatedDate desc")
            .first.to_h
      end

      def create(opts)
        connection.create(self.object_name, opts)
      end

      def describe
        connection.describe(self.object_name)
      end

      def find(object_id)
        connection.find(self.object_name, object_id)
      end

      def new
        self.describe['urls']['uiNewRecord']
      end

      def home
        self.new.chomp('/e') << '/o'
      end


      def where(where_clauses)
        clauses= []
        where_clauses.each_pair { |key, value| clauses << "#{key} = '#{value}'" }
        clauses = clauses.join(' and ')
        connection.query("select #{self.field_names.to_clean_string} from #{self.object_name} where #{clauses}").to_a
      end

      def method_missing(method, *args, &block)
        if method.to_s =~ /^find_by_(.*)$/
          connection.query("select #{self.field_names.to_clean_string} from #{self.object_name} where #{$1} = '#{args.first}'").first
        else
          super
        end
      end

      def edit(object)
        self.describe['urls']['uiEditTemplate']
            .gsub('{ID}', object.to_s)
      end

      def delete(object_id)
        connection.destroy(self.object_name, object_id)
      end


      def to_h
        Hash[self.field_labels.zip self.field_names]
      end


      private
      def connect_to_salesforce
        case ENV['ENVIRONMENT'].to_sym
          when :gcmdev
            Restforce.new :username => 'qatestuser@netjetsus.com.gcmdev',
                          :password => 'Winter15',
                          :security_token => 'oQM58AIcomVkUGACvNSi5rDBh',
                          :client_id => '3MVG9Gmy2zmPB01rdX_Qk0kAMpMOfXCHrG3m995wDUMpc_.Tmva1ltHNUdGGwktlKxY907eUJrHpFjxJWm8.Y',
                          :client_secret => '7766936512381988683',
                          :host => 'test.salesforce.com',
                          :api_version => "28.0"
          when :gcmqa
            Restforce.new :username => 'qatestuser@netjetsus.com.gcmqa',
                          :password => 'Winter15',
                          :security_token => 'KyMt8Amr2mFmKZJwGEVYEnTN',
                          :client_id => '3MVG9sLbBxQYwWquHXNJWg4HpAd9QzGDzSWHMuQK_Zi8LZuIkpbgwLKt8A2DTyreX5zmmS937OHIBnb4gva1W',
                          :client_secret => '1010539601819403420',
                          :host => 'test.salesforce.com',
                          :api_version => "28.0"

          when :gcmdemo
            Restforce.new :username => 'qatestuser@netjetsus.com.gcmdemo',
                          :password => 'Winter15',
                          :security_token => 'gx3zTVwD9niJjxavDnftpZxpM',
                          :client_id => '3MVG9MHOv_bskkhT0hEodkKu5TSqnzsyspaG13y89gUHAMkJxGs2uNEg4mZBryK00zAOrHmRc1mzduefZDrHM',
                          :client_secret => '8334807544342384622',
                          :host => 'test.salesforce.com',
                          :api_version => "28.0"
          else
            puts "Invalid environment #{ENV['ENVIRONMENT'].to_sym} set, please check"
        end
      end
    end
  end
end