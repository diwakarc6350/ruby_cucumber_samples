module NjSalesforce
  class PaymentInformation < NjSalesforce::Base
    self.object_name = 'Payment_Information__c'
  end
end