module NjSalesforce
  class ProposalLineItem < NjSalesforce::Base
    self.object_name = 'Apttus_Proposal__Proposal_Line_Item__c'

  end
end