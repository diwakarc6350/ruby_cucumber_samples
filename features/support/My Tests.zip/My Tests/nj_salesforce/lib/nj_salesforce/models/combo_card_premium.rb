module NjSalesforce
  class ComboCardPremium < NjSalesforce::Base
    self.object_name = 'Combo_Card_Premium__c'

    def self.waiver_amount(aircraft_1, aircraft_2)
      aircraft_1_record = NjSalesforce::AircraftList.all.find {|aircraft| aircraft['Name'] == aircraft_1}
      aircraft_2_record = NjSalesforce::AircraftList.all.find {|aircraft| aircraft['Name'] == aircraft_2}
      premiums_for_aircraft = self.all.select{|prem| prem['Aircraft_1_Cabin_Class__c'] == aircraft_1_record['Cabin_Class__c'] && prem['Aircraft_2_Cabin_Class__c'] ==  aircraft_2_record['Cabin_Class__c']}
      premiums_for_aircraft.sort_by { |prem| Date.strptime(prem['Effective_Date__c'], '%Y-%m-%d') }.reverse.find { |prem| Date.strptime(prem['Effective_Date__c'], '%Y-%m-%d') <= Date.today }
    end

  end
end