module NjSalesforce
  class Proposal < NjSalesforce::Base
    self.object_name = 'Apttus_Proposal__Proposal__c'

    def self.proposal_information
      connection.query("Select (select id from attachments) , Id, Name, Record_Type_Name__c, RecordTypeId,
                        Apttus_Proposal__Approval_Stage__c from #{self.object_name} ")
          .to_a
          .map { |obj| obj.to_h }
          .each { |obj| obj.delete('attributes') }
    end

    def self.proposal_documents(proposal_id)
      connection.query("Select Id, (select Id, Name from Attachments) from #{self.object_name} WHERE Id = '#{proposal_id}'")
          .first['Attachments']
          .to_a
          .map { |obj| obj.to_h }
          .each { |obj| obj.delete('attributes') }

    end

  end
end