module NjSalesforce
  class AircraftList < NjSalesforce::Base
    self.object_name = 'Aircraft_List__c'

    def self.aircraft_list_data
      connection.query("select Aircraft_Type_Cross_Ref_Id__c,
                      Cabin_Class__c,
                      Cabin_Class_Ranking__c,
                      Name,
                      Aircraft_Type_Ranking__c,
                      Active__c
                      from #{self.object_name}")
      .to_a
      .map { |obj| obj.to_h }
      .each { |obj| obj.delete('attributes') }
    end

    def self.cabin_class_rankings
      connection.query("select Name,Cabin_Class__c from #{self.object_name}").to_a
    end

  end
end