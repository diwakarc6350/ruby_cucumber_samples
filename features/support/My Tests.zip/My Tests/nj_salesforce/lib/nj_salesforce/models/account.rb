module NjSalesforce
  class Account < NjSalesforce::Base
    self.object_name = 'Account'
  end
end