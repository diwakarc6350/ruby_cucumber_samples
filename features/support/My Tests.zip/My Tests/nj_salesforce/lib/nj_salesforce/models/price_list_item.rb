module NjSalesforce
  class PriceListItem < NjSalesforce::Base
    self.object_name = 'Apttus_Config2__PriceListItem__c'
  end
end