module NjSalesforce
  class PeakPeriodList < NjSalesforce::Base
    self.object_name = 'Peak_Period_List__c'

    def self.peak_period_list_information
      connection.query("select Company__c,
                        Effective_Date__c,
                        Inactive_Date__c,
                        PPD_List_Id__c,
                        Name,
                        Id
                        from #{self.object_name}")
          .to_a
          .map { |obj| obj.to_h }
          .each { |obj| obj.delete('attributes') }
    end

  end
end