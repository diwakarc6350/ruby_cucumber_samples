module NjSalesforce
  class AirportStates < NjSalesforce::Base
    self.object_name = 'Airport_States__c'

    def self.state_information
      connection.query(" select Country__c,
                         Name
                         from #{self.object_name}")
          .to_a
          .map { |obj| obj.to_h }
          .each { |obj| obj.delete('attributes') }
    end

  end
end