module NjSalesforce
  class Contact < NjSalesforce::Base
    self.object_name = 'contact'

  end
end