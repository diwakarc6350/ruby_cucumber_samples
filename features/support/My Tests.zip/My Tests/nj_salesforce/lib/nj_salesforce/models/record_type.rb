module NjSalesforce
  class RecordType < NjSalesforce::Base
    self.object_name = 'RecordType'

  end
end
