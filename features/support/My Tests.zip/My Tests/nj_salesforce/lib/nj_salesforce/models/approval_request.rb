module NjSalesforce
  class ApprovalRequest < NjSalesforce::Base
    self.object_name = 'Apttus_Approval__Approval_Request__c'
  end
end