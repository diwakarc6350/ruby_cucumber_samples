module NjSalesforce
  class FuelInformation < NjSalesforce::Base
    self.object_name = 'Fuel_Rate__c'

    def self.fuel_data
      connection.query("select Program__c,
                      Aircraft_Fuel_Rate_ID__c,
                      Aircraft_List__c,
                      Effective_Date__c,
                      Fuel_Type__c,
                      Time_Period_Type__c,
                      Commercial_Status__c,
                      Variable_Rate__c,
                      Fuel_Rate__c
                      from #{self.object_name}")
          .to_a
          .map { |obj| obj.to_h }
          .map { |obj| obj['Aircraft_List__c'] = self.connection.find('Aircraft_List__c', obj['Aircraft_List__c']).Aircraft_Type_Cross_Ref_Id__c; obj}
          .each { |obj| obj.delete('attributes') }
    end

  end
end