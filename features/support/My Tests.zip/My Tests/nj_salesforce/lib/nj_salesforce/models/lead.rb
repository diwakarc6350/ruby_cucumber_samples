module NjSalesforce
  class Lead < NjSalesforce::Base
    self.object_name = 'Lead'
  end
end