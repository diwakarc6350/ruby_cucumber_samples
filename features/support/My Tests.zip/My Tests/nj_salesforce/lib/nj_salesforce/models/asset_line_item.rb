module NjSalesforce
  class AssetLineItem < NjSalesforce::Base
    self.object_name = 'Apttus_Config2__AssetLineItem__c'
  end
end