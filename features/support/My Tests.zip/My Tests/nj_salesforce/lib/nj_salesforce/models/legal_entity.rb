module NjSalesforce
  class LegalEntity < NjSalesforce::Base
    self.object_name = 'Legal_Entity__c'
  end
end