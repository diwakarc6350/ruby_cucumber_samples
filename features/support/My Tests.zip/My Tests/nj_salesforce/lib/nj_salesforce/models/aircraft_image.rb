module NjSalesforce
  class AircraftImage < NjSalesforce::Base
    self.object_name = 'CS_Product_Image__c'
  end
end