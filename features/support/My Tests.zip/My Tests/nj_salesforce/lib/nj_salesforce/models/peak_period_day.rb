module NjSalesforce
  class PeakPeriodDay < NjSalesforce::Base
    self.object_name = 'Peak_Period_Day__c'

    def self.peak_period_day_information
      connection.query("select Date__c,
                        Peak_Day_Id__c,
                        Peak_Period_List__c,
                        Name
                        from #{self.object_name}")
          .to_a
          .map { |obj| obj.to_h }
          .each { |obj| obj.delete('attributes') }
    end

    def self.cabin_class_rankings
      connection.query("select Name,Cabin_Class__c from #{self.object_name}").to_a
    end

  end
end