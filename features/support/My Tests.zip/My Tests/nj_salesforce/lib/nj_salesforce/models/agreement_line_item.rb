module NjSalesforce
  class AgreementLineItem < NjSalesforce::Base
    self.object_name = 'Apttus__AgreementLineItem__c'
  end
end