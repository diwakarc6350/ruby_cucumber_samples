module NjSalesforce
  class InterchangeRateType < NjSalesforce::Base
    self.object_name = 'Interchange_Rate_Type__c'

    def self.interchange_rate_type_data
      connection.query("select Name, Effective_Date__c, From__c, Inactive_Date__c, Rate_Type_Id__c, To_Program_Name__c
                      from #{self.object_name}")
      .to_a
      .map { |obj| obj.to_h }
      .each { |obj| obj.delete('attributes') }
    end

  end
end