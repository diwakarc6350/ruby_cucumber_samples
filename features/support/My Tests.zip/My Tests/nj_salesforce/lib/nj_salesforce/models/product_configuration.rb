module NjSalesforce
  class ProductConfiguration < NjSalesforce::Base
    self.object_name = 'Apttus_Config2__ProductConfiguration__c'

  end
end