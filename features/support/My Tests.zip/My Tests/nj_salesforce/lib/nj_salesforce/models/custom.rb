module NjSalesforce
  class CustomSetting < NjSalesforce::Base
    def self.card_number
      self.object_name = 'CS_CardNumber__c'
      self.first['Card_Number__c']
    end

    def self.activation_emails
      self.object_name = 'CS_AgreementActivationEmail__c'
      self.all
    end

  end
end