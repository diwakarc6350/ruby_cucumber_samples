module NjSalesforce
  class Opportunity < NjSalesforce::Base
    self.object_name = 'Opportunity'

  end
end