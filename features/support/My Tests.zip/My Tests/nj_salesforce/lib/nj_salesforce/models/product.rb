module NjSalesforce
  class Product < NjSalesforce::Base
    self.object_name = 'Product2'

    def self.product_information
      connection.query("select Id, Accounting_Company__c, Program__c, Name, Card_Type__c
                        from #{self.object_name}")
      .to_a
      .map { |obj| obj.to_h }
      .each { |obj| obj.delete('attributes') }
    end

  end
end