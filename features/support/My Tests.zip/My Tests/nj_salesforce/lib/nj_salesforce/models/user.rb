module NjSalesforce
  class User < NjSalesforce::Base
    self.object_name = 'User'

  end
end