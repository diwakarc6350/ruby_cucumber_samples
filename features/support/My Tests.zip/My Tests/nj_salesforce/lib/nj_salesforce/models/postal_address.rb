module NjSalesforce
  class PostalAddress < NjSalesforce::Base
    self.object_name = 'Postal_Address__c'

  end
end