module NjSalesforce
  class Airports < NjSalesforce::Base
    self.object_name = 'Airports__c'

    def self.airport_information
      connection.query( "select Airport_City__c,
                          Airport_Country__c,
                          Airport_Id__c,
                          Airport_State__c,
                          Name
                          from #{self.object_name}")
          .to_a
          .map { |obj| obj.to_h }
          .each { |obj| obj.delete('attributes') }
    end

  end
end