module NjSalesforce
  class AttachmentNotes < NjSalesforce::Base
    self.object_name = 'Attachment'

    def self.download(id, save_in = '')
      begin
        attachment = connection.query("select Id, Name, Body from Attachment where Id = '#{id}'")
                         .first
        File.open(save_in << '/' << attachment.Name, 'wb') do |f|
          f.write(attachment.Body)
          f.close
        end
        return attachment.Name
      rescue => download_exception
        raise "Unexpected error in downloading...#{download_exception}"
      end
    end
  end
end