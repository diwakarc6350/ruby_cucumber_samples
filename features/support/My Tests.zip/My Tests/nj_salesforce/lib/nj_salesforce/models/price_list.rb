module NjSalesforce
  class PriceList < NjSalesforce::Base
    self.object_name = 'Apttus_Config2__PriceList__c'
  end
end