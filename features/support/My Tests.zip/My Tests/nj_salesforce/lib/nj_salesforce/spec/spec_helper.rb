require 'rspec'
require 'patches/array'
