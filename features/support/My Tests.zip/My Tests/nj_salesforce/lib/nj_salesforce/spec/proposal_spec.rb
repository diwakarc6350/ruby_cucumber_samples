require 'spec_helper'
require 'models/base'
require 'models/proposal'
require 'models/attachment'
require 'models/agreement'
require 'models/approval_request'
require 'models/payment_entry'

describe 'proposal' do
  it 'gets the proposal information' do
    #set the environment to gcm qa
    ENV['ENVIRONMENT'] = 'gcmqa'
    # attachments = NjSalesforce::Proposal.proposal_documents('a2xc0000001LRNs')
    # puts attachments
    # NjSalesforce::AttachmentNotes.download(attachments.first['Id'], "C:\\Users\\dchandrasekaran\\agreement_documents")

    #puts NjSalesforce::Proposal.agreements_for_proposal('a2xc0000001LSL5AAO')
    #puts NjSalesforce::Proposal.first

    # puts NjSalesforce::Agreement.where({Apttus_QPComply__RelatedProposalId__c: 'a2xc0000001LSL5AAO'}).to_a
    #          .map { |obj| obj.to_h }
    #          .each { |obj| obj.delete('attributes') }

=begin
    puts NjSalesforce::ApprovalRequest.where({Apttus_Approval__Related_Agreement__c: 'a1tc0000002mraGAAQ'}).to_a
             .map { |obj| obj.to_h }
             .each { |obj| obj.delete('attributes') }
=end

    puts NjSalesforce::PaymentEntry.where({Agreement__c: 'a1tc0000002mmSnAAI'}).to_a


  end
end


