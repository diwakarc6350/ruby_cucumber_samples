require 'spec/spec_helper'
require 'models/base'
require 'models/agreement'
require 'models/agreement_line_item'
require 'models/custom'


describe 'account' do
  it 'gets the account info' do
    #set the environment to gcm qa
    ENV['ENVIRONMENT'] = 'gcmdemo'
    # #accounts = NjSalesforce::Account.all.select { |x| x['Name']=='Vedic Investments' }
    # accounts = NjSalesforce::Account.where({Name: 'Vedic Investments'})
    # contacts = NjSalesforce::Contact.where({LastName: 'Sastri'})
    # #opportunities = NjSalesforce::Opportunity.where({Name: 'Vedic Investments(Sastri)'})
    # opportunities = NjSalesforce::Opportunity.where({Name: 'Vedic Investments(Sastri)', Owner_Is__c: 'Existing'})
    # # opportunities = NjSalesforce::Opportunity.all
    # #                     # .connection.query("select Account.Id, Account.Name, Id, Name from Opportunity where Account.Name='Vedic Investments'")
    # #                     # .to_a
    # #                     # .map { |obj| obj.to_h }
    # #                     # .each { |obj| obj.delete('attributes') }

    #puts NjSalesforce::CustomSetting.activation_emails

    puts NjSalesforce::Agreement.describe
  end
end
