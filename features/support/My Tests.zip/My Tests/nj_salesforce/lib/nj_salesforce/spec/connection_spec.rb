require 'spec/spec_helper'
require 'models/base'

describe 'connection' do
  it 'connects to gcm qa' do
    #set the environment to gcm qa
    ENV['ENVIRONMENT'] = 'gcmqa'
    user_info = NjSalesforce::Base.connection(reset=true).user_info.to_h
    expect(user_info['username']).to eq('qatestuser@netjetsus.com.gcmqa')
  end

  it 'connects to gcm demo' do
    #set the environment to gcm qa
    ENV['ENVIRONMENT'] = 'gcmdemo'
    user_info = NjSalesforce::Base.connection(reset=true).user_info.to_h
    expect(user_info['username']).to eq('qatestuser@netjetsus.com.gcmdemo')
  end

  it 'makes a connection when reset is not set' do
    ENV['ENVIRONMENT'] = 'gcmdemo'
    user_info = NjSalesforce::Base.connection.user_info
    expect(user_info).not_to be_nil
  end
end


