require 'spec/spec_helper'
require 'models/base'
require 'models/legal_entity'

describe 'legal entity' do
  it 'gets the all legal entity' do
    #set the environment to gcm qa
    ENV['ENVIRONMENT'] = 'gcmdemo'
    puts NjSalesforce::LegalEntity.home
    puts NjSalesforce::LegalEntity.new
    puts NjSalesforce::LegalEntity.describe

  end

end