require 'spec/spec_helper'
require 'models/base'
require 'models/aircraft_image'

describe 'aircraft image' do
  it 'gets the aircraft image' do
    #set the environment to gcm qa
    ENV['ENVIRONMENT'] = 'gcmqa'
    puts NjSalesforce::AircraftImage.all.first.to_h
  end

  it 'can describe itself' do
    puts NjSalesforce::AircraftImage.new

  end
end