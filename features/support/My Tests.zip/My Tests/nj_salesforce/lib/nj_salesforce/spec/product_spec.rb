require 'spec/spec_helper'
require 'models/base'
require 'models/product'

describe 'product' do
  it 'gets the product information' do
    #set the environment to gcm qa
    ENV['ENVIRONMENT'] = 'gcmqa'
    user_info = NjSalesforce::Product.connection
    puts user_info
  end
end


