require 'spec/spec_helper'
require 'models/base'
require 'models/asset_line_item'

describe 'asset line item' do
  it 'gets the aircraft image' do
    #set the environment to gcm qa
    ENV['ENVIRONMENT'] = 'gcmqa'
    puts NjSalesforce::AssetLineItem.all.first.to_h
  end

end