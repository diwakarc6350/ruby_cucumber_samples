require 'spec/spec_helper'
require 'models/base'
require 'models/agreement'
require 'models/attachment'
require 'models/proposal'

describe 'agreement' do
  it 'gets the agreement documents' do
    #set the environment to gcm qa
    ENV['ENVIRONMENT'] = 'gcmdev'
    attachments = NjSalesforce::Agreement.agreement_documents('a1tc0000002mqmpAAA')
    puts NjSalesforce::AttachmentNotes.download(attachments.first['Id'], "C:\\Users\\dchandrasekaran\\agreement_documents")
  end

  it 'gets the agreement information' do
    #set the environment to gcm qa
    ENV['ENVIRONMENT'] = 'gcmdev'
    #puts NjSalesforce::Agreement.agreement_information[0]
    #puts NjSalesforce::Agreement.first
    fields = NjSalesforce::Agreement.describe['fields']
    puts fields.select { |x| x['name']=='LastViewedDate' }.first.to_h
    puts fields.select { |x| x['name']=='LastReferencedDate' }.first.to_h

  end

end
