module EnvironmentMap
  [:gcmqa => :itg1, :gcmdemo => :qa]
end