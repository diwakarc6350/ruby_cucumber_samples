require 'restforce'
require_relative 'connection_adapters/base.rb'

CLIENT =  SalesforceAuth.connection

puts CLIENT.query("select id from Account").first


# EXAMPLES:

#create, update and delete a salesforce object
#
# •	SF Object is API Name in Object Definitions
# •	Field Names are Field Name for Standard Fields.
# •	Custom Fields are API Name.
# •	See attached image.
#
# Creating a SF Object
# connection.create('Legal_Entity__c',
#                   Name: 'Di & Di Legal',
#                   Legal_Entity_Address_Street__c: 'N Columbus St.',
#                   Legal_Entity_Address_City__c: 'Columbus',
#                   Legal_Entity_Address_State_Province__c:'OH',
#                   Legal_Entity_Address_Postal_Code__c: '43215'
# )
#
# Updating a SF Object
#
# connection.update('Legal_Entity__c', Id:'a5jc00000009Ih2',
#                   Legal_Entity_Address_Street__c: 'W Columbus St.',
#                   Legal_Entity_Address_City__c: 'Akron',
#                   Legal_Entity_Address_State_Province__c:'OH',
#                   Legal_Entity_Address_Postal_Code__c: '75852'
# )
#
# Deleting a SF Object
# connection.destroy('Legal_Entity__c','a5jc00000009Ih2')

