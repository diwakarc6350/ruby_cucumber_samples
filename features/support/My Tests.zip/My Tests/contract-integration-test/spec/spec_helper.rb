require 'rspec'
require 'patches/array'
require 'patches/string'
require 'nj_salesforce'
require 'connection'
require 'logger'
require 'rspec/retry'
require "#{File.dirname(__FILE__)}/../enum"

def log
  Logger.new(STDOUT)
end

RSpec.configure do |config|
  # show retry status in spec process
  config.verbose_retry = true
  # show exception that triggers a retry if verbose_retry is set to true
  config.display_try_failure_messages = true
end

puts "Using #{ENV['ENVIRONMENT']} for testing..."