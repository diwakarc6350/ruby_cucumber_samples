require 'active_record'

#require "#{File.dirname(__FILE__)}/lib/ojdbc6-11.2.0.3.jar"

class AbsData < ActiveRecord::Base
  self.abstract_class = true
  self.establish_connection(
      :adapter => 'jdbc',
      :username => 'GC_TEST_USER',
      :password => '59c81e83be4d72f4f604fc160e38f198',
      :driver => 'com.microsoft.sqlserver.jdbc.SQLServerDriver',
      :url => 'jdbc:sqlserver://LISDEVSQL01:1433;databaseName=TB_NETJETS_ABS_CMH'
  )
end

class CmsNjeData < ActiveRecord::Base
  self.abstract_class = true
  self.establish_connection(
      :adapter => 'jdbc',
      :username => 'cms_etl_datareader',
      :password => 'aedd54732bfd20e43f70fae9808840b4',
      :driver => 'com.microsoft.sqlserver.jdbc.SQLServerDriver',
      :url => 'jdbc:sqlserver://LISQACMS01:1433;databaseName=CMSNJE_TARGET'
  )
end

class CmsNjaData < ActiveRecord::Base
  self.abstract_class = true
  self.establish_connection(
      :adapter => 'jdbc',
      :username => 'GC_Test_User',
      :password => '7b96kXmN',
      :driver => 'com.microsoft.sqlserver.jdbc.SQLServerDriver',
      :url => 'jdbc:sqlserver://cmhprdcmsapp01:1433;databaseName=CMS V2'
  )
end

class MarsData < ActiveRecord::Base
  self.abstract_class = true
  self.establish_connection(
      :adapter => 'jdbc',
      :username => 'MARS_ETL_GC_User',
      :password => 'ABtVKvhsMQ1uJx9ulbxi',
      :driver => 'com.microsoft.sqlserver.jdbc.SQLServerDriver',
      :url => 'jdbc:sqlserver://CMHPRDMRSSQL01:1433;databaseName=Marquis'
  )
end

class StagingData < ActiveRecord::Base
  self.abstract_class = true
  self.establish_connection(
      :adapter => 'jdbc',
      :username => 'CNCS_APP_TEAM',
      :password => 'C0ns0l1d4te',
      :driver => 'oracle.jdbc.driver.OracleDriver',
      :url => "jdbc:oracle:thin:@
             (DESCRIPTION_LIST=
             (LOAD_BALANCE=off)
             (FAILOVER=on)
             (DESCRIPTION=
             (ADDRESS_LIST=
             (LOAD_BALANCE=on)
             (ADDRESS=(PROTOCOL=TCP)(HOST=cexa-scan)(PORT=1521)))
             (CONNECT_DATA=(SERVICE_NAME=Ijet2ThinDv5.netjets.com))))"
  )
end

=begin
class IjetData < ActiveRecord::Base
  self.abstract_class = true
  self.establish_connection(
      :adapter => 'jdbc',
      :username => 'GCDM_ETL_USER',
      :password => 'Fu$10ng10w',
      :driver => 'oracle.jdbc.driver.OracleDriver',
      :url => 'jdbc:oracle:thin:@ijet2rptdr :1521:ijet2rptdr'
  )
end
=end

class EdwData < ActiveRecord::Base
  self.abstract_class = true
  self.establish_connection(
      :adapter => 'jdbc',
      :username => 'GLOBAL_CNTRCT_USER',
      :password => 'M1grat1onC0n',
      :driver => 'oracle.jdbc.driver.OracleDriver',
      #:url => 'jdbc:oracle:thin:@ED01DB :1521:ED01DB'
      :url => "jdbc:oracle:thin:@
                (DESCRIPTION_LIST=
                (LOAD_BALANCE=off)
                (FAILOVER=on)
                (DESCRIPTION=
                (ADDRESS_LIST=
                (LOAD_BALANCE=on)
                (ADDRESS=(PROTOCOL=TCP)(HOST=bexa-scan)(PORT=1521)))
                  (CONNECT_DATA=(SERVICE_NAME=EdwThinPrd.netjets.com)))
                (DESCRIPTION=
                (ADDRESS_LIST=
                (LOAD_BALANCE=on)
                (ADDRESS=(PROTOCOL=TCP)(HOST=cexa-scan)(PORT=1521)))
                (CONNECT_DATA=(SERVICE_NAME=EdwThinPrd.netjets.com))))")
end

class IjetData < ActiveRecord::Base
  self.abstract_class = true
  self.establish_connection(
      :adapter => 'jdbc',
      :username => 'GCDM_ETL_USER',
      :password => 'Fu$10ng10w',
      :driver => 'oracle.jdbc.driver.OracleDriver',
      #:url => 'jdbc:oracle:thin:@ED01DB :1521:ED01DB'
      :url => "jdbc:oracle:thin:@
                (DESCRIPTION_LIST=
                (LOAD_BALANCE=off)
                (FAILOVER=on)
                (DESCRIPTION=
                (ADDRESS_LIST=
                (LOAD_BALANCE=on)
                (ADDRESS=(PROTOCOL=TCP)(HOST=bexa-scan)(PORT=1521)))
                  (CONNECT_DATA=(SERVICE_NAME=MRDPRD.netjets.com)))
                (DESCRIPTION=
                (ADDRESS_LIST=
                (LOAD_BALANCE=on)
                (ADDRESS=(PROTOCOL=TCP)(HOST=bexa-scan)(PORT=1521)))
                (CONNECT_DATA=(SERVICE_NAME=MRDPRD.netjets.com))))")
end

# class IjetData < ActiveRecord::Base
#   self.abstract_class = true
#   self.establish_connection(
#       :adapter => 'jdbc',
#       :username => 'gc_test_user',
#       :password => 'f1nd1ngs',
#       :driver => 'oracle.jdbc.driver.OracleDriver',
#       :url => 'jdbc:oracle:thin:@i2rptqa1:1521:i2rptqa1'
#   )
# end

class DBConnectors
  def self.abs
    AbsData.connection
  end

  def self.ijet
    IjetData.connection
  end

  def self.mars
    MarsData.connection
  end

  def self.cms_nje
    CmsNjeData.connection
  end

  def self.cms_nja
    CmsNjaData.connection
  end

  def self.staging
    StagingData.connection
  end

  def self.edw
    EdwData.connection
  end


end