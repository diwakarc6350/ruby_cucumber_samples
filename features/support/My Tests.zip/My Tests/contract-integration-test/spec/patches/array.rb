class Array
  def to_clean_string
    self.to_s.gsub('["', '').gsub(']', '').gsub('"','')
  end
end