require 'active_record'
require 'yaml'

$CLASSPATH << "#{Dir.pwd}/lib/ojdbc7.jar"
$CLASSPATH << "#{Dir.pwd}/lib/sqljdbc4.jar"

#supress active record deprecation warnings.
ActiveSupport::Deprecation.silenced = true

def connect_to_db(environment)
  connection_info = YAML.load_file("#{File.dirname(__FILE__)}/../database.yml")
  begin
    if !ActiveRecord::Base.connected?
      ActiveRecord::Base
          .establish_connection(connection_info[environment])
      puts "Connected to #{ActiveRecord::Base.connection.current_database}"
    end
  rescue NameError
    fail "No Salesforce environment exists for #{environment}"
  end

end