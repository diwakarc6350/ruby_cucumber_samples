require 'active_record'
require "#{File.dirname(__FILE__)}/../../../spec/connection"
require "#{File.dirname(__FILE__)}/../../../spec/connectors"

module IJET
  class Airports < IjetData
    self.table_name = 'ijet.airport'

    def self.airport_information
      self.find_by_sql('select A.AIRPORTID,A.AIRPORT_NAME,A.CITY_NAME,
                        case when a.country_cd in (\'USA\',\'CAN\') then state.value
                        else a.state_cd end state_cd,
                        C.COUNTRY_NAME
                        from airport A  JOIN country C
                        ON A.COUNTRY_CD=C.COUNTRY_CD
                        left join (select *  from code_table_str
                        where tag in (\'USState\',\'CAProvince\'))state
                        on state.code=a.state_cd
                        where A.AIRPORT_CLOSED_FLAG=\'F\'')
          .map(&:attributes)
    end

    def self.all_cities
      self.find_by_sql('select distinct A.CITY_NAME,
                        case when a.country_cd in (\'USA\',\'CAN\') then state.value
                        else a.state_cd end state_cd,
                        C.COUNTRY_NAME
                        from airport A  JOIN country C
                        ON A.COUNTRY_CD=C.COUNTRY_CD
                        left join (select *  from code_table_str
                        where tag in (\'USState\',\'CAProvince\'))state
                        on state.code=a.state_cd
                        where A.AIRPORT_CLOSED_FLAG=\'F\'').map(&:attributes)
    end

    def self.all_states
      self.find_by_sql('select unique cd.value
                        from airport a
                        join code_table_str cd
                        on cd.code = a.state_cd
                        where a.airport_closed_flag = \'F\'
                        and cd.tag = \'CAProvince\'
                        or cd.tag = \'USState\'').map(&:attributes)
    end

    def self.all_countries
      self.find_by_sql('select unique c.country_name
                        from airport a
                        join country c
                        on a.country_cd = c.country_cd
                        where a.airport_closed_flag = \'F\'').map(&:attributes)
    end
  end
end