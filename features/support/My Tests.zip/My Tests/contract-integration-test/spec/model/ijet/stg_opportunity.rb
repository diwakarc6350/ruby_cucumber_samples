module IJET
  class StagingOpportunity < ActiveRecord::Base
    self.table_name = 'cntr_owner.cntr_stg_opportunity'

  end
end
