module IJET
  class StagingOpportunityXref < ActiveRecord::Base
    self.table_name = 'cntr_owner.apttus_stg_oppor_col_xref'

  end
end
