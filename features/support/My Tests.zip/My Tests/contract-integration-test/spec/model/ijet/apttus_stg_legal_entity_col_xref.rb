module IJET
  class StagingLegalEntityXref < ActiveRecord::Base
    self.table_name = 'cntr_owner.apttus_stg_le_col_xref'

  end
end
