module IJET
  class StagingAgreementXref < ActiveRecord::Base
    self.table_name = 'cntr_owner.apttus_stg_agreement_col_xref'

  end
end
