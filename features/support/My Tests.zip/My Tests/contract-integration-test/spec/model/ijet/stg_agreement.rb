module IJET
  class StagingAgreement < ActiveRecord::Base
    self.table_name = 'cntr_owner.cntr_stg_agreement'

  end
end
