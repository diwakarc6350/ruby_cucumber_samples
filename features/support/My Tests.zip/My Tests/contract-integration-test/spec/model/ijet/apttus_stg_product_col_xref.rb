module IJET
  class StagingProductXref < ActiveRecord::Base
    self.table_name = 'cntr_owner.apttus_stg_product_col_xref'

  end
end
