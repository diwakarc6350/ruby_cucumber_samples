module IJET
  class StagingAgreementLineItemXref < ActiveRecord::Base
    self.table_name = 'cntr_owner.apttus_stg_ali_col_xref'

  end
end
