module IJET
  class StagingAgreementLineItem < ActiveRecord::Base
    self.table_name = 'cntr_owner.cntr_stg_agreement_line_item'


  end
end
