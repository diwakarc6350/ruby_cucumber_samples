module IJET
  class StagingProduct < ActiveRecord::Base
    self.table_name = 'cntr_owner.cntr_stg_product'

  end
end
