require 'active_record'
require 'spec/connection'

module OCMS
  class InterchangeRates < ActiveRecord::Base
    self.table_name = 'prdt_owner.prdt_aircraft_interchange_rate'

    def self.all_interchange_rates
      self.find_by_sql('select r.prdt_aircraft_inter_rate_id, m.PRDT_INTERCHANGE_RATE_TYPE_ID, t.RATE_TYPE_NAME,
                        atf.aircraft_type_name as from_aircraft_type_name, att.aircraft_type_name as to_aircraft_type_name,
                        r.interchange_rate, m.effective_month_dt
                        from prdt_aircraft_interchange_rate r
                        join prdt_exchange_per_month m on r.prdt_exchange_per_month_id = m.prdt_exchange_per_month_id
                        join prdt_interchange_rate_type t on t.PRDT_INTERCHANGE_RATE_TYPE_ID = m.PRDT_INTERCHANGE_RATE_TYPE_ID
                        join acft_aircraft_type_xref atxf on atxf.ACFT_AIRCRAFT_TYPE_XREF_ID =r.from_acft_aircraft_type_xf_id
                        join acft_aircraft_type_xref atxt on atxt.ACFT_AIRCRAFT_TYPE_XREF_ID =r.to_acft_aircraft_type_xf_id
                        join acft_aircraft_type atf on atf.acft_aircraft_type_id = atxf.acft_aircraft_type_id
                        join acft_aircraft_type att on att.acft_aircraft_type_id = atxt.acft_aircraft_type_id')
      .map(&:attributes)
    end
  end

end