require 'active_record'
require 'spec/connection'

module OCMS
  class FuelInformation < ActiveRecord::Base
    self.table_name = 'prdt_owner.PRDT_FUEL_TYPE'

    def self.fuel_data
      self.find_by_sql("select COMP.COMPANY_NAME,
                               FA.PRDT_ACFT_AVG_FUEL_RATE_ID,
                               XREF.ACFT_AIRCRAFT_TYPE_XREF_ID,
                               FVAR.EFFECTIVE_DT,
                               FTYPE.FUEL_TYPE_NAME,
                               FVAR.VARIABLE_RATE_QTY,
                               FA.FUEL_RATE,
                               FA.TIME_PERIOD_TYPE,
                               C.COMMERCIAL_STATUS_FLG
                               from
                               IJET.EJ_COMPANY COMP
                               JOIN PRDT_FUEL_TYPE FTYPE
                               ON COMP.EJ_COMPANY_ID=FTYPE.EJ_COMPANY_ID
                               JOIN PRDT_OWNER.PRDT_FUEL_CALC_VARIABLE FVAR
                               ON FVAR.PRDT_FUEL_TYPE_ID=FTYPE.PRDT_FUEL_TYPE_ID
                               JOIN ACFT_OWNER.ACFT_AIRCRAFT_TYPE_XREF XREF
                               ON FVAR.ACFT_AIRCRAFT_TYPE_XREF_ID=XREF.ACFT_AIRCRAFT_TYPE_XREF_ID
                               JOIN PRDT_OWNER.PRDT_ACFT_AVG_FUEL_RATE FA
                               ON FVAR.PRDT_FUEL_CALC_VARIABLE_ID = FA.PRDT_FUEL_CALC_VARIABLE_ID
                               JOIN PRDT_OWNER.PRDT_FUEL_TYPE_COMMERCIAL C
                               ON FA.PRDT_FUEL_TYPE_COMMERCIAL_ID = C.PRDT_FUEL_TYPE_COMMERCIAL_ID").map(&:attributes)
    end
  end

end