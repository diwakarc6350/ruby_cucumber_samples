require 'active_record'
require 'spec/connection'

module OCMS
  class Ppd < ActiveRecord::Base
    self.table_name = 'prdt_owner.PRDT_PEAK_DAY'

    def self.peak_period_day_information
      self.find_by_sql("select peak_dt from prdt_peak_day").map(&:attributes)
    end

    def self.peak_day_and_list_name
      self.find_by_sql("select ppd.peak_dt , ppdl.list_nm
                        from prdt_peak_day ppd
                        join prdt_peak_day_list ppdl on ppdl.prdt_peak_day_list_id = ppd.PRDT_PEAK_DAY_LIST_ID").map(&:attributes)
    end

  end
end