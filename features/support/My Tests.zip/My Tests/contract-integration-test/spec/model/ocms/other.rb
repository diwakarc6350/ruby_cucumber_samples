require 'active_record'
require 'spec/connection'

module OCMS
  class Program < ActiveRecord::Base
    self.table_name = 'ijet.program'
  end

  class Company < ActiveRecord::Base
    self.table_name = 'ijet.ej_company'
  end

end
