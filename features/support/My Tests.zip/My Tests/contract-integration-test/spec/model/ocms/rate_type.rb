require 'active_record'
require 'spec/connection'

module OCMS
  class RateTypes < ActiveRecord::Base
    self.table_name = 'prdt_owner.prdt_exchange_rate'

    def self.all_rate_types
      self.find_by_sql('select r.prdt_exchange_rate_id, r.to_program_id, r.from_program_id, r.from_ej_company_id,
                        r.exchange_rate_name, r.effective_dt, r.inactive_dt, p.program_name, c.company_name
                        from prdt_owner.prdt_exchange_rate r
                        left join program p
                        on r.from_program_id = p.program_id
                        left join ej_company c
                        on r.from_ej_company_id = c.ej_company_id').map(&:attributes)
    end
  end
end