require 'active_record'
require 'spec/connection'

module OCMS
  class PpdList < ActiveRecord::Base
    self.table_name = 'prdt_owner.PRDT_PEAK_DAY_LIST'

    def self.peak_period_day_lists_information
      self.find_by_sql("select peak.prdt_peak_day_list_id, comp.company_name, peak.effective_dt, peak.inactive_dt,
                        peak.list_nm
                        from prdt_peak_day_list peak
                        join ijet.ej_company comp
                        on comp.ej_company_id=peak.ej_company_id").map(&:attributes)
    end

  end
end