require 'active_record'

module AIS
  class AcftAircraftType < ActiveRecord::Base

    self.table_name = 'acft_owner.acft_aircraft_type'

    def self.aircraft_list_data
      self.find_by_sql("select aatx.acft_aircraft_type_xref_id, acc.cabin_class_name, acc.cabin_class_rnk, aat.aircraft_type_ranking_nbr,
                      aat.aircraft_type_name, aat.aircraft_type_ranking_nbr, aat.active_status_flg
                      from acft_owner.acft_aircraft_type aat
                      join acft_owner.acft_cabin_class acc
                      on aat.acft_cabin_class_id = acc.acft_cabin_class_id
                      join acft_owner.acft_aircraft_type_xref aatx
                      on aatx.acft_aircraft_type_id = aat.acft_aircraft_type_id").map(&:attributes)
    end
  end
end