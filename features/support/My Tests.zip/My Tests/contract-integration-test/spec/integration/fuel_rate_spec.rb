require 'spec_helper'
require 'model/OCMS/fuel_information'
require 'awesome_print'

describe 'fuel rate information integration' do

  it 'fuel rate information between apttus and ocms matches' do
    connect_to_db ENV['ENVIRONMENT'].to_sym

    ocms_fuel_data = OCMS::FuelInformation.fuel_data
    log.info "ocms has #{ocms_fuel_data.size} entries"

    apttus_fuel_data = NjSalesforce::FuelInformation.fuel_data
    log.info "apttus has #{apttus_fuel_data.size} entries for fuel information"

    ocms_fuel_data = scrub_ocms_fuel_data(ocms_fuel_data)
    apttus_fuel_data = scrub_apttus_fuel_data(apttus_fuel_data)

    unique_elements = ocms_fuel_data - apttus_fuel_data
    ap unique_elements
    expect(unique_elements).to be_empty

    #unique_elements = apttus_fuel_data - ocms_fuel_data
    #expect(unique_elements).to be_empty
  end
end

def scrub_ocms_fuel_data(fuel_data)
  fuel_data.map do |record|
    record['company_name'] = record.delete('company_name')
    if record['company_name'] == 'NJE'
      record.delete('fuel_type_name')
      record.delete('commercial_status')
    else
      fuel_type_name = record.delete('fuel_type_name')
      record['fuel_type'] = fuel_type_name
    end
    record['fuel_rate'] = record['fuel_rate'].to_f
    record['effective_date'] = record.delete('effective_dt').strftime("%F")
    record['variable_rate_qty'] = record.delete('variable_rate_qty').to_f
    record.delete('prdt_fuel_type_id')
    record
  end
end

def scrub_apttus_fuel_data(fuel_data)
  fuel_data.map do |record|
    record['company_name'] = record.delete('Program__c').to_s
    if record['company_name'] == 'NJE'
      record.delete('Fuel_Type__c')
    else
      record['fuel_type'] = record.delete('Fuel_Type__c').to_s
    end
    record['acft_aircraft_type_xref_id'] = record.delete('Aircraft_List__c').to_i.to_s
    record.delete('Aircraft_Type__r')
    record['effective_date'] = record.delete('Effective_Date__c').to_time.strftime("%F")
    record['prdt_acft_avg_fuel_rate_id'] = record.delete('Aircraft_Fuel_Rate_ID__c').to_i.to_s
    record['time_period_type'] = record.delete('Time_Period_Type__c').to_i.to_s
    rate = record.delete('Fuel_Rate__c').to_f
    record['fuel_rate'] = rate
    record['commercial_status_flg'] = record.delete('Commercial_Status__c')
    record['variable_rate_qty'] = record.delete('Variable_Rate__c').to_f
    record.delete 'Monthly_Variable_Rate__c'
    record.delete 'Three_Month_Variable_Rate__c'

    record
  end
end