require 'awesome_print'
require 'spec_helper'
require 'model/ocms/aircraft_interchange_rates'

describe 'interchange rate integration' do

  before(:all) do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    @ocms_interchange_rates_data = OCMS::InterchangeRates.all_interchange_rates
    @interchange_rate_data = NjSalesforce::InterchangeRate.interchange_rate_data
    #puts @ocms_interchange_rates_data, @interchange_rate_data
  end

  it 'interchange rate information between apttus and ocms matches' do
    log.info "ocms has #{@ocms_interchange_rates_data.size} entries"
    log.info "apttus has #{@interchange_rate_data.size} entries"
    expect(@ocms_interchange_rates_data.length).to eq(@interchange_rate_data.length)
  end

  it 'has the correct interchange rate information' do
    chosen_ocms_interchange = @ocms_interchange_rates_data[rand(@ocms_interchange_rates_data.length)]
    interchange_rate = @interchange_rate_data
    .select { |x| x['Interchange_ID__c'].to_i==chosen_ocms_interchange['prdt_aircraft_inter_rate_id'] }[0]
    expect(interchange_rate['From_Aircraft_Type__r']['Name']).to eq(chosen_ocms_interchange['from_aircraft_type_name'])
    expect(interchange_rate['To_Aircraft_Type__r']['Name']).to eq(chosen_ocms_interchange['to_aircraft_type_name'])
    expect(interchange_rate['Interchange_Rate__c'].to_f).to eq(chosen_ocms_interchange['interchange_rate'].to_f)
    expect(interchange_rate['Name']).to eq(chosen_ocms_interchange['rate_type_name'])
    expected_effective_month = chosen_ocms_interchange['effective_month_dt'].to_datetime.strftime('%Y-%m-%d')
    expect(interchange_rate['Effective_Month__c']).to eq(expected_effective_month)
  end

end