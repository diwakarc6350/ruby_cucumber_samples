require 'spec_helper'
require 'integration/from_apttus/compare'
require 'model/ijet/stg_agreement'
require 'model/ijet/stg_legal_entity'
require 'model/ijet/apttus_stg_legal_entity_col_xref'

describe 'legal entity integration' do

  it 'all legal entities have an agreement' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    staging_legal_entities = IJET::StagingLegalEntity.select(:id).map(&:id).sort
    agreements_legal_entities = IJET::StagingAgreement.select(:legal_entity)
                                    .where("processed_flag = 'N'").map(&:legal_entity).to_a.uniq.sort
    expect(staging_legal_entities).to eq(agreements_legal_entities)
  end

  describe 'legal entity information between apttus and staging matches' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    chosen_legal_entity = IJET::StagingLegalEntity.where("processed_flag = 'N'").map(&:attributes).sample
    expected_legal_entity_info = NjSalesforce::LegalEntity.where({Id: chosen_legal_entity['id']}).first.to_h
    field_descriptions = NjSalesforce::LegalEntity.describe['fields']
    maps = IJET::StagingLegalEntityXref.all.map(&:attributes)
    maps.each do |map|
      include_examples 'compare', chosen_legal_entity, expected_legal_entity_info, field_descriptions, map
    end
  end
end