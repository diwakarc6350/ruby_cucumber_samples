require 'spec_helper'

shared_examples 'compare' do |chosen, expected, field_descriptions, map|
  it "sets #{map['apttus_attribute_name']} as #{map['stg_column_name']}" do
    field_type = field_descriptions.select { |x| x['name']==map['apttus_attribute_name'] }.first['type']
    case field_type
      when 'currency' || 'double' || 'percent'
        if chosen[map['apttus_attribute_name']].nil?
          expect(chosen[map['stg_column_name'].downcase])
              .to eq(expected[map['apttus_attribute_name']])
        else
          expect(chosen[map['stg_column_name'].downcase].to_f)
              .to eq(expected[map['apttus_attribute_name']])
        end
      when 'datetime'
        if chosen[map['stg_column_name'].downcase].nil?
          expect(chosen[map['stg_column_name'].downcase])
              .to eq(expected[map['apttus_attribute_name']])
        else
          start_time = chosen[map['stg_column_name'].downcase].to_datetime
          end_time = chosen[map['apttus_attribute_name'].downcase].to_datetime
          expect(TimeDifference.between(start_time, end_time).in_seconds).to eq(0)
        end
      when 'date'
        if chosen[map['apttus_attribute_name']].nil?
          expect(chosen[map['stg_column_name'].downcase])
              .to eq(expected[map['apttus_attribute_name']])
        else
          start_time = chosen[map['stg_column_name'].downcase].to_datetime
          end_time = chosen_agreement_line_item[map['apttus_attribute_name'].downcase].to_datetime
          expect(TimeDifference.between(start_time, end_time).in_seconds).to eq(0)
        end
      when 'boolean'
        expect(chosen[map['stg_column_name'].downcase].to_bool)
            .to eq(expected[map['apttus_attribute_name']])
      else
        expect(chosen[map['stg_column_name'].downcase])
            .to eq(expected[map['apttus_attribute_name']])
    end
  end
end