require 'spec_helper'
require 'time_difference'
require 'integration/from_apttus/compare'
require 'model/ijet/stg_agreement'
require 'model/ijet/stg_agreement_line_item'
require 'model/ijet/apttus_stg_agreement_line_item_col_xref'

describe 'agreement line item integration' do

  describe 'apttus agreement line item has all the columns defined in agreement line item xref' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    pulled_agreement_line_item = NjSalesforce::AgreementLineItem.all.sample.to_h
    maps = IJET::StagingAgreementLineItemXref.all.map(&:attributes)
    maps.each do |map|
      it "has #{map['apttus_attribute_name']}" do
        expect(pulled_agreement_line_item.has_key?(map['apttus_attribute_name'])).to be true
      end
    end
  end

  describe 'staging agreement line item has all the columns defined in agreement line item xref' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    agreement_line_item_from_apttus = IJET::StagingAgreementLineItem.where("processed_flag = 'N'").map(&:attributes).sample
    maps = IJET::StagingAgreementLineItemXref.all.map(&:attributes)
    maps.each do |map|
      it "has #{map['stg_column_name']}" do
        expect(agreement_line_item_from_apttus.has_key?(map['stg_column_name'].downcase)).to be true
      end
    end
  end

  describe 'all the agreement line item fields in apttus are defined in agreement line item xref' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    pulled_agreement_line_item = NjSalesforce::AgreementLineItem.all.sample.to_h
    pulled_agreement_line_item.delete('attributes')
    maps = IJET::StagingAgreementLineItemXref.all.map(&:apttus_attribute_name)
    pulled_agreement_line_item.each do |field|
      it "has #{field[0]}", :diff => true do
        expect(maps.include?(field[0])).to be true
      end
    end
  end

  describe 'no agreement line items are orphaned' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    staging_agreement_line_items = IJET::StagingAgreementLineItem.select(:agreementid, :id).map(&:attributes)
    staging_agreements_from_apttus = IJET::StagingAgreement.select(:id).where("processed_flag = 'N'").map(&:id).to_a
    staging_agreement_line_items.each do |ali|
      it "has #{ali['agreementid']}" do
        expect(staging_agreements_from_apttus.include?(ali['agreementid'])).to be true
      end
    end
  end

  describe 'agreement line item information between apttus and staging matches' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    chosen_agreement_line_item = IJET::StagingAgreementLineItem.where("processed_flag = 'N'").map(&:attributes).sample
    expected_agreement_line_item_info = NjSalesforce::AgreementLineItem.where({Id: chosen_agreement_line_item['id']}).first.to_h
    field_descriptions = NjSalesforce::AgreementLineItem.describe['fields']
    maps = IJET::StagingAgreementLineItemXref.all.map(&:attributes)
    maps.each do |map|
      include_examples 'compare', chosen_agreement_line_item, expected_agreement_line_item_info, field_descriptions, map
    end
  end
end
