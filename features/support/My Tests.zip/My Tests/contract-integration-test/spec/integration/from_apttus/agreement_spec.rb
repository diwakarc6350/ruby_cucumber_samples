require 'spec_helper'
require 'time_difference'
require 'integration/from_apttus/compare'
require 'model/ijet/stg_agreement'
require 'model/ijet/apttus_stg_agreement_col_xref'

describe 'agreement integration' do

  describe 'apttus agreement has all the columns defined in agreement xref' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    active_pulled_agreement = NjSalesforce::Agreement.all.select { |x|
      x['Apttus__Status_Category__c']=='In Effect' && x['Apttus__Status__c']=='Activated' }.sample.to_h
    maps = IJET::StagingAgreementXref.all.map(&:attributes)
    maps.each do |map|
      it "has #{map['apttus_attribute_name']}" do
        expect(active_pulled_agreement.has_key?(map['apttus_attribute_name'])).to be true
      end
    end
  end

  describe 'staging agreement has all the columns defined in agreement xref' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    active_agreement_from_apttus = IJET::StagingAgreement.where("processed_flag = 'N'").map(&:attributes).sample
    maps = IJET::StagingAgreementXref.all.map(&:attributes)
    maps.each do |map|
      it "has #{map['stg_column_name']}" do
        expect(active_agreement_from_apttus.has_key?(map['stg_column_name'].downcase)).to be true
      end
    end
  end

  describe 'all the agreement fields in apttus are defined in agreement xref' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    active_pulled_agreement = NjSalesforce::Agreement.all.select { |x|
      x['Apttus__Status_Category__c']=='In Effect' && x['Apttus__Status__c']=='Activated' }.sample.to_h
    active_pulled_agreement.delete('attributes')
    maps = IJET::StagingAgreementXref.all.map(&:apttus_attribute_name)
    active_pulled_agreement.each do |field|
      it "has #{field[0]}", :diff => true do
        expect(maps.include?(field[0])).to be true
      end
    end

  end

  it 'has the correct number of active agreement pulled' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    active_agreements_from_apttus = IJET::StagingAgreement.where("processed_flag = 'N'")
    active_pulled_agreements = NjSalesforce::Agreement.all.select { |x|
      x['Apttus__Status_Category__c']=='In Effect' && x['Apttus__Status__c']=='Activated' }
    expect(active_pulled_agreements.length).to eq(active_agreements_from_apttus.length)
  end

  describe 'agreement information between apttus and staging matches' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    chosen_agreement = IJET::StagingAgreement.where("processed_flag = 'N'").map(&:attributes).sample
    expected_agreement_info = NjSalesforce::Agreement.where({Id: chosen_agreement['id']}).first.to_h
    field_descriptions = NjSalesforce::Agreement.describe['fields']
    maps = IJET::StagingAgreementXref.all.map(&:attributes)
    maps.each do |map|
      include_examples 'compare', chosen_agreement, expected_agreement_info, field_descriptions, map
    end
  end

end
