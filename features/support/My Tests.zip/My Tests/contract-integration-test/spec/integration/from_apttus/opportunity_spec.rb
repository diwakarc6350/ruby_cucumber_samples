require 'awesome_print'
require 'spec_helper'
require 'model/ijet/stg_agreement'
require 'model/ijet/stg_opportunity'

describe 'opportunity integration' do
  describe 'no opportunities are orphaned' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    staging_opportunities = IJET::StagingOpportunity.select(:id).map(&:id).sort
    agreements_related_opportunity = IJET::StagingAgreement.select(:related_opportunity)
                                         .where("processed_flag = 'N'").map(&:related_opportunity).to_a.uniq.sort
    it 'all opportunities have an agreement' do
      expect(staging_opportunities).to eq(agreements_related_opportunity)
    end
  end
end
