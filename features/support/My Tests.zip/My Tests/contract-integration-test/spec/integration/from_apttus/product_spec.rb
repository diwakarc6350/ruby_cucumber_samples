require 'spec_helper'
require 'model/ijet/stg_agreement_line_item'
require 'integration/from_apttus/compare'
require 'model/ijet/stg_opportunity'
require 'model/ijet/stg_product'
require 'model/ijet/apttus_stg_product_col_xref'

describe 'product integration' do
  it 'all opportunities have an agreement' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    staging_products = IJET::StagingProduct.select(:id).map(&:id).uniq.sort
    ali_products = IJET::StagingAgreementLineItem.select(:productid).where("processed_flag = 'N'").map(&:productid).to_a.uniq.sort
    expect(staging_products).to eq(ali_products)
  end

  describe 'product information between apttus and staging matches' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    chosen_product = IJET::StagingProduct.where("processed_flag = 'N'").map(&:attributes).sample
    expected_product_info = NjSalesforce::Product.where({Id: chosen_product['id']}).first.to_h
    field_descriptions = NjSalesforce::Product.describe['fields']
    maps = IJET::StagingProductXref.all.map(&:attributes)
    maps.each do |map|
      include_examples 'compare', chosen_product, expected_product_info, field_descriptions, map
    end
  end
end
