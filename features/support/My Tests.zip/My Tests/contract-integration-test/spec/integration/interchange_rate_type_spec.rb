require 'date'
require 'awesome_print'
require 'spec_helper'
require 'model/ocms/rate_type'
require 'model/ocms/other'

describe 'interchange rate type integration' do
  before(:all) do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    @ocms_rate_types_data = OCMS::RateTypes.all_rate_types
    @apttus_rate_type_data = NjSalesforce::InterchangeRateType.interchange_rate_type_data
    #puts @ocms_rate_types_data, '---', @apttus_rate_type_data
  end

  it 'interchange rate type record count between apttus and ocms matches' do
    log.info "ocms has #{@ocms_rate_types_data.size} entries"
    log.info "apttus has #{@apttus_rate_type_data.size} entries"
  end

  it 'has the correct exchange_rate_name, effective_dt and inactive_dt' do
    chosen_apttus_rate_type = @apttus_rate_type_data[rand(@ocms_rate_types_data.length)]
    ocms_rate_type = @ocms_rate_types_data
    .select { |x| x['exchange_rate_name'] == chosen_apttus_rate_type['Name'] }[0]
    #puts chosen_apttus_rate_type, ocms_rate_type
    expect(chosen_apttus_rate_type['Name']).to eq(ocms_rate_type['exchange_rate_name'])
    expected_effective_date = ocms_rate_type['effective_dt'].to_datetime.strftime('%Y-%m-%d')
    expect(chosen_apttus_rate_type['Effective_Date__c']).to eq(expected_effective_date)

    if !ocms_rate_type['inactive_dt'].nil?
      expected_inactive_date = ocms_rate_type['inactive_dt'].to_datetime.strftime('%Y-%m-%d')
      expect(chosen_apttus_rate_type['Inactive_Date__c']).to eq(expected_inactive_date)
    end
  end

  it "has the correct \"from and to program\"" do
    chosen_ocms_rate_type = @ocms_rate_types_data.select { |x| x['to_program_id']!=nil && x['from_program_id']!= nil }[0]
    apttus_rate_type = @apttus_rate_type_data
    .select { |x| x['Name'] == chosen_ocms_rate_type['exchange_rate_name'] }[0]
    programs = OCMS::Program.select(:program_id, :program_name).map(&:attributes)

    expected_from_program = programs.select { |x| x['program_id']==chosen_ocms_rate_type['from_program_id'] }[0]
    expect(apttus_rate_type['From__c']).to eq(expected_from_program['program_name'])

    expected_from_program = programs.select { |x| x['program_id']==chosen_ocms_rate_type['to_program_id'] }[0]
    expect(apttus_rate_type['To_Program_Name__c']).to eq(expected_from_program['program_name'])
  end

  it "has the correct \"from company\" if available" do
    chosen_ocms_rate_type = @ocms_rate_types_data.select { |x| x['from_ej_company_id']!=nil }[0]
    if chosen_ocms_rate_type.length > 1
      apttus_rate_type = @apttus_rate_type_data
      .select { |x| x['Name'] == chosen_ocms_rate_type['exchange_rate_name'] }[0]
      companies = OCMS::Company.select(:ej_company_id, :company_name).map(&:attributes)

      expected_from_company = companies.select { |x| x['ej_company_id']==chosen_ocms_rate_type['from_ej_company_id'] }[0]
      expect(apttus_rate_type['From__c']).to eq(expected_from_company['company_name'])
    else
      log.info('cannot find test data')
    end
  end

end