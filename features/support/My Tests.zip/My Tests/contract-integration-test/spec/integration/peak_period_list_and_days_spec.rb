require 'awesome_print'
require 'spec_helper'
require 'model/ocms/ppd_list'
require 'model/ocms/ppd'

describe 'peak period list integration' do

  it 'peak period list information between apttus and ocms matches' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    ocms_ppd_list_data = OCMS::PpdList.peak_period_day_lists_information
    log.info "ocms has #{ocms_ppd_list_data.size} entries"

    apttus_ppd_list_data = NjSalesforce::PeakPeriodList.peak_period_list_information
    log.info "apttus has #{apttus_ppd_list_data.size} entries"

    apttus_ppd_list_data = scrub_apttus_ppd_list_data apttus_ppd_list_data
    ap apttus_ppd_list_data
    ocms_ppd_list_data = scrub_ocms_ppd_list_data ocms_ppd_list_data
    ap ocms_ppd_list_data

    unique_elements = ocms_ppd_list_data - apttus_ppd_list_data
    expect(unique_elements).to be_empty

    unique_elements = apttus_ppd_list_data - ocms_ppd_list_data
    expect(unique_elements).to be_empty
  end

  it 'peak period day information between apttus and ocms matches' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    ocms_ppd_data = OCMS::Ppd.peak_period_day_information
    log.info "ocms has #{ocms_ppd_data.size} peak period days"

    apttus_ppd_data = NjSalesforce::PeakPeriodDay.peak_period_day_information
    log.info "apttus has #{apttus_ppd_data.size} peak period days"

    apttus_ppd_data = scrub_apttus_ppd_data apttus_ppd_data
    #ap apttus_ppd_data
    ocms_ppd_data = scrub_ocms_ppd_data ocms_ppd_data
    #ap ocms_ppd_data

    unique_elements = ocms_ppd_data - apttus_ppd_data
    expect(unique_elements).to be_empty

    unique_elements = apttus_ppd_data - ocms_ppd_data
    expect(unique_elements).to be_empty
  end

  it 'peak period list day association between apttus and ocms matches' do
    connect_to_db ENV['ENVIRONMENT'].to_sym
    ocms_ppd_list = OCMS::PpdList.peak_period_day_lists_information.sample
    ocms_ppd_data = OCMS::Ppd.peak_day_and_list_name

    ocms_associated_ppd = ocms_ppd_data.select { |list| list['list_nm'] == ocms_ppd_list['list_nm'] }
    ocms_associated_ppd = scrub_ocms_ppd_data ocms_associated_ppd

    apttus_ppd_list_data = NjSalesforce::PeakPeriodList.peak_period_list_information
    apttus_ppd_list = apttus_ppd_list_data.select { |list| list['Name'] == ocms_ppd_list['list_nm'] && list['Company__c'] == ocms_ppd_list['company_name'] }[0]
    apttus_ppd_data = NjSalesforce::PeakPeriodDay.peak_period_day_information

    apttus_associated_ppd = apttus_ppd_data.select { |list| list['Peak_Period_List__c'] == apttus_ppd_list['Id'] }
    apttus_associated_ppd = scrub_apttus_ppd_data apttus_associated_ppd

    unique_elements = ocms_associated_ppd - apttus_associated_ppd
    expect(unique_elements).to be_empty

    unique_elements = apttus_associated_ppd - ocms_associated_ppd
    expect(unique_elements).to be_empty

  end
end

#### ACTIVEREECORD UPDATE, CREATE QUERIES FOR PPD ####
# list_to_delete = OCMS::PpdList.find_by_list_nm('Standard Test')
# list_to_delete.destroy unless list_to_delete.nil?
# ocms_ppd_list_data = OCMS::PpdList.create(prdt_peak_day_list_id: 7, ej_company_id: 1000001, effective_dt: '1/1/2015 11:00:00PM', list_nm: 'Standard Test', version_nbr: 1)
# list_to_update = OCMS::PpdList.find_by_list_nm('Standard Test')
# list_to_update.update(effective_dt:'4/11/2015 12:00:00PM')

def scrub_apttus_ppd_list_data(aircraft_data)
  aircraft_data.map do |record|
    record['prdt_peak_day_list_id'] = record.delete('PPD_List_Id__c')
    record['company_name'] = record.delete('Company__c')
    record['effective_dt'] = Date.parse(record.delete('Effective_Date__c'))
    record['inactive_dt'] = record.delete('Inactive_Date__c')
    record['inactive_dt'] = Date.parse(record['inactive_dt']) unless record['inactive_dt'].nil?
    record['list_nm'] = record.delete('Name')
    record.delete('Id')
    record
  end
end

def scrub_ocms_ppd_list_data(aircraft_data)
  aircraft_data.map do |record|
    record['prdt_peak_day_list_id'] = record.delete('prdt_peak_day_list_id').to_f
    record['effective_dt'] = Date.parse(record.delete('effective_dt').to_s)
    record['inactive_dt'] = record.delete('inactive_dt')
    record['inactive_dt'] = Date.parse(record['inactive_dt'].to_s) unless record['inactive_dt'].nil?
    record
  end
end

def scrub_apttus_ppd_data(ppd_data)
  ppd_data.map do |record|
    record['date'] = record.delete('Date__c')
    record['date'] = Date.parse(record['date']) unless record['date'].nil?
    record.delete('Peak_Day_Id__c')
    record.delete('Peak_Period_List__c')
    record.delete('Name')
    record.delete('Id')
    record
  end
end

def scrub_ocms_ppd_data(ppd_data)
  ppd_data.map do |record|
    record['date'] = record.delete('peak_dt')
    record['date'] = Date.parse(record['date'].to_s) unless record['date'].nil?
    record.delete('prdt_peak_day_id')
    record.delete('list_nm')
    record
  end
end

