require "#{File.dirname(__FILE__)}/../../spec/spec_helper"
require "#{File.dirname(__FILE__)}/../../spec/model/IJET/airports"

describe 'location integration' do
  before(:all) do
    connect_to_db ENV['ENVIRONMENT'].to_sym
  end

  it 'matches airport information from IJET to APTTUS' do
    apttus_airports = scrub_apttus_airports NjSalesforce::Airports.airport_information
    ijet_airports = scrub_ijet_airports IJET::Airports.airport_information
    expect(apttus_airports.length).to be_within(0.1).percent_of(ijet_airports.length)
    apttus_airports.sample(100).each do |airport|
      expect(ijet_airports.select{|ijet_airport| ijet_airport['Airport_Id'] == airport['Airport_Id']}.first).to_not be_nil
    end
  end

  it 'matches city information from IJET to APTTUS' do
    apttus_cities = scrub_apttus_cities NjSalesforce::AirportCities.city_information
    ijet_cities = scrub_ijet_countries IJET::Airports.all_cities
    expect(apttus_cities.length).to be_within(1).percent_of(ijet_cities.length)
    apttus_cities.sample(100).each do |city|
      expect(ijet_cities.select{|ijet_city| ijet_city['City'] == city['City']}.first).to_not be_nil
    end
  end

  it 'matches state information from IJET to APTTUS' do
    apttus_states = (scrub_apttus_states NjSalesforce::AirportStates.state_information).map.map{ |item| item.values }.flatten
    ijet_states = (scrub_ijet_states IJET::Airports.all_states).map.map{ |item| item.values }.flatten
    expect(ijet_states- apttus_states).to eq(['District of Columbia'])
    expect((apttus_states - ijet_states).length).to eq(9)
  end

  it 'matches country information from IJET to APTTUS' do
    apttus_countries = (scrub_apttus_countries NjSalesforce::AirportCountries.country_information).map.map{ |item| item.values }.flatten
    ijet_countries = (scrub_ijet_countries IJET::Airports.all_countries).map.map{ |item| item.values }.flatten
    expect((apttus_countries- ijet_countries).length).to eq((ijet_countries - apttus_countries).length)
  end

  def scrub_apttus_airports(apttus_airports)
    apttus_airports.each do |record|
      record['Airport_Id'] = record.delete('Airport_Id__c')
      record['Airport_Name'] = record.delete('Name')
    end
    self.scrub_apttus_cities(apttus_airports)
  end

  def scrub_apttus_cities(apttus_cities)
    apttus_cities.each do |record|
      record['State'] = record.delete('State__c') || record.delete('Airport_State__c')
      record['Country'] = record.delete('Country__c') || record.delete('Airport_Country__c')
      record['City'] = (record.delete('Name') || record.delete('Airport_City__c'))
      record
    end
  end

  def scrub_apttus_states(apttus_states)
    apttus_states.each do |record|
      record['State'] = record.delete('Name').downcase.split.map(&:capitalize).join(' ')
      record.delete('Country__c')
      record
    end
  end

  def scrub_apttus_countries(apttus_countries)
    apttus_countries.each do |record|
      record['Country'] = record.delete('Name').downcase.split.map(&:capitalize).join(' ')
      record
    end
  end

  def scrub_ijet_airports(ijet_airports)
    ijet_airports.each do |record|
      record['Airport_Id'] = record.delete('airportid')
      record['Airport_Name'] = record.delete('airport_name')
    end
    self.scrub_ijet_countries(ijet_airports)
  end

  def scrub_ijet_countries(ijet_countries)
    ijet_countries.each { |record| record['Country'] = record.delete('country_name')}
    self.scrub_ijet_states(ijet_countries)
  end

  def scrub_ijet_states(ijet_states)
    ijet_states.each {|record| record['State'] = record.delete('state_cd') || record.delete('value') }
    self.scrub_ijet_cities(ijet_states)
  end

  def scrub_ijet_cities(ijet_cities)
    ijet_cities.each do |record|
      record['City'] = record.delete('city_name')
      record.delete('airportid')
      record.reject! {|k,v| v==nil}
      record
    end
  end

end