require 'awesome_print'
require 'spec_helper'
require 'model/aircraft/acft_aircraft_type'

describe 'aircraft types integration' do
  it 'aircraft type information between apttus and ais matches' do
    connect_to_db ENV['ENVIRONMENT'].to_sym

    ais_aircraft_data = AIS::AcftAircraftType.aircraft_list_data
    log.info "ais has #{ais_aircraft_data.size} entries"

    apttus_aircraft_data = NjSalesforce::AircraftList.aircraft_list_data
    log.info "apttus has #{apttus_aircraft_data.size} entries"

    apttus_aircraft_data = scrub_apptus_aircraft_data apttus_aircraft_data
    ais_aircraft_data = scrub_ais_aircraft_data ais_aircraft_data

    unique_elements = ais_aircraft_data - apttus_aircraft_data
    ap unique_elements
    expect(unique_elements).to be_empty

    # unique_elements = apttus_aircraft_data - ais_aircraft_data
    # expect(unique_elements).to be_empty
  end
end

def scrub_apptus_aircraft_data(aircraft_data)
  aircraft_data.map do |record|
    record['acft_aircraft_type_xref_id'] = record.delete('Aircraft_Type_Cross_Ref_Id__c')
    record['cabin_class_name'] = record.delete('Cabin_Class__c')
    record['cabin_class_rank'] = record.delete('Cabin_Class_Ranking__c')
    record['aircraft_type_name'] = record.delete('Name')
    record['aircraft_type_ranking_nbr'] = record.delete('Aircraft_Type_Ranking__c')
    record['active_status_flag'] = record.delete('Active__c')
    record
  end
end

def scrub_ais_aircraft_data(aircraft_data)
  aircraft_data.map do |record|
    record.delete('acft_aircraft_type_id')
    record['acft_aircraft_type_xref_id'] = record.delete('acft_aircraft_type_xref_id').to_f
    record['cabin_class_rank'] = record.delete('cabin_class_rnk').to_f
    record['aircraft_type_ranking_nbr'] = record.delete('aircraft_type_ranking_nbr').to_f
    record['active_status_flag'] = record.delete('active_status_flg').to_bool
    record
  end
end