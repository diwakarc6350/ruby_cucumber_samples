class Janitor
  class << self

    def add_mess(mess)
      @messes ||= []
      @messes << mess
    end

    def clean_messes
      unless @messes.nil?
        @messes.each { |mess| mess.clean }
        @messes.clear
      end
    end
  end
end

