require 'json'
require 'active_record'
require 'cgi'
require "#{File.dirname(__FILE__)}/../models/fleet_group"

class FleetGroupMess

  attr_reader :modify_fleet_group_url

  def initialize(fleet_group_name)
    fleet_group_id = FleetGroup.retrieve_fleet_group_id(fleet_group_name)
    @modify_fleet_group_url = "#{base_url}/fleetGroup/delete?fleetGroupName=" + CGI.escape(fleet_group_name) + "&fleetGroupId=" + fleet_group_id.to_s
  end

  def clean
    AISAgent.browser.get(@modify_fleet_group_url)
  end
end