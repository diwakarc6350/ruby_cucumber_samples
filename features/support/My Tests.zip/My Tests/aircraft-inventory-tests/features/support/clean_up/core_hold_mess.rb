require 'json'
require 'active_record'
require 'cgi'
require "#{File.dirname(__FILE__)}/../models/hold"

class CoreHoldMess

  attr_reader :modify_hold_url

  def initialize(acft_tail_no)
    hold_id = Hold.retrieve_core_hold_id(acft_tail_no)
    @modify_hold_url = "#{base_url}/hold/deleteLglHold?holdId=" + hold_id.to_s + "&aircraftId="
  end

  def clean
    AISAgent.browser.get(@modify_hold_url)
  end
end