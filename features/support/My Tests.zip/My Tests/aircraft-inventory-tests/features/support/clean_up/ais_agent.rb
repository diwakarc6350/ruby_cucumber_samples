require 'json'
require 'mechanize'

class AISAgent
  class << self

    attr_reader :agent

    def browser
      return @agent unless @agent.nil?
      authenticate
    end

    private
    def authenticate
      agent = Mechanize.new
      agent.verify_mode = OpenSSL::SSL::VERIFY_NONE
      login_form = agent.get(base_url).form(class: 'form-horizontal')
      login_form.field(id: 'username').value = USER_MAP[:"AIS Administrator"].fetch(:user)
      login_form.field(id: 'password').value = USER_MAP[:"AIS Administrator"].fetch(:password)
      agent.submit(login_form, login_form.buttons.first)
      @agent = agent
    end
  end

end
