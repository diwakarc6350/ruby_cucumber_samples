require 'json'
require 'active_record'
require "#{File.dirname(__FILE__)}/../../support/actions/common_actions"
class AircraftMess

  attr_reader :aircraft_tail_number

  def initialize(tail_number)
    @aircraft_tail_number = tail_number
  end

  def clean
    login_to_AIS
    goto_aircraft_inventory_administration
    on_page(InventoryAdministration) do |p|
      p.aircrafts = @aircraft_tail_number
      p.wait_for_ajax
      p.edit_ac
      p.aircraft_states = 'ID\'d for Disposal'
      p.aircraft_decommission_dt = Time.new.strftime('%m/%d/%Y')
      p.aircraft_contracts_until_dt = Time.new.strftime('%m/%d/%Y')
      p.update_aircraft
    end
  end
end