require 'json'
require 'active_record'
require 'cgi'
require "#{File.dirname(__FILE__)}/../models/fleet_group"

class AircraftTypeMess

  attr_reader :modify_aircraft_type_url

  def initialize(aircraft_type_name)
    aircraft_type_id = AircraftType.retrieve_aircraft_type_id(aircraft_type_name)
    @modify_aircraft_type_url = "#{base_url}/maintenance/inactivateACType?acTypeIdHidden=" + aircraft_type_id.to_s
  end

  def clean
    AISAgent.browser.get(@modify_aircraft_type_url)
  end
end