$LOAD_PATH << File.dirname(__FILE__)+"/pages/sub_pages"
$LOAD_PATH << File.dirname(__FILE__)+"/pages/sqls"
$LOAD_PATH << Dir.pwd
$LOAD_PATH << Dir.pwd + '/features/support'

require 'page-object'
require 'models/acft_cabin_class'
require 'sync_tolerance'

AIS_ENVIRONMENT = {
    :ci => 'http://amdev01:6380',
    :ci2 => 'http://amdev01:6380',
    :qa => 'https://aircraftinventoryqa.netjets.com',
    :itg => 'https://aircraftinventoryitg1.netjets.com',
    :itg2 => 'https://aircraftinventoryitg2.netjets.com',
    :local => 'localhost:8080/aircraft-inventory-web',
    :local2 => 'localhost:8080/aircraft-inventory-web'
}

def base_url
  env_to_test = ENV['ENVIRONMENT']
  AIS_ENVIRONMENT[env_to_test.to_sym] || AIS_ENVIRONMENT[:local]
end

puts "Using #{ENV['ENVIRONMENT']} to test..."
puts "Using #{base_url} as base url to test..."

PageObject.javascript_framework = :jquery