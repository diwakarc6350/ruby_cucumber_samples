module AircraftInventoryActions

  # Returns the first tail number from the Aircraft Inventory table
  #
  # @return [String] The first tail number on the Aircraft Inventory table
  def return_first_tail
    on(AircraftInventory).raw_aircraft_inventory[1].tail_no_element.text
  end

  # Searches the inventory for the provided aircraft tail number
  #
  # @param [String] aircraft The tail number to be searched
  def search_inventory(aircraft)
    on(AircraftInventory).tail_number = aircraft
    @browser.send_keys :enter
    on(AircraftInventory).wait_for_ajax
  end

  def inventory_is_filtered_by_tail?(aircraft)
    on(AircraftInventory).raw_aircraft_inventory[1].tail_no_element.text == aircraft
  end

end

World(AircraftInventoryActions)