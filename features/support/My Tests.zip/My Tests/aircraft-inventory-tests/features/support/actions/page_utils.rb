module PageUtils
  def get_value(field)
    field.strip == '' ? nil : field.strip
  end
end