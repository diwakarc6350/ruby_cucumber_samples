module InventorySettingsActions
  def navigate_to_aircraft_inventory_settings
    on(HomePage).inventory
    on(AircraftInventory).administration
    on(InventoryAdministration).edit_settings
    on(Settings).wait_for_ajax
  end

  def current_aircraft_inventory_settings
    on(Settings).current_aircraft_inventory_settings
  end

  def update_single_value_in_aircraft_inventory_settings
    #this line of code chooses a value in the range 10-25, but makes sure to take out whatever the current value is
    new_value = ((10..25).to_a - [on(Settings).max_legal_hold_duration.to_i]).sample
    on(Settings).max_legal_hold_duration = new_value
    current_aircraft_inventory_settings
  end

  def update_multiple_values_in_aircraft_inventory_settings
    #this line of code chooses a value in the range 10-25, but makes sure to take out whatever the current value is
    new_value = ((10..25).to_a - [on(Settings).max_legal_hold_duration.to_i]).sample
    new_disposal_value = ((10..25).to_a - [on(Settings).identified_for_disposal_threshold.to_i]).sample
    on(Settings).max_legal_hold_duration = new_value
    on(Settings).identified_for_disposal_threshold = new_disposal_value
    current_aircraft_inventory_settings
  end

  def update_max_legal_hold_duration_to_be_invalid
    @errors = Hash.new()
    on(Settings).max_legal_hold_duration = -1
    on(Settings).save
    sleep 1
    @errors[-1] = on(Settings).error_message
    on(Settings).max_legal_hold_duration = 0
    on(Settings).save
    sleep 1
    @errors[0] = on(Settings).error_message
  end

  def update_identified_for_disposal_threshold_to_be_invalid
    @errors = Hash.new()
    on(Settings).identified_for_disposal_threshold = -1
    on(Settings).save
    sleep 1
    @errors[-1] = on(Settings).error_message
    on(Settings).identified_for_disposal_threshold = 0
    on(Settings).save
    sleep 1
    @errors[0] = on(Settings).error_message
    on(Settings).identified_for_disposal_threshold = 37
    on(Settings).save
    sleep 1
    @errors[37] = on(Settings).error_message
  end

  def save_aircraft_inventory_settings
    on(Settings).save
  end

  def cancel_aircraft_inventory_settings
    on(Settings).cancel
  end

  def is_aircraft_inventory_settings_changed_confirmation_present?
    on(Settings).confirm_settings_saved?
  end

  def dismiss_settings_changed_confirmation
    on(Settings).confirm_settings_saved
  end

  def create_aircraft_for_holds
    on_page(InventoryAdministration) do |p|
      p.create_holds_aircraft
      p.aircraft_aircraft_types = p.aircraft_aircraft_types_options[2]
      p.populate_page_with p.data_for(:hold_test_aircraft)
      p.aircraft_save
    end
  end

  def place_hold_past_maximum_duration
    on_page(AircraftHoldSearch).hold_search
    place_legal_acft_hold_with_end_date_no_del(self.data_for(:hold_test_aircraft)['aircraft_tail_no'], 25,
                                               self.data_for(:aircraft_view_holds)['hold_notes'],
                                               1000.days_from_today(format = '%m/%d/%Y'))
  end

end

World InventorySettingsActions