module CommonActions
  def open_first_tail_details
    on_page AircraftInventory do |p|
      p.inventory
      p.tail_number = p.data_for(:aircraft_view_holds)['tail_with_more_holds']
      p.search
      p.select_aircraft_tail(1)
    end
  end

  def goto_aircraft_inventory_administration
    on_page(AircraftInventory).inventory
    on_page(AircraftInventory).administration
  end

  def open_aircraft_type_mapping
    on(AircraftInventory).aircraft_type_mapping
  end

  def edit_ais_aircraft_ijet_mapping(ais_aircraft_type,ijet_aircraft_type)
    on(AircraftTypeMappingPage) do |page|
      page.ais_aircraft_types = ais_aircraft_type
      page.ijet_aircraft_types = ijet_aircraft_type
      page.save
      page.wait_for_ajax
    end
  end

  def place_core_aircraft_hold(tail_number, percent_hold, notes)
    on_page AircraftDetail do |p|
      p.delete_acft_holds(tail_number)
    end

    place_core_acft_hold_no_del(tail_number, percent_hold, notes)
  end

  def place_legal_aircraft_hold(tail_number, percent_hold, notes)
    on_page AircraftDetail do |p|
      p.delete_acft_holds(tail_number)
    end

    place_legal_acft_hold_no_del(tail_number, percent_hold, notes)
  end

  def place_core_acft_hold_no_del(tail_number, percent_hold, notes)
    on_page AircraftInventory do |p|
      p.inventory
      p.select_aircraft_by_tail(tail_number)
    end

    on_page AircraftDetail do |p|
      p.place_hold
      p.legal_hold_interest_size = percent_hold
      p.hold_type = 'Core'
      p.hold_end_date = p.data_for(:aircraft_legal_holds)['hold_end_date']
      p.legal_notes = notes
      p.save_legal_hold
      p.confirm_hold
    end
  end

  def place_legal_acft_hold_no_del(tail_number, percent_hold, notes)
    on_page AircraftInventory do |p|
      p.inventory
      p.select_aircraft_by_tail(tail_number)
    end

    on_page AircraftDetail do |p|
      p.place_hold
      if p.text.include? "Select Hold Type"
        p.hold_type = 'Legal'
      end
      p.legal_hold_interest_size = percent_hold
      p.hold_end_date = p.data_for(:aircraft_legal_holds)['hold_end_date']
      p.legal_notes = notes
      p.save_legal_hold
      p.confirm_hold
    end
  end

  def place_legal_acft_hold_with_end_date_no_del(tail_number, percent_hold, notes, hold_end_date)
    on_page AircraftInventory do |p|
      p.inventory
      p.select_aircraft_by_tail(tail_number)
    end

    on_page AircraftDetail do |p|
      p.place_hold
      p.hold_type = 'Legal'
      p.legal_hold_interest_size = percent_hold
      p.hold_end_date = hold_end_date
      p.legal_notes = notes
    end
  end

  def login_as_admin
    visit_page LoginPage
    on_page LoginPage do |login_page|
      login_page.login_as('AIS Administrator')
    end
  end

  def login_to_AIS(role='AIS Administrator')
    visit(LoginPage).login_as(role)
  end

end

World(CommonActions)