require 'active_record'
require 'data_magic'

$CLASSPATH << "#{File.dirname(__FILE__)}/lib/ojdbc6-11.2.0.3.jar"

# loads the test data's. we tell data magic where our test data folder is located,
# and we load all the data files from that folder.
DataMagic.yml_directory = 'features/support/data'
Dir.entries(DataMagic.yml_directory).delete_if { |x| x=='.' || x=='..' }.each { |f| DataMagic.load(f) }

ENV['ENVIRONMENT'] ||= 'local'

case ENV['ENVIRONMENT'].to_sym
  when :qa
    $ais_con = ActiveRecord::Base.establish_connection(
        :adapter => 'jdbc',
        :username => 'aircraft_app_user',
        :password => 'pr0p4g4t3',
        :driver => 'oracle.jdbc.driver.OracleDriver',
        :url =>   "jdbc:oracle:thin:@(DESCRIPTION=
                  (CONNECT_TIMEOUT=5)
                  (TRANSPORT_CONNECT_TIMEOUT=3)
                  (RETRY_COUNT=3)
                  (LOAD_BALANCE=on)
                  (FAILOVER=on)
                  (ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)
                  (HOST=cexa-scan)
                  (PORT=1521))
                  (ADDRESS=(PROTOCOL=TCP)(HOST=bexa-scan)(PORT=1521)))
                  (CONNECT_DATA=(SERVICE_NAME=EDRThinQAT.netjets.com)))")
  when :itg2, :local2, :ci2
    $ais_con = ActiveRecord::Base.establish_connection(
        :adapter => 'jdbc',
        :username => 'aircraft_app_user',
        :password => 'tr4nsm1t',
        :driver => 'oracle.jdbc.driver.OracleDriver',
        :url => "jdbc:oracle:thin:@
                 (DESCRIPTION_LIST=
                 (LOAD_BALANCE=off)
                 (FAILOVER=on)
                 (DESCRIPTION=
                 (ADDRESS_LIST=
                 (LOAD_BALANCE=on)
                 (ADDRESS=(PROTOCOL=TCP)(HOST=cexa-scan)(PORT=1521)))
                 (CONNECT_DATA=(SERVICE_NAME=Ijet2ThinDv5.netjets.com))))")
  when :itg, :ci, :local, :itg1
    $ais_con = ActiveRecord::Base.establish_connection(
        :adapter => 'jdbc',
        :username => 'aircraft_app_user',
        :password => 'tr4nsm1t',
        :driver => 'oracle.jdbc.driver.OracleDriver',
        :url => "jdbc:oracle:thin:@
                 (DESCRIPTION=(CONNECT_TIMEOUT=5)
                  (TRANSPORT_CONNECT_TIMEOUT=3)(RETRY_COUNT=3)
                  (LOAD_BALANCE=on)
                  (FAILOVER=on)
                  (ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=cexa-scan)(PORT=1521))
                  (ADDRESS=(PROTOCOL=TCP)(HOST=bexa-scan)(PORT=1521)))
                  (CONNECT_DATA=(SERVICE_NAME=EDRThinITG1.netjets.com))))
              ")
  #puts ($ais_con.connection.methods - Object.methods).sort
end

puts "Using #{$ais_con.connection.current_database} as database"

def db_conn_ais
  $ais_con
end

# Login related data
INVALID_USER = {:user => 'nouser', :password => 'somepassword'}
USER_WITH_INVALID_PASSWORD = {:user => 'qtest3', :password => 'invalid-password'}
USER_MAP ={
    :'AIS Insurance Administrator' => {:user => "qatest4", :password => "DeP@rture1"},
    :'AIS Unauthorized User' => {:user => 'qatest5', :password => 'somepassword'},
    :'AIS Administrator' => {:user => "qatest1", :password => "DeP@rture1"},
    :'AIS Sales User' => {:user => "qatest20", :password => "DeP@rture1"},
    :'AIS User' => {:user => "qatest2", :password => "DeP@rture1"}
}