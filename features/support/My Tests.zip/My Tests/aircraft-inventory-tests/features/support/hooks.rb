require 'watir-webdriver'

browser = Watir::Browser.new :chrome
browser.driver.manage.window.maximize
@browser = browser

Before do
  begin
    @browser = browser
  rescue => e
    puts e
  end
end

After do |scenario|
  begin
    @browser.cookies.clear
    if scenario.failed?
      Dir::mkdir('screenshots') if not File.directory?('screenshots')
      screenshot = "./screenshots/FAILED_#{scenario.name.gsub(' ', '_').gsub(/[^0-9A-Za-z_]/, '')}.png"
      @browser.screenshot.save(screenshot)
      embed screenshot, 'image/png'
    end
    edit_ais_aircraft_ijet_mapping(@ais_aircraft_type,'---- None ----') if scenario.tags.first.name == '@mapping'
  rescue => e
    puts e
  end
  Janitor.clean_messes
  stock.empty
  @browser.goto "#{base_url}/j_spring_security_logout"
end
#
# AfterStep do |scenario, step|
# sleep 1
# end

at_exit do
  @browser.close
  db_conn_ais.disconnect!
end