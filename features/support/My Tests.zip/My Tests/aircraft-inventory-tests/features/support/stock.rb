class Stock
  def initialize
    @attributes = {}
  end

  def method_missing(method, *args)
    attribute = method.to_s
    if attribute =~ /=$/
      @attributes[attribute.chop] = args[0]
    else
      @attributes[attribute]
    end
  end
end

module StockHelper
  def stock
    @stock ||= Stock.new
  end

  def empty
    @stock = nil
  end

  alias_method :clear, :empty
end

World(StockHelper)