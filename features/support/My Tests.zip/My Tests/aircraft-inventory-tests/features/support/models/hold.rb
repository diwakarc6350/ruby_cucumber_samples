require 'active_record'

class Hold < ActiveRecord::Base
  self.table_name = 'acft_owner.acft_hold'

  def self.retrieve_legal_hold_id(acft_tail_number)
          FleetGroup.find_by_sql("select ac.ACFT_HOLD_ID from acft_hold ac
                                  join acft_aircraft a on a.acft_aircraft_id = ac.acft_aircraft_id
                                  where ac.is_deleted_flg = 'F'
                                  and a.aircraft_tail_nbr = '#{acft_tail_number}'
                                  and ac.HOLD_TYPE_CD = '16'
                                  order by ac.placed_ts desc").first.acft_hold_id.to_i
  end

  def self.retrieve_core_hold_id(acft_tail_number)
    FleetGroup.find_by_sql("select ac.ACFT_HOLD_ID from acft_hold ac
                                  join acft_aircraft a on a.acft_aircraft_id = ac.acft_aircraft_id
                                  where ac.is_deleted_flg = 'F'
                                  and a.aircraft_tail_nbr = '#{acft_tail_number}'
                                  and ac.HOLD_TYPE_CD = '18'
                                  order by ac.placed_ts desc").first.acft_hold_id.to_i
  end

end