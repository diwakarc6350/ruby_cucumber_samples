require 'active_record'

class FleetGroup < ActiveRecord::Base
  self.table_name = 'acft_owner.acft_fleet_group'
  self.sequence_name = 'acft_owner.s_acft_fleet_group'

  def self.retrieve_fleet_group_id(fleet_group_name)
    FleetGroup.find_by_sql("select ac.ACFT_FLEET_GROUP_ID from acft_fleet_group ac
    where ac.FLEET_GROUP_NAME = '#{fleet_group_name}'").first.acft_fleet_group_id.to_i
  end

end