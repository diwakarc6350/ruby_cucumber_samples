require 'active_record'

class AircraftType < ActiveRecord::Base
  self.table_name = 'acft_owner.acft_aircraft_type'

  def self.retrieve_aircraft_type_id(aircraft_type_name)
    AircraftType.find_by_sql("select ac.ACFT_AIRCRAFT_TYPE_ID from acft_aircraft_type ac
    where ac.aircraft_type_name = '#{aircraft_type_name}'").first.acft_aircraft_type_id.to_i
  end

  def self.ais_aircrafts_with_no_mappings
    self.find_by_sql("select aat.AIRCRAFT_TYPE_NAME from ACFT_AIRCRAFT_TYPE aat
                                                    where aat.ACFT_AIRCRAFT_TYPE_ID not in (select aatx.ACFT_AIRCRAFT_TYPE_ID from ACFT_AIRCRAFT_TYPE_XREF aatx)").sample['aircraft_type_name']
  end

  def self.ijet2_aircrafts_with_no_mappings
    type = self.find_by_sql("select iat.typename from IJET.AIRCRAFT_TYPE iat
                                                      where iat.NETJETS_FLAG = 'T'
                                                      and iat.typename not in (select atx.type_name from ACFT_AIRCRAFT_TYPE_XREF atx)")

    type.sample['typename'] unless type.empty?
  end

end