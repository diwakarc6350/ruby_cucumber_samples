require 'active_record'

class AcftCabinClass < ActiveRecord::Base
  self.table_name = 'acft_owner.acft_cabin_class'
end