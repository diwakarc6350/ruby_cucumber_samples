require 'page-object'
require 'audit_log'
require 'aircraft_type'
require_relative '../sections/aircraft_type_rankings_section'

module AircraftTypes
  include PageObject
  include AircraftTypeData

  page_sections(:aircraft_type_rankings, AircraftTypeRankingsSection, xpath: '//*[@id="typeRankingTable"]/tbody/tr')

  select_list(:fleet_group, :id => 'acTypeFleetGroupSel')
  text_field(:aircraft_type_name, :id => 'acTypeTxt')
  select_list(:cabin_class, :id => 'aircraftCabinClassSel')
  select_list(:sales_status, :id => 'saleStatusSel')
  text_field(:manufacturer, :id => 'manufacturerTxt')
  text_field(:legal_model_name, :id => 'legalModelNameTxt')
  select_list(:no_of_engines, :id => 'noOfEnginesSel')
  #text_field(:aircraft_type_status, :id => 'aircraftTypeStatus')
  text_field(:rank, :name => 'acTypeRanking')
  text_area(:notes, :id => 'notesTxtArea')

  #create aircraft type page elements
  button(:cancel_at_type_save, :id => 'createAcftTypeCancel')
  button(:save_ac_type, :id => 'createAcftTypeSave')

  #edit aircraft type page elements
  button(:cancel_ac_type_edit, :id => 'editATCancel')
  button(:confirm_ac_type_edit, :id => 'createAcftTypeSave')
  button(:edit_ac_type_ok, :id => 'confirmATOk')
  button(:edit_ac_type, :id => 'editACtype')

  #inactivate page elements
  button(:inactivate_ac_type, :name => 'inactivateAT')
  button(:cancel_ac_type_inactivate, :id => 'confirmCancel')
  button(:confirm_ac_type_inactivate, :id => 'confirmInactivate')

  button(:inactivate, :id => "deleteACType")
  button(:delete, :id => "confirmACTypesDelete")

  def create_aircraft_type
    sql = self.delete_aircraft_type_sql(self.data_for(:aircraft_type_create)['aircraft_type_name'])
    db_conn_ais.connection.execute(sql)
    sql = delete_log_sql('Create', 'Aircraft Type', self.data_for(:aircraft_type_create)['aircraft_type_name'],
                         USER_MAP['AIS Administrator'.to_sym][:user])
    db_conn_ais.connection.execute(sql)
    sql = delete_log_sql('Update', 'Aircraft Type', self.data_for(:aircraft_type_edit)['aircraft_type_name'],
                         USER_MAP['AIS Administrator'.to_sym][:user])
    db_conn_ais.connection.execute(sql)
    sql = delete_log_sql('Delete', 'Aircraft Type', self.data_for(:aircraft_type_create)['aircraft_type_name'],
                         USER_MAP['AIS Administrator'.to_sym][:user])
    db_conn_ais.connection.execute(sql)
    self.new_aircraft_type
    self.wait_until { self.text.include? "Create Aircraft Type" }
  end

  def save_aircraft_type(confirm=true)
    self.save_ac_type
    if confirm
      self.wait_until { self.text.include? "ACType created successfully" }
      sleep 2
    end
  end

  def cancel_aircraft_type
    self.cancel_at_type_save
    self.wait_until { !self.text.include? "Create Aircraft Type" }
  end

  def edit_aircraft_type
    self.edit_ac_type
    self.wait_until { (self.text.include? "Edit Aircraft Type") || (self.text.include? "Fleet Group:") && (self.text.include? "Aircraft Type Rankings:")}
  end

  def update_aircraft_type
    self.confirm_ac_type_edit
  end

  def cancel_edit_aircraft_type
    self.cancel_ac_type_edit
  end

  def inactivate_aircraft_type
    self.inactivate_ac_type
  end

  def inactivate_aircraft
    self.wait_until {self.text.include? "Are you sure you wish to Inactivate the Aircraft-Type ?"}
  end

  def clean_aircraft_type
    sql = self.delete_aircraft_type_sql(self.data_for(:aircraft_type_create)['aircraft_type_name'])
    db_conn_ais.connection.execute(sql)
  end

end