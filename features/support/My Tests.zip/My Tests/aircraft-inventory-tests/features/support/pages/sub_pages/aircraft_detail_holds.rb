require 'page-object'
require 'audit_log'
require 'aircraft_holds_data'
require 'date'
require 'watir-scroll'

module AircraftDetailHolds
  include PageObject
  include AircraftHoldsData

  table(:current_holds, :id => 'currentHoldsTable')
  link(:show_all_holds, :id => 'seeMoreRecords')

  indexed_property(:raw_current_holds, [
                                         [:cell, :hold_type, {:xpath => '//*[@id="currentHoldsTable"]/tbody/tr[position()="%s"]/td[1]'}],
                                         [:cell, :interest_size, {:xpath => '//*[@id="currentHoldsTable"]/tbody/tr[position()="%s"]/td[2]'}],
                                         [:cell, :placed_by, {:xpath => '//*[@id="currentHoldsTable"]/tbody/tr[position()="%s"]/td[3]'}],
                                         [:cell, :placed_on, {:xpath => '//*[@id="currentHoldsTable"]/tbody/tr[position()="%s"]/td[4]'}],
                                         [:cell, :expiration_date, {:xpath => '//*[@id="currentHoldsTable"]/tbody/tr[position()="%s"]/td[5]'}],
                                         [:link, :notes, {:xpath => '//*[@id="currentHoldsTable"]/tbody/tr[position()="%s"]/td[6]'}],
                                         [:link, :edit, {:xpath => '//*[@id="currentHoldsTable"]/tbody/tr[position()="%s"]/td[7]'}],
                                         [:link, :delete, {:xpath => '//*[@id="currentHoldsTable"]/tbody/tr[%s]/td[8]'}],
                                     ])
  cell(:no_hold_notes, :xpath => '//*[@id="currentHoldsTable"]/tbody/tr/td[6]')

  def actual_current_holds
    holds = []
    (1..(self.current_holds_count)-1).each do |i|
      hold = {}
      self.raw_current_holds[i].hold_type == 'NA' ? hold['hold_type'] = nil :
          hold['hold_type'] = self.raw_current_holds[i].hold_type
      self.raw_current_holds[i].interest_size == 'NA' ? hold['interest_size'] = nil :
          hold['interest_size'] = self.raw_current_holds[i].interest_size.delete("%").to_s
      self.raw_current_holds[i].placed_by == 'NA' ? hold['placed_by'] = nil :
          hold['placed_by'] = self.raw_current_holds[i].placed_by
      self.raw_current_holds[i].placed_on == 'NA' ? hold['placed_on'] = nil :
          hold['placed_on'] = self.raw_current_holds[i].placed_on
      self.raw_current_holds[i].expiration_date == 'NA' ? hold['expiration_date'] = nil :
          if self.raw_current_holds[i].expiration_date == ""
            hold['expiration_date'] = nil
          else
            hold['expiration_date'] = self.raw_current_holds[i].expiration_date
          end
      holds << hold
    end
    holds
  end

  def edit_first_hold
    edit_first_hold_link = browser.link(:xpath => '//*[@id="currentHoldsTable"]/tbody/tr/td[7]/a')
    browser.scroll.to edit_first_hold_link
    edit_first_hold_link.click
  end

  def view_hold_notes()
    self.raw_current_holds[1].notes
  end

  def delete_first_hold
    sleep 1
    first_hold_delete_link = browser.link(:xpath => '//*[@id="currentHoldsTable"]/tbody/tr/td[8]/a')
    browser.scroll.to first_hold_delete_link
    first_hold_delete_link.click
    self.wait_until { (self.text.include? "Are you sure you wish to delete the selected Hold ?") }
  end

  def expected_current_holds
    sql = expected_current_holds_sql(self.tail_no.strip)
    all_holds = db_conn_ais.connection.execute(sql)
    all_holds.select { |rec| rec['expiration_date'].to_date >= DateTime.now.to_date }
  end

  def expected_current_holds_by_tail(tail_number)
    sql = expected_current_holds_sql(tail_number.to_s)
    all_holds = db_conn_ais.connection.execute(sql)
    unless all_holds.empty?
      if all_holds[0]['expiraton_date'] != nil
        all_holds.select { |rec| rec['expiration_date'].to_date >= DateTime.now.to_date }
      else
        return all_holds
      end
    end
    all_holds

  end

  def current_holds_count
    count = 0
    sleep(1)
    self.current_holds_element.each { |x| count+=1 } if self.current_holds_element.exists?
    count
  end

  def expired_holds?
    hold_expired = false
    today = DateTime.now.to_date
    (1..(self.current_holds_count)-1).each do |i|
      expiration_date = self.raw_current_holds[i].expiration_date
      exp_dt = expiration_date.to_date
      if exp_dt!=nil and exp_dt < today
        hold_expired = true
        break
      end
    end
    hold_expired
  end

  def show_more_holds
    script = <<-JS.gsub(/^ {16}/, '')
                el = document.getElementById('seeMoreRecords')
                el.scrollIntoView(true)
    JS
    @browser.execute_script script
    self.show_all_holds
  end

  def sort_by_hold_type
    self.current_holds_element[0][0].click
  end

  def sort_by_interest_size
    self.current_holds_element[0][1].click
  end

  def sort_by_placed_by
    self.current_holds_element[0][2].click
  end

  def sort_by_placed_on
    self.current_holds_element[0][3].click
  end

  def sort_by_expiration_date
    self.current_holds_element[0][4].click
  end

  def sorted_hold_type
    actual_current_holds.map { |v| v['hold_type'] }
  end

  def sorted_interest_size
    actual_current_holds.map { |v| v['interest_size'] }
  end

  def sorted_placed_by
    actual_current_holds.map { |v| v['placed_by'] }
  end

  def sorted_placed_on
    actual_current_holds.map { |v| v['placed_on'] }.select { |x| !x.nil? }.map { |x| x.to_datetime }
  end

  def sorted_expiration_date
    actual_current_holds.map { |v| v['expiration_date'] }.select { |x| !x.nil? }.map { |x| x.to_datetime }
  end

  def cleanup_holds
    sql = delete_holds_sql
    db_conn_ais.connection.execute(sql)
  end

  def setup_holds
    sql = insert_holds_sql
    db_conn_ais.connection.execute(sql)
  end

  def show_first_notes
    script = <<-JS.gsub(/^ {16}/, '')
      window.scrollTo(0, document.body.scrollHeight);
    JS
    @browser.execute_script script
    self.current_holds_element[1][5].click
  end

  def sum_holds
    sum_holds = 0
    self.show_all_holds_element.visible? ? self.show_all_holds : ''
    (1..(self.current_holds_count)-1).each do |i|
      sum_holds += raw_current_holds[i].interest_size.delete("%").to_f
    end
    sum_holds
  end

  def tail_is_held_correctly(interest_size, hold_type)
    result = []
    self.actual_current_holds.each {|hold| result << (hold['interest_size'] == interest_size && hold['hold_type'] == hold_type)}
    (result.uniq.length == 1 && result.uniq[0] == true)
  end

end