require 'page-object'

module FleetGroups
  include PageObject
  include SyncTolerance

  text_field(:fleet_group_name, :id => 'fleetGroupName')
  text_field(:edit_fleet_group_name, :id => 'fleetGroupNameEdit')

  #create fleet group page elements
  button(:cancel_fleet_group_save, :id => 'createFGCancel')
  button(:save, :id => 'createFGSave')
  button(:ok, :id => 'createFGOk')

  #delete fleet group page elements
  button(:delete_fg, :name => 'deleteFG')
  button(:cancel_delete, :id => 'confirmCancel')
  button(:confirm_delete, :id => 'confirmDelete')
  button(:close_delete, :id => 'deleteClose')

  #edit fleet group page elements
  button(:cancel_edit, :id => 'editFGCancel')
  button(:confirm_edit, :id => 'editFGUpdate')
  button(:edit_ok, :id => 'confirmFGOk')
  button(:edit, :id => 'editFG')

  #disassociate fleet group page elements
  button(:cancel_disassociate, :id => 'confirmACTypesCancel')
  button(:confirm_disassociate, :id => 'confirmACTypesDelete')

  div(:error_dialogue, id: 'errorDialogEdit')

  def create_fleet_group
    sql = delete_log_sql('Create', 'Fleet Group', self.data_for(:fleet_groups)['valid'],
                         USER_MAP['AIS Administrator'.to_sym][:user])
    db_conn_ais.connection.execute(sql)
    self.new_fleet_group
    self.wait_until { self.text.include? "Create Fleet Group" }
  end

  def save_fleet_group(confirm=true, delay=true)
    self.save
    if confirm && delay
      self.wait_until { self.text.include? "The Fleet Group has been created successfully." }
      self.ok
    end
  end

  def cancel_fleet_group
    self.cancel_fleet_group_save
    self.wait_until { !self.text.include? "Create Fleet Group" }
  end

  def delete_fleet_group
    sql = delete_log_sql('Delete', 'Fleet Group', self.data_for(:fleet_groups)['edit'],
                         USER_MAP['AIS Administrator'.to_sym][:user])
    db_conn_ais.connection.execute(sql)
    self.wait_until { (self.text.include? "Fleet Group Name:") }
    self.delete_fg
    self.wait_until { (self.text.include? "Are you sure you wish to delete the selected Fleet Group ?") &&
        (self.text.include? "Delete Fleet Group") }
    self.confirm_delete
    self.wait_until { (self.text.include? "The Fleet Group has been successfully deleted.") &&
        (self.text.include? "Fleet Group Deleted") }
    self.close_delete
  end

  def delete_fleet_group_with_sql(fleet_group)
    sql = delete_fleet_group_sql(fleet_group)
    db_conn_ais.connection.execute(sql)
  end

  def cancel_fleet_group_delete
    self.wait_until { (self.text.include? "Fleet Group Name:") }
    self.delete_fg
    self.wait_until { (self.text.include? "Are you sure you wish to delete the selected Fleet Group ?") &&
        (self.text.include? "Delete Fleet Group") }
    self.cancel_delete
  end

  def edit_fleet_group(name, disassociate, cancel)
    self.wait_until { (self.text.include? "Fleet Group Name:") }
    self.edit
    self.wait_until {
      (self.text.include? "Fleet Group Name:") &&
          (self.text.include? "Edit Fleet Group") }
    self.edit_fleet_group_name = name if name != nil
    @browser.i(:class => 'removeIcon').click if disassociate
    if cancel != nil
      if cancel
        self.cancel_edit
      else
        self.confirm_edit
        self.wait_until { self.text.include? "The edits you have made have been successfully saved." }
        self.edit_ok
      end
    else
      self.confirm_edit
    end
  end

  def edit_fleet_group_with_name(old_name, new_name)
    self.fleet_groups = old_name
    sleep 1
    self.edit
    sleep 1
    self.edit_fleet_group_name = new_name
    self.confirm_edit
    sleep 1
    self.edit_ok
  end

end