module AircraftHoldsData
  def expected_current_holds_sql(tail)
    <<-SQL.gsub(/^ {6}/, '')
      select hcode.code_type_name as hold_type, hold_pct as interest_size, held_by_userid as placed_by,
      to_char(placed_ts,'DD Mon YYYY')  as placed_on, to_char(expiration_ts,'DD Mon YYYY') as expiration_date
      from acft_hold h
      join acft_aircraft a
      on a.acft_aircraft_id = h.acft_aircraft_id
      join ACFT_CODE_TYPE hcode
      on h.hold_type_cd = hcode.acft_code_type_id
      where a.aircraft_tail_nbr = '#{tail}'
      order by placed_on desc
    SQL
  end

  def hold_settings_sql
    <<-SQL.gsub(/^ {6}/, '')
      select * from acft_ais_app_settings
    SQL
  end

  def delete_holds_sql
    <<-SQL.gsub(/^ {6}/, '')
      delete from acft_hold where acft_aircraft_id = 34
    SQL
  end

end