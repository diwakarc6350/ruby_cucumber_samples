require 'page-object'

module Header
  include PageObject

  button(:btn_home, :id => "home")
  button(:btn_inventory, :id => "inventory")
  button(:btn_hold_search, :id => "hold")
  link(:lnk_logout, :href => "/j_spring_security_logout")

  def header_integral?
    self.btn_home_element.present?&&
        self.lnk_logout_element.present?
  end

  def logout
    self.lnk_logout
  end

  def inventory
    self.btn_inventory
    sleep 2
  end

  def hold_search
    self.btn_hold_search
    sleep 2
  end

  def inventory_exists?
    self.btn_inventory_element.exists?
  end

  def home
    self.btn_home
  end

end