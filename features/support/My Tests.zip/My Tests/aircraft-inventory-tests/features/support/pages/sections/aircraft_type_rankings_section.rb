class AircraftTypeRankingsSection
  include PageObject

  td(:aircraft_type, index: 0)
  td(:rank, index: 1)

end

