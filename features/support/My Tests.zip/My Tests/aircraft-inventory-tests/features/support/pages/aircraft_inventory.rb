require 'page-object'
require 'header'
require 'aircraft_data'
require 'watir-scroll'

class AircraftInventory
  include PageObject
  include Header
  include DataMagic
  include AircraftData
  include PageUtils

  indexed_property(:raw_aircraft_inventory, [
                                              [:cell, :fleet_group, {:xpath => '//*[@id="inventoryResultsTable"]/tbody/tr[position()="%s"]/td[1]'}],
                                              [:link, :ac_type, {:xpath => '//*[@id="inventoryResultsTable"]/tbody/tr[position()="%s"]/td[2]/u/a'}],
                                              [:cell, :ac_state, {:xpath => '//*[@id="inventoryResultsTable"]/tbody/tr[position()="%s"]/td[3]'}],
                                              [:cell, :vintage, {:xpath => '//*[@id="inventoryResultsTable"]/tbody/tr[position()="%s"]/td[4]'}],
                                              [:link, :tail_no, {:xpath => '//*[@id="inventoryResultsTable"]/tbody/tr[position()="%s"]/td[5]/u/a'}],
                                              [:cell, :contracts_until, {:xpath => '//*[@id="inventoryResultsTable"]/tbody/tr[position()="%s"]/td[7]'}],
                                              [:cell, :warranty, {:xpath => '//*[@id="inventoryResultsTable"]/tbody/tr[position()="%s"]/td[8]'}],
                                              [:cell, :percent_available, {:xpath => '//*[@id="inventoryResultsTable"]/tbody/tr[position()="%s"]/td[9]'}],
                                              [:cell, :percent_on_hold, {:xpath => '//*[@id="inventoryResultsTable"]/tbody/tr[position()="%s"]/td[11]'}],
                                              [:cell, :company, {:xpath => '//*[@id="inventoryResultsTable"]/tbody/tr[position()="%s"]/td[12]'}],
                                              [:cell, :sales_status, {:xpath => '//*[@id="inventoryResultsTable"]/tbody/tr[position()="%s"]/td[13]'}]
                                          ])
  select_list(:fleet_groups, :id => 'fleetGroupSel')
  select_list(:aircraft_types, :id => 'aircraftTypeName')
  select_list(:company, :name => 'company')
  select_list(:aircraft_states, :id => 'aircraftState')
  select_list(:aircraft_sales_status, :id => 'salesStatus')
  select_list(:shares_sizes, :id => 'shareSize')
  text_field(:tail_number, :name => 'searchQuery')
  table(:aircraft_inventory, :id => 'inventoryResultsTable')
  table(:aircraft_inventory_header, :class => 'head')
  button(:reset, :id => 'resetFilters')
  button(:search, :id => 'search')
  checkbox(:inventory_only, :id => 'inventoryOnly')
  link(:administration, :xpath => '/html/body/div[2]/form/div[1]/div[1]/a')
  div(:edit_ac, :class => 'col-md-offset-11')
  h1(:results_count, :id => 'resultsCount')
  link(:aircraft_type_mapping, xpath: '//*[@id="acMapping"]/a')

  def actual_inventory
    inventory = []
    (1..(self.inventory_count)-2).each do |i|
      aircraft = {}
      self.raw_aircraft_inventory[i].fleet_group == 'NA' ? aircraft['fleet_group'] = nil :
          aircraft['fleet_group'] = self.raw_aircraft_inventory[i].fleet_group
      aircraft['aircraft_type_name'] = self.raw_aircraft_inventory[i].ac_type_element.text
      aircraft['ac_state'] = self.raw_aircraft_inventory[i].ac_state
      aircraft['vintage'] = get_value(self.raw_aircraft_inventory[i].vintage)
      aircraft['aircraft_tail_nbr'] = self.raw_aircraft_inventory[i].tail_no_element.text
      aircraft['contracts_until_dt'] = get_value(self.raw_aircraft_inventory[i].contracts_until)
      aircraft['warranty_expiration_dt'] = get_value(self.raw_aircraft_inventory[i].warranty)
      aircraft['company'] = get_value(self.raw_aircraft_inventory[i].company)
      aircraft['sales_status'] = self.raw_aircraft_inventory[i].sales_status
      inventory << aircraft
    end
    inventory
  end

  def actual_availability
    filtered = true
    (1..(self.inventory_count)-2).each do |i|
      availability = self.raw_aircraft_inventory[i].percent_available.delete("%").to_i
      if availability < self.shares_sizes.to_i
        filtered = false
        break
      end
    end
    filtered
  end

  def inventory_count
    count = 0
    self.aircraft_inventory_element.each { |x| count+=1 }
    count
  end

  def integral? #checks for the completeness of the page.
    self.header_integral? &&
        self.tail_number_element.present? &&
        self.aircraft_types_element.present? &&
        self.reset_element.present? &&
        self.search_element.present?
  end

  def choose_aircraft_type
    max_length = self.aircraft_types_options.length - 1
    self.aircraft_types = self.aircraft_types_options[rand(1..max_length)]
  end

  def select_aircraft_type
    self.raw_aircraft_inventory[rand(1..(self.inventory_count-1))].ac_type
  end

  def select_aircraft_tail(tail_position=0)
    sleep 2
    if tail_position < 1
      index = rand(1..3)
    else
      index = tail_position
    end
    script = <<-JS.gsub(/^ {16}/, '')
                el = document.getElementById('inventoryResultsTable').rows[#{index}]
                el.scrollIntoView(false)
    JS
    @browser.execute_script script
    self.raw_aircraft_inventory[index].tail_no
  end

  def select_aircraft_by_tail(tail)
    self.tail_number = tail
    self.search
    sleep 1
    tail_link = @browser.link(:text => tail.to_s)
    @browser.scroll.to tail_link
    @browser.send_keys :page_up
    self.wait_for_ajax
    sleep(2)
    tail_link.click
  end

  def choose_aircraft_state
    max_length = self.aircraft_states_options.length - 1
    self.aircraft_states = self.aircraft_states_options[rand(1..max_length)]
  end

  def choose_sales_status
    max_length = self.aircraft_sales_status_options.length - 1
    self.aircraft_sales_status = self.aircraft_sales_status_options[rand(1..max_length)]
  end

  def choose_fleet_group
    max_length = self.fleet_groups_options.length - 1
    self.fleet_groups = self.fleet_groups_options[rand(1..max_length)]
  end

  def choose_company
    max_length = self.company_options.length - 1
    self.company = self.company_options[rand(1..max_length)]
  end

  def choose_share_size
    max_length = self.shares_sizes_options.length - 1
    self.shares_sizes = self.shares_sizes_options[rand(1..max_length)]
    sleep 2
  end

  def expected_aircraft_types
    sql = self.expected_aircraft_types_sql
    results = db_conn_ais.connection.execute(sql)
    results.map { |value| value['aircraft_type_name'] }
  end

  def expected_fleet_groups
    sql = self.expected_fleet_groups_sql
    results = db_conn_ais.connection.execute(sql)
    results.map { |value| value['fleet_group_name'] }
  end

  def expected_sales_status
    ['All', 'Selling Fractionally', 'Selling Add-Ons', 'No Sales']
  end

  def expected_company
    ['All', 'NJA', 'NJE', 'EJM', 'EJME']
  end

  def expected_aircraft_states
    ['All', 'On Order', 'Active']
  end

  def expected_all_aircraft_states
    ['All', 'On Order', 'Active', 'ID\'d for Disposal', 'Decommissioned', 'Cancelled']
  end

  def expected_shares_sizes
    ["All", "3.125", "6.25", "9.375", "12.5", "15.625", "18.75", "21.875", "25", "28.125", "31.25", "34.375", \
    "37.5", "40.625", "43.75", "46.875", "50", "53.125", "56.25", "59.375", "62.5", "65.625", "68.75", "71.875", \
    "75", "78.125", "81.25", "84.375", "87.5", "90.625", "93.75", "96.875", "100"]
  end

  def expected_default_company(user_id)
    sql = expected_default_company_sql(user_id)
    results = db_conn_ais.connection.execute(sql)
    mapped_results = results.map { |value| value['company_name'] }
    case mapped_results[0]
      when nil
        'All'
      else
        mapped_results[0]
    end
  end

  def sort_by_fleet_group
    self.aircraft_inventory_element[1][0].click
  end

  def sorted_fleet_group
    actual_inventory.map { |value| value['fleet_group'] }.select { |x| !x.nil? }
  end

  def sort_by_ac_type
    self.aircraft_inventory_element[1][1].click
  end

  def sorted_by_ac_type
    actual_inventory.map { |value| value['aircraft_type_name'] }
  end

  def sort_by_ac_state
    self.aircraft_inventory_element[1][2].click
  end

  def sorted_by_ac_state
    actual_inventory.map { |value| value['ac_state'] }
  end

  def sort_by_vintage
    self.aircraft_inventory_element[1][3].click
  end

  def sorted_by_vintage
    actual_inventory.map { |value| value['vintage'] }.select { |x| !x.nil? }
  end

  def sort_by_tail
    self.aircraft_inventory_element[1][4].click
  end

  def sorted_by_tail
    actual_inventory.map { |value| value['aircraft_tail_nbr'] }
  end

  def sort_by_contracts_until
    self.aircraft_inventory_element[1][6].click
  end

  def sorted_by_contracts_until
    actual_inventory.map { |value| value['contracts_until_dt'] }.select { |x| !x.nil? }.map { |x| x.to_datetime }
  end

  def sort_by_warranty
    self.aircraft_inventory_element[1][7].click
  end

  def sorted_by_warranty
    actual_inventory.map { |value| value['warranty_expiration_dt'] }.select { |x| !x.nil? }.map { |x| x.to_datetime }
  end

  def sort_by_company
    self.aircraft_inventory_element[1][11].click
  end

  def sorted_by_company
    actual_inventory.map { |value| value['company'] }.select { |x| !x.nil? }
  end

  def sort_by_percent_on_hold
    self.aircraft_inventory_element[1][11].click
  end

  def expected_inventory(type=default)
    # default is ALL aircraft type and no tail number
    # search is ALL aircraft type and a tail number is provided
    # filter is aircraft type is provided and no tail number
    # combo is aircraft type and a tail number is provided
    sql = case type
            when 'default'
              expected_inventory_sql(type, nil, nil, nil, nil, nil)
            when 'search'
              expected_inventory_sql(type, nil, self.tail_number, nil, nil, nil)
            when 'aircraft_type'
              aircraft_type_name = self.aircraft_types=='All' ? NIL : self.aircraft_types.gsub("'", "''")
              expected_inventory_sql(type, aircraft_type_name, nil, nil, nil, nil)
            when 'fleet_group'
              fleet_group = self.fleet_groups=='All' ? NIL : self.fleet_groups.gsub("'", "''")
              expected_inventory_sql(type, nil, nil, fleet_group, nil, nil)
            when 'aircraft_state'
              aircraft_state = self.aircraft_states=='All' ? NIL : self.aircraft_states
              expected_inventory_sql(type, nil, nil, nil, aircraft_state, nil)
            when 'company'
              company = self.company=='All' ? NIL : self.company
              expected_inventory_sql(type, nil, nil, nil, nil, company)
            when 'combo1'
              aircraft_state = self.aircraft_states
              aircraft_fleet_group = self.fleet_groups.gsub("'", "''")
              expected_inventory_sql(type, nil, nil, aircraft_fleet_group, aircraft_state, nil)
            when 'combo2'
              aircraft_type = self.aircraft_types.gsub("'", "''")
              aircraft_company = self.company
              expected_inventory_sql(type, aircraft_type, nil, nil, nil, aircraft_company)
            when 'combo3'
              aircraft_type = self.aircraft_types.gsub("'", "''")
              tail = self.tail_number
              expected_inventory_sql(type, aircraft_type, tail, nil, nil, nil)
            when 'combo4'
              aircraft_fleet_group = self.fleet_groups.gsub("'", "''")
              tail = self.tail_number
              expected_inventory_sql(type, nil, tail, aircraft_fleet_group, nil, nil)
            when 'combo5'
              aircraft_company = self.company
              tail = self.tail_number
              expected_inventory_sql(type, nil, tail, nil, nil, aircraft_company)
            else
              raise 'invalid type given'
          end
    db_conn_ais.connection.execute(sql)
  end

  def delete_user_settings(user)
    query = <<-SQL.gsub(/^ {8}/, '')
        delete from acft_owner.ACFT_AIS_USER_SETTINGS where USER_ID = \'#{user}\'
    SQL
    db_conn_ais.connection.execute(query)
  end

  def select_first_tail_with_holds
    self.aircraft_inventory_element[1][10].click
    self.raw_aircraft_inventory[1].tail_no_element.click
  end

  def select_first_tail_number_with_holds
    self.aircraft_inventory_element[1][10].click
    self.aircraft_inventory_element[1][10].click
    self.raw_aircraft_inventory[1].tail_no_element.text
  end

  def select_first_tail_number_with_no_holds
    self.aircraft_inventory_element[1][10].click
    self.raw_aircraft_inventory[1].tail_no_element.text
  end

  def confirm_held_percentage(held_tail)
    query = <<-SQL.gsub(/^ {8}/, '')
      select sum(hold_pct) as total_hold from acft_hold h
      where h.acft_aircraft_id =
        (select a.acft_aircraft_id from acft_aircraft a
        where a.aircraft_tail_nbr =  \'#{held_tail}\')
      and h.is_deleted_flg = 'F'
      and (h.expiration_ts > CURRENT_DATE
          or h.expiration_ts is null)
    SQL
    db_conn_ais.connection.execute(query)[0]["total_hold"]
  end

  def first_tail_held_percentage
    self.raw_aircraft_inventory[1].percent_on_hold.chomp("%").to_f.to_s
  end

  def first_tail_calculated_holds
    self.raw_aircraft_inventory[1].tail_no_element.click
    on(AircraftDetail).sum_holds
  end

  def select_first_tail
    self.raw_aircraft_inventory[1].tail_no_element.click
  end

  def select_active_tails
    self.aircraft_states = 'Active'
    self.wait_for_ajax
  end

  def select_on_order_tails
    self.aircraft_states = 'On Order'
    self.wait_for_ajax
  end

  def select_id_for_disposal_tails
    self.aircraft_states = 'ID\'d for Disposal'
    sleep 1
  end

  def view_all_aircraft
    self.inventory_only_checked? ? self.uncheck_inventory_only : ''
    sleep 1
  end

  def create_new_fleet_group(fleet_group_name)
    on(InventoryAdministration).new_fleet_group
    on(InventoryAdministration).create_fleet_group_from_name(fleet_group_name)
  end

  def fleet_groups
    self.fleet_groups_options
  end

  def create_messy_legal_hold(aircraft)
    mess = LegalHoldMess.new(aircraft)
    Janitor.add_mess(mess)
  end

  def create_messy_core_hold(aircraft)
    mess = CoreHoldMess.new(aircraft)
    Janitor.add_mess(mess)
  end

  def create_messy_fleet_group(fleet_group)
    mess = FleetGroupMess.new(fleet_group)
    Janitor.add_mess(mess)
  end

end