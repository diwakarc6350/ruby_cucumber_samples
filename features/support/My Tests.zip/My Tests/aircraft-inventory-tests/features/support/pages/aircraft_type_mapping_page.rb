require 'pages/sections/mapped_aircraft_types_section'

class AircraftTypeMappingPage
  include PageObject

  select_list(:ais_aircraft_types, id: 'aisAcType')
  select_list(:ijet_aircraft_types, id: 'ijetAcType')

  page_sections(:mapped_aircraft_types, MappedAircraftTypesSection, xpath: '//*[@id="acTypesMappingResultsTable"]/tbody/tr')

  button(:save, id: 'saveMapping')
end