module AircraftTypeData
  def delete_aircraft_type_sql(type_name)
    <<-SQL.gsub(/^ {6}/, '')
      delete from acft_aircraft_type
      where aircraft_type_name = '#{type_name}'
    SQL
  end
end