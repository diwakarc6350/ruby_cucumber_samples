require 'page-object'
require 'header'
require 'aircraft_hold_data'
require 'aircraft_detail_holds'
require 'edit_legal_hold'

class AircraftHoldSearch
  include PageObject
  include Header
  include DataMagic
  include AircraftHoldData
  include PageUtils
  include AircraftDetailHolds
  include EditLegalHold
  include SyncTolerance

  indexed_property(:raw_aircraft_holds, [
      [:cell, :fleet_group, {:xpath => '//*[@id="holdResultsTable"]/tbody/tr[position()="%s"]/td[1]'}],
      [:link, :ac_type, {:xpath => '//*[@id="holdResultsTable"]/tbody/tr[position()="%s"]/td[2]/u/a'}],
      [:link, :tail_no, {:xpath => '//*[@id="holdResultsTable"]/tbody/tr[position()="%s"]/td[3]/u/a'}],
      [:cell, :vintage, {:xpath => '//*[@id="holdResultsTable"]/tbody/tr[position()="%s"]/td[4]'}],
      [:cell, :hold_type, {:xpath => '//*[@id="holdResultsTable"]/tbody/tr[position()="%s"]/td[5]'}],
      [:cell, :held_by, {:xpath => '//*[@id="holdResultsTable"]/tbody/tr[position()="%s"]/td[6]'}],
      [:cell, :placed_date, {:xpath => '//*[@id="holdResultsTable"]/tbody/tr[position()="%s"]/td[7]'}],
      [:cell, :expiration_date, {:xpath => '//*[@id="holdResultsTable"]/tbody/tr[position()="%s"]/td[8]'}],
      [:cell, :amount_held, {:xpath => '//*[@id="holdResultsTable"]/tbody/tr[position()="%s"]/td[9]'}],
      [:link, :edit_hold, {:xpath => '//*[@id="holdResultsTable"]/tbody/tr[position()="%s"]/td[10]'}],
      [:link, :cancel_hold, {:xpath => '//*[@id="holdResultsTable"]/tbody/tr[position()="%s"]/td[11]'}],
  ])
  table(:aircraft_holds, :id => 'holdResultsTable')
  select_list(:fleet_groups, :id => 'fleetGroup')
  select_list(:vintages, :id => 'vintage')
  select_list(:aircraft_types, :name => 'aircraftTypeName')
  select_list(:hold_types, :id => 'holdType')
  button(:reset, :id => 'resetFilters')
  button(:search, :id => 'search')
  text_field(:query, :name => 'holdSearchQuery')
  div(:error, :class => 'alert alert-info')
  link(:view_first_hold, :xpath => '//*[@id="inventoryResultsTable"]/tbody/tr/td[5]/u/a')

  def actual_holds
    holds = []
    (1..(self.holds_count)-2).each do |i|
      aircraft = {}
      self.raw_aircraft_holds[i].fleet_group == 'NA' ? aircraft['fleet_group'] = nil :
          aircraft['fleet_group'] = self.raw_aircraft_holds[i].fleet_group
      aircraft['aircraft_type_name'] = self.raw_aircraft_holds[i].ac_type_element.text
      aircraft['aircraft_tail_nbr'] = self.raw_aircraft_holds[i].tail_no_element.text
      aircraft['vintage'] = get_value(self.raw_aircraft_holds[i].vintage)
      aircraft['hold_type'] = get_value(self.raw_aircraft_holds[i].hold_type)
      aircraft['held_by'] = get_value(self.raw_aircraft_holds[i].held_by)
      aircraft['placed_on'] = get_value(self.raw_aircraft_holds[i].placed_date)
      aircraft['expiration_dt'] = get_value(self.raw_aircraft_holds[i].expiration_date)
      aircraft['hold_percent'] = get_value(self.raw_aircraft_holds[i].amount_held).delete("%").strip!
      holds << aircraft
    end
    holds
  end

  def integral_holds? #checks for the completeness of the page.
    self.header_integral? &&
        self.query_element.present? &&
        self.fleet_groups_element.present? &&
        self.reset_element.present? &&
        self.search_element.present?
  end

  def expected_holds(type=default)
    # default is ALL aircraft type and no tail number
    # search is ALL aircraft type and a tail number is provided
    # filter is aircraft type is provided and no tail number
    # combo is aircraft type and a tail number is provided
    sql = case type
            when 'default'
              expected_table_sql
            when 'ordered_default'
              filtered_default_order
            when 'user_search'
              filtered_by_user_search_sql(self.data_for(:hold_index_screen_data)['held_by'])
            when 'held_tail'
              #puts self.data_for(:hold_index_screen_data)['held_tail']
              filtered_by_tail_sql(self.data_for(:hold_index_screen_data)['held_tail'])
            when 'aircraft_type', 'Aircraft Type'
              aircraft_type_name = self.aircraft_types=='All' ? NIL : self.aircraft_types.gsub("'", "''")
              filtered_by_ac_type_sql(aircraft_type_name)
            when 'fleet_group', 'Fleet Group'
              fleet_group = self.fleet_groups=='All' ? NIL : self.fleet_groups.gsub("'", "''")
              filtered_by_fleet_group_sql(fleet_group)
            when 'vintage', 'Vintage'
              vintage = self.vintages=='All' ? NIL : self.vintages
              filtered_by_vintage_sql(vintage)
            when 'Hold Type'
              hold_type = self.hold_types=='All' ? NIL : self.hold_types.gsub("'", "''")
              filtered_by_hold_type_sql(hold_type)
            when 'Fleet Group and Type'
              aircraft_type_name = self.aircraft_types=='All' ? NIL : self.aircraft_types.gsub("'", "''")
              aircraft_fleet_group = self.fleet_groups.gsub("'", "''")
              filtered_by_fg_and_type_sql(aircraft_fleet_group, aircraft_type_name)
            when 'Vintage and Hold Type'
              vintage = self.vintages=='All' ? NIL : self.vintages
              hold_type = self.hold_types=='All' ? NIL : self.hold_types.gsub("'", "''")
              filtered_by_v_and_h_type(vintage, hold_type)
            when 'Hold Type, Vintage and Fleet Group'
              vintage = self.vintages=='All' ? NIL : self.vintages
              hold_type = self.hold_types=='All' ? NIL : self.hold_types.gsub("'", "''")
              fleet_group = self.fleet_groups=='All' ? NIL : self.fleet_groups.gsub("'", "''")
              filtered_v_fg_and_h_type(vintage, hold_type, fleet_group)
            else
              raise 'invalid type given'
          end
    db_conn_ais.connection.execute(sql)
  end

  def choose_filter(filter)
    case filter
      when 'Fleet Group'
        max_length = self.fleet_groups_options.length - 1
        self.fleet_groups = self.fleet_groups_options[rand(1..max_length)]
      when 'Aircraft Type'
        max_length = self.aircraft_types_options.length - 1
        self.aircraft_types = self.aircraft_types_options[rand(1..max_length)]
      when 'Vintage'
        max_length = self.vintages_options.length - 1
        self.vintages = self.vintages_options[rand(1..max_length)]
      when 'Hold Type'
        max_length = self.hold_types_options.length - 1
        self.hold_types = self.hold_types_options[rand(1..max_length)]
      when 'Fleet Group and Type'
        max_length = self.fleet_groups_options.length - 1
        self.fleet_groups = self.fleet_groups_options[rand(1..max_length)]
        max_length = self.aircraft_types_options.length - 1
        self.aircraft_types = self.aircraft_types_options[rand(1..max_length)]
      when 'Vintage and Hold Type'
        max_length = self.vintages_options.length - 1
        self.vintages = self.vintages_options[rand(1..max_length)]
        max_length = self.hold_types_options.length - 1
        self.hold_types = self.hold_types_options[rand(1..max_length)]
      when 'Hold Type, Vintage and Fleet Group'
        max_length = self.hold_types_options.length - 1
        self.hold_types = self.hold_types_options[rand(1..max_length)]
        max_length = self.vintages_options.length - 1
        self.vintages = self.vintages_options[rand(1..max_length)]
        max_length = self.fleet_groups_options.length - 1
        self.fleet_groups = self.fleet_groups_options[rand(1..max_length)]
      else
        raise 'invalid type given'
    end
  end

  def sort_holds
    for column in 0..8
      2.times { self.aircraft_holds_element[1][column].click }
    end
  end

  def reset_filters
    self.reset
  end

  def expected_vintages
    sql = self.expect_vintages_sql
    results = db_conn_ais.connection.execute(sql)
    results.map { |value| value['vintage'] }
  end

  def expected_holds_fleet_groups
    sql = self.expect_holds_fleet_groups_sql
    results = db_conn_ais.connection.execute(sql)
    results.map { |value| value['fleet_group_name'] }
  end

  def expected_types
    sql = self.expect_types_sql
    results = db_conn_ais.connection.execute(sql)
    results.map { |value| value['aircraft_type_name'] }
  end

  def expected_holds_types
    sql = self.expect_hold_types_sql
    results = db_conn_ais.connection.execute(sql)
    results.map { |value| value['hold_type'] }
  end


  def holds_count
    count = 0
    self.aircraft_holds_element.each { |x| count+=1 }
    count
  end

  def expect_types_sql
    <<-SQL.gsub(/^ {6}/, '')
      select aircraft_type_name from acft_aircraft_type where active_status_flg like 'T' order by aircraft_type_name
    SQL
  end

  def expect_hold_types_sql
    <<-SQL.gsub(/^ {6}/, '')
      select hcode.code_type_name order by code_type_name
    SQL
  end

  def expect_vintages_sql
    <<-SQL.gsub(/^ {6}/, '')
      select distinct to_char(extract(year from manufacture_dt)) as vintage from acft_aircraft
      where to_char(extract(year from manufacture_dt)) is not null
      order by to_char(extract(year from manufacture_dt)) desc
    SQL
  end

  def actual_vintage_options
    self.vintages_options[1..self.vintages_options.length]
  end

  def actual_fleet_group_options
    self.fleet_groups_options[1..self.fleet_groups_options.length]
  end

  def actual_aircraft_type_options
    self.aircraft_types_options[1..self.aircraft_types_options.length]
  end

  def actual_hold_type_options
    self.hold_types_options[1..self.hold_types_options.length]
  end

  def edit_first_hold
    patiently {self.aircraft_holds_element[2][9].click}
    self.wait_until { (self.text.include?('Notes: (optional)')) }
  end

  def view_first_hold
    sleep 1
    self.aircraft_holds_element[2][2].click
  end

  def return_first_tail
    self.raw_aircraft_holds[1].tail_no_element.text
  end

  def return_first_held_by
    self.raw_aircraft_holds[1].held_by
  end

  def holds_are_filtered_by_held_by?(holder_name)
    result = []
    self.actual_holds.each {|hold| result << (hold['held_by'] == holder_name)}
    (result.uniq.length == 1 && result.uniq[0] == true)
  end

  def holds_are_filtered_by_tail?(tail_no)
    result = []
    self.actual_holds.each {|hold| result << (hold['aircraft_tail_nbr'] == tail_no)}
    (result.uniq.length == 1 && result.uniq[0] == true)
  end

end