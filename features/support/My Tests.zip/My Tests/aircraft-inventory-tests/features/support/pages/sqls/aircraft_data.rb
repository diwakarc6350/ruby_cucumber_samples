module AircraftData
  def expected_inventory_sql(type, aircraft_name, tail_number, fleet_group, aircraft_state, company)
    query = <<-SQL.gsub(/^ {8}/, '')
        select fg.fleet_group_name as fleet_group, at.aircraft_type_name, acode.code_type_name as ac_state,
        to_char(extract(year from a.manufacture_dt)) as vintage, a.aircraft_tail_nbr,
        to_char(a.contracts_until_dt,'DD Mon YYYY') as contracts_until_dt,
        to_char(a.warranty_expiration_dt,'DD Mon YYYY') as warranty_expiration_dt, ejm.company_name as company,
        code.code_type_name as sales_status
        from acft_aircraft a
        join acft_aircraft_type at
        on a.acft_aircraft_type_id = at.acft_aircraft_type_id
        left outer join acft_fleet_group fg
        on at.fleet_group_id = fg.acft_fleet_group_id
        left outer join ej_company ejm
        on a.ijet_ej_company_id = ejm.ej_company_id
        join ACFT_CODE_TYPE acode
        on a.aircraft_state_cd = acode.acft_code_type_id
        join acft_code_type code
        on  code.acft_code_type_id = a.sales_status_cd
    SQL
    clause = {
        :default => "where a.aircraft_state_cd in (2,3)" +
            "order by at.display_rnk asc, a.manufacture_dt desc ",
        :search => "where a.aircraft_tail_nbr like \'%#{tail_number}%\' " +
            "and a.aircraft_state_cd in (2,3) order by at.display_rnk asc, a.manufacture_dt desc ",
        :aircraft_type => "where at.aircraft_type_name = \'#{aircraft_name}\'" +
            "and a.aircraft_state_cd in (2,3) order by at.display_rnk asc, a.manufacture_dt desc ",
        :fleet_group => "where fg.fleet_group_name = \'#{fleet_group}\'" +
            "and a.aircraft_state_cd in (2,3) order by at.display_rnk asc, a.manufacture_dt desc ",
        :aircraft_state => "where acode.code_type_name = \'#{aircraft_state}\'" +
            "and a.aircraft_state_cd in (2,3) order by at.display_rnk asc, a.manufacture_dt desc ",
        :company => "where ejm.company_name = \'#{company}\'" +
            "and a.aircraft_state_cd in (2,3) order by at.display_rnk asc, a.manufacture_dt desc, a.acft_aircraft_id desc",
        :combo1 => "where fg.fleet_group_name =  \'#{fleet_group}\'" +
            "and acode.code_type_name = \'#{aircraft_state}\'" +
            "and a.aircraft_state_cd in (2,3) order by at.display_rnk asc, a.manufacture_dt desc ",
        :combo2 => "where aircraft_type_name = \'#{aircraft_name}\'" +
            "and ejm.company_name = \'#{company}\'" +
            "and a.aircraft_state_cd in (2,3) order by at.display_rnk asc, a.manufacture_dt desc ",
        :combo3 => "where aircraft_type_name = \'#{aircraft_name}\'" +
            "and aircraft_tail_nbr like \'%#{tail_number}%\'" +
            "and a.aircraft_state_cd in (2,3) order by at.display_rnk asc, a.manufacture_dt desc ",
        :combo4 => "where fg.fleet_group_name = \'#{fleet_group}\'" +
            "and aircraft_tail_nbr like \'%#{tail_number}%\'" +
            "and a.aircraft_state_cd in (2,3) order by at.display_rnk asc, a.manufacture_dt desc ",
        :combo5 => "where ejm.company_name = \'#{company}\'" +
            "and aircraft_tail_nbr like \'%#{tail_number}%\'" +
            "and a.aircraft_state_cd in (2,3) order by at.display_rnk asc, a.manufacture_dt desc "
    }
    query + clause[type.to_sym]
  end

  def delete_aircraft_sql(tail_number)
    <<-SQL.gsub(/^ {8}/, '')
        delete from acft_aircraft where aircraft_tail_nbr = '#{tail_number}'
    SQL
  end

  def delete_engines_sql(tail_number)
    <<-SQL.gsub(/^ {8}/, '')
        delete from acft_engine where acft_aircraft_id in (select acft_aircraft_id from  acft_aircraft where aircraft_tail_nbr = '#{tail_number}')
    SQL
  end

  def delete_acft_holds_sql(tail_number)
    <<-SQL.gsub(/^ {8}/, '')
        delete from acft_hold where acft_aircraft_id in (select acft_aircraft_id from  acft_aircraft where aircraft_tail_nbr = '#{tail_number}')
    SQL
  end

  def expected_aircraft_types_sql
    <<-SQL.gsub(/^ {8}/, '')
        select aircraft_type_name from acft_aircraft_type where active_status_flg = 'T' order by aircraft_type_name
    SQL
  end

  def expected_fleet_groups_sql
    <<-SQL.gsub(/^ {6}/, '')
      select fleet_group_name from acft_fleet_group order by fleet_group_name
    SQL
  end

  def expected_aircraft_state_sql
    <<-SQL.gsub(/^ {6}/, '')
      select code_type_name from ACFT_CODE_TYPE where code_category_id = 2
    SQL
  end

  def expected_sales_status_sql
    <<-SQL.gsub(/^ {6}/, '')
      select code_type_name from ACFT_CODE_TYPE where code_category_id = 3
    SQL
  end

  def expected_aircrafts_sql
    <<-SQL.gsub(/^ {6}/, '')
      select aircraft_tail_nbr from acft_aircraft order by aircraft_tail_nbr
    SQL
  end

  def expected_default_company_sql(user_id)
    <<-SQL.gsub(/^ {6}/, '')
      select company.company_name from acft_ais_user_settings settings
      join ej_company company
      on company.ej_company_id = settings.last_company_slctn_id
      where settings.user_id = '#{user_id}'
    SQL
  end

end