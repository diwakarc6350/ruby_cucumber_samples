require 'page-object'
class LoginPage

  include PageObject
  page_url base_url

  text_field(:username, :id => 'username')
  text_field(:password, :id => 'password')
  button(:login, :name => 'action')

  def login_with_invalid_user
    self.username = INVALID_USER[:user]
    self.password = INVALID_USER[:password]
    self.login
  end

  def login_with_invalid_password
    self.username = USER_WITH_INVALID_PASSWORD[:user]
    self.password = USER_WITH_INVALID_PASSWORD[:password]
    self.login
  end

  def login_as(role='AIS Administrator')
    self.username = USER_MAP[role.to_sym][:user]
    self.password = USER_MAP[role.to_sym][:password]
    self.login
  end
end
