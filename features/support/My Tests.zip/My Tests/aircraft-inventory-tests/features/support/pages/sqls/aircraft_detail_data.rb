module AircraftDetailData
  def expected_delivery_info_sql(tail_number)
    <<-SQL.gsub(/^ {6}/, '')
      select antcptd_delivery_dt as anticipated_delivery_date, actual_delivery_dt as actual_delivery_date,
      antcptd_selling_dt as anticipated_sold_date , actual_selling_dt as actual_sold_date
      from acft_aircraft
      where aircraft_tail_nbr = '#{tail_number}'
    SQL
  end

  def expected_selling_info_sql(tail_number)
    <<-SQL.gsub(/^ {6}/, '')
      select  contracts_until_dt as contracts_until_date, code.code_type_name as sales_status
      from acft_aircraft aircraft
      join acft_code_type code
      on  code.acft_code_type_id = aircraft.sales_status_cd
      where aircraft_tail_nbr = '#{tail_number}'
    SQL
  end

  def expected_engine_info_sql(tail_number)
    <<-SQL.gsub(/^ {6}/, '')
      select eng.model_name as model_name, eng.manufacturer_name
      from acft_engine eng
      join acft_aircraft a
      on eng.acft_aircraft_id = a.acft_aircraft_id
      where aircraft_tail_nbr = '#{tail_number}'
      order by model_name
    SQL
  end

  def expected_standard_info_sql(tail_number)
    <<-SQL.gsub(/^ {6}/, '')
      select a.aircraft_tail_nbr as tail_no, acode.code_type_name as ac_state, at.aircraft_type_name as ac_type,
      fg.fleet_group_name as fleet_group, ocode.code_type_name as ownership_status,
      ijet_aircraft_id as ijet_id,
      to_char(extract(year from a.manufacture_dt)) as vintage,
      serial_nbr as serial_number, icode.code_type_name as insurance_status, re_regstr_nbr as re_registration_code,
      to_char(a.warranty_expiration_dt,'DD Mon YYYY') as warranty_date, ejm.company_name as company,
      to_char(a.title_search_dt,'DD Mon YYYY') as title_search_date
      from acft_aircraft a
      join acft_aircraft_type at
      on a.acft_aircraft_type_id = at.acft_aircraft_type_id
      left outer join acft_fleet_group fg
      on at.fleet_group_id = fg.acft_fleet_group_id
      left outer join ej_company ejm
      on a.ijet_ej_company_id = ejm.ej_company_id
      join ACFT_CODE_TYPE acode
      on a.aircraft_state_cd = acode.acft_code_type_id
      left outer  join ACFT_CODE_TYPE ocode
      on a.ownership_status_cd = ocode.acft_code_type_id
      left outer join ACFT_CODE_TYPE icode
      on a.insurance_status_cd = icode.acft_code_type_id
      where aircraft_tail_nbr = '#{tail_number}'
    SQL
  end
end