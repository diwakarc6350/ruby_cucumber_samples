require 'page-object'

module BreadCrumbs
  include PageObject

  unordered_list(:bread_crumbs, :class => 'breadcrumb')

  def get_bread_crumbs
    crumbs = {};index=0
    list_items = self.bread_crumbs_element
    list_items.each do |list_item|
      crumbs[index] = list_item.text
      index += 1
    end
  end

end