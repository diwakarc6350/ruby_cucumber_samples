require 'page-object'
require 'aircraft_data'

module Aircraft
  include PageObject
  include AircraftData

  #mandatory fields
  text_field(:aircraft_tail_no, :id => 'tailNumberTxt')
  text_field(:aircraft_legal_model_name, :id => 'legalModelNameTxt')
  text_field(:aircraft_manufacturer, :id => 'manufacturerTxt')
  select_list(:aircraft_aircraft_types, :id => 'acTypeSel')
  select_list(:aircraft_states, :id => 'aircraftStatusSel')
  select_list(:aircraft_ownership_status, :id => 'ownershipStatusSel')
  select_list(:aircraft_sales_status, :id => 'saleStatusSel')

  #optional standard aircraft information
  select_list(:aircraft_fleet_groups, :id => 'fleetGroupSel')
  text_field(:aircraft_year_manufactured, :id => 'yearManufactured')
  text_field(:aircraft_serial_number, :id => 'serialNumber')
  text_field(:aircraft_ijet_id, :id => 'ijetIdTxt')
  text_field(:aircraft_warranty_dt, :id => 'warrantyDte')
  text_field(:aircraft_contracts_until_dt, :id => 'contractsUntilDte')
  text_field(:aircraft_decommission_dt, :id => 'decommissionDte')
  text_field(:aircraft_title_search_dt, :id => 'titleSearchDte')
  select_list(:aircraft_company, :id => 'company')
  select_list(:aircraft_insurance_status, :id => 'insuranceStatus')

  #optional delivery information
  text_field(:aircraft_anticipated_delivery_dt, :id => 'anticipatedDlvryDte')
  text_field(:aircraft_actual_delivery_dt, :id => 'actualDlvryDte')
  text_field(:aircraft_re_reg_code, :id => 'regisCode')

  #optional engine information
  text_field(:aircraft_engine_manufacturer1, :id => 'manufacturer1')
  text_field(:aircraft_engine_model1, :id => 'model1')
  text_field(:aircraft_engine_manufacturer2, :id => 'manufacturer2')
  text_field(:aircraft_engine_model2, :id => 'model2')
  text_field(:aircraft_engine_manufacturer3, :id => 'manufacturer3')
  text_field(:aircraft_engine_model3, :id => 'model3')
  text_field(:aircraft_engine_manufacturer4, :id => 'manufacturer4')
  text_field(:aircraft_engine_model4, :id => 'model4')

  button(:aircraft_save, :id => 'createAcftSave')
  button(:aircraft_cancel_save, :id => 'createAcftCancel')

  #edit aircraft type page elements
  #NEED TO MAP THESE TO ELEMENTS ON PAGE
  button(:cancel_ac_edit, :id => 'editATCancel')
  button(:confirm_ac_edit, :id => 'createAcftSave')
  button(:edit_ac_ok, :id => 'confirmATOk')
  button(:edit_ac, :id => 'editAircraft')

  def create_holds_aircraft
    sql = delete_engines_sql(self.data_for(:hold_test_aircraft)['aircraft_tail_no'])
    db_conn_ais.connection.execute(sql)
    sql = delete_acft_holds_sql(self.data_for(:hold_test_aircraft)['aircraft_tail_no'])
    db_conn_ais.connection.execute(sql)
    sql = delete_aircraft_sql(self.data_for(:hold_test_aircraft)['aircraft_tail_no'])
    db_conn_ais.connection.execute(sql)
    self.new_aircraft
    self.wait_until { self.text.include? "Create Aircraft" }
  end

  def create_aircraft
    sql = delete_acft_holds_sql(self.data_for(:aircraft_create_with_no_options)['aircraft_tail_no'])
    db_conn_ais.connection.execute(sql)
    sql = delete_engines_sql(self.data_for(:aircraft_create_with_no_options)['aircraft_tail_no'])
    db_conn_ais.connection.execute(sql)
    sql = delete_aircraft_sql(self.data_for(:aircraft_create_with_no_options)['aircraft_tail_no'])
    db_conn_ais.connection.execute(sql)
    self.new_aircraft
    self.wait_until { self.text.include? "Create Aircraft" }
  end

  def expected_fleet_groups
    sql = expected_fleet_groups_sql
    results = db_conn_ais.connection.execute(sql)
    results.map { |value| value['fleet_group_name'] }
  end

  def expected_aircraft_types
    sql = expected_aircraft_types_sql
    results = db_conn_ais.connection.execute(sql)
    results.map { |value| value['aircraft_type_name'] }
  end

  def edit_aircraft
    self.edit_ac
    sleep 1
    #self.wait_until (self.text.include? "Edit Aircraft")
  end

  def update_aircraft
    self.confirm_ac_edit
  end

  def expected_aircrafts
    sql = expected_aircrafts_sql
    results = db_conn_ais.connection.execute(sql)
    results.map { |value| value['aircraft_tail_nbr'] }
  end

end