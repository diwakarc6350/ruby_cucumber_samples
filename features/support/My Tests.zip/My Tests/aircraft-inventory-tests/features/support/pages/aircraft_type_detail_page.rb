require 'page-object'
require 'header'
require 'breadcrumbs'

class AircraftTypeDetail
  include PageObject
  include BreadCrumbs
  include Header

  span(:manufacturer, :id => 'legalManufacturer')
  span(:model_name, :id => 'legalModelName')
  span(:notes, :id => 'notes')
  span(:no_of_engines, :id => 'noOfEngines')
  span(:cabin_size, :id => 'cabin')
  span(:sales_status, :id => 'salesStatus')
  button(:close_x, :class => 'close')
  button(:close_b, :id => 'modalFooterClose')
  h4(:modal_legal_model, :id => 'modalHeaderTitle')
  link(:edit_aircraft_type, :xpath => '//*[@id="myModal"]/div/div/div[2]/a')

  AIRCRAFT_CABIN_SIZE_CODES = {'Lite' => ['L', 'Lite'], 'Mid' => ['M', 'Mid'], 'Large' => ['L', 'Large']}

  def actual_aircraft_type_detail
    ac_type_detail = {}
    ac_type_detail['legal_model_name'] = self.model_name
    ac_type_detail['legal_manufacturer_name'] = self.manufacturer
    ac_type_detail['sales_status'] = self.sales_status
    ac_type_detail['notes_txt'] = (self.notes.nil? || self.notes.empty?) ? NIL : self.notes
    ac_type_detail['engines_cnt'] = self.no_of_engines
    ac_type_detail['cabin_size_cd'] = AIRCRAFT_CABIN_SIZE_CODES[self.cabin_size][0]
    ac_type_detail
  end

  def select_list_aircraft_types
    self.back_to_aircraft_types_list
  end

  def get_legal_model
    model = self.modal_legal_model
    model[0..(model.length-10)]
  end

  def expected_aircraft_type_detail
    ais_sql = get_ais_ac_type_detail_sql(self.get_legal_model)
    db_conn_ais.connection.execute(ais_sql)
  end

  def get_ais_ac_type_detail_sql(legal_model)
    <<-SQL.gsub(/^ {6}/, '')
      select legal_model_name, legal_manufacturer_name, notes_txt,
      engines_cnt from acft_aircraft_type
      where legal_model_name = '#{legal_model}'
    SQL
  end

end