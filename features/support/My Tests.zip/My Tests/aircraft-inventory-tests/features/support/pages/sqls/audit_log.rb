module AuditLog
  def delete_log_sql(action, item, desc, by)
    <<-SQL.gsub(/^ {6}/, '')
      delete from acft_audit_log
      where audit_action = '#{action}'
      and affected_item = '#{item}'
      and detail_desc = '#{desc}'
      and created_by = '#{by}'
    SQL
  end

  def get_log_sql(action, item, desc, by)
    <<-SQL.gsub(/^ {6}/, '')
      select count(*) as audit_count from acft_audit_log
      where audit_action = '#{action}'
      and affected_item = '#{item}'
      and detail_desc = '#{desc}'
      and created_by = '#{by}'
    SQL
  end

  def delete_fleet_group_sql(fleet_group)
    <<-SQL.gsub(/^ {6}/, '')
      delete from acft_fleet_group
      where FLEET_GROUP_NAME = '#{fleet_group}'
    SQL
  end
end