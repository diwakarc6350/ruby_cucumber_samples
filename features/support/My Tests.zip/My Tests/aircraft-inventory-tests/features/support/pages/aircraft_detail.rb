require 'page-object'
require 'header'
require 'breadcrumbs'
require 'aircraft_detail_data'
require 'aircraft_detail_holds'
require 'legal_hold'
require 'audit_log'
require 'edit_legal_hold'

class AircraftDetail
  include PageObject
  include BreadCrumbs
  include DataMagic
  include Header
  include AircraftDetailData
  include AircraftDetailHolds
  include LegalHold
  include PageUtils
  include AuditLog
  include EditLegalHold

  #standard aircraft information
  span(:tail_no, :id => 'tailNumber')
  span(:ac_state, :id => 'acState')
  span(:ac_type, :id => 'acType')
  span(:fleet_group, :id => 'fleetGroup')
  span(:ownership_status, :id => 'ownerShipStatus')
  span(:ijet_id, :id => 'iJetId')
  span(:vintage, :id => 'vintage')
  span(:serial_number, :id => 'serialNumber')
  span(:insurance_status, :id => 'insStatus')
  span(:re_registration_code, :id => 'reRegisCode')
  span(:warranty_date, :id => 'warrantyDate')
  span(:company, :id => 'company')
  span(:title_search_date, :id => 'titSearchDate')

  #engine information
  span(:manufacturer_1, :id => 'engineName_1')
  span(:model_1, :id => 'engineNumber_1')
  span(:manufacturer_2, :id => 'engineName_2')
  span(:model_2, :id => 'engineNumber_2')
  span(:manufacturer_3, :id => 'engineName_3')
  span(:model_3, :id => 'engineNumber_3')
  span(:manufacturer_4, :id => 'engineName_4')
  span(:model_4, :id => 'engineNumber_4')

  #delivery information
  span(:anticipated_delivery_date, :id => 'antDelDate')
  span(:actual_delivery_date, :id => 'actDelDate')
  span(:anticipated_sold_date, :id => 'antSoldDate')
  span(:actual_sold_date, :id => 'actSoldDate')
  span(:anticipated_disposal_date, :id => 'antSoldDate')

  #selling information
  span(:contracts_until_date, :id => 'ctrUntilDate')
  span(:sales_status, :id => 'salesStatus')

  link(:go_back_to_inventory, :link_text => 'Back to Inventory')

  #place hold
  button(:place_hold_btn, :id => 'placeHold')
  button(:confirm_hold_btn, :id => 'createHoldConfirm')

  #delete hold
  button(:delete_hold, :id => 'confirmLglDelete')
  button(:cancel_delete_hold, :id => 'confirmLglCancel')
  button(:delete_close, :id => 'deleteClose')
  div(:hold_notes, :id =>'dialog')

  paragraph(:confirmation_message, :xpath => '//*[@id="createSuccess"]/div/div/div[1]/p')

  def actual_standard_info
    actual_info = {}
    actual_info['tail_no'] = self.tail_no.strip
    actual_info['ac_state'] = self.ac_state.strip
    actual_info['ac_type'] = self.ac_type.strip
    actual_info['fleet_group'] = get_value(self.fleet_group)
    actual_info['ownership_status'] = get_value(self.ownership_status)
    self.ijet_id.strip == '' ? actual_info['ijet_id'] = nil :
        actual_info['ijet_id'] = self.ijet_id.strip.to_s
    actual_info['vintage'] = get_value(self.vintage)
    actual_info['serial_number'] = get_value(self.serial_number)
    actual_info['insurance_status'] = get_value(self.insurance_status)
    actual_info['re_registration_code'] = get_value(self.re_registration_code)
    actual_info['warranty_date'] = get_value(self.warranty_date)
    actual_info['company'] = get_value(self.company)
    actual_info['title_search_date'] = get_value(self.title_search_date)
    actual_info
  end

  def expected_standard_info
    sql = expected_standard_info_sql(self.tail_no.strip)
    db_conn_ais.connection.execute(sql)[0]
  end

  def actual_selling_info
    selling_info = {}
    selling_info['contracts_until_date'] = self.contracts_until_date.to_date.to_s
    selling_info['sales_status']= self.sales_status.strip
    selling_info
  end

  def expected_selling_info
    sql = expected_selling_info_sql(self.tail_no.strip)
    db_conn_ais.connection.execute(sql)[0]
  end

  def actual_delivery_info
    delivery_info = {}
    if anticipated_delivery_date_element.exists? and self.anticipated_delivery_date.strip != ''
      delivery_info['anticipated_delivery_date'] = self.anticipated_delivery_date.strip.to_datetime.utc
    else
      delivery_info['anticipated_delivery_date'] = nil
    end
    if actual_delivery_date_element.exists? and self.actual_delivery_date.strip != ''
      delivery_info['actual_delivery_date'] = self.actual_delivery_date.to_date.to_s
    else
      delivery_info['actual_delivery_date'] = nil
    end
    if anticipated_sold_date_element.exists? and self.anticipated_sold_date.strip != ''
      delivery_info['anticipated_sold_date'] = self.anticipated_sold_date.strip.to_datetime.utc
    else
      delivery_info['anticipated_sold_date'] = nil
    end
    if actual_sold_date_element.exists? and self.actual_sold_date.strip != ''
      delivery_info['actual_sold_date'] = self.actual_sold_date.strip.to_datetime.utc
    else
      delivery_info['actual_sold_date'] = nil
    end
    delivery_info
  end

  def expected_delivery_info
    sql = expected_delivery_info_sql(self.tail_no.strip)
    db_conn_ais.connection.execute(sql)[0]
  end

  def actual_engine_info
    engines = []
    if manufacturer_1_element.exists?
      engine_info = {}
      engine_info['model_name'] = self.model_1.strip
      engine_info['manufacturer_name'] = self.manufacturer_1.strip
      engines << engine_info
    end
    if manufacturer_2_element.exists?
      engine_info = {}
      engine_info['model_name'] = self.model_2.strip
      engine_info['manufacturer_name'] = self.manufacturer_2.strip
      engines << engine_info
    end
    if manufacturer_3_element.exists?
      engine_info = {}
      engine_info['model_name'] = self.model_3.strip
      engine_info['manufacturer_name'] = self.manufacturer_3.strip
      engines << engine_info
    end
    if manufacturer_4_element.exists?
      engine_info = {}
      engine_info['model_name'] = self.model_4.strip
      engine_info['manufacturer_name'] = self.manufacturer_4.strip
      engines << engine_info
    end
    sorted_engines = engines.sort_by { |v| v['model_name'] }
    sorted_engines
  end

  def expected_engine_info
    sql = expected_engine_info_sql(self.tail_no.strip)
    db_conn_ais.connection.execute(sql)
  end

  def place_hold
    self.place_hold_btn
    self.wait_until { (self.text.include? "Select Interest Size") }
  end

  def audited?(action, item, desc, by)
    sql = get_log_sql(action, item, desc, by)
    audit_logs = db_conn_ais.connection.execute(sql)[0]
    audit_logs['audit_count'].to_i > 0 ? true : false
  end

end