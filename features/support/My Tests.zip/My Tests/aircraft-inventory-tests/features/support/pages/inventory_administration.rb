require 'page-object'
require 'header'
require 'breadcrumbs'
require 'fleet_groups'
require 'aircraft_types'
require 'aircraft'
require 'audit_log'
require 'legal_hold'

class InventoryAdministration
  include PageObject
  include DataMagic
  include BreadCrumbs
  include AuditLog
  include Header
  include FleetGroups
  include AircraftTypes
  include Aircraft
  include LegalHold

  link(:close_maintenance, :link_text  => "Close Management Screen")
  link(:new_fleet_group, :id => "newFG")
  select(:fleet_groups, :id => "fleetGroupSel")
  select(:aircraft_types, :id => "aircraftTypeName")
  select(:aircrafts, :id => "aircraftSel")
  link(:new_aircraft_type, :id => "newACType")
  link(:new_aircraft, :id => "newAircraft")
  link(:edit_settings, :id => "editSettings")

  def audited?(action, item, desc, by)
    sql = get_log_sql(action, item, desc, by)
    audit_logs = db_conn_ais.connection.execute(sql)[0]
    audit_logs['audit_count'].to_i > 0 ? true : false
  end

  def create_fleet_group_from_name(fleet_group_name)
    sleep 1
    self.fleet_group_name = fleet_group_name
    self.save_fleet_group
    self.wait_for_ajax
  end

end