require 'page-object'

class HomePage
  include PageObject
  include Header

  page_url base_url+'/aircraftTypes/index'
end
