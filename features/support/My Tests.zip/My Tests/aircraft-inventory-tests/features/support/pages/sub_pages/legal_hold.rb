require 'page-object'
require 'aircraft_holds_data'
require 'aircraft_data'
require 'audit_log'

module LegalHold
  include PageObject
  include AircraftHoldsData
  include AircraftData

  h5(:title, :id => 'modalStdHoldTitle')
  select(:legal_hold_interest_size, :id => 'interestSize')
  select(:hold_type, :id => 'holdType')
  button(:legal_hold_save, :id => 'confirmLglHoldSave')
  button(:legal_hold_cancel, :id => 'confirmLglHoldCancel')
  text_area(:legal_notes, :id => 'notesTxtArea')
  text_field(:hold_end_date, :id => 'holdEndDate')

  def save_legal_hold
    self.legal_hold_save
    self.wait_until { self.text.include? "The hold has been created successfully." }
  end

  def confirm_hold
    self.confirm_hold_btn
  end

  def cancel_legal_hold(interest_size=3.125)
    self.interest_size = interest_size
    self.legal_hold_cancel
  end

  def current_holds
    sql = expected_current_holds_sql(self.tail_no.strip)
    db_conn_ais.connection.execute(sql)
  end

  def max_allowed_holds
    sql = hold_settings_sql
    db_conn_ais.connection.execute(sql)['maximum_holds_allowed']
  end

  def hold_duration
    sql = hold_settings_sql
    db_conn_ais.connection.execute(sql)['maximum_holds_duration']
  end

  def delete_acft_holds(tail)
    sql = delete_acft_holds_sql(tail)
    db_conn_ais.connection.execute(sql)
  end



end