class MappedAircraftTypesSection
  include PageObject

  td(:ais_aircraft_type , index: 0)
  td(:ijet_aircraft_type , index: 1)

end