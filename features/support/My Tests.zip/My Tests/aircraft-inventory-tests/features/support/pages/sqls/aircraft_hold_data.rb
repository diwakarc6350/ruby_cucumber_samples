module AircraftHoldData
  def expected_table_sql
    query = <<-SQL.gsub(/^ {8}/, '')
        select fg.fleet_group_name as fleet_group,
        at.aircraft_type_name as aircraft_type_name,
        a.aircraft_tail_nbr, to_char(extract(year from a.manufacture_dt)) as vintage,
        hcode.code_type_name as hold_type, h.held_by_user_name as held_by,
        to_char(h.placed_ts, 'DD Mon YYYY') as placed_on,
        to_char(h.expiration_ts, 'DD Mon YYYY') as expiration_dt,
        to_char(h.hold_pct) as hold_percent
        from acft_hold h
        join acft_aircraft a
        on a.acft_aircraft_id = h.acft_aircraft_id
        join acft_aircraft_type at
        on a.acft_aircraft_type_id = at.acft_aircraft_type_id
        left outer join acft_fleet_group fg
        on at.fleet_group_id = fg.acft_fleet_group_id
        join ACFT_CODE_TYPE hcode
        on h.hold_type_cd = hcode.acft_code_type_id
        where h.expiration_ts >= (sysdate + 5/24)
        and h.is_deleted_flg = 'F'
    SQL
  end

  def filtered_default_order
    query = expected_table_sql
    clause = {
        :ordered => "order by at.display_rnk asc, h.expiration_ts asc, h.hold_pct asc, a.aircraft_tail_nbr asc, a.aircraft_tail_nbr asc, hold_type desc"
    }
    query + clause[:ordered]
  end

  def filtered_by_fleet_group_sql(fleet_group)
    query = expected_table_sql
    clause = {
        :fleet_group => "and fg.fleet_group_name = \'#{fleet_group}\'" +
            "order by at.display_rnk asc, h.expiration_ts asc, h.hold_pct asc, a.aircraft_tail_nbr asc"
    }
    query + clause[:fleet_group]
  end

  def filtered_by_user_search_sql(held_by)
    query = expected_table_sql
    clause = {
        :user_search => "and h.held_by_user_name like \'%#{held_by}%\' " +
            "order by at.display_rnk asc, h.expiration_ts asc, h.hold_pct asc, a.aircraft_tail_nbr asc"
    }
    query + clause[:user_search]
  end

  def filtered_by_tail_sql(tail_number)
    query = expected_table_sql
    clause = {
        :held_tail => "and a.aircraft_tail_nbr like \'%#{tail_number}%\' " +
            "order by at.display_rnk asc, h.expiration_ts asc, h.hold_pct asc, a.aircraft_tail_nbr asc"
    }
    query + clause[:held_tail]
  end

  def filtered_by_ac_type_sql(aircraft_type)
    query = expected_table_sql
    clause = {
        :aircraft_type => "and at.aircraft_type_name = \'#{aircraft_type}\'" +
            "order by at.display_rnk asc, h.expiration_ts asc, h.hold_pct asc, a.aircraft_tail_nbr asc"
    }
    query + clause[:aircraft_type]
  end

  def filtered_by_vintage_sql(vintage)
    query = expected_table_sql
    clause = {
        :vintage => "and to_char(extract(year from a.manufacture_dt)) = \'#{vintage}\'" +
            "order by at.display_rnk asc, h.expiration_ts asc, h.hold_pct asc, a.aircraft_tail_nbr asc"
    }
    query + clause[:vintage]
  end

  def filtered_by_hold_type_sql(hold_type)
    query = expected_table_sql
    clause = {
        :hold_type => "and hcode.code_type_name = \'#{hold_type}\'" +
            "order by at.display_rnk asc, h.expiration_ts asc, h.hold_pct asc, a.aircraft_tail_nbr asc"
    }
    query + clause[:hold_type]
  end

  def filtered_by_fg_and_type_sql(fleet_group, aircraft_type)
    query = expected_table_sql
    clause = {
        :fg_type => "and fg.fleet_group_name =  \'#{fleet_group}\'" +
            "and at.aircraft_type_name = \'#{aircraft_type}\'" +
            "order by at.display_rnk asc, h.expiration_ts asc, h.hold_pct asc, a.aircraft_tail_nbr asc"
    }
    query + clause[:fg_type]
  end

  def filtered_by_v_and_h_type(vintage, hold_type)
    query = expected_table_sql
    clause = {
        :v_hold_type => "and to_char(extract(year from a.manufacture_dt)) = \'#{vintage}\'" +
            "and hcode.code_type_name = \'#{hold_type}\'" +
            "order by at.display_rnk asc, h.expiration_ts asc, h.hold_pct asc, a.aircraft_tail_nbr asc"
    }
    query + clause[:v_hold_type]
  end

  def filtered_v_fg_and_h_type(vintage, hold_type, fleet_group)
    query = expected_table_sql
    clause = {
        :hold_vintage_fg => "and  hcode.code_type_name = \'#{hold_type}\'" +
            "and to_char(extract(year from a.manufacture_dt)) = \'#{vintage}\'" +
            "and fg.fleet_group_name =  \'#{fleet_group}\'" +
            "order by at.display_rnk asc, h.expiration_ts asc, h.hold_pct asc, a.aircraft_tail_nbr asc"
    }
    query + clause[:hold_vintage_fg]
  end

  def expect_holds_acft_types_sql
    <<-SQL.gsub(/^ {8}/, '')
        select aircraft_type_name from acft_aircraft_type where active_status_flg = 'T' order by aircraft_type_name
    SQL
  end

  def expect_holds_fleet_groups_sql
    <<-SQL.gsub(/^ {6}/, '')
      select fleet_group_name from acft_fleet_group order by fleet_group_name
    SQL
  end

  def total_hold_pct(tail_no)
    <<-SQL.gsub(/^ {6}/, '')
      select sum(h.hold_pct)
        from acft_hold h
        where h.acft_aircraft_id = (select acft_aircraft_id from  acft_aircraft where aircraft_tail_nbr = \'#{tail_no}\')
    SQL
  end

end
