require 'page-object'
require 'confirmations'

class Settings

  include PageObject
  include Confirmations

  text_field(:max_legal_hold_duration, :id => 'maxLegalHoldDuration')
  text_field(:identified_for_disposal_threshold, :id => 'disposalThresholdMonths')

  button(:save, :id => 'saveSettings')
  button(:cancel, :id => 'cancelSettings')

  div(:error_message, :id => 'errorDialogData')

  def current_aircraft_inventory_settings
    {
        :max_legal_hold_duration => max_legal_hold_duration,
        :identified_for_disposal_threshold => identified_for_disposal_threshold
    }
  end

end