require 'page-object'

module Confirmations
  include PageObject

  button(:confirm_settings_saved, :id => 'settingsSavedConfirm')
end