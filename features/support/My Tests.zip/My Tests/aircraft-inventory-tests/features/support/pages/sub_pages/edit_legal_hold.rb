require 'page-object'
require 'aircraft_holds_data'
require 'aircraft_data'
require 'audit_log'

module EditLegalHold
  include PageObject
  include AircraftHoldsData
  include AircraftData

  h5(:title, :id => 'modalStdHoldTitle')
  select(:edit_legal_hold_interest_size, :id => 'editInterestSize')
  select(:edit_hold_type, :id => 'editHoldType')
  button(:edit_legal_hold_save, :id => 'confirmEditLglHoldSave')
  button(:edit_legal_hold_cancel, :id => 'confirmEditLglHoldCancel')
  text_area(:edit_legal_notes, :id => 'editNotesTxtArea')
  text_field(:edit_hold_end_date, :id => 'editHoldEndDate')
  button(:edit_hold_ok, :id => 'editHoldConfirm')
  div(:confirmation_message, :id => 'createEditSuccess')

  def yesterday_end_date
    d = Date.parse(Time.now.to_s)
    (d >> 1).strftime("%d/%m/%Y")
    d = d - 1
    d.strftime("%m/%d/%Y")
  end

  def today_end_date
    d = Date.parse(Time.now.to_s)
    d.strftime("%m/%d/%Y")
  end

  def distant_end_date
    d = Date.parse(Time.now.to_s)
    (d >> 1).strftime("%d/%m/%Y")
    d = d + 62
    d.strftime("%m/%d/%Y")
  end

end