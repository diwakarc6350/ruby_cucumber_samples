class Array
  def decreasing?
    each_cons(2).all? { |a,b| (a <=> b) >= 0}
  end

  def increasing?
    each_cons(2).all? { |a,b| (a <=> b) <= 0}
  end
end