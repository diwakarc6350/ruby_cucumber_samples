Then(/^I should be able to create an Aircraft Type$/) do
  on_page AircraftInventory do |p|
    p.inventory
    expect(p.administration_element.exists?).to be_true
  end
end

When(/^I create an Aircraft Type with no required fields$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft_type
    p.save_aircraft_type(confirm=false)
  end
end

When(/^I create an Aircraft Type with long legal model$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft_type
    p.legal_model_name = p.data_for(:aircraft_type_invalid)['legal_model']
  end
end

When(/^I create an Aircraft Type with manufacturer name more than (\d+) characters$/) do |arg|
  on_page(InventoryAdministration) do |p|
    p.create_aircraft_type
    p.manufacturer = p.data_for(:aircraft_type_invalid)['manufacturer']
    p.save_aircraft_type
  end
end

When(/^I create a duplicate Aircraft Type$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft_type
    p.populate_page_with p.data_for(:aircraft_type_create)
    p.aircraft_type_name = p.aircraft_types_options[1]
    p.save_aircraft_type(confirm=false)
  end
end

When(/^I create an Aircraft Type with optional values$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft_type
    p.populate_page_with p.data_for(:aircraft_type_create)
    p.notes = 'some notes'
    p.fleet_group = p.fleet_group_options[1]
    p.save_aircraft_type(confirm=true)
  end
end

Then(/^the aircraft type should be created$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_types_options).to include(p.data_for(:aircraft_type_create)['aircraft_type_name'])
  end
end

And(/^the create aircraft type action is logged in the audit trail$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.audited?('Create', 'Aircraft Type', p.data_for(:aircraft_type_create)['aircraft_type_name'],
                      USER_MAP['AIS Administrator'.to_sym][:user])).to be_true
  end
end

When(/^I create an Aircraft Type with no optional values$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft_type
    p.populate_page_with p.data_for(:aircraft_type_create)
    p.save_aircraft_type(confirm=true)
  end
end

When(/^I create an Aircraft Type with the bottom ranking$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft_type
    p.populate_page_with p.data_for(:aircraft_type_create)
    @last_rank = p.aircraft_type_rankings[-1].rank.to_i + 1 #latest rank
    p.rank = @last_rank
    p.save_aircraft_type(confirm=true)
  end
end

When(/^I create an Aircraft Type$/) do
  login_to_AIS
  on_page(AircraftInventory).inventory
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.new_aircraft_type
    p.wait_for_ajax
    p.populate_page_with p.data_for(:messy_aircraft_type_create)
    @dynamic_aircraft_type = 'TIMECRAFT ' + Time.new.to_s
    p.aircraft_type_name = @dynamic_aircraft_type
    p.legal_model_name = @dynamic_aircraft_type
    p.save_aircraft_type(confirm=true)
    mess = AircraftTypeMess.new(@dynamic_aircraft_type)
    Janitor.add_mess(mess)
  end
end

Then(/^Aircraft Cabin Class should be ordered by ascending size$/) do
  on_page(InventoryAdministration) do |p|
    # expect(p.cabin_class_options).to eq(['Select'] + p.data_for(:static_data)['aircraft_cabin_classes'])
    expect(p.cabin_class_options).to eq(['Select'] + AcftCabinClass.all.map { |cabin_class| cabin_class.cabin_class_name })

  end
end

Then(/^the length of the legal model name should not be more than (\d+)$/) do |length|
  on_page(InventoryAdministration) do |p|
    expect(@browser.text).to include('Legal Model Name must be less than 40 characters long')
    expect(p.save_ac_type_element.enabled?).to eq(false)
  end
end

Then(/^the length of the manufacturer should not be more than (\d+)$/) do |length|
  on_page(InventoryAdministration) do |p|
    expect(@browser.text).to include('Manufacturer must be less than 40 characters long')
    expect(p.save_ac_type_element.enabled?).to eq(false)
  end
end


Then(/^the length of the aircraft type name should not be more than (\d+)$/) do |length|
  on_page(InventoryAdministration) do |p|
    expect(@browser.text).to include('Aircraft Type must be less than 40 characters long')
    expect(p.save_ac_type_element.enabled?).to eq(false)
  end
end

Then(/^I should see an error message$/) do
  on_page(InventoryAdministration) do |p|
    expect(@browser.text).to include("Aircraft Type is required" ||
                                         "Manufacturer is required" ||
                                         "Aircraft Cabin Class is required" ||
                                         "Legal Model Name is required" ||
                                         "Sale Status is required" ||
                                         "Number of Engines are required")
    expect(p.save_ac_type_element.enabled?).to eq(false)
  end
end

When(/^I create an Aircraft Type with long manufacturer$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft_type
    p.manufacturer = p.data_for(:aircraft_type_invalid)['manufacturer']
  end
end

When(/^I create an Aircraft Type with long name$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft_type
    p.aircraft_type_name = p.data_for(:aircraft_type_invalid)['type']
  end
end

When(/^I create an Aircraft Type with long notes$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft_type
    p.notes = p.data_for(:aircraft_type_invalid)['notes']
  end
end

Then(/^the length of the notes should not be more than (\d+)$/) do |length|
  on_page(InventoryAdministration) do |p|
    expect(@browser.text).to include('Notes must be less than 500 characters long')
    expect(p.save_ac_type_element.enabled?).to eq(false)
  end
end

Given(/^There is an Aircraft Type$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as
  end
  sleep 2
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.aircraft_types = p.data_for(:aircraft_type_edit)['aircraft_type_name']
  end
end

When(/^I change Aircraft Type Manufacturer and Model name$/) do
  on_page(InventoryAdministration) do |p|
    p.edit_aircraft_type
    p.legal_model_name = p.data_for(:aircraft_type_edit)['legal_model_name']
    p.manufacturer = p.data_for(:aircraft_type_edit)['manufacturer']
    p.update_aircraft_type
  end
end

When(/^I change the Aircraft Type rank$/) do
  on_page(InventoryAdministration) do |p|
    sleep 2
    p.edit_aircraft_type
    p.rank = (p.aircraft_type_rankings[-1].rank.to_i/2)
    p.update_aircraft_type
    p.aircraft_types = p.data_for(:aircraft_type_edit)['aircraft_type_name']
    sleep 2
    p.edit_aircraft_type
    @old_aircraft_type_ranks = p.aircraft_type_rankings.map { |acft| {aircraft_type: acft.aircraft_type, rank: acft.rank} }.delete_if { |acft| acft[:aircraft_type] == p.data_for(:aircraft_type_edit)['aircraft_type_name'] }
    @old_rank = p.rank.to_i
    @new_rank = rand(2..@old_aircraft_type_ranks.size)
    p.rank= @new_rank
    p.update_aircraft_type
  end
end

# When(/^I change Aircraft Type rank to a lower rank$/) do
#   on_page(InventoryAdministration) do |p|
#     p.edit_aircraft_type
#     p.rank = (p.aircraft_type_rankings[-1].rank.to_i/2)
#     p.update_aircraft_type
#     p.aircraft_types = p.data_for(:aircraft_type_edit)['aircraft_type_name']
#     p.edit_aircraft_type
#     @old_aircraft_type_ranks = p.aircraft_type_rankings.map{|acft| {aircraft_type: acft.aircraft_type, rank: acft.rank}}
#     @new_rank = p.rank.to_i - 1
#     p.rank = @new_rank
#     p.update_aircraft_type
#   end
# end

Then(/^Manufacturer and Model should be updated and audit trail logged$/) do
  on_page(InventoryAdministration) do |p|
    p.aircraft_types = p.data_for(:aircraft_type_edit)['aircraft_type_name']
    sleep 1
    expect(p.manufacturer).to eq(p.data_for(:aircraft_type_edit)['manufacturer'])
    expect(p.legal_model_name).to eq(p.data_for(:aircraft_type_edit)['legal_model_name'])
    expect(p.audited?('Update', 'Aircraft Type', p.data_for(:aircraft_type_edit)['aircraft_type_name'],
                      USER_MAP['AIS Administrator'.to_sym][:user])).to be_true
  end
end

When(/^I change Aircraft Type Engine, Cabin Size and Sales Status$/) do
  on_page(InventoryAdministration) do |p|
    p.edit_aircraft_type
    sleep 2
    p.no_of_engines = p.data_for(:aircraft_type_edit)['no_of_engines']
    @cabin_class = AcftCabinClass.all.map { |cabin_class| cabin_class.cabin_class_name }.sample
    p.cabin_class = @cabin_class
    p.sales_status = p.data_for(:aircraft_type_edit)['sales_status']
    p.update_aircraft_type
  end
end

Then(/^Engine, Cabin Size and Sales Status should be updated and audit trail logged$/) do
  on_page(InventoryAdministration) do |p|
    p.aircraft_types = p.data_for(:aircraft_type_edit)['aircraft_type_name']
    sleep 3

    p.edit_aircraft_type
    expect(p.no_of_engines.to_i).to eq((p.data_for(:aircraft_type_edit)['no_of_engines']))
    expect(p.sales_status).to eq(p.data_for(:aircraft_type_edit)['sales_status'])
    expect(p.cabin_class).to eq(@cabin_class)
    expect(p.audited?('Update', 'Aircraft Type', p.data_for(:aircraft_type_edit)['aircraft_type_name'],
                      USER_MAP['AIS Administrator'.to_sym][:user])).to be_true
  end
end

When(/^I update Aircraft Types optional fields$/) do
  on_page(InventoryAdministration) do |p|
    p.edit_aircraft_type
    p.fleet_group = p.fleet_group_options[2]
    p.notes = p.data_for(:aircraft_type_edit)['notes']
    p.update_aircraft_type
  end
end

Then(/^Optional fields should be updated and audit trail logged$/) do
  on_page(InventoryAdministration) do |p|
    p.aircraft_types = p.data_for(:aircraft_type_edit)['aircraft_type_name']
    sleep 2
    p.edit_aircraft_type
    sleep 2
    expect(p.fleet_group).to eq(p.fleet_group_options[2])
    expect(p.notes).to eq(p.data_for(:aircraft_type_edit)['notes'])
    expect(p.audited?('Update', 'Aircraft Type', p.data_for(:aircraft_type_edit)['aircraft_type_name'],
                      USER_MAP['AIS Administrator'.to_sym][:user])).to be_true
  end
end

Given(/^There is an Aircraft Type with no Active Aircrafts$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as
  end
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.aircraft_types = p.data_for(:aircraft_inactivate)['valid']
  end

end

When(/^I inactivate the Aircraft Type$/) do
  on_page(InventoryAdministration) do |p|
    p.inactivate
    p.inactivate_aircraft
    p.delete
  end
end

Then(/^Aircraft Type is inactivated$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_types_options).not_to include(p.data_for(:aircraft_type_edit)['aircraft_type'])
    p.clean_aircraft_type
  end
end

And(/^the update aircraft type action is logged in the audit trail$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.audited?('Inactivate', 'Aircraft Type', p.data_for(:aircraft_inactivate)['valid'],
                      USER_MAP['AIS Administrator'.to_sym][:user])).to be_true
  end
end

Given(/^There is an Aircraft Type with Active Aircrafts$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as
  end
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    @aircraft_type_to_inactivate = p.data_for(:aircraft_inactivate)['invalid']
    p.aircraft_types = @aircraft_type_to_inactivate
  end
end

When(/^I Inactivate an Aircraft Type with Active Aircrafts$/) do
  on_page(InventoryAdministration) do |p|
    p.inactivate
    p.inactivate_aircraft
    p.delete
  end
end

Then(/^I should not be able to inactivate$/) do
  expect(@browser.text).to include('Aircraft Type to be Inactivated has associated Aircraft')
end

Then(/^I should see an duplicate aircraft type error message$/) do
  expect(@browser.text).to include('Aircraft Type should be unique')
end

When(/^I cancel creating an Aircraft Type$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as
  end
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft_type
    p.aircraft_type_name = 'Airbus A380'
  end
end

Then(/^the Aircraft Type should not be created$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_types_options).not_to include('Airbus A380')
  end
end

Then(/^I should see correct Aircraft Type information$/) do
  on_page(InventoryAdministration) do |p|
    p.aircraft_types = p.data_for(:aircraft_type_edit)['aircraft_type_name']
    expect(@browser.text).to include(p.data_for(:aircraft_type_edit)['manufacturer'])
    expect(@browser.text).to include(p.data_for(:aircraft_type_edit)['legal_model_name'])
    expect(@browser.text).to include(p.data_for(:aircraft_type_edit)['sales_status'])
    expect(@browser.text).to include(p.data_for(:aircraft_type_edit)['aircraft_type_name'])

  end
end

When(/^an "([^"]*)" is viewing an Active Aircraft Type$/) do |role|
  visit_page LoginPage do |login_page|
    login_page.login_as(role)
  end

  on_page AircraftInventory do |p|
    p.inventory
    p.select_aircraft_type
  end

end

Then(/^I should be able to edit Aircraft Type$/) do
  expect(on(AircraftInventory).edit_ac?).to equal(true)
end

Then(/^I should not be able to edit Aircraft Type$/) do
  expect(on(AircraftInventory).edit_ac?).to equal(false)
end

When(/^an AIS Administrator is viewing an Inactive Aircraft Type$/) do
  visit_page LoginPage do |login_page|
    login_page.login_as('AIS Administrator')
  end

  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.populate_page_with p.data_for(:aircraft_create_with_no_options)
    p.aircraft_aircraft_types = 'Encore'
    p.aircraft_states = 'Cancelled'
    p.aircraft_save
  end

  on_page AircraftInventory do |p|
    p.inventory
    p.uncheck_inventory_only
    p.wait_for_ajax
    p.tail_number = 'N9999QS'
    p.search
    sleep 1
    p.raw_aircraft_inventory[1].ac_type
  end
end


Then(/^the aircraft is added to the ranking list with that rank$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.aircraft_types = p.data_for(:aircraft_type_create)['aircraft_type_name']
    sleep 2
    p.edit_aircraft_type
    sleep 2
    expect(p.aircraft_type_rankings[-1].rank.to_i).to eq @last_rank
    expect(p.aircraft_type_rankings[-1].aircraft_type).to eq p.data_for(:aircraft_type_create)['aircraft_type_name']
  end
end

Then(/^the aircraft rank is set to that rank$/) do
  on_page(InventoryAdministration) do |p|
    p.aircraft_types = p.data_for(:aircraft_type_edit)['aircraft_type_name']
    sleep 2
    p.edit_aircraft_type
    expect(p.rank.to_i).to eq @new_rank
  end
end

And(/^all the aircraft ranks adjust based on the new rank$/) do
  effected_ranks = @old_aircraft_type_ranks.select do |acft|
    r = acft.fetch(:rank).to_i
    x = [@new_rank, @old_rank]
    r.between?(x.min, x.max)
  end

  if @old_rank < @new_rank
    @new_acft_ranks = effected_ranks.map do |r|
      r[:rank] = (r[:rank].to_i - 1).to_s
      r
    end
  elsif @old_rank > @new_rank
    @new_acft_ranks = effected_ranks.map do |r|
      r[:rank] = (r[:rank].to_i + 1).to_s
      r
    end
  else
    pending("Rank Did Not Change!")
  end

  new_aircraft_type_ranks = on_page(InventoryAdministration).aircraft_type_rankings.map { |acft| {aircraft_type: acft.aircraft_type, rank: acft.rank} }.delete_if { |acft| acft[:aircraft_type] == p.data_for(:aircraft_type_edit)['aircraft_type_name'] }.select do |acft|
    r = acft.fetch(:rank).to_i
    x = [@new_rank, @old_rank]
    r.between?(x.min, x.max)
  end

  expect(new_aircraft_type_ranks).to eq @new_acft_ranks
  acft_in_new_ranking = on_page(InventoryAdministration).aircraft_type_rankings.find { |acft| acft.rank == @new_rank.to_s }.aircraft_type
  expect(acft_in_new_ranking).to eq p.data_for(:aircraft_type_edit)['aircraft_type_name']
end


When(/^I change the Aircraft Type rank of the aircraft to a number higher then the number of aircrafts$/) do
  on_page(InventoryAdministration) do |p|
    sleep 2
    p.edit_aircraft_type
    p.rank = (p.aircraft_type_rankings[-1].rank.to_i + rand(2..100))
  end
end

Then(/^the rank cannot be saved$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.confirm_ac_type_edit_element).to be_disabled
    expect(@browser.text).to include("Please enter a value less than or equal to #{p.aircraft_type_rankings[-1].rank.to_i + 1}")
  end

end

Then(/^that Aircraft Type is visible in Aircraft Inventory Management$/) do
  expect(on_page(AircraftInventory).aircraft_types_options).to include(@dynamic_aircraft_type)
end

When(/^I edit the Aircraft Type$/) do
  on_page(InventoryAdministration).aircraft_types = @dynamic_aircraft_type
  on_page(InventoryAdministration).wait_for_ajax
  on_page(InventoryAdministration).edit_ac_type
  @dynamic_aircraft_type += 'Z'
  on_page(InventoryAdministration).aircraft_type_name = @dynamic_aircraft_type
  on_page(InventoryAdministration).confirm_ac_type_edit
end

Then(/^the Aircraft Type is updated with my changes$/) do
  expect(on_page(AircraftInventory).aircraft_types_options).to include(@dynamic_aircraft_type)
end