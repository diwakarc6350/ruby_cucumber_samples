include DataMagic

def check_aircraft_legal_hold(tail_number)
  on_page AircraftInventory do |p|
    p.inventory
    p.select_aircraft_by_tail(tail_number)
  end
  on AircraftDetail do |p|
    expect(p.expected_current_holds_by_tail(tail_number)).to eq(p.actual_current_holds)
  end
end

When(/^there is an available aircraft (.*)$/) do |tail_Number|
  on_page AircraftInventory do |p|
    p.inventory
    p.select_aircraft_by_tail(tail_Number)
  end
end

And(/^the hold action is logged in the audit trail$/) do
  on_page AircraftDetail do |p|
    expect(p.audited?('Create', 'Hold', 'Legal-' + self.data_for(:aircraft_legal_holds)['tail_numbers'][0].to_s,
                      USER_MAP['AIS User'.to_sym][:user])).to be_true
  end
end

Then(/^I should be able to place legal holds$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.select_aircraft_tail
  end
  on_page AircraftDetail do |p|
    sleep 1
    place_legal_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][0], 3.125, self.data_for(:aircraft_view_holds)['hold_notes'])
  end
end

Then(/^I should be able to place core holds$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.select_aircraft_tail
  end
  on_page AircraftDetail do |p|
    sleep 1
    place_core_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][0], 3.125, self.data_for(:aircraft_view_holds)['hold_notes'])
  end
end

Then(/^I should not be able to place holds$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.select_aircraft_tail
  end
  on_page AircraftDetail do |p|
    expect(p.place_hold_btn_element.exists?).to be_false
  end
end

Then(/^I should not be able to place core holds$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.aircraft_inventory_element[1][10].click
    p.select_aircraft_tail
  end
  on_page AircraftDetail do |p|
    place_legal_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][0], 3.125, self.data_for(:aircraft_view_holds)['hold_notes'])
    p.place_hold
    sleep 1
    expect(p.hold_type_element.disabled?).to eq(true)
  end
end

When(/^I create notes with more than (\d+) characters$/) do |arg|
  on_page AircraftDetail do |p|
    p.place_hold
    sleep 1
    p.legal_notes = p.data_for(:aircraft_legal_holds)['notes']
  end
end

Then(/^I should receive a notes cannot be more than (\d+) characters long error$/) do |arg|
  on_page AircraftDetail do |p|
    expect(@browser.text).to include("Notes must be less than 500 characters long")
  end
end


Then(/^I should be able to place a (.*) Legal Hold$/) do |interest_Size|
  on_page AircraftDetail do |p|
    p.place_hold
    sleep 1
    p.legal_hold_interest_size = interest_Size.to_s
    p.hold_end_date = p.data_for(:aircraft_legal_holds)['hold_end_date']
    p.legal_notes = 'Placing a legal hold'
    p.legal_hold_save
  end
end

When(/^there is an available aircraft$/) do
  on_page AircraftInventory do |p|
    p.inventory
    tail = p.select_first_tail_number_with_holds
    p.select_aircraft_by_tail(tail)
  end
end

And(/^the hold action for (.*) is logged in the audit trail$/) do |tail_Number|
  on_page AircraftDetail do |p|
    expect(p.audited?('Hold', 'Aircraft Type', tail_Number.to_s,
                      USER_MAP['AIS Sales User'.to_sym][:user])).to be_true
  end
end

When(/^I place legal holds on multiple Aircrafts$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as("AIS User")
  end
  place_legal_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][0], 3.125, self.data_for(:aircraft_view_holds)['hold_notes'])
  place_legal_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][1], 6.25, self.data_for(:aircraft_view_holds)['hold_notes'])
  place_legal_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][2], 100, self.data_for(:aircraft_view_holds)['hold_notes'])
end

When(/^I place core holds on multiple Aircraft$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as("AIS Administrator")
  end
  place_core_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][0], 3.125, self.data_for(:aircraft_view_holds)['hold_notes'])
  place_core_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][1], 6.25, self.data_for(:aircraft_view_holds)['hold_notes'])
  place_core_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][2], 100, self.data_for(:aircraft_view_holds)['hold_notes'])
end

Then(/^the tail is held for those percentages$/) do
  check_aircraft_legal_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][0])
  check_aircraft_legal_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][1])
  check_aircraft_legal_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][2])
end

When(/^I place multiple legal holds on an Aircraft$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as("AIS User")
  end
  place_legal_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][0], 25, self.data_for(:aircraft_view_holds)['hold_notes'])
  place_legal_acft_hold_no_del(self.data_for(:aircraft_legal_holds)['tail_numbers'][0], 25, self.data_for(:aircraft_view_holds)['hold_notes'])
end

When(/^I place multiple core holds on an Aircraft$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as("AIS Administrator")
  end
  place_core_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][0], 25, self.data_for(:aircraft_view_holds)['hold_notes'])
  place_core_acft_hold_no_del(self.data_for(:aircraft_legal_holds)['tail_numbers'][0], 25, self.data_for(:aircraft_view_holds)['hold_notes'])
end

Given(/^a tail currently has a hold$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as("AIS User")
  end
  place_legal_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][0], 50, self.data_for(:aircraft_view_holds)['hold_notes'])
end

When(/^I place a legal hold exceeding 100%$/) do
  #place_legal_aircraft_hold('N802QS', 100)
end

When(/^I place a core hold$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as("AIS Administrator")
  end
  on_page AircraftInventory do |p|
    p.inventory
    p.select_first_tail_with_holds
  end
  on_page AircraftDetail do |p|
    p.place_hold
    p.hold_type = 'Core'
  end
end

Then(/^I should see only valid interest sizes up to maximum of 100%$/) do
  on_page AircraftDetail do |p|
    p.hold_type = 'Core'
    (p.legal_hold_interest_size_options[-1]).to_i.should be <= 100
  end
end

Then(/^I should not be able to save the hold$/) do
  pending
end

And(/^the hold actions are logged in the audit trail$/) do
  on_page AircraftDetail do |p|
    expect(p.audited?('Create', 'Hold', 'Legal-' + self.data_for(:aircraft_legal_holds)['tail_numbers'][0].to_s,
                      USER_MAP['AIS User'.to_sym][:user])).to be_true
    expect(p.audited?('Create', 'Hold', 'Legal-' + self.data_for(:aircraft_legal_holds)['tail_numbers'][1].to_s,
                      USER_MAP['AIS User'.to_sym][:user])).to be_true
    expect(p.audited?('Create', 'Hold', 'Legal-' + self.data_for(:aircraft_legal_holds)['tail_numbers'][2].to_s,
                      USER_MAP['AIS User'.to_sym][:user])).to be_true
  end
end

When(/^I am viewing a hold$/) do
  login_as_admin
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_holds_aircraft
    p.aircraft_aircraft_types = p.aircraft_aircraft_types_options[2]
    p.populate_page_with p.data_for(:hold_test_aircraft)
    p.aircraft_save
  end
  on_page(AircraftHoldSearch).hold_search
  place_legal_aircraft_hold(self.data_for(:hold_test_aircraft)['aircraft_tail_no'], 25, self.data_for(:aircraft_view_holds)['hold_notes'])
end

Then(/^I should be able to delete that hold$/) do
  on_page AircraftDetail do |p|
    p.delete_first_hold
    p.wait_for_ajax
    p.delete_hold
  end
end

When(/^I have placed a hold$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as('AIS User')
  end
  on_page AircraftInventory do |p|
    p.delete_user_settings('qatest2')
    p.delete_user_settings('qatest20')
  end
  place_legal_aircraft_hold(self.data_for(:hold_test_aircraft)['aircraft_tail_no'], 3.125, self.data_for(:aircraft_view_holds)['hold_notes'])
end

Then(/^I should be able to edit the hold$/) do
  on_page(AircraftHoldSearch).hold_search
  on_page AircraftHoldSearch do |p|
    p.query = p.data_for(:hold_test_aircraft)['aircraft_tail_no']
    p.search
    p.edit_first_hold
  end
end

When(/^I am viewing a hold placed by another user$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as('AIS Administrator')
  end
  place_legal_aircraft_hold(self.data_for(:hold_test_aircraft)['aircraft_tail_no'], 3.125, self.data_for(:aircraft_view_holds)['hold_notes'])
  on_page(AircraftHoldSearch).logout
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as('AIS User')
  end
  on_page(AircraftHoldSearch).hold_search
  on_page AircraftHoldSearch do |p|
    p.query = p.data_for(:hold_test_aircraft)['aircraft_tail_no']
    p.search
  end
end

Then(/^I should not be able to edit the hold$/) do
  on_page AircraftHoldSearch do |p|
    expect(p.raw_aircraft_holds[1].edit_hold?).to equal(false)
  end
end

Given(/^there is a hold$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as('AIS User')
  end
  place_legal_aircraft_hold(self.data_for(:hold_test_aircraft)['aircraft_tail_no'], 3.125, self.data_for(:aircraft_view_holds)['hold_notes'])
end

When(/^I edit a hold from Hold Search$/) do
  on_page AircraftHoldSearch do |p|
    p.hold_search
    p.query = p.data_for(:hold_test_aircraft)['aircraft_tail_no']
    p.search
    p.edit_first_hold
  end
end

When(/^I edit a hold from Aircraft Detail$/) do
  on_page(AircraftHoldSearch).hold_search
  on_page AircraftHoldSearch do |p|
    p.query = p.data_for(:hold_test_aircraft)['aircraft_tail_no']
    p.search
    p.view_first_hold
  end
  on_page AircraftDetail do |p|
    p.edit_first_hold
  end
end

Then(/^I should see the current values$/) do
  on_page AircraftHoldSearch do |p|
    expect(p.edit_legal_hold_interest_size).to eq('3.125')
    expect(p.edit_hold_end_date).to eq(p.data_for(:aircraft_legal_holds)['hold_end_date'])
    p.edit_legal_hold_interest_size = 6.25
    p.edit_hold_end_date = p.data_for(:aircraft_legal_holds)['hold_end_date']
    p.edit_legal_notes = 'Editing a legal hold'
    p.edit_legal_hold_save
  end
end

And(/^I should see a success message$/) do
  on_page AircraftHoldSearch do |p|
    p.wait_for_ajax
    expect(p.confirmation_message).to include('The hold has been Edited successfully.')
    p.edit_hold_ok
  end
end

And(/^the edit hold action is logged in the audit trail$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.audited?('Update', 'Hold', 'Legal-' + p.data_for(:hold_test_aircraft)['aircraft_tail_no'],
                      USER_MAP['AIS User'.to_sym][:user])).to be_true
  end
end

And(/^the hold should be modified on the detail screen$/) do
  on_page AircraftHoldSearch do |p|
    expect(p.current_holds).to include('6.25%')
  end
end

And(/^the hold should be modified on the hold search screen$/) do
  on_page AircraftHoldSearch do |p|
    p.query = p.data_for(:hold_test_aircraft)['aircraft_tail_no']
    p.search
    sleep 1
    expect(p.raw_aircraft_holds[1].amount_held).to eq('6.25 %')
  end
end

When(/^I edit a hold$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as('AIS Administrator')
  end
  on_page(AircraftHoldSearch).hold_search
end

When(/^I edit a legal hold$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as('AIS Administrator')
  end
  on_page(AircraftHoldSearch).hold_search
end

When(/^I edit a core hold$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as('AIS Administrator')
  end
  on_page(AircraftHoldSearch).hold_search
end

Then(/^I should be able see the hold notes$/) do
  on_page AircraftDetail do |p|
    p.show_first_notes
    expect(@browser.text).to include("Placing a legal hold")
  end
end

When(/^I choose an Aircraft Tail Number with no hold notes$/) do
  on_page AircraftInventory do |p|
    place_legal_aircraft_hold(p.data_for(:aircraft_view_holds)['tail_with_3_active_holds'], 25, '')
    p.inventory
    p.tail_number = p.data_for(:aircraft_view_holds)['tail_with_3_active_holds']
    p.search
    sleep 2
    p.select_aircraft_tail(1)
  end
end

Then(/^I should not be able see the hold notes$/) do
  on_page AircraftDetail do |p|
    expect(p.no_hold_notes).to eq('N/A')
  end
end

Then(/^I should not be able to exceed maximum availability$/) do
  place_legal_aircraft_hold(self.data_for(:hold_test_aircraft)['aircraft_tail_no'], 75, '')
  place_legal_acft_hold_no_del(self.data_for(:hold_test_aircraft)['aircraft_tail_no'], 25, '')
  on_page AircraftDetail do |p|
    p.edit_first_hold
    p.wait_for_ajax
    expect(p.edit_legal_hold_interest_size_options).to eq(p.data_for(:hold_test_aircraft)['hold_interest_options'])
  end

end

Then(/^I should not be able to choose an expiration date outside of legal boundaries$/) do
  place_legal_aircraft_hold(self.data_for(:hold_test_aircraft)['aircraft_tail_no'], 75, '')
  on_page AircraftDetail do |p|
    p.edit_first_hold
    sleep 1
    p.edit_hold_end_date = p.yesterday_end_date
    expect(@browser.text).to include('Past date not allowed')
    p.edit_hold_end_date = p.distant_end_date
    expect(@browser.text).to include('Date is beyond max hold date limit')
  end
end

Then(/^I should not be able to choose the current date as the expiration date$/) do
  place_legal_aircraft_hold(self.data_for(:hold_test_aircraft)['aircraft_tail_no'], 75, '')
  on_page AircraftDetail do |p|
    p.edit_first_hold
    sleep 1
    p.edit_hold_end_date = p.today_end_date
    expect(@browser.text).to include('Current date not allowed')
  end
end

Then(/^I should be able to choose any future expiration date$/) do
  place_core_aircraft_hold(self.data_for(:hold_test_aircraft)['aircraft_tail_no'], 75, '')
  on_page AircraftDetail do |p|
    p.edit_first_hold
    sleep 1
    p.edit_hold_end_date = p.distant_end_date
    p.edit_legal_hold_save
  end
end

Then(/^I should be able to change the expiration date and percentage$/) do
  place_core_aircraft_hold(self.data_for(:hold_test_aircraft)['aircraft_tail_no'], 75, '')
  on_page AircraftDetail do |p|
    p.edit_first_hold
    sleep 1
    p.edit_hold_end_date = p.distant_end_date
    r = Random.new
    p.edit_legal_hold_interest_size = p.edit_legal_hold_interest_size_options[r.rand(1..(p.edit_legal_hold_interest_size_options.length-1))]
    p.edit_legal_hold_save
  end
end

Then(/^I should not be able to change the hold type$/) do
  place_legal_aircraft_hold(self.data_for(:hold_test_aircraft)['aircraft_tail_no'], 75, '')
  on_page AircraftDetail do |p|
    p.edit_first_hold
    sleep 1
    on_page AircraftHoldSearch do |q|
      expect(q.edit_hold_type_element.enabled?).to be(false)
    end
  end
end

When(/^I cancel editing a hold$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as('AIS User')
  end
  on_page(AircraftHoldSearch).hold_search
  place_legal_aircraft_hold(self.data_for(:hold_test_aircraft)['aircraft_tail_no'], 75, 'SECRET HOLD NOTES?!')
  on_page AircraftDetail do |p|
    p.edit_first_hold
    sleep 1
    p.edit_legal_notes = 'This will not be saved'
    p.edit_legal_hold_cancel
  end
end

When(/^I cancel deleting a hold$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as('AIS User')
  end
  on_page(AircraftHoldSearch).hold_search
  place_legal_aircraft_hold(self.data_for(:hold_test_aircraft)['aircraft_tail_no'], 75, '')
  on_page AircraftDetail do |p|
    p.delete_first_hold
    sleep 1
    p.cancel_delete_hold
  end
end

Then(/^the changes should not be saved$/) do
  on_page AircraftDetail do |p|
    p.show_first_notes
    sleep 1
    expect(p.hold_notes).to eq('SECRET HOLD NOTES?!')
  end
end

Then(/^I should not be able to delete that hold$/) do
  on_page AircraftHoldSearch do |p|
    expect(p.raw_aircraft_holds[1].cancel_hold?).to equal(false)
  end
end

When(/^I delete a hold$/) do
  on_page AircraftDetail do |p|
    p.delete_first_hold
    sleep 1
    p.delete_hold
  end
end

Then(/^I should see confirmation of that deletion$/) do
  on_page AircraftDetail do |p|
    p.delete_close
  end
end

And(/^the delete hold action is logged in the audit trail$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.audited?('Delete', 'Hold', 'Legal-' + p.data_for(:hold_test_aircraft)['aircraft_tail_no'],
                      USER_MAP['AIS Administrator'.to_sym][:user])).to be_true
  end
end


Then(/^the hold should not be deleted$/) do
  on_page AircraftDetail do |p|
    expect(p.raw_current_holds[1].interest_size).to eq('75%')
  end
end

When(/^I choose an Aircraft Tail Number with deleted holds$/) do
  on_page AircraftInventory do |p|
    place_legal_aircraft_hold(p.data_for(:aircraft_view_holds)['tail_with_3_active_holds'], 25, '')
  end
  on_page AircraftDetail do |p|
    p.delete_first_hold
    p.wait_for_ajax
    p.delete_hold
    p.wait_for_ajax
    p.delete_close
    p.wait_for_ajax
  end
end

Then(/^I should not be able see the deleted holds$/) do
  on_page AircraftDetail do |p|
    p.go_back_to_inventory
  end
  on_page AircraftInventory do |p|
    p.tail_number = p.data_for(:aircraft_view_holds)['tail_with_3_active_holds']
    p.search
    sleep 2
    p.select_aircraft_tail(1)
    on_page AircraftDetail do |p|
      expect(p.current_holds_element.exists?).to be_false
    end
  end
end

When(/^I choose an Aircraft Tail Number with sum of active core and active legal holds totalling 100%$/) do
  place_core_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][0], 50, self.data_for(:aircraft_view_holds)['hold_notes'])
  place_legal_acft_hold_no_del(self.data_for(:aircraft_legal_holds)['tail_numbers'][0], 50, self.data_for(:aircraft_view_holds)['hold_notes'])
end

Then(/^the place hold button must be disabled$/) do
  on_page AircraftDetail do |p|
    expect(p.place_hold_btn_element.enabled?).to be_false
  end
end

Given(/^there is a 100% hold on a tail$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as("AIS User")
  end
  place_core_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][0], 100, self.data_for(:aircraft_view_holds)['hold_notes'])
end

When(/^I delete that hold$/) do
  on_page AircraftDetail do |p|
    p.delete_first_hold
    p.wait_for_ajax
    p.delete_hold
    p.wait_for_ajax
    p.delete_close
  end
end

Then(/^I should be able to place a hold on the tail$/) do
  on_page AircraftDetail do |p|
    expect(p.place_hold_btn_element.enabled?).to be_true
  end
end

When(/^there is a core hold with an end date$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as("AIS Administrator")
  end
  place_core_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][0], 50, self.data_for(:aircraft_view_holds)['hold_notes'])
end

Then(/^I should be able to remove the end date$/) do
  on_page AircraftDetail do |p|
    p.edit_first_hold
    p.wait_for_ajax
    p.edit_hold_end_date = ""
    p.edit_legal_hold_save
    p.wait_for_ajax
    p.edit_hold_ok
  end
end

When(/^there is a core hold$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as("AIS Administrator")
  end
  place_core_aircraft_hold(self.data_for(:aircraft_legal_holds)['tail_numbers'][0], 50, self.data_for(:aircraft_view_holds)['hold_notes'])
end

Then(/^the I should not be able to place another hold that exceeds 100% held$/) do
  on_page AircraftDetail do |p|
    p.place_hold
    (p.legal_hold_interest_size_options[-1]).to_i.should be == 50
  end
end

When(/^I place multiple Legal Holds on an Aircraft$/) do
  login_to_AIS
  on_page(AircraftInventory).inventory
  on_page(AircraftInventory).select_active_tails
  @aircraft = on_page(AircraftInventory).select_first_tail_number_with_no_holds
  place_legal_acft_hold_no_del(@aircraft, '3.125', 'notes')
  on_page(AircraftInventory).create_messy_legal_hold(@aircraft)
  place_legal_acft_hold_no_del(@aircraft, '3.125', 'notes')
  on_page(AircraftInventory).create_messy_legal_hold(@aircraft)
end

Then(/^the Legal Holds are visible on that Aircraft$/) do
  expect(on_page(AircraftDetail).tail_is_held_correctly('3.125', 'Legal')).to be true
end

Given(/^I place a Hold on an Aircraft$/) do
  login_to_AIS
  on_page(AircraftInventory).inventory
  on_page(AircraftInventory).select_active_tails
  @aircraft = on_page(AircraftInventory).select_first_tail_number_with_no_holds
  place_legal_acft_hold_no_del(@aircraft, '3.125', 'notes')
  on_page(AircraftInventory).create_messy_legal_hold(@aircraft)
end

When(/^I edit the Hold$/) do
  on_page(AircraftDetail).edit_first_hold
  on_page(AircraftDetail).wait_for_ajax
  on_page(AircraftHoldSearch).edit_legal_hold_interest_size = '6.25'
  on_page(AircraftHoldSearch).edit_legal_hold_save
  sleep 1
  on_page(AircraftHoldSearch).edit_hold_ok
end

Then(/^the Hold is updated with my changes$/) do
  expect(on_page(AircraftDetail).tail_is_held_correctly('6.25', 'Legal')).to be true
end

When(/^I place multiple Core Holds on an Aircraft$/) do
  login_to_AIS
  on_page(AircraftInventory).inventory
  on_page(AircraftInventory).select_active_tails
  @aircraft = on_page(AircraftInventory).select_first_tail_number_with_no_holds
  place_core_acft_hold_no_del(@aircraft, '3.125', 'notes')
  on_page(AircraftInventory).create_messy_core_hold(@aircraft)
  place_core_acft_hold_no_del(@aircraft, '3.125', 'notes')
  on_page(AircraftInventory).create_messy_core_hold(@aircraft)
end

Then(/^the Core Holds are visible on that Aircraft$/) do
  expect(on_page(AircraftDetail).tail_is_held_correctly('3.125', 'Core')).to be true
end

When(/^I delete a Hold on an Aircraft$/) do
  login_to_AIS
  on_page(AircraftInventory).inventory
  on_page(AircraftInventory).select_active_tails
  @aircraft = on_page(AircraftInventory).select_first_tail_number_with_no_holds
  place_legal_acft_hold_no_del(@aircraft, '3.125', 'notes')
  on_page AircraftDetail do |p|
    p.delete_first_hold
    p.wait_for_ajax
    p.delete_hold
    p.wait_for_ajax
    p.delete_close
  end
end

Then(/^the Hold is no longer placed on the Aircraft$/) do
  expect(on_page(AircraftDetail).current_holds_element.visible?).to be false
end