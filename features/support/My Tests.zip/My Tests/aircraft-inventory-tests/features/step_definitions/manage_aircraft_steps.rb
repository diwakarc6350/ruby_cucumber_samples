def ensure_aircraft_saved_validation_error(error_message)
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_save_element.enabled?).to eq(false)
    expect(@browser.text).to include(error_message)
  end
end

def populate_no_option_ac
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.populate_page_with p.data_for(:aircraft_create_with_no_options)
    p.aircraft_aircraft_types = p.aircraft_aircraft_types_options[1]
  end
end


When(/^I create an Aircraft$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration).create_aircraft
end

Then(/^I should be able to choose from all existing fleet groups$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_fleet_groups_options).to eq(['All'] + p.expected_fleet_groups)
  end
end

Then(/^I should be able to choose from all existing Aircraft States$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_states_options).to eq(['Select'] + p.data_for(:static_data)['all_aircraft_states'])
  end
end

Then(/^I should be able to choose from all existing Ownership Statuses$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_ownership_status_options).to eq(['Select']+ p.data_for(:static_data)['ownership_status'])
  end
end

Then(/^I should be able to choose from all existing Sales Statuses$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_sales_status_options).to eq(['Select'] + p.data_for(:static_data)['sales_status'])
  end
end

Then(/^I should be able to choose from all existing Companies$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_company_options).to match_array(['Select'] + p.data_for(:static_data)['company'])
  end
end

Then(/^I should be able to choose from all existing Insurance Statuses$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_insurance_status_options).to eq(['Select'] + p.data_for(:static_data)['insurance_status'])
  end
end

Then(/^I should be able to choose from all existing Aircraft Types$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_aircraft_types_options).to eq(['Select'] + p.expected_aircraft_types)
  end
end

Then(/^I should receive an error$/) do
  on_page(InventoryAdministration) do |p|
    expect(@browser.text).to include("Tail number is required" ||
                                         "Legal Model Name is required" ||
                                         "Manufacturer is required" ||
                                         "Aircraft Type is required" ||
                                         "Aircraft State is required" ||
                                         "Ownership Status is required" ||
                                         "Sales Status is required")
    expect(p.aircraft_save_element.enabled?).to eq(false)
  end
end

When(/^I create an Aircraft with no information$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration).create_aircraft
  on_page(InventoryAdministration).aircraft_save
end

When(/^I create an Aircraft with a long tail number$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.aircraft_tail_no = p.data_for(:aircraft_invalid)['tail_no']
  end
end

Then(/^I should receive a Tail Number too long error message$/) do
  ensure_aircraft_saved_validation_error("The Tail number must be less than 23 characters long")

end

When(/^I create an Aircraft with a long legal model name$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.aircraft_legal_model_name = p.data_for(:aircraft_invalid)['legal_model']
  end
end

Then(/^I should receive a legal model name too long error message$/) do
  ensure_aircraft_saved_validation_error("The Legal model name must be less than 41 characters long")
end

When(/^I create an Aircraft with a long manufacturer name$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.aircraft_manufacturer = p.data_for(:aircraft_invalid)['manufacturer']
  end
end

Then(/^I should receive a manufacturer name too long error message$/) do
  ensure_aircraft_saved_validation_error("The Manufacturer name must be less than 41 characters long")
end

Then(/^I should receive an invalid warranty date error$/) do
  ensure_aircraft_saved_validation_error("Warranty Date must be a valid date")
end

Then(/^I should receive an invalid contracts until date error$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_save_element.enabled?).to eq(false)
    expect(@browser.text).to include("Contracts Until Date must be a valid date")
  end

end

Then(/^I should receive an invalid title search date error$/) do
  ensure_aircraft_saved_validation_error("Title Search Date must be a valid date")
end

Then(/^I should receive an invalid anticipated delivery date error$/) do
  ensure_aircraft_saved_validation_error("Anticipated Delivery Date must be a valid date")
end

Then(/^I should receive an invalid actual delivery date error$/) do
  ensure_aircraft_saved_validation_error("Actual Delivery Date must be a valid date")
end

When(/^I create an Aircraft with required fields$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.aircraft_aircraft_types = p.aircraft_aircraft_types_options[1]
    p.populate_page_with p.data_for(:aircraft_create_with_no_options)
    p.aircraft_save
  end
end

Then(/^I should see the aircraft in inventory$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircrafts_options).to include(p.data_for(:aircraft_create_with_no_options)['aircraft_tail_no'])
  end
end

And(/^the create aircraft action is logged in the audit trail$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.audited?('Create', 'Aircraft', p.data_for(:aircraft_create_with_no_options)['aircraft_tail_no'],
                      USER_MAP['AIS Administrator'.to_sym][:user])).to be_true
  end
end

When(/^I cancel creating an Aircraft$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.populate_page_with p.data_for(:aircraft_create_with_no_options)
    p.aircraft_aircraft_types = p.aircraft_aircraft_types_options[1]
    p.aircraft_cancel_save
  end
end

Then(/^the aircraft should not be created$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircrafts).not_to include(p.data_for(:aircraft_create_with_no_options)['aircraft_tail_no'])
  end
end

When(/^I create an Aircraft with (\d+) engine information$/) do |engine_count|
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.populate_page_with p.data_for(:aircraft_create_with_no_options)
    if engine_count.to_i==1
      p.populate_page_with p.data_for(:aircraft_create_engine1_options)
    elsif engine_count.to_i==4
      p.populate_page_with p.data_for(:aircraft_create_engine4_options)
    end
    p.aircraft_aircraft_types = p.aircraft_aircraft_types_options[1]
    p.aircraft_save
  end
end

When(/^I create an Aircraft with standard information$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.populate_page_with p.data_for(:aircraft_create_with_no_options)
    p.aircraft_aircraft_types = p.aircraft_aircraft_types_options[1]
    p.populate_page_with p.data_for(:aircraft_create_standard_options)
    p.aircraft_save
  end
end

When(/^I create an Aircraft with delivery information$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.populate_page_with p.data_for(:aircraft_create_with_no_options)
    p.aircraft_aircraft_types = p.aircraft_aircraft_types_options[1]
    p.populate_page_with p.data_for(:aircraft_create_delivery_options)
    p.aircraft_save
  end
end

When(/^I create a managed Aircraft$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.aircraft_ownership_status = 'Managed'
  end
end

Then(/^I should not be able to choose Sales Status$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_sales_status).to eq('No Sales')
  end
end

Then(/^I should see Insurance Status$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_insurance_status_element.visible?).to eq(true)
  end
end

When(/^I create a leased aircraft$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.aircraft_ownership_status = 'Leased'
  end
end

Then(/^I should not be able to choose insurance status$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_insurance_status_element.visible?).to eq(false)
  end
end

When(/^I create a Aircraft$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.populate_page_with p.data_for(:aircraft_create_with_no_options)
    p.aircraft_aircraft_types = p.aircraft_aircraft_types_options[1]
    p.aircrafts = p.aircrafts_options[1]
    p.aircraft_save
  end
end

Then(/^default values from the aircraft type must be displayed$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_manufacturer).not_to be_empty
    expect(p.aircraft_legal_model_name).not_to be_empty
    expect(p.aircraft_manufacturer).not_to eq('Select')
  end
end

When(/^I create an Aircraft with invalid "([^"]*)" Date$/) do |date_field|
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.populate_page_with p.data_for(:aircraft_create_with_no_options)
    p.aircraft_aircraft_types = p.aircraft_aircraft_types_options[1]
    case date_field
      when 'Warranty'
        p.aircraft_warranty_dt = p.data_for(:aircraft_create_invalid)['date']
      when 'Contracts Until'
        p.aircraft_contracts_until_dt = p.data_for(:aircraft_create_invalid)['date']
      when 'Title Search'
        p.aircraft_title_search_dt = p.data_for(:aircraft_create_invalid)['date']
      when 'Anticipated Delivery'
        p.aircraft_anticipated_delivery_dt = p.data_for(:aircraft_create_invalid)['date']
      when 'Actual Delivery'
        p.aircraft_actual_delivery_dt = p.data_for(:aircraft_create_invalid)['date']
      else
        puts 'invalid date field'
    end

  end
end

When(/^I create an Aircraft with a long Ijet Id$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.populate_page_with p.data_for(:aircraft_create_with_no_options)
    p.aircraft_aircraft_types = p.aircraft_aircraft_types_options[1]
    p.aircraft_ijet_id = '01234567890012'
  end
end

Then(/^I should receive an invalid Ijet Id length error$/) do
  ensure_aircraft_saved_validation_error("IJET Id must be less than 11 characters long")
end

When(/^I create an Aircraft with invalid Ijet Id$/) do
  goto_aircraft_inventory_administration
  populate_no_option_ac
  on_page(InventoryAdministration) do |p|
    p.aircraft_ijet_id = p.data_for(:aircraft_create_invalid)['aircraft_ijet_id']
  end
end

Then(/^I should receive an invalid Ijet Id error$/) do
  ensure_aircraft_saved_validation_error("IJET Id must be a number")
end

When(/^I create an Aircraft with a long Year Manufactured$/) do
  goto_aircraft_inventory_administration
  populate_no_option_ac
  on_page(InventoryAdministration) do |p|
    p.aircraft_year_manufactured = p.data_for(:aircraft_create_invalid)['aircraft_year_manufactured_long']
  end
end

Then(/^I should receive an invalid year manufactured long length error$/) do
  ensure_aircraft_saved_validation_error("Year manufactured must be 4 characters")
end

When(/^I create an Aircraft with a invalid characters in the Year Manufactured$/) do
  goto_aircraft_inventory_administration
  populate_no_option_ac
  on_page(InventoryAdministration) do |p|
    p.aircraft_year_manufactured = p.data_for(:aircraft_create_invalid)['aircraft_year_manufactured_characters']
  end
end

Then(/^I should receive an invalid year manufactured characters error$/) do
  ensure_aircraft_saved_validation_error("Year manufactured must be a number")
end

When(/^I create an Aircraft with a short Year Manufactured$/) do
  goto_aircraft_inventory_administration
  populate_no_option_ac
  on_page(InventoryAdministration) do |p|
    p.aircraft_year_manufactured = p.data_for(:aircraft_create_invalid)['aircraft_year_manufactured_short']
  end
end

Then(/^I should receive an invalid year manufactured short length error$/) do
  ensure_aircraft_saved_validation_error("Year manufactured must be 4 characters")
end

When(/^I create a decommissioned aircraft$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.aircraft_states = 'Decommissioned'
  end
end

Then(/^I should be able to enter a decommissioned date$/) do
  on_page(InventoryAdministration) do |p|
    sleep 2
    expect(p.aircraft_decommission_dt_element.visible?).to eq(true)
  end
end

When(/^I create an active aircraft$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.aircraft_states = 'Active'
  end
end

Then(/^I should not be able to enter a decommissioned date$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircraft_decommission_dt_element.visible?).to eq(false)
  end
end

When(/^I create an Aircraft without saving$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.populate_page_with p.data_for(:aircraft_create_with_no_options)
    p.aircraft_aircraft_types = p.aircraft_aircraft_types_options[1]
    p.aircrafts = p.aircrafts_options[1]
  end
end

Given(/^there is an Aircraft$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as
  end
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.populate_page_with p.data_for(:aircraft_create_with_no_options)
    p.aircraft_aircraft_types = p.aircraft_aircraft_types_options[1]
    p.aircraft_save
  end
  on_page(InventoryAdministration) do |p|
    sleep 2
    p.aircrafts = p.data_for(:aircraft_create_with_no_options)['aircraft_tail_no']
  end
end

And(/^the update aircraft action is logged in the audit trail$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.audited?('Update', 'Aircraft', p.data_for(:aircraft_create_with_no_options)['aircraft_tail_no'],
                      USER_MAP['AIS Administrator'.to_sym][:user])).to be_true
  end
end

When(/^I change the Required information$/) do
  on_page(InventoryAdministration) do |p|
    p.wait_for_ajax
    p.edit_aircraft
    p.populate_page_with p.data_for(:aircraft_edit_required_information)
    p.update_aircraft
  end
end

Then(/^Required information should be updated$/) do
  on_page(InventoryAdministration) do |p|
    p.aircrafts = p.data_for(:aircraft_create_with_no_options)['aircraft_tail_no']
    sleep 1
    p.edit_aircraft
    expect(p.aircraft_legal_model_name).to eq((p.data_for(:aircraft_edit_required_information)['aircraft_legal_model_name']))
    expect(p.aircraft_manufacturer).to eq((p.data_for(:aircraft_edit_required_information)['aircraft_manufacturer']))
    expect(p.aircraft_states).to eq((p.data_for(:aircraft_edit_required_information)['aircraft_states']))
    expect(p.aircraft_ownership_status).to eq((p.data_for(:aircraft_edit_required_information)['aircraft_ownership_status']))
    expect(p.aircraft_sales_status).to eq((p.data_for(:aircraft_edit_required_information)['aircraft_sales_status']))
  end
end

When(/^I change the Optional AC Information$/) do
  on_page(InventoryAdministration) do |p|
    p.edit_aircraft
    p.wait_for_ajax
    p.populate_page_with p.data_for(:aircraft_edit_optional_information)
    p.update_aircraft
  end
end

Then(/^Optional AC Information should be updated$/) do
  on_page(InventoryAdministration) do |p|
    p.aircrafts = p.data_for(:aircraft_create_with_no_options)['aircraft_tail_no']
    #create page object for validation
    sleep 1
    p.edit_aircraft
    sleep 5
    expect(p.aircraft_year_manufactured).to eq((p.data_for(:aircraft_edit_optional_information)['aircraft_year_manufactured']))
    expect(p.aircraft_serial_number).to eq((p.data_for(:aircraft_edit_optional_information)['aircraft_serial_number']))
    expect(p.aircraft_ijet_id).to eq((p.data_for(:aircraft_edit_optional_information)['aircraft_ijet_id']))
    expect(p.aircraft_warranty_dt).to eq((p.data_for(:aircraft_edit_optional_information)['aircraft_warranty_dt']))
    expect(p.aircraft_contracts_until_dt).to eq((p.data_for(:aircraft_edit_optional_information)['aircraft_contracts_until_dt']))
    expect(p.aircraft_decommission_dt).to eq((p.data_for(:aircraft_edit_optional_information)['aircraft_decommission_dt']))
    expect(p.aircraft_title_search_dt).to eq((p.data_for(:aircraft_edit_optional_information)['aircraft_title_search_dt']))
    expect(p.aircraft_company).to eq((p.data_for(:aircraft_edit_optional_information)['aircraft_company']))
    expect(p.aircraft_insurance_status).to eq((p.data_for(:aircraft_edit_optional_information)['aircraft_insurance_status']))

  end
end

When(/^I change the delivery information$/) do
  on_page(InventoryAdministration) do |p|
    p.wait_for_ajax
    p.edit_ac
    p.populate_page_with p.data_for(:aircraft_edit_delivery_information)
    p.update_aircraft
  end
end

Then(/^delivery information should be updated$/) do
  on_page(InventoryAdministration) do |p|
    p.aircrafts = p.data_for(:aircraft_create_with_no_options)['aircraft_tail_no']
    sleep 1
    p.edit_aircraft
    expect(p.aircraft_anticipated_delivery_dt).to eq((p.data_for(:aircraft_edit_delivery_information)['aircraft_anticipated_delivery_dt']))
    expect(p.aircraft_actual_delivery_dt).to eq((p.data_for(:aircraft_edit_delivery_information)['aircraft_actual_delivery_dt']))
    expect(p.aircraft_re_reg_code).to eq((p.data_for(:aircraft_edit_delivery_information)['aircraft_re_reg_code']))
  end
end

When(/^I change the engine information$/) do
  on_page(InventoryAdministration) do |p|
    p.edit_aircraft
    p.populate_page_with p.data_for(:aircraft_edit_engine_options)
    sleep 1
    p.update_aircraft
  end
end

Then(/^engine information should be updated$/) do
  on_page(InventoryAdministration) do |p|
    sleep 2
    p.aircrafts = p.data_for(:aircraft_create_with_no_options)['aircraft_tail_no']
    sleep 1
    p.edit_aircraft
    expect(p.aircraft_engine_manufacturer1).to eq((p.data_for(:aircraft_edit_engine_options)['aircraft_engine_manufacturer1']))
    expect(p.aircraft_engine_model1).to eq((p.data_for(:aircraft_edit_engine_options)['aircraft_engine_model1']))
  end
end

When(/^I create a "([^"]*)" aircraft$/) do |ownership_status|
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_aircraft
    p.populate_page_with p.data_for(:aircraft_create_with_no_options)
    p.aircraft_ownership_status = ownership_status
    p.aircraft_aircraft_types = p.aircraft_aircraft_types_options[1]
    p.aircraft_save
  end
end

Then(/^the insurance status should be "([^"]*)"$/) do |arg|
  on_page(InventoryAdministration) do |p|
    p.aircrafts = p.data_for(:aircraft_create_with_no_options)['aircraft_tail_no']
    sleep 1
    expect(@browser.text).to include("NetJets Insurance")
  end
end

Then(/^I should receive an aircraft tail number uniqueness error$/) do
  ensure_aircraft_saved_validation_error("Aircraft tail number should be unique")
end


When(/^I am on inventory management/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as
  end
  goto_aircraft_inventory_administration
end

Then(/^I should be able to choose from all existing Aircrafts$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.aircrafts_options).to eq(['All'] + p.expected_aircrafts)
  end
end

When(/^I create a new Aircraft$/) do
  login_to_AIS
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.new_aircraft
    p.wait_for_ajax
    p.populate_page_with p.data_for(:smoke_aircraft)
    p.aircraft_aircraft_types = p.aircraft_aircraft_types_options[1]
    @tail_no = ('Test' + Time.now.strftime("%m%d%y%H%M%S"))
    p.aircraft_tail_no = @tail_no
    p.populate_page_with p.data_for(:aircraft_create_standard_options)
    p.aircraft_contracts_until_dt = Time.now.strftime('%m/%d/%Y')
    p.aircraft_legal_model_name = @tail_no
    p.aircraft_save
  end
end

Then(/^that Aircraft is visible in the Inventory$/) do
  on_page(AircraftInventory).inventory
  aircraft = @tail_no
  search_inventory(aircraft)
  on_page(AircraftInventory).wait_for_ajax
  expect(inventory_is_filtered_by_tail?(aircraft)).to be true
end

When(/^I edit the Aircraft$/) do
  on_page(InventoryAdministration) do |p|
    p.aircrafts = @tail_no
    sleep 1
    p.edit_ac
    @tail_no = ('Test' + Time.now.strftime("%m%d%y%H%M%S"))
    p.aircraft_tail_no = @tail_no
    p.update_aircraft
  end
end

Then(/^the Aircraft is updated with my changes$/) do
  on_page(AircraftInventory).inventory
  aircraft = @tail_no
  search_inventory(aircraft)
  on_page(AircraftInventory).wait_for_ajax
  expect(inventory_is_filtered_by_tail?(aircraft)).to be true
end