Then(/^I should have access to fleet group Management$/) do
  on_page AircraftInventory do |p|
    p.inventory
    expect(p.administration_element.exists?).to be_true
  end
end

Then(/^I should not have access to fleet group management$/) do
  on_page AircraftInventory do |p|
    p.inventory
    expect(p.administration_element.exists?).to be_false
  end
end

When(/^I create a Fleet Group$/) do
  login_to_AIS
  on_page(AircraftInventory).inventory
  on_page(AircraftInventory).administration
  on_page(AircraftInventory).create_new_fleet_group('Messy Fleetgroup')
  on_page(AircraftInventory).create_messy_fleet_group('Messy Fleetgroup')
end

When(/^I create a Fleet Group to be edited$/) do
  login_to_AIS
  on_page(AircraftInventory).inventory
  on_page(AircraftInventory).administration
  on_page(AircraftInventory).create_new_fleet_group('Messy Fleetgroup')
end

Then(/^the new Fleet Group will be displayed in Aircraft search$/) do
  expect(on_page(AircraftInventory).fleet_groups.include? 'Messy Fleetgroup').to be true
end

And(/^the create action is logged in the audit trail$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.audited?('Create', 'Fleet Group', p.data_for(:fleet_groups)['valid'],
                      USER_MAP['AIS Administrator'.to_sym][:user])).to be_true
  end
end

When(/^I create a duplicate Fleet Group$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_fleet_group
    duplicate_fleet_group_name = p.fleet_groups_options[1]
    p.fleet_group_name = duplicate_fleet_group_name
    p.save_fleet_group(false, false)
  end
end

Then(/^I should receive an error message$/) do
  on_page(InventoryAdministration) do |p|
    p.confirm_edit
    expect(p.error_dialogue).to include('Fleet Group name already Exists')
  end
end

Given(/^There is a Fleet Group$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as
  end
  goto_aircraft_inventory_administration
end

When(/^an Aircraft Administrator edits a Fleet Group Name$/) do
  on_page(InventoryAdministration) do |p|
    p.fleet_groups = p.data_for(:fleet_groups)['valid']
    p.edit_fleet_group(name = p.data_for(:fleet_groups)['edit'], disassociate=false, cancel=false)
  end
end

Then(/^the updated Fleet Group will be displayed in Aircraft search$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.fleet_groups_options).to include(p.data_for(:fleet_groups)['edit'])
  end
end

And(/^the edit action is logged in the audit trail$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.audited?('Update', 'Fleet Group',
                      p.data_for(:fleet_groups)['valid'] + ' to ' + p.data_for(:fleet_groups)['edit'],
                      USER_MAP['AIS Administrator'.to_sym][:user])).to be_true
  end
end

When(/^an Aircraft Administrator edits a Fleet Group with duplicate name$/) do
  on_page(InventoryAdministration) do |p|
    duplicate_fleet_group_name = p.fleet_groups_options[1]
    p.fleet_groups = duplicate_fleet_group_name
    p.edit_fleet_group(name=p.fleet_groups_options[2], disassociate=false, cancel=nil)
  end
end
Given(/^There is a Fleet Group with no associated aircrafts types$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as
  end
  goto_aircraft_inventory_administration
end

When(/^an Aircraft Administrator deletes a Fleet Group$/) do
  on_page(InventoryAdministration) do |p|
    p.fleet_groups = p.data_for(:fleet_groups)['delete']
    p.delete_fleet_group
  end
end

Then(/^the deleted Fleet Group will not be displayed in Aircraft Search$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.fleet_groups_options).not_to include(p.data_for(:fleet_groups)['valid'])
  end
end

And(/^the delete action is logged in the audit trail$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.audited?('Delete', 'Fleet Group', p.data_for(:fleet_groups)['edit'],
                      USER_MAP['AIS Administrator'.to_sym][:user])).to be_true
  end
end

Given(/^There is a fleet group with associated aircraft type$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as
  end
  goto_aircraft_inventory_administration
end

When(/^an Aircraft Administrator deletes a Fleet Group with associated aircraft type$/) do
  on_page(InventoryAdministration) do |p|
    p.fleet_groups = p.data_for(:fleet_groups)['associated']
    sleep 2
    p.delete_fg
    sleep 2
    p.confirm_delete
  end
end

When(/^I cancel creating a fleet group$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_fleet_group
    p.fleet_group_name = p.data_for(:fleet_groups)['cancelled']
    p.cancel_fleet_group
  end
end

Then(/^the fleet group should not be created$/) do
  on_page(AircraftInventory) do |p|
    p.inventory
    expect(p.fleet_groups_options).not_to include(p.data_for(:fleet_groups)['cancelled'])
  end
end

When(/^I am on fleet group maintenance screen$/) do
  goto_aircraft_inventory_administration
end

Then(/^an error message will be displayed$/) do
  expect(@browser.text).to include('Fleet group to be deleted has associated aircraft types')
end

Given(/^the fleet group delete is cancelled$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as
  end
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.fleet_groups = p.data_for(:fleet_groups)['associated']
    p.cancel_fleet_group_delete
  end
end

When(/^the fleet group must not be deleted$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.fleet_groups_options).to include(p.data_for(:fleet_groups)['associated'])
  end
end

Then(/^I should be in aircraft inventory list$/) do
  on_page(InventoryAdministration).close_maintenance
  on AircraftInventory do |p|
    expect(p.integral?).to be true
  end
end

Given(/^There is a Fleet Group associated with Aircraft Type$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as
  end
  goto_aircraft_inventory_administration
end

When(/^I cancel the disassociation$/) do
  on_page(InventoryAdministration) do |p|
    p.fleet_groups = p.data_for(:fleet_groups)['associated']
    p.edit_fleet_group(name=nil, disassociate=true, cancel=true)
  end
end

Then(/^the fleet groups must not be disassociated$/) do
  on_page(InventoryAdministration) do |p|
    expect(@browser.text).to include('G400')
  end
end

Given(/^the fleet group edit is cancelled$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as
  end
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.fleet_groups = p.data_for(:fleet_groups)['associated']
    p.edit_fleet_group(name = p.data_for(:fleet_groups)['edit'], disassociate=false, cancel=true)
  end
end

Then(/^the fleet group must not be updated$/) do
  on_page(InventoryAdministration) do |p|
    expect(p.fleet_groups_options).to include(p.data_for(:fleet_groups)['associated'])
  end
end

When(/^I create a invalid fleet group name with more than (\d+) characters$/) do |arg|
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_fleet_group
    p.fleet_group_name = p.data_for(:fleet_groups)['long']
  end
end

Then(/^the fleet group name should not be more than (\d+) characters in length$/) do |length|
  expect(on_page(InventoryAdministration).fleet_group_name.length.to_i).to eq(length.to_i)
end

When(/^I create a fleet group with no name$/) do
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.create_fleet_group
    p.fleet_group_name = ''
    p.save_fleet_group(false, false)
  end
end

Then(/^I should receive a enter fleet group name error message$/) do
  expect(@browser.text).to include('Please enter Fleet Group Name')
end

Given(/^the fleet group edit and disassociate is cancelled$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as
  end
  goto_aircraft_inventory_administration
  on_page(InventoryAdministration) do |p|
    p.fleet_groups = p.data_for(:fleet_groups)['associated']
    p.edit_fleet_group(name='Edited Fleet Group Name', disassociate=true, cancel=true)
  end
end

Then(/^the fleet group must not be updated and disassociated$/) do
  expect(@browser.text).to include('G400')
  @browser.refresh
  on_page(InventoryAdministration) do |p|
    expect(p.fleet_groups_options).to include(p.data_for(:fleet_groups)['associated'])

  end
end

When(/^I edit the Fleet Group$/) do
  on_page(InventoryAdministration).edit_fleet_group_with_name('Messy Fleetgroup', 'Messier Fleetgroup')
  on_page(AircraftInventory).create_messy_fleet_group('Messier Fleetgroup')
end

Then(/^the Fleet Group is updated with my changes$/) do
  expect(on_page(AircraftInventory).fleet_groups_options.include? 'Messier Fleetgroup').to be true
end