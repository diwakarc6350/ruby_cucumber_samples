Given(/^an existing aircraft type in AIS$/) do
  login_as_admin
  @ais_aircraft_type = AircraftType.ais_aircrafts_with_no_mappings
  @ijet_aircraft_type  = AircraftType.ijet2_aircrafts_with_no_mappings

  pending("No available ijet2 types to map!") if @ijet_aircraft_type.nil?
end

When(/^I map it to an Ijet2 aircraft type$/) do
  open_aircraft_type_mapping
  puts @ais_aircraft_type
  puts @ijet_aircraft_type
  edit_ais_aircraft_ijet_mapping(@ais_aircraft_type,@ijet_aircraft_type)
end

Then(/^the types are associated in Ijet2$/) do
  aircraft_mapping = on(AircraftTypeMappingPage).mapped_aircraft_types.find {|mapping| mapping.ais_aircraft_type.include? @ais_aircraft_type}
  expect(aircraft_mapping.ijet_aircraft_type).to eq @ijet_aircraft_type

end

When(/^the type is not duplicated in the list$/) do
  mapped_ais_aircrafts = on(AircraftTypeMappingPage).mapped_aircraft_types.map(&:ais_aircraft_type)
  mapped_ijet_aircrafts = on(AircraftTypeMappingPage).mapped_aircraft_types.map(&:ijet_aircraft_type)

  expect(mapped_ais_aircrafts).to match_array mapped_ais_aircrafts.uniq
  expect(mapped_ijet_aircrafts).to match_array mapped_ijet_aircrafts.uniq
end