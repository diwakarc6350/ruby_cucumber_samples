Then(/^I should see the detailed aircraft information$/) do
  on AircraftDetail do |p|
    expect(p.expected_standard_info).to eq(p.actual_standard_info)
    expect(p.expected_selling_info).to eq(p.actual_selling_info)
    expect(p.expected_delivery_info).to eq(p.actual_delivery_info)
    expect(p.expected_engine_info).to eq(p.actual_engine_info)
  end
end

When(/^I am viewing Aircraft detail$/) do
  on_page(AircraftInventory).inventory
  on_page(AircraftInventory).select_aircraft_tail
  on_page(AircraftDetail).go_back_to_inventory
end

Then(/^I should be able to go back to aircraft inventory list$/) do
  on AircraftInventory do |p|
    expect(p.integral?).to be true
  end
end

Then(/^I should not see Anticipated Delivery Date$/) do
  on AircraftDetail do |p|
    expect(@browser.text).to include('Actual Delivery Date')
    expect(@browser.text).not_to include('Anticipated Delivery Date')
    expect(p.anticipated_delivery_date_element.exists?).to be_false
    expect(p.actual_delivery_date_element.exists?).to be_true
  end
end

Then(/^I should see Anticipated Delivery Date$/) do
  on AircraftDetail do |p|
    expect(p.anticipated_delivery_date_element.exists?).to be_true
    expect(@browser.text).to include('Anticipated Delivery Date')
  end
end

Then(/^I should not see Anticipated Disposal Date$/) do
  on AircraftDetail do |p|
    expect(p.anticipated_sold_date_element.exists?).to be_false
    expect(@browser.text).not_to include('Anticipated Disposal Date')
  end
end

Then(/^I should see Anticipated Disposal Date$/) do
  on AircraftDetail do |p|
    expect(p.anticipated_sold_date_element.exists?).to be_true
    expect(@browser.text).to include('Anticipated Disposal Date')
  end
end

Then(/^I should be able to see the current holds order by placed on descending/) do
  on AircraftDetail do |p|
    expect(p.expected_current_holds.length).to be <= 3
    expect(p.expected_current_holds).to eq(p.actual_current_holds)
  end
end

Then(/^I should see holds ordered by placed on descending$/) do
  on AircraftDetail do |p|
    expect(p.holds_placed_in.decreasing?).to be true
  end
end

When(/^I choose to see more holds$/) do
  on_page AircraftInventory do |p|
    p.inventory
    place_legal_acft_hold_no_del(p.data_for(:aircraft_view_holds)['tail_with_3_active_holds'], 25, '')
    p.inventory
    p.tail_number = p.data_for(:aircraft_view_holds)['tail_with_3_active_holds']
    p.search
    sleep 2
    p.select_aircraft_tail(1)
  end
  on AircraftDetail do |p|
    p.show_more_holds
  end
end

Then(/^more than three holds must be shown$/) do
  on AircraftDetail do |p|
    expect(p.actual_current_holds.length).to be > 3
  end
end

Then(/^I should not see expired holds$/) do
  on AircraftDetail do |p|

    expect(p.expired_holds?).to be false
  end
end

When(/^I choose to sort Hold Type by Ascending order$/) do
    place_legal_aircraft_hold(self.data_for(:aircraft_view_holds)['tail_with_more_holds'], 3.125, '')
    place_legal_acft_hold_no_del(self.data_for(:aircraft_view_holds)['tail_with_more_holds'], 3.125, '')
    place_legal_acft_hold_no_del(self.data_for(:aircraft_view_holds)['tail_with_more_holds'], 3.125, '')
    place_legal_acft_hold_no_del(self.data_for(:aircraft_view_holds)['tail_with_more_holds'], 3.125, '')
  open_first_tail_details
  on AircraftDetail do |p|
    p.show_more_holds
    p.sort_by_hold_type
  end
end

Then(/^I should be see the Current Holds sorted by Hold Type in Ascending order$/) do
  on AircraftDetail do |p|
    expect(p.sorted_hold_type.increasing?).to be true
  end
end

When(/^I choose to sort Hold Type by Descending order$/) do
  on_page AircraftInventory do |p|
    p.delete_user_settings('qatest20')
  end
  open_first_tail_details
  on AircraftDetail do |p|
    p.show_more_holds
    2.times { p.sort_by_hold_type }
  end
end

Then(/^I should be see the Current Holds sorted by Hold Type in Descending order$/) do
  on AircraftDetail do |p|
    expect(p.sorted_hold_type.decreasing?).to be true
  end
end

When(/^I choose to sort Interest Size by Ascending order$/) do
  open_first_tail_details
  on AircraftDetail do |p|
    p.show_more_holds
    p.sort_by_interest_size
  end
end

Then(/^I should be see the Current Holds sorted by Interest Size in Ascending order$/) do
  on AircraftDetail do |p|
    expect(p.sorted_interest_size.increasing?).to be true
  end
end

When(/^I choose to sort Interest Size by Descending order$/) do
  open_first_tail_details
  on AircraftDetail do |p|
    p.show_more_holds
    2.times { p.sort_by_interest_size }
  end
end

Then(/^I should be see the Current Holds sorted by Interest Size in Descending order$/) do
  on AircraftDetail do |p|
    expect(p.sorted_interest_size.decreasing?).to be true
  end
end

When(/^I choose to sort Placed By Ascending order$/) do
  open_first_tail_details
  on AircraftDetail do |p|
    p.show_more_holds
    p.sort_by_placed_by
  end
end

Then(/^I should be see the Current Holds sorted by Placed By in Ascending order$/) do
  on AircraftDetail do |p|
    expect(p.sorted_placed_by.increasing?).to be true
  end
end

When(/^I choose to sort Placed By by Descending order$/) do
  open_first_tail_details
  on AircraftDetail do |p|
    p.show_more_holds
    2.times { p.sort_by_placed_by }
  end
end

Then(/^I should be see the Current Holds sorted by Placed By in Descending order$/) do
  on AircraftDetail do |p|
    expect(p.sorted_placed_by.decreasing?).to be true
  end
end

When(/^I choose to sort Placed On by Ascending order$/) do
  open_first_tail_details
  on AircraftDetail do |p|
    p.show_more_holds
    p.sort_by_placed_on
  end
end

Then(/^I should be see the Current Holds sorted by Placed On in Ascending order$/) do
  on AircraftDetail do |p|
    expect(p.sorted_placed_on.increasing?).to be true
  end
end

When(/^I choose to sort Placed On by Descending order$/) do
  open_first_tail_details
  on AircraftDetail do |p|
    p.show_more_holds
    2.times { p.sort_by_placed_on }
  end
end

Then(/^I should be see the Current Holds sorted by Placed On in Descending order$/) do
  on AircraftDetail do |p|
    expect(p.sorted_placed_on.decreasing?).to be true
  end
end

When(/^I choose to sort Expiration Date by Ascending order$/) do
  open_first_tail_details
  on AircraftDetail do |p|
    p.show_more_holds
    p.sort_by_expiration_date
  end
end

Then(/^I should be see the Current Holds sorted by Expiration Date in Ascending order$/) do
  on AircraftDetail do |p|
    expect(p.sorted_expiration_date.increasing?).to be true
  end
end

When(/^I choose to sort Expiration Date by Descending order$/) do
  open_first_tail_details
  on AircraftDetail do |p|
    p.show_more_holds
    2.times { p.sort_by_expiration_date }
  end
end

Then(/^I should be see the Current Holds sorted by Expiration Date in Descending order$/) do
  on AircraftDetail do |p|
    expect(p.sorted_expiration_date.decreasing?).to be true
  end
end


When(/^I choose an Aircraft Tail Number with holds$/) do
  on_page AircraftInventory do |p|
    place_legal_aircraft_hold(p.data_for(:aircraft_view_holds)['tail_with_3_active_holds'], 25, p.data_for(:aircraft_view_holds)['hold_notes'])
    place_legal_acft_hold_no_del(p.data_for(:aircraft_view_holds)['tail_with_3_active_holds'], 25, p.data_for(:aircraft_view_holds)['hold_notes'])
    place_legal_acft_hold_no_del(p.data_for(:aircraft_view_holds)['tail_with_3_active_holds'], 25, p.data_for(:aircraft_view_holds)['hold_notes'])
    sleep 2
    p.inventory
    p.tail_number = p.data_for(:aircraft_view_holds)['tail_with_3_active_holds']
    p.search
    sleep 2
    p.select_aircraft_tail(1)
  end
end