require 'page-object'
require 'page-object/page_factory'
include PageObject::PageFactory

When(/^I choose to sort Fleet Group by Ascending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.sort_by_fleet_group
  end
end

Then(/^I should see the Aircraft Inventory List sorted by Fleet Group in Ascending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_fleet_group.increasing?).to be true
  end
end

When(/^I choose to sort Fleet Group by Descending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    2.times { p.sort_by_fleet_group }
  end
end

Then(/^I should see the Aircraft Inventory List sorted by Fleet Group in Descending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_fleet_group.decreasing?).to be true
  end
end

When(/^I choose to sort Aircraft Type by Ascending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.sort_by_ac_type
  end
end

Then(/^I should see the Aircraft Inventory List sorted by Aircraft Type in Ascending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_by_ac_type.increasing?).to be true
  end
end

When(/^I choose to sort Aircraft Type by Descending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    2.times { p.sort_by_ac_type }
  end
end

Then(/^I should see the Aircraft Inventory List sorted by Aircraft Type in Descending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_by_ac_type.decreasing?).to be true
  end
end

When(/^I choose to sort Aircraft State by Ascending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.sort_by_ac_state
  end
end

Then(/^I should see the Aircraft Inventory List sorted by Aircraft State in Ascending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_by_ac_state.increasing?).to be true
  end
end

When(/^I choose to sort Aircraft State by Descending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    2.times { p.sort_by_ac_state }
  end
end


Then(/^I should see the Aircraft Inventory List sorted by Aircraft State in Descending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_by_ac_state.decreasing?).to be true
  end
end

When(/^I choose to sort Vintage by Ascending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.sort_by_vintage
  end
end

Then(/^I should see the Aircraft Inventory List sorted by Vintage in Ascending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_by_vintage.increasing?).to be true
  end
end

When(/^I choose to sort Vintage by Descending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    2.times { p.sort_by_vintage }
  end
end

Then(/^I should see the Aircraft Inventory List sorted by Vintage in Descending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_by_vintage.decreasing?).to be true
  end
end

When(/^I choose to sort Tail by Ascending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.sort_by_tail
  end
end

Then(/^I should see the Aircraft Inventory List sorted by Tail in Ascending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_by_tail.increasing?).to be true
  end
end

When(/^I choose to sort Tail  by Descending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    2.times { p.sort_by_tail }
  end
end

Then(/^I should see the Aircraft Inventory List sorted by Tail in Descending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_by_tail.decreasing?).to be true
  end
end

When(/^I choose to sort Company by Ascending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.sort_by_company
  end
end

Then(/^I should see the Aircraft Inventory List sorted by Company in Ascending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_by_company.increasing?).to be true
  end
end

When(/^I choose to sort Company by Descending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    2.times { p.sort_by_company }
  end
end

Then(/^I should see the Aircraft Inventory List sorted by Company in Descending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_by_company.decreasing?).to be true
  end
end


When(/^I choose to sort Contracts Until by Ascending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.sort_by_contracts_until
  end
end

Then(/^I should see the Aircraft Inventory List sorted by Contracts Until in Ascending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_by_contracts_until.increasing?).to be true
  end
end

When(/^I choose to sort Contracts Until by Descending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    2.times { p.sort_by_contracts_until }
  end
end

Then(/^I should see the Aircraft Inventory List sorted by Contracts Until in Descending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_by_contracts_until.decreasing?).to be true
  end
end

When(/^I choose to sort Warranty by Ascending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.sort_by_warranty
  end
end

Then(/^I should see the Aircraft Inventory List sorted by Warranty in Ascending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_by_warranty.increasing?).to be true
  end
end

When(/^I choose to sort Warranty by Descending order$/) do
  on_page AircraftInventory do |p|
    p.inventory
    2.times { p.sort_by_warranty }
  end
end

Then(/^I should see the Aircraft Inventory List sorted by Warranty in Descending order$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_by_warranty.decreasing?).to be true
  end
end