def actual_eq_expected_holds(expected_value)
  on_page AircraftHoldSearch do |p|
    expect(p.integral_holds?).to be_true
    expect(p.actual_holds).to eq(p.expected_holds(expected_value))
  end
end

def search_for(data)
  on_page(AircraftHoldSearch).hold_search
  on_page AircraftHoldSearch do |p|
    p.query = p.data_for(:hold_index_screen_data)[data]
    p.search
  end
end

When(/^a (.*) searches for holds$/) do |user_type|
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as(user_type)
  end
  on_page(AircraftHoldSearch).hold_search
end

When(/^a user is searching for holds$/) do
  login_as_admin
  on_page(AircraftHoldSearch).hold_search
end

Then(/^all active holds are shown$/) do
  actual_eq_expected_holds('ordered_default')
end

Then(/^the holds are ordered by Aircraft Type Desc, Expiration Date Desc and Amount Held in Desc$/) do
  actual_eq_expected_holds('ordered_default')
end

Then(/^the user has the ability to filter by any vintage$/) do
  on_page AircraftHoldSearch do |p|
    #pull out expect parentheses into page_object thing
    expect(p.actual_vintage_options).to eq(p.expected_vintages)
  end
end

And(/^the user has the ability to filter by any fleet group$/) do
  on_page AircraftHoldSearch do |p|
    expect(p.actual_fleet_group_options).to eq(p.expected_holds_fleet_groups)
  end
end

And(/^the user has the ability to filter by any aircraft type$/) do
  on_page AircraftHoldSearch do |p|
    expect(p.actual_aircraft_type_options).to eq(p.expected_types)
  end
end

And(/^the user has the ability to filter by any hold type$/) do
  on_page AircraftHoldSearch do |p|
    expect(p.actual_hold_type_options).to eq(p.expected_holds_types)
  end
end


When(/^a user filters holds by a (.*)$/) do |filter|
  login_as_admin
  on_page(AircraftHoldSearch).hold_search
  on_page AircraftHoldSearch do |p|
    p.choose_filter(filter)
  end
end

Then(/^only holds matching that (.*) are shown$/) do |filter|
  actual_eq_expected_holds(filter)
end

When(/^I search for holds by who held$/) do
  #change into two methods, login and search
  login_as_admin
  search_for('held_by')
end

Then(/^I should see the active holds for that user$/) do
  actual_eq_expected_holds('user_search')
end

When(/^I search for holds by a tail number$/) do
  login_as_admin
  search_for('held_tail')
end

Then(/^I should see the active holds for that tail$/) do
  actual_eq_expected_holds('held_tail')
end

Then(/^the results are sortable by all displayed attributes$/) do
  on_page AircraftHoldSearch do |p|
    p.sort_holds
  end
end

When(/^I reset the hold search filters$/) do
  login_as_admin
  on_page(AircraftHoldSearch).hold_search
  on_page AircraftHoldSearch do |p|
    p.reset_filters
  end
end

Then(/^default hold results should be displayed$/) do
  actual_eq_expected_holds('ordered_default')
end

And(/^filter and search will be cleared$/) do
  on_page AircraftHoldSearch do |p|
    expect(p.query).to eq("")
    expect(p.fleet_groups).to eq(p.data_for(:hold_index_screen_data)['default'])
    expect(p.aircraft_types).to eq(p.data_for(:hold_index_screen_data)['default'])
    expect(p.vintages).to eq(p.data_for(:hold_index_screen_data)['default'])
    expect(p.hold_types).to eq(p.data_for(:hold_index_screen_data)['default'])
  end
end

When(/^I search for an nonexistent held by$/) do
  login_as_admin
  search_for('nonexistent_hold')
end

When(/^a user filters holds using (.*)$/) do |criteria|
  login_as_admin
  on_page(AircraftHoldSearch).hold_search
  on_page AircraftHoldSearch do |p|
    p.choose_filter(criteria)
  end
end

Then(/^only holds matching the given (.*) are shown$/) do |criteria|
  actual_eq_expected_holds(criteria)
end

Then(/^I should receive a No Matching Holds Found error$/) do
  on_page AircraftHoldSearch do |p|
    expect(p.error).to eq('No Matching records Found')
  end
end

Then(/^I can search Holds by Held By$/) do
  login_to_AIS
  on_page(AircraftInventory).hold_search
  first_holder = on_page(AircraftHoldSearch).return_first_held_by
  on_page(AircraftHoldSearch).query = first_holder
  on_page(AircraftHoldSearch).search
  on_page(AircraftHoldSearch).wait_for_ajax
  expect(on_page(AircraftHoldSearch).holds_are_filtered_by_held_by?(first_holder)).to be true
end

And(/^I can search Holds by Tail Number$/) do
  on_page(AircraftInventory).hold_search
  first_tail = on_page(AircraftHoldSearch).return_first_tail
  on_page(AircraftHoldSearch).query = first_tail
  on_page(AircraftHoldSearch).search
  on_page(AircraftHoldSearch).wait_for_ajax
  expect(on_page(AircraftHoldSearch).holds_are_filtered_by_tail?(first_tail)).to be true
end