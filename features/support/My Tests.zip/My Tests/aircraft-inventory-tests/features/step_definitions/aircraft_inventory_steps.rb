require 'page-object'
require 'page-object'
require 'page-object/page_factory'
include PageObject::PageFactory

def actual_eq_expected(expected_value)
  on_page AircraftInventory do |p|
    expect(p.integral?).to be_true
    expect(p.actual_inventory).to match_array(p.expected_inventory(expected_value))
  end
end

def actual_eq_expected_inventory(arg)
  on_page AircraftInventory do |p|
    expect(p.actual_inventory).to eq(p.expected_inventory(arg))
  end
end

When(/^I select Inventory$/) do
  on_page AircraftInventory do |p|
    p.delete_user_settings('qatest20')
    p.delete_user_settings('qatest1')
  end
  on_page(AircraftInventory).inventory
end

Then(/^I should see the Aircraft Inventory List$/) do
  actual_eq_expected('default')
end

Then(/^I should not see the Aircraft Inventory List$/) do
  on_page AircraftInventory do |p|
    expect(p.inventory_exists?).to be_false
  end
end

When(/^I filter by a Aircraft Type$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.choose_aircraft_type
  end
end

When(/^I filter by a Fleet Group$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.choose_fleet_group
  end
end

When(/^I filter by an Aircraft State$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.choose_aircraft_state
  end
end

When(/^I filter by a Sales Status$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.choose_sales_status
  end
end

When(/^I filter by a Company$/) do
  on_page AircraftInventory do |p|
    p.delete_user_settings('qatest20')
    p.inventory
    p.choose_company
  end
end

When(/^I filter by a Share Size$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.choose_share_size
    sleep 3
  end
end

Then(/^I should see the Aircraft Inventory List filtered by Aircraft Type$/) do
  actual_eq_expected('aircraft_type')
end

Then(/^I should see the filtered Aircraft Inventory List by Fleet Group$/) do
  actual_eq_expected('fleet_group')
end

Then(/^I should see the filtered Aircraft Inventory List by Aircraft State$/) do
  actual_eq_expected('aircraft_state')
end

Then(/^I should see the filtered Aircraft Inventory List by Sales Status$/) do
  actual_eq_expected('sales_status')
end

Then(/^I should see the filtered Aircraft Inventory List by Company$/) do
  on_page AircraftInventory do |p|
    case p.company
      when 'All'
        actual_eq_expected('default')
      else
        actual_eq_expected('company')
    end

    p.delete_user_settings('qatest20')
  end
end

Then(/^I should see the filtered Aircraft Inventory List by Share Size$/) do
  on_page AircraftInventory do |p|
    expect(p.actual_availability).to eq(true)
  end
end

When(/^I Reset Filter$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.choose_aircraft_type
    p.choose_aircraft_state
    p.choose_sales_status
    p.choose_fleet_group
    p.choose_company
    p.uncheck_inventory_only
    p.tail_number = p.data_for(:tail_numbers)['end']
    p.reset
  end
end

Then(/^I should see Aircraft Type and Tail Number reset to default$/) do
  on_page AircraftInventory do |p|
    expect(p.aircraft_types).to eq('All')
    expect(p.fleet_groups).to eq('All')
    expect(p.aircraft_sales_status).to eq('All')
    expect(p.aircraft_states).to eq('All')
    expect(p.company).to eq('All')
    expect(p.tail_number).to eq("")
    expect(p.inventory_only_checked?).to be true
  end
end

When(/^I search by Aircraft Tail Number$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.tail_number = p.data_for(:tail_numbers)['full']
    p.search
  end
end

When(/^I enter a tail number and press enter$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.tail_number = p.data_for(:tail_numbers)['full']
    @browser.send_keys :enter
  end
end

Then(/^I should see the Aircraft Inventory List filtered by Tail Number$/) do
  on_page AircraftInventory do |p|
    expect(p.tail_number).to eq(p.data_for(:tail_numbers)['full'])
    expect(p.actual_inventory).to eq(p.expected_inventory('search'))
  end
end

When(/^I partially search for Aircraft Tail Number$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.tail_number = p.data_for(:partial_tail_numbers)['middle']
    p.search
  end
end

Then(/^I should see the Aircraft Inventory List filtered by Partial Tail Number$/) do
  actual_eq_expected_inventory('search')
end

When(/^I filter by Fleet Group and Aircraft State$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.choose_aircraft_state
    p.choose_fleet_group
  end
end

Then(/^I should see the Aircraft Inventory List filtered by Fleet Group and Aircraft State$/) do
  actual_eq_expected_inventory('combo1')
end

When(/^I filter by Aircraft Type and Company$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.choose_aircraft_type
    p.choose_company
  end
end

Then(/^I should see the Aircraft Inventory List filtered by Aircraft Type and Company$/) do
  actual_eq_expected_inventory('combo2')
  on_page AircraftInventory do |p|
    p.delete_user_settings('qatest20')
  end
end

When(/^I search for "([^"]*)"$/) do |value|
  on_page AircraftInventory do |p|
    p.inventory
    p.tail_number = value
    p.search
  end
end

Then(/^I should not see any results$/) do
  on_page AircraftInventory do |p|
    expect(p.actual_inventory).to eq([])
  end
end

Then(/^I should see the Aircraft Types$/) do
  on_page AircraftInventory do |p|
    expect(p.aircraft_types_options[1..p.aircraft_types_options.length]).to eq(p.expected_aircraft_types)
  end
end

Then(/^I should see the Aircraft States$/) do
  on_page AircraftInventory do |p|
    expect(p.aircraft_states_options[0..p.aircraft_types_options.length]).to eq(p.expected_aircraft_states)
  end
end

Then(/^I should see the Fleet Groups$/) do
  on_page AircraftInventory do |p|
    expect(p.fleet_groups_options[1..p.fleet_groups_options.length]).to eq(p.expected_fleet_groups)
  end
end

Then(/^I should see the Sales Status$/) do
  on_page AircraftInventory do |p|
    expect(p.aircraft_sales_status_options[0..p.aircraft_types_options.length]).to eq(p.expected_sales_status)
  end
end

Then(/^I should see the Company$/) do
  on_page AircraftInventory do |p|
    expect(p.company_options[0..p.aircraft_types_options.length]).to match_array(p.expected_company)
  end
end

When(/^I filter by Aircraft Type and Tail Number$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.choose_aircraft_type
    p.tail_number = p.data_for(:partial_tail_numbers)['end']
    p.search
  end
end

Then(/^I should see the Aircraft Inventory List filtered by Aircraft Type and Tail Number$/) do
  actual_eq_expected_inventory('combo3')
end

When(/^I filter by Fleet Group and Tail Number$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.choose_fleet_group
    p.tail_number = p.data_for(:partial_tail_numbers)['end']
    p.search
  end
end

Then(/^I should see the Aircraft Inventory List filtered by Fleet Group and Tail Number$/) do
  actual_eq_expected_inventory('combo4')
end

When(/^I filter by Company and Tail Number$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.choose_company
    p.tail_number = p.data_for(:partial_tail_numbers)['end']
    p.search
  end
end

Then(/^I should see the Aircraft Inventory List filtered by Company and Tail Number$/) do
  actual_eq_expected_inventory('combo5')
  on_page AircraftInventory do |p|
    p.delete_user_settings('qatest20')
  end
end


Then(/^The tail number should not be more than (\d+) characters in length$/) do |length|
  expect(on_page(AircraftInventory).tail_number.length.to_i).to eq(length.to_i)
end

And(/^I select Aircraft Type$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.select_aircraft_type
  end
end

When(/^I close the detail window with X$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.select_aircraft_type
  end
  @browser.windows.last.use do
    on_page AircraftTypeDetail do |p|
      p.close_x_element.when_visible(timeout=30) do
        p.close_x
      end
    end
  end
end

When(/^I close the detail window$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.select_aircraft_type
  end
  @browser.windows.last.use do
    on_page AircraftTypeDetail do |p|
      p.close_b_element.when_visible(timeout=30) do
        p.close_b
      end
    end
  end
end

Then(/^The modal window should be closed$/) do
  on_page AircraftInventory do |p|
    expect(p.search_element.exists?).to be_true
  end
end

Then(/^I should have an Inventory only option$/) do
  on_page AircraftInventory do |p|
    expect(p.inventory_only_element.exists?).to be_true
  end
end

Then(/^I should not have an Inventory only option$/) do
  on_page AircraftInventory do |p|
    expect(p.inventory_only_element.exists?).to be_false
  end
end

Then(/^Inventory search will be the default option$/) do
  on_page AircraftInventory do |p|
    expect(p.inventory_only_checked?).to be_true
  end
end

When(/^I choose to see search all aircrafts$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.uncheck_inventory_only
  end
end

Then(/^I should see all the Active and Inactive Aircraft Inventory List$/) do
  on_page AircraftInventory do |p|
    expect(p.aircraft_states_options).to eq(p.expected_all_aircraft_states)
  end
end

When(/^I choose to see Inventory Only Option$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.uncheck_inventory_only
    p.check_inventory_only
    p.wait_for_ajax
  end
end

Then(/^I should see all the Active Aircraft Inventory List$/) do
  on_page AircraftInventory do |p|
    actual_aircraft_states_list = p.sorted_by_ac_state
    expect(p.aircraft_states_options).to eq(p.expected_aircraft_states)
    expect(actual_aircraft_states_list).not_to include("Decommissioned")
    expect(actual_aircraft_states_list).not_to include("ID'd for Disposal")
    expect(actual_aircraft_states_list).not_to include("Cancelled")
  end
end

When(/^I filter by an Aircraft State for All Aircrafts$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.uncheck_inventory_only
    p.choose_aircraft_state
  end
end

Then(/^I should see the All Aircraft Inventory List by Aircraft State$/) do
  on_page AircraftInventory do |p|
    expect(p.sorted_by_ac_state.uniq[0]).to eq(p.aircraft_states)
  end
end

Then(/^I should see detailed Aircraft Type information$/) do
  on_page AircraftTypeDetail do |p|
    expect(p.actual_aircraft_type_detail).to include(p.expected_aircraft_type_detail[0])
  end
end

When(/^I apply filters and choose All Aircrafts$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.choose_fleet_group
    p.choose_aircraft_type
    p.choose_company
    p.choose_aircraft_state
    p.choose_sales_status
    p.uncheck_inventory_only
  end
end

Then(/^the filters should be retained$/) do
  on_page AircraftInventory do |p|
    expect(p.aircraft_types).to eq('All')
    expect(p.fleet_groups).not_to eq('All')
    expect(p.aircraft_sales_status).not_to eq('All')
    expect(p.aircraft_states).to eq('All')
    expect(p.company).not_to eq('All')
    expect(p.tail_number).to eq("")
  end
end

When(/^I choose an Aircraft Tail Number$/) do
  on_page AircraftInventory do |p|
    p.delete_user_settings('qatest1')
    p.delete_user_settings('qatest4')
    p.delete_user_settings('qatest2')
    p.delete_user_settings('qatest20')
    sleep 2
    p.inventory
    p.tail_number = p.data_for(:aircraft_view_holds)['tail_with_3_active_holds']
    p.search
    sleep 2
    p.select_aircraft_tail(1)
  end
end

When(/^I choose an "([^"]*)" Aircraft Tail number$/) do |aircraft_state|
  on_page AircraftInventory do |p|
    p.inventory
    if aircraft_state == "ID'd for Disposal"
      p.uncheck_inventory_only
      sleep 2
    end
    p.aircraft_states = aircraft_state
    sleep 2
    p.select_aircraft_tail
  end
end

Then(/^I should see the Share Sizes$/) do
  on_page AircraftInventory do |p|
    expect(p.shares_sizes_options).to eq(p.expected_shares_sizes)
  end
end


When(/^I click the Edit Aircraft Type link$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.select_aircraft_type
  end
  @browser.windows.last.use do
    on_page AircraftTypeDetail do |p|
      p.close_b_element.when_visible(timeout=30)
      p.edit_aircraft_type
    end
  end
end

Then(/^I should be on the Edit Aircraft Type page$/) do
  on_page(InventoryAdministration) do |p|
    p.edit_ac_type
  end
end

When(/^I click the Edit Aircraft link$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.select_aircraft
  end
  @browser.windows.last.use do
    on_page AircraftTypeDetail do |p|
      p.close_b_element.when_visible(timeout=30)
      p.edit_aircraft
    end
  end
end

Then(/^I should be on the Edit Aircraft page$/) do
  on_page(InventoryAdministration) do |p|
    p.edit_ac
  end
end

When(/^I choose an Aircraft Tail Number with expired holds$/) do
  on_page AircraftInventory do |p|
    p.delete_user_settings('qatest2')
    place_legal_acft_hold_no_del(p.data_for(:aircraft_view_holds)['tail_with_more_holds'], 25, '')
    p.inventory
    p.tail_number = p.data_for(:aircraft_view_holds)['tail_with_more_holds']
    p.search
    sleep 2
    p.select_aircraft_tail(1)
  end
end

Then(/^I should receive a No Matching Records Found error$/) do
  expect(@browser.text).to include('No Matching records Found')
end

When(/^I search for an nonexistent Aircraft tail$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.tail_number = 'InvalidTail'
    p.search
  end
end

When(/^I search and filter for an nonexistent Aircraft tail$/) do
  on_page AircraftInventory do |p|
    p.inventory
    p.shares_sizes = ('100')
    p.company = ('EJM')
    p.aircraft_sales_status = ('Selling Fractionally')
    p.search
  end
end

Then(/^I should see the default company filter for "([^"]*)"$/) do |user|
  on_page(AircraftInventory).inventory
  on_page AircraftInventory do |p|
    user_id = USER_MAP[user.to_sym][:user]
    expect(p.company).to eq(p.expected_default_company(user_id))
  end
end

Given(/^I am on Inventory Search$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as("AIS Administrator")
  end
  on_page(AircraftInventory).inventory
end

Then(/^the % On Hold should be the sum of all active holds for an aircraft$/) do
  on_page AircraftInventory do |p|
    held_tail = p.select_first_tail_number_with_holds
    expect(p.first_tail_held_percentage.to_i).to eq(p.confirm_held_percentage(held_tail).to_i)
  end
end

Then(/^the results count should be the number of Aircraft displayed$/) do
  on_page AircraftInventory do |p|
    expect(p.inventory_count).to eq(p.results_count)
  end
end

### STEPS ADDED FOR NEW SMOKE TESTS ###

Then(/^I can search by Tail Number$/) do
  login_to_AIS
  on_page(AircraftInventory).inventory
  aircraft = return_first_tail
  search_inventory(aircraft)
  expect(inventory_is_filtered_by_tail?(aircraft)).to be true
end

When(/^I view an Aircraft with holds$/) do
  login_to_AIS
  on_page(AircraftInventory).inventory
  on_page(AircraftInventory).select_first_tail_number_with_holds
end

Then(/^the Aggregate Holds is the sum of all holds on the Aircraft$/) do
  expect(on_page(AircraftInventory).first_tail_held_percentage.to_f).to eq (on_page(AircraftInventory).first_tail_calculated_holds)
end

When(/^I select an Active Tail$/) do
  login_to_AIS
  on_page(AircraftInventory).inventory
  on_page(AircraftInventory).select_active_tails
  on_page(AircraftInventory).select_first_tail
end

Then(/^there is no Anticipated Delivery Date$/) do
  expect(on(AircraftDetail).anticipated_delivery_date_element.exists?).to be false
end

And(/^there is no Anticipated Disposal Date$/) do
  expect(on(AircraftDetail).anticipated_disposal_date_element.exists?).to be false
end

When(/^I select an On Order Tail$/) do
  login_to_AIS
  on_page(AircraftInventory).inventory
  on_page(AircraftInventory).select_on_order_tails
  on_page(AircraftInventory).select_first_tail
end

Then(/^there is an Anticipated Delivery Date$/) do
  expect(on(AircraftDetail).anticipated_delivery_date_element.exists?).to be true
end

When(/^I select an Id'd for Disposal Tail$/) do
  login_to_AIS
  on_page(AircraftInventory).inventory
  on_page(AircraftInventory).view_all_aircraft
  on_page(AircraftInventory).select_id_for_disposal_tails
  on_page(AircraftInventory).select_first_tail
end

Then(/^there is an Anticipated Disposal Date$/) do
  expect(on(AircraftDetail).anticipated_disposal_date_element.exists?).to be true
end