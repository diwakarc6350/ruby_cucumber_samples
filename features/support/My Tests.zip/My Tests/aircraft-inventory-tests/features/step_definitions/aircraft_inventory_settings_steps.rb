When(/^I change a single value in the settings screen$/) do
  login_as_admin
  navigate_to_aircraft_inventory_settings
  old_settings = current_aircraft_inventory_settings
  new_settings = update_single_value_in_aircraft_inventory_settings
  save_aircraft_inventory_settings

  stock.old_settings = old_settings
  stock.new_settings = new_settings
end

Then(/^I receive a confirmation message about the changed setting$/) do
  expect(is_aircraft_inventory_settings_changed_confirmation_present?).to eq true
  dismiss_settings_changed_confirmation
end

Then(/^the new value is present when I go back to the settings$/) do
  navigate_to_aircraft_inventory_settings
  current_settings = current_aircraft_inventory_settings

  expect(current_settings).to eq stock.new_settings
  expect(current_settings).to_not eq stock.old_settings
end

When(/^I change multiple values in the settings screen$/) do
  login_as_admin
  navigate_to_aircraft_inventory_settings
  old_settings = current_aircraft_inventory_settings
  new_settings = update_multiple_values_in_aircraft_inventory_settings
  save_aircraft_inventory_settings

  stock.old_settings = old_settings
  stock.new_settings = new_settings
end

When(/^I view the settings without changing them$/) do
  login_as_admin
  navigate_to_aircraft_inventory_settings
  old_settings = current_aircraft_inventory_settings
  save_aircraft_inventory_settings
  sleep 1
  dismiss_settings_changed_confirmation
  stock.old_settings = old_settings
end

Then(/^the settings should not be changed$/) do
  navigate_to_aircraft_inventory_settings
  current_settings = current_aircraft_inventory_settings

  expect(current_settings).to eq stock.old_settings
end

When(/^I cancel changing the settings$/) do
  login_as_admin
  navigate_to_aircraft_inventory_settings
  old_settings = current_aircraft_inventory_settings
  cancel_aircraft_inventory_settings

  stock.old_settings = old_settings
end

When(/^I change the maximum legal hold duration to be invalid$/) do
  login_as_admin
  navigate_to_aircraft_inventory_settings
  old_settings = current_aircraft_inventory_settings
  new_settings = update_max_legal_hold_duration_to_be_invalid
  cancel_aircraft_inventory_settings
  stock.old_settings = old_settings
  stock.new_settings = new_settings
end

When(/^I change the identified for disposal time frame to be invalid$/) do
  login_as_admin
  navigate_to_aircraft_inventory_settings
  old_settings = current_aircraft_inventory_settings
  new_settings = update_identified_for_disposal_threshold_to_be_invalid
  cancel_aircraft_inventory_settings

  stock.old_settings = old_settings
  stock.new_settings = new_settings
end

Then(/^I should receive an invalid maximum legal hold duration error$/) do
  expect(@errors[-1]).to include('Param maxLegalHoldDurationDays value must be greater than -1')
  expect(@errors[0]).to include('Param maxLegalHoldDurationDays value must be greater than 0')
end

Then(/^I should receive an invalid identified for disposal time frame error$/) do
  expect(@errors[-1]).to include('Param disposalThresholdMonths value must be greater than -1')
  expect(@errors[0]).to include('Param disposalThresholdMonths value must be greater than 0')
  expect(@errors[37]).to include('Param disposalThresholdMonths value cannot exceed limit of 36')
end

When(/^I create a legal hold past the maximum duration$/) do
  login_as_admin
  goto_aircraft_inventory_administration
  create_aircraft_for_holds
  place_hold_past_maximum_duration
end

Then(/^I should receive a max hold date error$/) do
  expect(@browser.text).to include('Date is beyond max hold date limit')
end