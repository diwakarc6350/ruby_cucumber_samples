require 'page-object'
require 'page-object/page_factory'
include PageObject::PageFactory

When(/^I login as a valid user$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as('AIS Administrator')
  end
end

Then(/^the user is on the landing page$/) do
  expect(@browser.title).to eq('Aircraft Home')
  expect(@browser.text).to include(Date.today.strftime('%Y') + ' NetJets, Inc')
end

When(/^I login as an invalid user$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_with_invalid_user
  end
end

Then(/^the user is notified of the invalid user$/) do
  expect(@browser.text).to include('Invalid Credentials - Please try again')
end

When(/^I login with an invalid password$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_with_invalid_password
  end
end

Then(/^the user is notified of the invalid password$/) do
  expect(@browser.text).to include('Invalid Credentials - Please try again')
end

Given(/^I login as "([^"]*)"$/) do |role|
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as(role)
  end
end

When(/^I login as unauthorized user$/) do
  visit_page LoginPage
  on_page LoginPage do |login_page|
    login_page.login_as('AIS Unauthorized User')
  end
end

Then(/^I should not have access to AIS System$/) do
  expect(@browser.text).to include('Invalid Credentials - Please try again')
end