require 'spec_helper'
require 'env_helper'

describe 'base_url' do
  it 'is default to local' do
    ENV['ENVIRONMENT'] = ''
    expect(base_url).to include('localhost')
  end
end