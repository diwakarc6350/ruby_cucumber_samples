require 'rspec'
$LOAD_PATH << File.dirname(__FILE__)+"/../features/support"