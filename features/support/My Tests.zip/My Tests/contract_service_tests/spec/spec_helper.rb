require 'rspec'
require 'rspec/core/shared_example_group'
require 'logger'
require 'json_extensions'
require 'active_record'
require 'patches/string'
require 'ijet2_midtier'
require 'enums'

include Enums::Cards
include Enums::CardTypes

#supress active record deprecation warnings.
ActiveSupport::Deprecation.silenced = true

SSL_OPTIONS = {
    verify_ssl: true,
    ssl_ca_file: File.dirname(__FILE__)+"/../resources/cacert.pem",
    ssl_version: 'SSLv23'
}

$logger = Logger.new STDOUT

def log
  $logger
end

def environment
  #:qa
  ENV['ENVIRONMENT'].to_sym
end

puts "Using #{environment} environment to test..."

