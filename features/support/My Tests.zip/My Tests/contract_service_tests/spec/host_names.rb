LAYER7_HOSTS = {
    local: 'localhost:8080/contract-service-web',
    ci: 'bcsdev01:9780/contract-service',
    itg: 'servicesdev.netjets.com',
    #itg2: 'bcsdev02:9180/contract-service',
    itg2: 'servicesdev2.netjets.com',
    qa: 'servicesqareg.netjets.com',
    clone: 'servicesclone.netjets.com',
    train: 'servicestrain.netjets.com',
    cat: 'servicescat.netjets.com',
    patch: 'servicespatch.netjets.com'
}

SERVICE_HOSTS = {
    local: 'localhost:8080/contract-service-web',
    ci: 'bcsdev01:9780/contract-service',
    itg: 'bdla6711:9080',
    itg2: 'bdla6771:9083',
    qa: 'bqla6714:9080',
    clone: '',
    train: '',
    cat: '',
    patch: 'bdla6721:9083'
}

OAUTH_HOSTS = {
    local: 'servicesdev.netjets.com',
    ci: 'servicesdev.netjets.com',
    itg: 'servicesdev.netjets.com',
    itg2: 'servicesdev2.netjets.com',
    qa: 'servicesqareg.netjets.com',
    clone: 'servicesclone.netjets.com',
    train: 'servicestrain.netjets.com',
    cat: 'servicescat.netjets.com',
    patch: 'servicespatch.netjets.com'
}

PROTOCOLS = {
    local: 'http://',
    ci: 'http://',
    itg: 'https://',
    itg2: 'https://',
    qa: 'https://',
    clone: 'https://',
    train: 'https://',
    cat: 'https://',
    patch: 'https://'
}

def layer7_host
  LAYER7_HOSTS[environment]
end

def services_host
  SERVICE_HOSTS[environment]
end

def oauth_host
  OAUTH_HOSTS[environment]
end

def protocol
  PROTOCOLS[environment]
end


CONTRACTS_V3_URL = "#{protocol}" + "#{layer7_host}/contract/v3/contracts"
CONTRACT_VARIATIONS_V3_URL ="#{protocol}" + "#{layer7_host}/contract/v3/variations"
CONTRACT_FOR_CHECKS_V3_URL = "#{protocol}" + "#{layer7_host}/contract/v3/contractForChecks"
USAGE_V3_URL = "#{protocol}" + "#{layer7_host}/contract/v3/contracts/usages"