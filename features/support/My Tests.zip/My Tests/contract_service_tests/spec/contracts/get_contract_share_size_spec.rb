require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'

=begin
  In this test we make sure the share size is correct
  in the response for each contract type. Also we make
  sure is share size is null in ijet it is displayed
  as zero.
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'contract share size' do
      $contract_ids_by_contract_types.each do |contract|
        it "gets share size for #{contract[0]['contract_type']}" do
          contract_id = contract[0]["contract_id"].to_i
          sql = " select cb.share_size
                  from contract_base cb
                  where cb.contract_id = #{contract_id}"
          share_size_info = $Ijet_con.connection.execute(sql)
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['shareSize']).to eq(share_size_info[0]["share_size"].to_f)
        end
      end

      context "share size is null in ijet" do
        it "gets share size as 0 " do
          sql = " select cb.contract_id, cb.share_size
                  from contract_base cb
                  where cb.share_size is null
                  and rownum <= 1"
          share_size_info = $Ijet_con.connection.execute(sql)
          contract_id = share_size_info[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['shareSize']).to eq(0)
        end
      end
    end
  end
end