require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'

=begin
  In this test we make sure the contract comment is
  displayed as stored in the IJET2 database.
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    begin
      describe 'contract comments' do
        it "does not get contract comments when comments are present in contract" do
          sql = "select contract_id from contract where rownum <= 1"
          contract_comments = $Ijet_con.connection.execute(sql)
          contract_id = contract_comments[0]['contract_id'].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc.has_key?('comments')).to be false
        end
        it "does not get contract comments when comments are not present in contract" do
          sql = "select contract_id from contract where rownum <= 1"
          contract_comments = $Ijet_con.connection.execute(sql)
          contract_id = contract_comments[0]['contract_id'].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc.has_key?('comments')).to be false
        end
      end
    end

  end
end