require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'

=begin
    In this test we make sure the contract variations are
    correctly displayed based on the information stored in the IJET2 database
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end
    describe 'contracts variations' do
      context 'when variations are present' do
        it "gets the account variation hasAccount for a contract as True" do
          sql = account_var_present_sql
          variation_info = $Ijet_con.connection.execute(sql)
          account_id = variation_info[0]['account_id'].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}?#{APP_AGENT_PARAM}&accountId=#{account_id}&includes=variations", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc[0]['variations']['hasAccount']).to be true
        end

        it "gets the billing variation hasBilling for a contract as True" do
          sql = billing_var_present_sql
          variation_info = $Ijet_con.connection.execute(sql)
          contract_id = variation_info[0]['billing_contract_id'].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=variations", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['variations']['hasBilling']).to be true
        end

        it "gets the operation variation hasOperational for a contract as True" do
          sql = operation_var_present_sql
          variation_info = $Ijet_con.connection.execute(sql)
          contract_id = variation_info[0]['operational_contract_id'].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=variations", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['variations']['hasOperational']).to be true
        end

        it "gets the contratual variation hasContractual for a contract as True" do
          sql = contractual_var_present_sql
          variation_info = $Ijet_con.connection.execute(sql)
          contract_id = variation_info[0]['contractual_contract_id'].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=variations", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['variations']['hasContractual']).to be true
        end

      end

      context 'when variations are not present' do
        it "gets the account variation hasAccount for a contract as False" do
          sql = account_var_not_present_sql
          variation_info = $Ijet_con.connection.execute(sql)
          contract_id = variation_info[0]['contract_id'].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=variations", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['variations']['hasAccount']).to be false
        end

        it "gets the billing variation hasBilling for a contract as False" do
          sql = billing_var_not_present_sql
          variation_info = $Ijet_con.connection.execute(sql)
          contract_id = variation_info[0]['contract_id'].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=variations", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['variations']['hasBilling']).to be false
        end

        it "gets the operation variation hasOperational for a contract as False" do
          sql =operation_var_not_present_sql
          variation_info = $Ijet_con.connection.execute(sql)
          contract_id = variation_info[0]['contract_id'].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=variations", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['variations']['hasOperational']).to be false
        end

        it "gets the contratual variation hasContractual for a contract as False" do
          sql = contractual_var_not_present_sql
          variation_info = $Ijet_con.connection.execute(sql)
          contract_id = variation_info[0]['contract_id'].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=variations", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['variations']['hasContractual']).to be false
        end
      end

      context 'when all variations are not present' do
        it "gets all variation for a contract as Null" do
          sql = no_var_not_present_sql
          variation_info = $Ijet_con.connection.execute(sql)
          contract_id = variation_info[0]['contract_id'].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=variations", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc.has_key?('variations')).to be false
        end
      end

    end
  end

  def account_var_present_sql
    # sql to get a account variation is present
    <<-SQL.gsub(/^ {6}/, '')
      select account_id, operational_contract_id, billing_contract_id, contractual_contract_id
      from contract_var
      where account_id is not null
      and rownum <=1
    SQL
  end

  def account_var_not_present_sql
    # sql to get a account variation is not present
    <<-SQL.gsub(/^ {6}/, '')
      select contract_id from contract_base ctr
      where contract_id in (select operational_contract_id from contract_var where operational_contract_id is not null )
      and contract_id in (select contractual_contract_id from contract_var where contractual_contract_id is not null )
      and contract_id in (select billing_contract_id from contract_var where billing_contract_id is not null )
      and ctr.acct_id not in (select account_id from contract_var where account_id is not null )
      and rownum <=1
    SQL
  end

  def billing_var_present_sql
    # sql to get a billing variation is present
    <<-SQL.gsub(/^ {6}/, '')
      select account_id, operational_contract_id, billing_contract_id, contractual_contract_id
      from contract_var
      where billing_contract_id is not null
      and rownum <=1
    SQL
  end

  def billing_var_not_present_sql
    # sql to get a billing variation is not present
    <<-SQL.gsub(/^ {6}/, '')
      select contract_id from contract_base ctr
      where contract_id in (select operational_contract_id from contract_var where operational_contract_id is not null )
      and contract_id in (select contractual_contract_id from contract_var where contractual_contract_id is not null )
      and contract_id not in (select billing_contract_id from contract_var where billing_contract_id is not null )
      and ctr.acct_id in (select account_id from contract_var where account_id is not null )
      and rownum <=1
    SQL
  end

  def operation_var_present_sql
    # sql to get a operation variation is present.
    <<-SQL.gsub(/^ {6}/, '')
      select account_id, operational_contract_id, billing_contract_id, contractual_contract_id
      from contract_var
      where operational_contract_id is not null
      and rownum <=1
    SQL
  end

  def operation_var_not_present_sql
    # sql to get a operation variation is not present.
    <<-SQL.gsub(/^ {6}/, '')
      select contract_id from contract_base ctr
      where contract_id not in (select operational_contract_id from contract_var where operational_contract_id is not null )
      and contract_id in (select contractual_contract_id from contract_var where contractual_contract_id is not null )
      and contract_id in (select billing_contract_id from contract_var where billing_contract_id is not null )
      and ctr.acct_id in (select account_id from contract_var where account_id is not null )
      and rownum <=1
    SQL
  end

  def contractual_var_present_sql
    # sql to get a contracual variation is present.
    <<-SQL.gsub(/^ {6}/, '')
      select account_id, operational_contract_id, billing_contract_id, contractual_contract_id
      from contract_var
      where contractual_contract_id is not null
      and rownum <=1
    SQL
  end

  def contractual_var_not_present_sql
    # sql to get a contracual variation is not present.
    <<-SQL.gsub(/^ {6}/, '')
      select contract_id from contract_base ctr
      where contract_id in (select operational_contract_id from contract_var where operational_contract_id is not null )
      and contract_id not in (select contractual_contract_id from contract_var where contractual_contract_id is not null )
      and contract_id in (select billing_contract_id from contract_var where billing_contract_id is not null )
      and ctr.acct_id in (select account_id from contract_var where account_id is not null )
      and rownum <=1
    SQL
  end

  def no_var_not_present_sql
    # sql to get a not variations are present.
    <<-SQL.gsub(/^ {6}/, '')
      select contract_id from contract_base ctr
      where contract_id not in (select operational_contract_id from contract_var where operational_contract_id is not null )
      and contract_id not in (select contractual_contract_id from contract_var where contractual_contract_id is not null )
      and contract_id not in (select billing_contract_id from contract_var where billing_contract_id is not null )
      and ctr.acct_id not in (select account_id from contract_var where account_id is not null )
      and rownum <=1
    SQL
  end

end