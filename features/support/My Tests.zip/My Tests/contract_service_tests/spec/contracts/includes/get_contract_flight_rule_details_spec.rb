require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require_relative '../../../spec/data/models/contract_detail'

=begin
    In this test we make sure the flight rule details are
    correctly displayed based on the information stored in the IJET2 database
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'includes flight rule details' do
      $flight_rules.each do |flight_rule|
        context "flight rule as #{flight_rule['value']}" do
          it "gets the flight rule id and description for #{flight_rule['value']}" do
            sql = " select c.contract_id, c.flight_rule_id, ctt.value as rule_description
                    from contract_base c
                    join code_table_trans ctt
                    on c.flight_rule_id = ctt.code
                    where ctt.tag = 'FlightRule'
                    and c.flight_rule_id is not null
                    and c.flight_rule_id != 6
                    and c.flight_rule_id = #{flight_rule['code']}
                    and rownum <=1"
            flight_rule_info = $Ijet_con.connection.execute(sql)
            if flight_rule_info.length > 0
              contract_id = flight_rule_info[0]["contract_id"].to_i
              tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=flightRuleDetail", @account_mgmt_oauth.authorized_oauth_header
              expect(tc_doc['flightRuleDetail'].has_key?('ruleId')).to be true
              expect(tc_doc['flightRuleDetail'].has_key?('ruleDescription')).to be true
              expect(tc_doc['flightRuleDetail']['ruleId']).to eq(flight_rule_info[0]['flight_rule_id'].to_i)
              expect(tc_doc['flightRuleDetail']['ruleDescription']).to eq(flight_rule_info[0]['rule_description'])
            else
              log.info("Flight Rule #{flight_rule['value']} has no data to test")
            end
          end

          it "gets the domestic rule id and description for #{flight_rule['value']}" do
            sql = " select cb.contract_id, cd.FLIGHT_RULE_ID_DOMESTIC, ctt.value as domestic_rule_description
                    from contract_base cb join contract_detail cd on cb.CONTRACT_ID = cd.CONTRACT_ID
                    join code_table_trans ctt
                    on cb.flight_rule_id = ctt.code
                    where ctt.tag = 'FlightRule'
                    and cd.FLIGHT_RULE_ID_DOMESTIC is not null
                    and cb.flight_rule_id = 4
                    and rownum <=1"
            flight_rule_info = $Ijet_con.connection.execute(sql)
            if flight_rule_info.length > 0
              contract_id = flight_rule_info[0]["contract_id"].to_i
              tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=flightRuleDetail", @account_mgmt_oauth.authorized_oauth_header
              expect(tc_doc['flightRuleDetail'].has_key?('domesticRuleId')).to be true
              expect(tc_doc['flightRuleDetail'].has_key?('domesticRuleDescription')).to be true
              expect(tc_doc['flightRuleDetail']['domesticRuleId']).to eq(flight_rule_info[0]['flight_rule_id_domestic'].to_i)
              expect(tc_doc['flightRuleDetail']['domesticRuleDescription']).to eq(flight_rule_info[0]['domestic_rule_description'])
            else
              log.info("Flight Rule #{flight_rule['value']} has no data to test")
            end

          end

          it "gets the international rule id and description for #{flight_rule['value']}" do
            sql = " select cb.contract_id, cd.FLIGHT_RULE_ID_INTL, ctt.value as intl_rule_description
                    from contract_base cb join contract_detail cd on cb.CONTRACT_ID = cd.CONTRACT_ID
                    join code_table_trans ctt
                    on cb.flight_rule_id = ctt.code
                    where ctt.tag = 'FlightRule'
                    and cd.FLIGHT_RULE_ID_INTL is not null
                    and cb.flight_rule_id = 4
                    and rownum <=1"
            flight_rule_info = $Ijet_con.connection.execute(sql)
            if flight_rule_info.length > 0
              contract_id = flight_rule_info[0]["contract_id"].to_i
              tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=flightRuleDetail", @account_mgmt_oauth.authorized_oauth_header
              expect(tc_doc['flightRuleDetail'].has_key?('internationalRuleId')).to be true
              expect(tc_doc['flightRuleDetail'].has_key?('internationalRuleDescription')).to be true
              expect(tc_doc['flightRuleDetail']['internationalRuleId']).to eq(flight_rule_info[0]['flight_rule_id_intl'].to_i)
              expect(tc_doc['flightRuleDetail']['internationalRuleDescription']).to eq(flight_rule_info[0]['intl_rule_description'])
            else
              log.info("Flight Rule #{flight_rule['value']} has no data to test")
            end
          end
        end
      end

      context 'when letter received date is not null' do
        it 'gets the letter received date ' do
          sql = " select contract_id, FLIGHT_RULE_LETTER_RECEIVED_DT
                  from contract_detail
                  where FLIGHT_RULE_LETTER_RECEIVED_DT is not null
                  and rownum <=1"
          flight_rule_info = $Ijet_con.connection.execute(sql)
          contract_id = flight_rule_info[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=flightRuleDetail", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['flightRuleDetail'].has_key?('letterReceivedDate')).to be true
          expect(tc_doc['flightRuleDetail']['letterReceivedDate'].to_datetime).to eq(flight_rule_info[0]['flight_rule_letter_received_dt'].to_datetime)
        end
      end

      context 'when letter received date is null' do
        it 'gets the letter received date as null' do
          sql = " select contract_id, FLIGHT_RULE_LETTER_RECEIVED_DT
                  from contract_detail
                  where FLIGHT_RULE_LETTER_RECEIVED_DT is null
                  and rownum <=1"
          flight_rule_info = $Ijet_con.connection.execute(sql)
          contract_id = flight_rule_info[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=flightRuleDetail", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['flightRuleDetail'].has_key?('internationalRuleId')).to be true
        end
      end

      context 'when domestic rule is id null in ijet' do
        it 'gets domestic rule as null ' do
          sql = " select contract_id, FLIGHT_RULE_ID_DOMESTIC
                  from contract_detail
                  where FLIGHT_RULE_ID_DOMESTIC is null
                  and rownum <=1"
          flight_rule_info = $Ijet_con.connection.execute(sql)
          contract_id = flight_rule_info[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=flightRuleDetail", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['flightRuleDetail'].has_key?('domesticRuleId')).to be false
          expect(tc_doc['flightRuleDetail'].has_key?('domesticRuleDescription')).to be false
        end
      end

      context 'when international rule is id null in ijet' do
        it 'gets international rule as null ' do
          sql = " select contract_id, FLIGHT_RULE_ID_INTL
                  from contract_detail
                  where FLIGHT_RULE_ID_INTL is null
                  and rownum <=1"
          flight_rule_info = $Ijet_con.connection.execute(sql)
          contract_id = flight_rule_info[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=flightRuleDetail", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['flightRuleDetail'].has_key?('internationalRuleId')).to be false
          expect(tc_doc['flightRuleDetail'].has_key?('internationalRuleDescription')).to be false
        end
      end

      context 'when flight_rule_id_ovr_flag is true ijet' do
        it 'gets domestic rule as true ' do
          sql = " select contract_id, FLIGHT_RULE_ID_OVR_FLG
                  from contract_detail
                  where FLIGHT_RULE_ID_OVR_FLG = 'T'
                  and rownum <=1"
          flight_rule_info = $Ijet_con.connection.execute(sql)
          contract_id = flight_rule_info[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=flightRuleDetail", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['flightRuleDetail'].has_key?('flightRuleOverrideFlag')).to be true
        end
      end

      context 'when flight_rule_id_ovr_flag is false ijet' do
        it 'gets domestic rule as false ' do
          sql = " select contract_id, FLIGHT_RULE_ID_OVR_FLG
                  from contract_detail
                  where FLIGHT_RULE_ID_OVR_FLG = 'F'
                  and rownum <=1"
          flight_rule_info = $Ijet_con.connection.execute(sql)
          contract_id = flight_rule_info[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=flightRuleDetail", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['flightRuleDetail'].has_key?('flightRuleOverrideFlag')).to be false
        end
      end
    end
  end
end