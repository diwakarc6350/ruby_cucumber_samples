require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/contracts_for_checks'

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @aircraft_per_day_info = $Ijet_con.connection.execute(get_aircrafts_per_day_sql)
      @accounts = $Ijet_con.connection.execute(get_accounts_sql)
    end

    it 'gets zero aircraft per day for a contract' do
      aircraft_per_day_zero = @aircraft_per_day_info.select { |rec| rec['aircraft_per_day'].to_i==0 }
      chosen_contract = aircraft_per_day_zero[rand(aircraft_per_day_zero.length)]
      contract_id = chosen_contract['contract_id'].to_i
      response = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=aircraftPerDay",
                                  @account_mgmt_oauth.authorized_oauth_header
      expected_aircraft_per_day = chosen_contract['aircraft_per_day'].to_i
      expect(response['aircraftPerDay']).to eq(expected_aircraft_per_day)
    end

    it 'gets one aircraft per day for a contract' do
      aircraft_per_day_zero = @aircraft_per_day_info.select { |rec| rec['aircraft_per_day'].to_i==1 }
      chosen_contract = aircraft_per_day_zero[rand(aircraft_per_day_zero.length)]
      contract_id = chosen_contract['contract_id'].to_i
      response = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=aircraftPerDay",
                                  @account_mgmt_oauth.authorized_oauth_header
      expected_aircraft_per_day = chosen_contract['aircraft_per_day'].to_i
      expect(response['aircraftPerDay']).to eq(expected_aircraft_per_day)
    end

    it 'gets more than one aircraft per day for a contract' do
      aircraft_per_day_zero = @aircraft_per_day_info.select { |rec| rec['aircraft_per_day'].to_i>1 }
      chosen_contract = aircraft_per_day_zero[rand(aircraft_per_day_zero.length)]
      contract_id = chosen_contract['contract_id'].to_i
      response = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=aircraftPerDay",
                                  @account_mgmt_oauth.authorized_oauth_header
      expected_aircraft_per_day = chosen_contract['aircraft_per_day'].to_i
      expect(response['aircraftPerDay']).to eq(expected_aircraft_per_day)
    end

    it 'gets the aircraft per day for accounts' do
      account_id = @accounts[rand(@accounts.length)]['acct_id']
      response = response_as_json "#{CONTRACTS_V3_URL}?#{APP_AGENT_PARAM}&accountId=#{account_id.to_i}&includes=aircraftPerDay",
                                  @account_mgmt_oauth.authorized_oauth_header
      response.each do |resp|
        expect(resp.has_key?('aircraftPerDay')).to be true
      end
    end

  end
end