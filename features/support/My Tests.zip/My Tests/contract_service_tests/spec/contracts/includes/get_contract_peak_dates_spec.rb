require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'date'
require 'data/models/contract_base'

=begin
    In this test we make sure the peak dates are
    correctly displayed based on the information stored in the IJET2 database
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end
    describe 'includes peak dates' do
      it "gets the peak dates for a contract" do
        contract_id = ContractBase.where(peak_date_list_cd: 2).first.contract_id

        sql = get_peak_dates_sql(contract_id)
        peak_date_info = $Ijet_con.connection.execute(sql)
        tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}&includes=peakDates",@account_mgmt_oauth.authorized_oauth_header
        expect(tc_doc['peakDates'].length).to eq(peak_date_info.length)
        for i in 0..tc_doc['peakDates'].length-1
          expect(tc_doc['peakDates'][i]['description']).to eq(peak_date_info[i]['description'])
          expect(tc_doc['peakDates'][i]['eventDate'].to_datetime).to eq(peak_date_info[i]['eventdate'].to_datetime)
        end
      end
    end
  end

  def get_peak_dates_sql(contract_id)
    <<-SQL.gsub(/^ {6}/, '')
      select descr as description, event_dt as eventdate from peak_date where program_id in (
      select program_id from account where accountid in (
      select acct_id from contract_base where contract_id = #{contract_id}))
      and peak_date.card_only = 'F'
      and peak_date.expanded_flag = 'F'
      and peak_date.event_dt > SYSDATE -365
      and peak_date.event_dt < SYSDATE +365
      order by 2 desc
    SQL
  end

end