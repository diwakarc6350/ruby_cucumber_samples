require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'

=begin
  In this test we make sure the flightRule is
  displayed as stored in the IJET2 database.
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'contract flightRule' do
      it "gets contract flightRule" do
        sql = " select c.contract_id, c.flight_rule_id, ctt.value
                from  contract_base c
                join code_table_trans ctt
                on c.flight_rule_id = ctt.code
                and ctt.tag = \'FlightRule\'
                and rownum <= 1"
        contract_flight_rule = $Ijet_con.connection.execute(sql)
        contract_id = contract_flight_rule[0]['contract_id'].to_i
        tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
        expect(tc_doc['flightRule']).to eq(contract_flight_rule[0]['value'])
      end
    end

  end
end