require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'

=begin
  In this test we make sure the ej_company_id and airport code
  are displayed correctly for each contract type from the service.
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'ej company id and airport id' do
      $contract_ids_by_contract_types.each do |contract|
        it "gets ej company id and airport id  for #{contract[0]['contract_type']}" do
          contract_id = contract[0]["contract_id"].to_i
          sql = " select ej.ej_company_id, ej.airport_id
                  from contract_base cb
                  join ej_company ej
                  on ej.ej_company_id = cb.ej_company_id
                  where cb.contract_id = #{contract_id}"
          ej_company_info = $Ijet_con.connection.execute(sql)
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['ejCompanyId'].to_i).to eq(ej_company_info[0]["ej_company_id"].to_i)
          expect(tc_doc['ejCompanyAirport']).to eq(ej_company_info[0]["airport_id"])
        end
      end
    end

  end
end