require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'

=begin
  In this test we make sure the contract status,  statusId and isBillable
  are correct displayed fr various contract statuses
  stored in the IJET2 database.
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'gets contract status and status_id' do
      contract_status = {1=>'Active',2=>'Inactive',3=>'Restricted',4=>'Accrual'}
      contract_status.each_pair do |i, status|
        it "gets #{status} contract" do
          sql = "select contract_id from contract where contract_status_id = #{i} and rownum <= 1"
          contract = $Ijet_con.connection.execute(sql)
          contract_id = contract[0]['contract_id'].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['status']).to eq(status)
          expect(tc_doc['statusId']).to eq(i)
        end
      end

      is_billable_false = {2=>'Inactive',3=>'Restricted'}
      is_billable_false.each_pair do |i, status|
        it "gets isBillable status as false for #{status} contract" do
          sql = "select contract_id from contract where contract_status_id = #{i} and rownum <= 1"
          contract = $Ijet_con.connection.execute(sql)
          contract_id = contract[0]['contract_id'].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['status']).to eq(status)
          expect(tc_doc['isBillable']).to be false
        end
      end

      is_billable_true =  {1=>'Active',4=>'Accrual'}
      is_billable_true.each_pair do |i, status|
          it "gets isBillable status as false for #{status} contract" do
            sql = "select contract_id from contract where contract_status_id = #{i} and rownum <= 1"
            contract = $Ijet_con.connection.execute(sql)
            contract_id = contract[0]['contract_id'].to_i
            tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
            expect(tc_doc['status']).to eq(status)
            expect(tc_doc['isBillable']).to be true
          end
        end
      end
    end
end