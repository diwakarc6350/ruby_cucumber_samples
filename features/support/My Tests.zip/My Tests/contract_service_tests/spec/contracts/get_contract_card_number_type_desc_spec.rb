require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'

=begin
  In this test we make sure the cardNumber, cardType, cardTypeDescription
  are correctly displayed in the response.
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'contract card information' do
      $card_types.each do |card_type|
        it "gets card information for #{card_type['value']}" do
          sql = "select cb.contract_id, cb.card_id, cd.CARD_TYPE_ID , crd.card_nbr, ctt.value
                  from contract_base cb join contract_detail cd on cb.CONTRACT_ID = cd.CONTRACT_ID
                  join code_table_trans ctt
                  on ctt.code = CARD_TYPE_ID
                  join card crd
                  on crd.card_id = cb.card_id
                  where cb.contract_type_id=17
                  and ctt.tag = 'CardSubType'
                  and ctt.code =  #{card_type['code']}
                  and rownum <= 1
                  order by cd.card_type_id"
          card_info = $Ijet_con.connection.execute(sql)
          contract_id = card_info[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['cardNumber']).to eq(card_info[0]["card_nbr"])
          expect(tc_doc['cardType']).to eq(card_info[0]["card_type_id"].to_i)
          expect(tc_doc['cardTypeDescription']).to eq(card_info[0]["value"])
        end
      end
    end

    context 'card type and number is null in ijet' do
      it 'gets no card information' do
        sql = "select cb.contract_id, cb.card_id, cd.card_type_id
                from contract_base cb join contract_detail cd on cb.CONTRACT_ID = cd.CONTRACT_ID
                where cb.card_id is null
                and cd.card_type_id is null"
        card_info = $Ijet_con.connection.execute(sql)
        contract_id = card_info[0]["contract_id"].to_i
        tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
        expect(tc_doc['cardNumber']).to be_nil
        expect(tc_doc['cardType']).to be_nil
        expect(tc_doc['cardTypeDescription']).to be_nil
      end
    end

    context 'card type is null but card number is present ijet' do
      it 'get card number but type and description should be be present' do
        sql = " select cb.contract_id, cb.card_id, cd.card_type_id
                from contract_base cb join contract_detail cd on cb.CONTRACT_ID = cd.CONTRACT_ID
                where cb.card_id is not null
                and cd.card_type_id is null"

        card_info = $Ijet_con.connection.execute(sql)
        contract_id = card_info[0]["contract_id"].to_i
        tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
        expect(tc_doc['cardNumber']).not_to be_nil
        expect(tc_doc['cardType']).to be_nil
        expect(tc_doc['cardTypeDescription']).to be_nil
      end
    end
  end
end