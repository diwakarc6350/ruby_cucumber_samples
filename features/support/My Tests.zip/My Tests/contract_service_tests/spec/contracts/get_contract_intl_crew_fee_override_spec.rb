require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require_relative '../../spec/data/models/contract_detail'

=begin
  In this test we make sure the four fields in the contract service
  internationalCrewFeeOverride1, internationalCrewFeeOverride2
  internationalCrewFeeOverride3, internationalCrewFeeOverride4
  are displayed correctly for every type of contract.
  And also we make sure the fees are displayed correctly when it is null
  or > 0
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'international crew fee override' do
      $contract_ids_by_contract_types.each do |contract|
        it "gets international crew fee override for #{contract[0]['contract_type']}" do
          contract_id = contract[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc.has_key?('internationalCrewFeeOverride1')).to be true
          expect(tc_doc.has_key?('internationalCrewFeeOverride2')).to be true
          expect(tc_doc.has_key?('internationalCrewFeeOverride3')).to be true
          expect(tc_doc.has_key?('internationalCrewFeeOverride4')).to be true
        end
      end

      context 'when international crew fee override > 0' do
        it "gets international crew fee override" do
          contract = ContractDetail.select(:contract_id,
                                           :intl_crew_fee_length1_override,
                                           :intl_crew_fee_length2_override,
                                           :intl_crew_fee_length3_override,
                                           :intl_crew_fee_length4_override)
                                   .where("intl_crew_fee_length2_override > 0",
                                          "intl_crew_fee_length3_override > 0",
                                          "intl_crew_fee_length4_override > 0").first
          contract_id = contract.contract_id
          contract = contract.attributes
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['internationalCrewFeeOverride1']).to eq(contract['intl_crew_fee_length1_override'])
          expect(tc_doc['internationalCrewFeeOverride2']).to eq(contract['intl_crew_fee_length2_override'])
          expect(tc_doc['internationalCrewFeeOverride3']).to eq(contract['intl_crew_fee_length3_override'])
          expect(tc_doc['internationalCrewFeeOverride4']).to eq(contract['intl_crew_fee_length4_override'])
        end
      end

      context 'when international crew fee override is null' do
        it "gets international crew fee override" do
          contract_id = ContractDetail.select(:contract_id,
                                              :intl_crew_fee_length1_override,
                                              :intl_crew_fee_length2_override,
                                              :intl_crew_fee_length3_override,
                                              :intl_crew_fee_length4_override)
                                      .where("intl_crew_fee_length1_override is null",
                                             "intl_crew_fee_length2_override is null",
                                             "intl_crew_fee_length3_override is null",
                                             "intl_crew_fee_length4_override is null").first.contract_id
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['internationalCrewFeeOverride1']).to eq(0)
          expect(tc_doc['internationalCrewFeeOverride2']).to eq(0)
          expect(tc_doc['internationalCrewFeeOverride3']).to eq(0)
          expect(tc_doc['internationalCrewFeeOverride4']).to eq(0)
        end
      end
    end

  end
end