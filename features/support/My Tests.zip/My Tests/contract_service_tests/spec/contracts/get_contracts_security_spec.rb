require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    it 'gets HTTP 401 error for missing appAgent parameter', :security => true do
      error_response = response_as_json("#{CONTRACTS_V3_URL}?#{APP_AGENT_PARAM_NONE}&accountId=#{$all_invalid_account_ids[1]}", @account_mgmt_oauth.authorized_oauth_header)
      expect(error_response["error"]).to eq("appagent_missing")
      expect(error_response["error_description"]).to eq("Missing appagent header/parameter")
    end

    it 'gets HTTP 403 error for unauthorized appAgent parameter', :security => true do
      error_response = response_as_json("#{CONTRACTS_V3_URL}?#{APP_AGENT_PARAM_NOT_ALLOWED}&accountId=#{$all_invalid_account_ids[1]}", @account_mgmt_oauth.authorized_oauth_header)
      expect(error_response["error"]).to eq("appagent_not_authorized")
      expect(error_response["error_description"]).to eq("appagent is not authorized")
    end

    #it 'gets no response when no access token is provided' do
    #  error_response = response_as_json("#{CONTRACTS_V3_URL}?#{APP_AGENT_PARAM}", '')
    #  puts error_response
    #  expect(error_response).to eq({})
    #end

    #it 'gets no response when invalid access token' do
    #  error_response = response_as_json("#{CONTRACTS_V3_URL}?#{APP_AGENT_PARAM}", '12345678-1234-1234-1234-72ffa5ab32e5')
    #  json_error_response = JSON.parse(error_response)
    #  expect(json_error_response).to eq({})
    #end

    it 'gets HTTP 403 error for an unauthorized user', :security => true do

      error_response = response_as_json "#{CONTRACTS_V3_URL}/1353732?#{APP_AGENT_PARAM}", SSL_OPTIONS.merge(@account_mgmt_oauth.unauthorized_oauth_header)
      error_block = error_response['errors'][0]
      expect(error_block["code"]).to eq('403')
      error_desc = error_block["description"].gsub(/([0123456789])/, '')
      expect(error_desc).to eq('AccountViewer access to account  was denied')
    end

    it 'gets HTTP 400 error for an unauthorized user with no contract id', :security => true do
      error_response = response_as_json "#{CONTRACTS_V3_URL}/?#{APP_AGENT_PARAM}", SSL_OPTIONS.merge(@account_mgmt_oauth.unauthorized_oauth_header)
      error_block = error_response['errors'][0]
      expect(error_block["code"].to_i).to eq(400)
    end

    it 'gets 404 error for an unauthorized user with invalid contract id', :security => true do
      error_response = response_as_json "#{CONTRACTS_V3_URL}/123456?#{APP_AGENT_PARAM}", SSL_OPTIONS.merge(@account_mgmt_oauth.unauthorized_oauth_header)
      error_block = error_response['errors'][0]
      expect(error_block["code"].to_i).to eq(404)
    end

    it 'gets contract information for an authorized external user', :security => true do
      tc_doc = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/1000134?#{APP_AGENT_PARAM}",
                                @account_mgmt_oauth.authorized_oauth_header('crossroads', 'cr0ssR0aDs')
      expect(tc_doc["contractVariationId"].to_i).to eq(1000134)
      expect(tc_doc["variationTypeDescription"]).to eq("Minimum Leg")
    end

    it 'does not gets contract information for an unauthorized external user', :security => true do
      error_response = response_as_json "#{CONTRACTS_V3_URL}/1001809?#{APP_AGENT_PARAM}",
                                        @account_mgmt_oauth.authorized_oauth_header('t.olofson@any.domain.cc', 'abc123ABC')
      error_block = error_response['errors'][0]
      expect(error_block["code"].to_i).to eq(403)
      expect(error_block["description"]).to eq ("AccountViewer access to account 1001037 was denied")

    end

=begin
    it 'gets the contract with variations for an authorized external user', :security => true do
      tc_doc = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/1002503?#{APP_AGENT_PARAM}",
                                @account_mgmt_oauth.authorized_oauth_header('crossroads', 'cr0ssR0aDs')
      puts tc_doc
    end
=end

  end
end