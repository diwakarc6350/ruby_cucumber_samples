require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/contracts_for_checks'

=begin
  In this rspec we make sure the number of contracts we get for an account is correct.
  We gather some sample test data by making a query to IJET get the top 10 records and
  bottom few records and compare if the count of contract returned by the service is right.
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
      nja_accounts = $Ijet_con.connection.execute(get_accounts_sql)
      $all_nja_account_ids = nja_accounts[((nja_accounts.length/2).to_i)..((nja_accounts.length/2).to_i + 5)]
    end

    it 'gets the correct number of contracts for an account' do
      account_ids = $all_nja_account_ids
      #expect(account_ids).to have_at_least(1).items
      account_ids.each do |account_id|
        tc_doc = response_as_json "#{CONTRACTS_V3_URL}?#{APP_AGENT_PARAM}&accountId=#{account_id["acct_id"].to_i}", @account_mgmt_oauth.authorized_oauth_header
        expect(tc_doc.length).to eq(account_id["cnt"].to_i)
      end
    end

  end
end