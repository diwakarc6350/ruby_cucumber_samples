require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'date'
require 'data/contract_hours'

=begin
  In this test we will make sure that the contract start and end dates are correct
  And the Current Period start and end dates are correct.
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"

      last_year = Date.today.year - 1
      @end_of_last_year = '31-DEC' + last_year.to_s

      this_year = Date.today.year
      @end_of_this_year = '31-DEC' + this_year.to_s

      @today = Date.today.strftime("%d-%^b-%Y")
    end

    describe 'contract start date and end date' do
      context 'when contract start date and end date is present in ijet' do
        it 'gets the startDate and endDate for a contract' do
          contract = $Ijet_con.connection.execute(' select contract_id, contract_start_dat, contract_end_dat
                                                    from contract where rownum <=1
                                                    order by contract_end_dat')
          contract_id = contract[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(contract[0]["contract_start_dat"].to_datetime).to eq(tc_doc["startDate"].to_datetime)
          expect(contract[0]["contract_end_dat"].to_datetime).to eq(tc_doc["endDate"].to_datetime)
        end
      end

      context 'when contract start date and end date is null in ijet' do
        it 'sets the startDate and endDate for a contract to null in response' do
          contract = $Ijet_con.connection.execute(contract_start_n_end_date_null)
          contract_id = contract[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc["startDate"]).to be_nil
          expect(tc_doc["endDate"]).to be_nil
        end
      end
    end

    describe 'contract extended term start date and end date' do
      context 'when contract extended term start date and end date is present in ijet' do
        it 'gets the extendedTermStartDate and extendedTermEndDate for a contract' do
          contract = $Ijet_con.connection.execute(contract_extended_start_end_date)
          contract_id = contract[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc.has_key?('extendedTermStartDate')).to be true
          expect(contract[0]["extended_term_start"].to_datetime).to eq(tc_doc["extendedTermStartDate"].to_datetime)
          expect(contract[0]["extended_term_end"].to_datetime).to eq(tc_doc["extendedTermEndDate"].to_datetime)
        end
      end

      context 'when contract extended term start date and end date is null in ijet' do
        it 'does not display the extendedTermStartDate and extendedTermEndDate for a contract in the response' do
          contract = $Ijet_con.connection.execute(contract_extended_start_end_date_null)
          contract_id = contract[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc.has_key?('extendedTermStartDate')).to be false
          expect(tc_doc.has_key?('extendedTermEndDate')).to be false
        end
      end
    end

    describe 'contract delayed start date' do
      context 'when delay start date is present in ijet' do
        it 'gets the delayedStartDate for a contract' do
          contract = $Ijet_con.connection.execute(contract_delayed_start)
          contract_id = contract[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc.has_key?('delayedStartDate')).to be true
          expect(tc_doc["delayedStartDate"].to_datetime).to eq(contract[0]["delayed_start"].to_datetime)
        end
      end

      context 'when delay start date is present is null in ijet' do
        it 'does not display the delayedStartDate for a contract in the response' do
          contract = $Ijet_con.connection.execute(contract_delayed_start_null)
          contract_id = contract[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc.has_key?('delayedStartDate')).to be false
        end
      end
    end

    describe 'contract current period start date and end date' do

      it 'gets first activity if contracts activities are in future' do
        contract = $Ijet_con.connection.execute(contract_future_activity(@end_of_this_year))
        contract_id = contract[0]["contract_id"].to_i
        tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
        expect(tc_doc.has_key?('currentPeriodStartDate')).to be true
        expect(tc_doc.has_key?('currentPeriodEndDate')).to be true
        expect(tc_doc['currentPeriodStartDate'].to_datetime).to eq(contract[contract.length-1]['activity_start_dat'].to_datetime)
        expect(tc_doc['currentPeriodEndDate'].to_datetime).to eq(contract[contract.length-1]['activity_end_dat'].to_datetime)
      end

      it 'gets last activity if contracts activities are in past' do
        contract = $Ijet_con.connection.execute(contract_past_activity(@end_of_last_year))
        contract_id = contract[0]["contract_id"].to_i
        tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
        expect(tc_doc.has_key?('currentPeriodStartDate')).to be true
        expect(tc_doc.has_key?('currentPeriodEndDate')).to be true
        expect(tc_doc['currentPeriodStartDate'].to_datetime).to eq(contract[contract.length-1]['activity_start_dat'].to_datetime)
        expect(tc_doc['currentPeriodEndDate'].to_datetime).to eq(contract[contract.length-1]['activity_end_dat'].to_datetime)
      end

      it 'gets activity that matches the current year' do
        contracts = $Ijet_con.connection.execute(contract_current_activity(@today))
        contract = contracts.select { |x| x['activity_end_dat'].to_datetime > @today && x['activity_start_dat'].to_datetime < @today }[0]
        contract_id = contract["contract_id"].to_i
        tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
        expect(tc_doc.has_key?('currentPeriodStartDate')).to be true
        expect(tc_doc.has_key?('currentPeriodEndDate')).to be true
        expect(tc_doc['currentPeriodStartDate'].to_datetime).to eq(contract['activity_start_dat'].to_datetime)
        expect(tc_doc['currentPeriodEndDate'].to_datetime).to eq(contract['activity_end_dat'].to_datetime)
      end
    end
  end

end