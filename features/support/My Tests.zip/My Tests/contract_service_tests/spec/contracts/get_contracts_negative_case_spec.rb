require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'

=begin
  In this rspec test suite we basically validate if the service generates
  appropriate error messages when invalid inputs are sent as part of request.
  We do the validation be send invalid contract or account ids in the request.
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    it 'gets HTTP 400 error when account_id is a negative number' do
      tc_doc = response_as_json("#{CONTRACTS_V3_URL}?#{APP_AGENT_PARAM}&accountId=#{$all_invalid_account_ids[0]}", @account_mgmt_oauth.authorized_oauth_header)
      error_response =  tc_doc['errors'][0]
      expect(error_response["code"].to_i).to eq(400)
      expect(error_response["description"]).to include("not a valid account id")
    end

    it 'gets HTTP 400 error when account_id is zero' do
      tc_doc = response_as_json("#{CONTRACTS_V3_URL}?#{APP_AGENT_PARAM}&accountId=#{$all_invalid_account_ids[1]}", @account_mgmt_oauth.authorized_oauth_header)
      error_response =  tc_doc['errors'][0]
      expect(error_response["code"].to_i).to eq(400)
      expect(error_response["description"]).to include("not a valid account id")
    end

    it 'gets HTTP 400 error when account_id is invalid' do
      tc_doc = response_as_json("#{CONTRACTS_V3_URL}?#{APP_AGENT_PARAM}&accountId=#{$all_invalid_account_ids[2]}", @account_mgmt_oauth.authorized_oauth_header)
      error_response =  tc_doc['errors'][0]
      expect(error_response["code"].to_i).to eq(400)
      expect(error_response["description"]).to include("not a valid account id")
    end

    it 'gets HTTP 400 error when account_id is empty' do
      tc_doc = response_as_json("#{CONTRACTS_V3_URL}?#{APP_AGENT_PARAM}&accountId=#{$all_invalid_account_ids[3]}", @account_mgmt_oauth.authorized_oauth_header)
      error_response =  tc_doc['errors'][0]
      expect(error_response["code"].to_i).to eq(400)
      expect(error_response["description"]).to include("Must have either account id or contract id")
    end


    it 'gets HTTP 400 error when account_id has invalid characters' do
      tc_doc = response_as_json("#{CONTRACTS_V3_URL}?#{APP_AGENT_PARAM}&accountId=#{$all_invalid_account_ids[4]}",@account_mgmt_oauth.authorized_oauth_header)
      error_response =  tc_doc['errors'][0]
      expect(error_response["code"].to_i).to eq(400)
      expect(error_response["description"]).to include("not a valid account id")
    end

    it 'gets HTTP 400 error when given contract_id is a negative number ' do
      tc_doc = response_as_json("#{CONTRACTS_V3_URL}/#{$invalid_contract_ids[0]}?#{APP_AGENT_PARAM}&includes=peakDates", @account_mgmt_oauth.authorized_oauth_header)
      error_response =  tc_doc['errors'][0]
      expect(error_response["code"].to_i).to eq(400)
      expect(error_response["description"]).to include("not a valid contract id")
    end

    it 'gets HTTP 400 error when given contract_id is zero ' do
      tc_doc = response_as_json("#{CONTRACTS_V3_URL}/#{$invalid_contract_ids[1]}?#{APP_AGENT_PARAM}&includes=peakDates", @account_mgmt_oauth.authorized_oauth_header)
      error_response =  tc_doc['errors'][0]
      expect(error_response["code"].to_i).to eq(400)
      expect(error_response["description"]).to include("not a valid contract id")
    end

    it 'gets HTTP 400 error when given contract_id is invalid ' do
      tc_doc = response_as_json("#{CONTRACTS_V3_URL}/#{$invalid_contract_ids[2]}?#{APP_AGENT_PARAM}&includes=peakDates", @account_mgmt_oauth.authorized_oauth_header)
      error_response =  tc_doc['errors'][0]
      expect(error_response["code"].to_i).to eq(400)
      expect(error_response["description"]).to include("is not a valid contract id")
    end

    it 'gets HTTP 400 error when given contract_id is empty' do
      tc_doc = response_as_json("#{CONTRACTS_V3_URL}/#{$invalid_contract_ids[3]}?#{APP_AGENT_PARAM}&includes=peakDates", @account_mgmt_oauth.authorized_oauth_header)
      error_response =  tc_doc['errors'][0]
      expect(error_response["code"].to_i).to eq(400)
      expect(error_response["description"]).to include("Must have either account id or contract id")
    end

    it 'gets HTTP 400 error when given contract_id has invalid characters ' do
      tc_doc = response_as_json("#{CONTRACTS_V3_URL}/#{$invalid_contract_ids[4]}?#{APP_AGENT_PARAM}&includes=peakDates", @account_mgmt_oauth.authorized_oauth_header)
      error_response =  tc_doc['errors'][0]
      expect(error_response["code"].to_i).to eq(400)
      expect(error_response["description"]).to include("not a valid contract id")
    end
  end
end