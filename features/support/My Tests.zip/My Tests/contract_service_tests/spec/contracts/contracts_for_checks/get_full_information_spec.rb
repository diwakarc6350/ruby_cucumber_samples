require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/contracts_for_checks'
require 'data/contract_variations'
require 'date'

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @oauth = @account_mgmt_oauth.authorized_oauth_header
      #@oauth_var = @account_mgmt_oauth.authorized_oauth_header(force_user='TQAtest1')
      @all_contracts = $Ijet_con.connection.execute(legs_for_contracts_sql)
      @resource = CONTRACT_FOR_CHECKS_V3_URL
    end

    describe 'contracts for checks full information' do

      it 'gets the account name' do
        chosen_contract = @all_contracts[rand(@all_contracts.length)]
        contract_id = chosen_contract['contract_id'].to_i
        leg_id = chosen_contract['leg_id'].to_i
        responses = response_as_json @resource + "/#{contract_id}?#{APP_AGENT_PARAM}&legId=#{leg_id}", @oauth
        expect(responses['accountName']).to eq(chosen_contract['account_name'])
      end

      it 'gets the guaranteed aircraft' do
        contracts = @all_contracts
        chosen_contract = contracts[rand(contracts.length)]
        contract_id = chosen_contract['contract_id'].to_i
        leg_id = chosen_contract['leg_id'].to_i
        responses = response_as_json @resource + "/#{contract_id}?#{APP_AGENT_PARAM}&legId=#{leg_id}", @oauth
        expect(responses['guaranteedAircraft']).to eq(chosen_contract['aircraft_type_name'])
      end

      it 'gets aircraft per day for a contract' do
        contracts = @all_contracts
        chosen_contract = contracts[rand(contracts.length)]
        contract_id = chosen_contract['contract_id'].to_i
        leg_id = chosen_contract['leg_id'].to_i
        aircraft_per_day = $Ijet_con.connection.execute(get_aircraft_per_day_contract_sql(contract_id))[0]
        if aircraft_per_day != nil
          expected_aircraft_per_day = aircraft_per_day['aircraft_per_day'].to_i
        else
          expected_aircraft_per_day = 0
        end
        responses = response_as_json @resource + "/#{contract_id}?#{APP_AGENT_PARAM}&legId=#{leg_id}", @oauth
        expect(responses['aircraftPerDay']).to eq(expected_aircraft_per_day)
      end

      it 'gets the operational and account variations for a contract' do
        contracts = @all_contracts
        chosen_contract = contracts[rand(contracts.length)]
        contract_id = chosen_contract['contract_id'].to_i
        leg_id = chosen_contract['leg_id'].to_i
        checks_responses = response_as_json @resource + "/#{contract_id}?#{APP_AGENT_PARAM}&legId=#{leg_id}", @oauth
        if checks_responses.has_key?('variations')
          variations = checks_responses['variations'].map { |var| var['variationGroup'] }
          expect(variations).to include('account' || 'operational')
        end
      end

      it 'does not get the contractual and billing variations for a contract' do
        contracts = @all_contracts
        chosen_contract = contracts[rand(contracts.length)]
        contract_id = chosen_contract['contract_id'].to_i
        leg_id = chosen_contract['leg_id'].to_i
        checks_responses = response_as_json @resource + "/#{contract_id}?#{APP_AGENT_PARAM}&legId=#{leg_id}", @oauth
        if checks_responses.has_key?('variations')
          variations = checks_responses['variations'].map { |var| var['variationGroup'] }
          expect(variations).not_to include('contractual' || 'billing')
        end
      end

      it 'get the contract variation information' do
        contracts = @all_contracts
        chosen_contract = contracts[rand(contracts.length)]
        contract_id = chosen_contract['contract_id'].to_i
        leg_id = chosen_contract['leg_id'].to_i
        checks_responses = response_as_json @resource + "/#{contract_id}?#{APP_AGENT_PARAM}&legId=#{leg_id}", @oauth
        if checks_responses.has_key?('variations')
          variations = checks_responses['variations']
          variations.each do |variation|
            contract_variation_id = variation['contractVariationId'].to_i
            expected_variation = $Ijet_con.connection.execute(get_by_variation_id_sql(contract_variation_id))[0]
            expect(variation['contractVariationId']).to eq(expected_variation['contract_var_id'].to_i)
            expect(variation['description']).to eq(expected_variation['descr'])
            expect(variation['variationTypeId']).to eq(expected_variation['contract_var_type_id'].to_i)
          end
        end
      end

      it 'gets response time' do
        contracts = @all_contracts
        chosen_contract = contracts[rand(contracts.length)]
        contract_id = chosen_contract['contract_id'].to_i
        leg_id = chosen_contract['leg_id'].to_i
        airport_id = chosen_contract['dep_airport_id']
        responses = response_as_json @resource + "/#{contract_id}?#{APP_AGENT_PARAM}&legId=#{leg_id}", @oauth
        expected_response_times = $Ijet_con.connection.execute(get_response_times_sql(contract_id, airport_id))

        if expected_response_times.length > 0
          expect(responses['responseTime']['responseHours']).to eq(expected_response_times[0]['resp_hrs'].to_i)
          expect(responses['responseTime']['peakResponseHours']).to eq(expected_response_times[0]['peak_day_resp_hrs'].to_i)
        else
          expect(responses.has_key?('responseTime')).to eq(false)
        end
      end

      it 'gets the asOfDate' do
        contracts = @all_contracts
        chosen_contract = contracts[rand(contracts.length)]
        contract_id = chosen_contract['contract_id'].to_i
        leg_id = chosen_contract['leg_id'].to_i
        expected_as_of_date = chosen_contract['etd_tm'].to_datetime.strftime("%Y-%m-%dT%H:%M:%SZ")
        responses = response_as_json @resource + "/#{contract_id}?#{APP_AGENT_PARAM}&legId=#{leg_id}", @oauth
        expect(responses['hoursRemaining']['asOfDate']).to eq(expected_as_of_date)
      end

      it 'gets the projected hours information non zero' do
        contracts = @all_contracts.select { |rec| rec['contract_rem_hrs']!=nil }
        chosen_contract = contracts[rand(contracts.length)]
        contract_id = chosen_contract['contract_id'].to_i
        leg_id = chosen_contract['leg_id'].to_i
        expected_projected_hours = chosen_contract['contract_rem_hrs'].to_f
        responses = response_as_json @resource + "/#{contract_id}?#{APP_AGENT_PARAM}&legId=#{leg_id}",
                                     @oauth
        expect(responses['hoursRemaining']['projectedRemainingHours']).to eq(expected_projected_hours)
      end

      it 'gets the projected hours information as zero' do
        contracts = @all_contracts.select { |rec| rec['contract_rem_hrs']==nil }
        chosen_contract = contracts[rand(contracts.length)]
        contract_id = chosen_contract['contract_id'].to_i
        leg_id = chosen_contract['leg_id'].to_i
        expected_projected_hours = 0.0
        responses = response_as_json @resource + "/#{contract_id}?#{APP_AGENT_PARAM}&legId=#{leg_id}&airportId=KCMH", @oauth
        expect(responses['hoursRemaining']['projectedRemainingHours']).to eq(expected_projected_hours)
      end

      it 'gets the hours information for NJE contracts' do
        if environment.to_s=='itg2' or environment.to_s=='ci' or environment.to_s=='local'
          log.info("This test will not be run in ITG2. Should be refactored to dynamically pick up data!")
        else
          nje_contracts = [['1349744', '8050049'], [1408685, 8174295]]
          nje_contracts.each do |contract_info|
            contract_id = contract_info[0]
            leg_id = contract_info[1]
            hours_info = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",
                                          @account_mgmt_oauth.authorized_oauth_header
            response = response_as_json @resource + "/#{contract_id}?#{APP_AGENT_PARAM}&legId=#{leg_id}", @oauth
            expect(response['hoursRemaining']['projectedRemainingHours'].to_f).to eq(hours_info['projectedRemainingHours'].to_f)
          end
        end
      end

      it 'raises error when leg is null' do
        contracts = @all_contracts
        chosen_contract = contracts[rand(contracts.length)]
        contract_id = chosen_contract['contract_id'].to_i
        error_response = response_as_json @resource + "/#{contract_id}?#{APP_AGENT_PARAM}&legId=", @oauth
        expect(error_response['errors'][0]["code"].to_i).to eq(422)
        expect(error_response['errors'][0]["description"]).to include("Param legId value cannot be null")
      end

      it 'raises error when leg is non-existent' do
        contracts = @all_contracts
        chosen_contract = contracts[rand(contracts.length)]
        contract_id = chosen_contract['contract_id'].to_i
        error_response = response_as_json @resource + "/#{contract_id}?#{APP_AGENT_PARAM}&legId=9999999999", @oauth
        expect(error_response['errors'][0]["code"].to_i).to eq(404)
        expect(error_response['errors'][0]["description"]).to include("Param legId value 9,999,999,999 "+
                                                                          "does not reference a valid leg")
      end

      it 'raises error when leg is invalid' do
        contracts = @all_contracts
        chosen_contract = contracts[rand(contracts.length)]
        contract_id = chosen_contract['contract_id'].to_i
        error_response = response_as_json @resource + "/#{contract_id}?#{APP_AGENT_PARAM}&legId=blah", @oauth
        expect(error_response['errors'][0]["code"].to_i).to eq(422)
        expect(error_response['errors'][0]["description"]).to include("Property legId must be a valid number")
      end

      it 'raises error when contract is null' do
        error_response = response_as_json @resource + "/?#{APP_AGENT_PARAM}&legId=1234567", @oauth
        expect(error_response['errors'][0]["code"].to_i).to eq(422)
        expect(error_response['errors'][0]["description"]).to include("Param contractId value cannot be null")
      end

      it 'raises error when contract is non-existent' do
        error_response = response_as_json @resource + "/999999999999?#{APP_AGENT_PARAM}&legId=1234567", @oauth
        expect(error_response['errors'][0]["code"].to_i).to eq(422)
        expect(error_response['errors'][0]["description"]).to include("Param contractId value must not " +
                                                                          "be greater than 9,999,999,999")
      end

      it 'raises error when contract is invalid' do
        error_response = response_as_json @resource + "/invalid?#{APP_AGENT_PARAM}&legId=1234567", @oauth
        expect(error_response['errors'][0]["code"].to_i).to eq(422)
        expect(error_response['errors'][0]["description"]).to include("must be a valid number")
      end

    end
  end
end