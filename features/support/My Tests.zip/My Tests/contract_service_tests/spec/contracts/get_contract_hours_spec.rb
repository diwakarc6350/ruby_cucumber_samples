require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'date'
require 'data/contract_hours'

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @today = Date.today.strftime("%Y-%m-%d")
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'contract hours information (initial, used, remaining)' do
      $contract_ids_by_contract_types.each do |contract|
        it "gets the contract initial, used and remaining hours for #{contract[0]['contract_type']}" do
          contract_id = contract[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expected_hours = $Ijet_con.connection.execute(get_hours_info_sql(contract_id))
          if expected_hours.length > 0
            expect(tc_doc['initialHours'].to_f).to eq(expected_hours[0]['tot_avail_hrs'].to_f)
            expect(tc_doc['usedHours'].to_f).to eq(expected_hours[0]['used_hrs'].to_f)
            expect(tc_doc['actualRemainingHours'].to_f).to eq(expected_hours[0]['rem_avail_hrs'].to_f)
          else
            log.info "No test data found"
          end
        end
      end
    end

    it 'get the projected remaining hours for card contract (with no invoice activity)' do
      card_contracts = [1352484]
      chosen_contract_id = card_contracts[rand(card_contracts.length)]
      tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{chosen_contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
      expected_projected_hours = $Ijet_con.connection.execute(get_current_card_contract_hrs(chosen_contract_id))[0]
      expect(tc_doc['projectedRemainingHours'].to_f).to eq(expected_projected_hours['rem_avail_hrs'].to_f)
      expect(tc_doc['actualRemainingHours'].to_f).to eq(expected_projected_hours['projectedRemainingHours'].to_f)
    end

=begin
    it 'get the projected remaining hours for card contract (with invoice activity) negative remaining' do
      if environment.to_s=='itg2' or environment.to_s=='ci' or  environment.to_s=='local'
        log.info("This test will not be run in ITG2. Should be refactored to dynamically pick up data!")
      else
        card_contracts = [1403415]
        chosen_contract_id = card_contracts[rand(card_contracts.length)]
        tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{chosen_contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
        expected_projected_hours = $Ijet_con.connection.execute(get_card_projected_hours_info_sql(chosen_contract_id, @today))
        expect(tc_doc['projectedRemainingHours'].to_f).to eq(expected_projected_hours[0]['contract_rem_hrs'].to_f)
      end
    end
=end

    it 'get the projected remaining hours for card contract (with invoice activity) positive remaining' do
      if environment.to_s=='itg2' or environment.to_s=='ci' or  environment.to_s=='local'
        log.info("This test will not be run in ITG2. Should be refactored to dynamically pick up data!")
      else
        card_contracts = [1408727]
        chosen_contract_id = card_contracts[rand(card_contracts.length)]
        tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{chosen_contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
        expected_projected_hours = $Ijet_con.connection.execute(get_card_projected_hours_info_sql(chosen_contract_id, @today))
        expect(tc_doc['projectedRemainingHours'].to_f).to eq(expected_projected_hours[0]['contract_rem_hrs'].to_f)
      end
    end

    it 'get the projected remaining hours for non card contract (with future invoice activity)' do
      if environment.to_s=='itg2' or environment.to_s=='ci' or  environment.to_s=='local'
        log.info("This test will not be run in ITG2. Should be refactored to dynamically pick up data!")
      else
        non_card_contracts = [1411882] #[1390434, 1348184, 1399488, 1411882]
        chosen_contract_id = non_card_contracts[rand(non_card_contracts.length)]
        tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{chosen_contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
        contract_start_date = Date.new(tc_doc['currentPeriodStartDate'].to_date.year,
                                       tc_doc['currentPeriodStartDate'].to_date.month,
                                       tc_doc['currentPeriodStartDate'].to_date.day)
        start_date = Date.new(tc_doc['currentPeriodStartDate'].to_date.year, tc_doc['currentPeriodStartDate'].to_date.month, 1)
        end_date = Date.new(tc_doc['currentPeriodEndDate'].to_date.year, tc_doc['currentPeriodEndDate'].to_date.month, 1)
        expected_projected_hours = $Ijet_con.connection.execute(
            get_non_card_projected_hours_info_sql(chosen_contract_id, contract_start_date, start_date, end_date))[0]
        expect(tc_doc['projectedRemainingHours']).to eq(expected_projected_hours['contract_rem_hrs'].to_f)
      end
    end

    it 'gets current period allotted, available, excess billed hours and year number for future activities' do
      this_year = Date.today.year
      end_of_this_year = '31-DEC-' + this_year.to_s
      contract = $Ijet_con.connection.execute(contract_future_activity(end_of_this_year))[0]
      contract_id = contract["contract_id"].to_i
      tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
      self.compare_response(tc_doc, contract)
    end

    it 'gets current period allotted, available, excess billed hours and year number  for past activities' do
      last_year = Date.today.year - 1
      end_of_last_year = '31-DEC-' + last_year.to_s
      contracts = $Ijet_con.connection.execute(contract_past_activity(end_of_last_year))
      contract = contracts[contracts.length-1]
      contract_id = contract["contract_id"].to_i
      tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
      self.compare_response(tc_doc, contract)
    end

    it 'gets current period allotted, available, excess billed hours and year number for current activities' do
      today = Date.today.strftime("%d-%^b-%Y")
      contracts = $Ijet_con.connection.execute(contract_current_activity(today))
      contract = contracts.select { |x| x['activity_end_dat'] > @today && x['activity_start_dat'] < @today }
      if contract.length > 1
        contract_id = contract["contract_id"].to_i
        tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
        self.compare_response(tc_doc, contract)
      else
        log.info "Cannot find data to test."
      end
    end

    it 'gets cardHours for a card contract' do
      this_year = Date.today.year
      end_of_this_year = '31-DEC-' + this_year.to_s
      contract = $Ijet_con.connection.execute(card_contract_current_activity(end_of_this_year))[0]
      contract_id = contract["contract_id"].to_i
      tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
      self.compare_response(tc_doc, contract)
      expect(tc_doc.has_key?('cardHours')).to be true
      expect(tc_doc['cardHours'].to_f).to eq(contract['allotted_hrs'].to_f)
    end

    it 'does not get cardHours for a non-card contract' do
      this_year = Date.today.year
      end_of_this_year = '31-DEC-' + this_year.to_s
      contract = $Ijet_con.connection.execute(non_card_contract_activity(end_of_this_year))[0]
      contract_id = contract["contract_id"].to_i
      tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
      expect(tc_doc.has_key?('cardHours')).to be false
    end

    def compare_response(tc_doc, contract)
      expect(tc_doc.has_key?('currentPeriodAllotedHours')).to be true
      expect(tc_doc.has_key?('currentPeriodAvailableHours')).to be true
      expect(tc_doc.has_key?('currentPeriodExcessBilledHours')).to be true
      expect(tc_doc.has_key?('currentPeriodYearNumber')).to be true
      expect(tc_doc['currentPeriodAllotedHours'].to_f).to eq(contract['rem_allotted_hrs'].to_f)
      expect(tc_doc['currentPeriodAvailableHours'].to_f).to eq(contract['rem_avail_hrs'].to_f)
      expect(tc_doc['currentPeriodExcessBilledHours'].to_f).to eq(contract['excs_hrs_billed'].to_f)
      expect(tc_doc['currentPeriodYearNumber'].to_f).to eq(contract['contract_year_nbr'].to_f)
    end

    def get_hours_info_sql(id)
      # sql to get a operational variation, but other variations are not present
      <<-SQL.gsub(/^ {6}/, '')
        select addl_hrs, allotted_hrs, used_hrs, tot_allotted_hrs, tot_avail_hrs, rem_allotted_hrs, rem_avail_hrs, activity_start_dat, activity_end_dat
        from contract_hrs where contract_id = #{id}
        order by activity_start_dat desc
      SQL
    end

    def get_card_projected_hours_info_sql(id, as_of_date)
      <<-SQL.gsub(/^ {6}/, '')
         select lc.contract_rem_hrs as contract_rem_hrs,
         nai.billing_cycle_ts as billing_cycle_ts,
         ch.ACTIVITY_START_DAT as asd, ch.ACTIVITY_END_DAT as aed from leg leg
         left outer join leg_contract_charges lc
         on leg.LEGID=lc.leg_id
         left outer join netjets_activity_invoice nai
         on lc.netjets_activity_invoice_id=nai.invoice_id
         left outer join contract_detail c
         on nai.contract_id=c.CONTRACT_ID
         left outer join CONTRACT_HRS ch
         on c.CONTRACT_ID=ch.CONTRACT_ID
         where ch.CONTRACT_ID=#{id} and (nai.invoice_status_cd in (1 , 2))
         and (lc.contract_rem_hrs is not null)
         --and nai.billing_cycle_ts<=  to_date('#{as_of_date}','yyyy-mm-dd')
         order by nai.billing_cycle_ts desc, leg.etd_tm desc
      SQL
    end

    def get_non_card_projected_hours_info_sql(id, as_of_date, currentStartDate, currentEndDate)
      <<-SQL.gsub(/^ {6}/, '')
        select lc.contract_rem_hrs as contract_rem_hrs,
        nai.billing_cycle_ts as billing_cycle_ts,
        ch.ACTIVITY_START_DAT as asd, ch.ACTIVITY_END_DAT as aed from leg leg
        left outer join leg_contract_charges lc
        on leg.LEGID=lc.leg_id
        left outer join netjets_activity_invoice nai
        on lc.netjets_activity_invoice_id=nai.invoice_id
        left outer join contract_base c
        on nai.contract_id=c.CONTRACT_ID
        left outer join CONTRACT_HRS ch
        on c.CONTRACT_ID=ch.CONTRACT_ID
        where ch.CONTRACT_ID=#{id}   and (nai.invoice_status_cd in (1 , 2))
        and (lc.contract_rem_hrs is not null)
        and leg.etd_tm >  to_date('#{as_of_date}', 'yyyy-mm-dd')
        and nai.billing_cycle_ts>=  to_date('#{currentStartDate}','yyyy-mm-dd')
        and nai.billing_cycle_ts<= to_date('#{currentEndDate}','yyyy-mm-dd')
        order by nai.billing_cycle_ts desc, leg.etd_tm desc
      SQL
    end

    def get_current_card_contract_hrs(id)
      <<-SQL.gsub(/^ {6}/, '')
        select * from contract_hrs where contract_id = #{id}
      SQL
    end

    def get_current_non_card_contract_hrs(id)
      <<-SQL.gsub(/^ {6}/, '')
        select * from contract_hrs where contract_id = #{id}
        and activity_end_dat > SYSDATE and activity_start_dat < SYSDATE
      SQL
    end

  end
end