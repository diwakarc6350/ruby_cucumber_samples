require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require '/data/contract_variations'

=begin
  In this test we make sure the contract variations
  correctly based on the information stored in the IJET2 database
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @oauth = @account_mgmt_oauth.authorized_oauth_header('crossroads','cr0ssR0aDs')
      @variation_types = $Ijet_con.connection.execute(contract_variation_types_sql)
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'variation by variation id' do

      it 'gets the account variation info by for given variation id' do
        account_variations = $Ijet_con.connection.execute(account_var_sql)
        expected_variation = account_variations[rand(account_variations.length)]
        chosen_variation_id = expected_variation['contract_var_id'].to_i
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/#{chosen_variation_id}?#{APP_AGENT_PARAM}", @oauth
        expect(response['contractVariationId']).to eq(expected_variation['contract_var_id'].to_i)
        expect(response['variationGroup']).to eq('account')
        expect(response['description']).to eq(expected_variation['descr'])
        expect(response['variationTypeId']).to eq(expected_variation['contract_var_type_id'].to_i)
        expected_variation = @variation_types.select { |rec| rec['tag']=='AccountContractVariationType' && \
                                                        rec['code'].to_i==response['variationTypeId'] }[0]
        expect(response['variationTypeDescription']).to eq(expected_variation['value'])
      end

      it 'gets the billing variation info by for given variation id' do
        billing_variations = $Ijet_con.connection.execute(billing_var_sql)
        expected_variation = billing_variations[rand(billing_variations.length)]
        chosen_variation_id = expected_variation['contract_var_id'].to_i
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/#{chosen_variation_id}?#{APP_AGENT_PARAM}", @oauth
        expect(response['contractVariationId']).to eq(expected_variation['contract_var_id'].to_i)
        expect(response['variationGroup']).to eq('billing')
        expect(response['description']).to eq(expected_variation['descr'])
        expect(response['variationTypeId']).to eq(expected_variation['contract_var_type_id'].to_i)
        expected_variation = @variation_types.select { |rec| rec['tag']=='BillingContractVariationType' && \
                                                        rec['code'].to_i==response['variationTypeId'] }[0]
        expect(response['variationTypeDescription']).to eq(expected_variation['value'])
      end

      it 'gets the operational variation info by for given variation id' do
        operational_variations = $Ijet_con.connection.execute(operational_var_sql)
        expected_variation = operational_variations[rand(operational_variations.length)]
        chosen_variation_id = expected_variation['contract_var_id'].to_i
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/#{chosen_variation_id}?#{APP_AGENT_PARAM}", @oauth
        expect(response['contractVariationId']).to eq(expected_variation['contract_var_id'].to_i)
        expect(response['variationGroup']).to eq('operational')
        expect(response['description']).to eq(expected_variation['descr'])
        expect(response['variationTypeId']).to eq(expected_variation['contract_var_type_id'].to_i)
        expected_variation = @variation_types.select { |rec| rec['tag']=='OperationalContractVariationType' && \
                                                        rec['code'].to_i==response['variationTypeId'] }[0]
        expect(response['variationTypeDescription']).to eq(expected_variation['value'])
      end

      it 'gets the contractual variation info by for given variation id' do
        billing_variations = $Ijet_con.connection.execute(contractual_var_sql)
        expected_variation = billing_variations[rand(billing_variations.length)]
        chosen_variation_id = expected_variation['contract_var_id'].to_i
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/#{chosen_variation_id}?#{APP_AGENT_PARAM}", @oauth
        expect(response['contractVariationId']).to eq(expected_variation['contract_var_id'].to_i)
        expect(response['variationGroup']).to eq('contractual')
        expect(response['description']).to eq(expected_variation['descr'])
        expect(response['variationTypeId']).to eq(expected_variation['contract_var_type_id'].to_i)
        expected_variation = @variation_types.select { |rec| rec['tag']=='ContractualVariationType' && \
                                                        rec['code'].to_i==response['variationTypeId'] }[0]
        expect(response['variationTypeDescription']).to eq(expected_variation['value'])

      end

      it 'gets 404 for invalid contract variation id' do
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/9?#{APP_AGENT_PARAM}", @oauth
        expect(response['errors'][0]['code']).to eq(404)
        expect(response['errors'][0]['description']).to eq("Param id value 9 does not reference a valid contract variation")
      end

      it 'gets 422 for negative contract variation id' do
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/-9?#{APP_AGENT_PARAM}",@oauth
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq("Param id value must not be less than 1")
      end

      it 'gets 422 for when contract variation id is zero' do
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/0?#{APP_AGENT_PARAM}",@oauth
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq("Param id value must not be less than 1")
      end

      it 'gets 422 for when contract variation id is non-numeric' do
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/xye@()?#{APP_AGENT_PARAM}", @oauth
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq("Param id value must be a valid number")
      end
    end
  end
end