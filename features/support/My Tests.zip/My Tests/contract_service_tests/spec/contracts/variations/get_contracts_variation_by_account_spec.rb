require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require '/data/contract_variations'

=begin
  In this test we make sure the contract variations
  correctly based on the information stored in the IJET2 database
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @oauth = @account_mgmt_oauth.authorized_oauth_header('crossroads','cr0ssR0aDs')
      @account_variations = $Ijet_con.connection.execute(get_accounts_id_by_count_sql)
      @variation_types = $Ijet_con.connection.execute(contract_variation_types_sql)
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'variations by account id' do
      it 'gets the variations by account id' do
        account_id = @account_variations[rand(@account_variations.length)]['account_id'].to_i
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/?accountId=#{account_id}&#{APP_AGENT_PARAM}",
                                    @oauth
        account_variations = $Ijet_con.connection.execute(account_var_by_id_sql(account_id))
        expect(response.length).to eq(account_variations.length)
        i=0
        response.each do |variation|
          expect(variation['contractVariationId']).to eq(account_variations[i]['contract_var_id'].to_i)
          expect(variation['description']).to eq(account_variations[i]['descr'])
          expect(variation['variationGroup']).to eq('account')
          expect(variation['variationTypeId']).to eq(account_variations[i]['contract_var_type_id'].to_i)
          expected_variation_description = @variation_types.select {
              |rec| rec['tag']=='AccountContractVariationType' && \
               rec['code'].to_i==variation['variationTypeId'] }[0]
          expect(variation['variationTypeDescription']).to eq(expected_variation_description['value'])
          i=i+1
        end
      end

      it 'gets 404 for invalid account variation id' do
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/?accountId=9&#{APP_AGENT_PARAM}", @oauth
        expect(response['errors'][0]['code']).to eq(404)
        expect(response['errors'][0]['description']).to eq("Param accountId value 9 does not reference a valid account")
      end

      it 'gets 422 for negative account variation id' do
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/?accountId=-9&#{APP_AGENT_PARAM}", @oauth
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq("Param accountId value must not be less than 1")
      end

      it 'gets 422 for when account variation id is zero' do
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/?accountId=0&#{APP_AGENT_PARAM}", @oauth
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq("Param accountId value must not be less than 1")
      end

      it 'gets 422 for when account variation id is non-numeric' do
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/?accountId=xye@()&#{APP_AGENT_PARAM}", @oauth
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include("must be a valid number")
      end

    end
  end
end