require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require '/data/contract_variations'

=begin
  In this test we make sure the contract variations
  correctly based on the information stored in the IJET2 database
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @oauth = @account_mgmt_oauth.authorized_oauth_header('crossroads','cr0ssR0aDs')
      @variations = $Ijet_con.connection.execute(get_variations_sql)
      @variation_types = $Ijet_con.connection.execute(contract_variation_types_sql)
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'variations by contract' do
      it 'gets the variations by contract id' do
        #1016284,1008463
        #contract_id = @variations[rand(@variations.length)]['contract_id'].to_i
        contract_id =1008463
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/?contractId=#{contract_id}&#{APP_AGENT_PARAM}",
                                    @oauth
        variations = $Ijet_con.connection.execute(get_contract_variations_sql(contract_id))
        expect(response.length).to eq(variations.length)
        i=0
        response.each do |variation|
          expect(variation['contractVariationId']).to eq(variations[i]['contract_var_id'].to_i)
          expect(variation['description'].strip_control_and_extended_characters)
          .to eq(variations[i]['descr'].strip_control_and_extended_characters)
          expect(variation['variationTypeId']).to eq(variations[i]['contract_var_type_id'].to_i)
          if variations[i]['billing_contract_id'] != nil
            expect(variation['variationGroup']).to eq('billing')
            expected_variation_description = @variation_types.select {
                |rec| rec['tag']=='BillingContractVariationType' && \
               rec['code'].to_i==variation['variationTypeId'] }[0]
            expect(variation['variationTypeDescription']).to eq(expected_variation_description['value'])
          elsif variations[i]['operational_contract_id'] != nil
            expect(variation['variationGroup']).to eq('operational')
            expected_variation_description = @variation_types.select {
                |rec| rec['tag']=='OperationalContractVariationType' && \
               rec['code'].to_i==variation['variationTypeId'] }[0]
            expect(variation['variationTypeDescription']).to eq(expected_variation_description['value'])
          elsif variations[i]['contractual_contract_id'] != nil
            expect(variation['variationGroup']).to eq('contractual')
            expected_variation_description = @variation_types.select {
                |rec| rec['tag']=='ContractualVariationType' && \
               rec['code'].to_i==variation['variationTypeId'] }[0]
            expect(variation['variationTypeDescription']).to eq(expected_variation_description['value'])
          end
          i=i+1
        end
      end

      it 'gets only billing variations when variationGroups=billing' do
        contract_id = @variations[rand(@variations.length)]['contract_id'].to_i
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/?contractId=#{contract_id}&variationGroups=billing&#{APP_AGENT_PARAM}",
                                    @oauth
        response.each do |variation|
          expect(variation['variationGroup']).to eq('billing')
        end
      end

      it 'gets only contractual variations when variationGroups=contractual' do
        contract_id = @variations[rand(@variations.length)]['contract_id'].to_i
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/?contractId=#{contract_id}&variationGroups=contractual&#{APP_AGENT_PARAM}",
                                    @oauth
        response.each do |variation|
          expect(variation['variationGroup']).to eq('contractual')
        end
      end

      it 'gets only operational variations when variationGroups=operational' do
        contract_id = @variations[rand(@variations.length)]['contract_id'].to_i
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/?contractId=#{contract_id}&variationGroups=operational&#{APP_AGENT_PARAM}",
                                    @oauth
        response.each do |variation|
          expect(variation['variationGroup']).to eq('operational')
        end
      end

      it 'does not get contractual variations when variationGroups=operational and billing' do
        contract_id = @variations[rand(@variations.length)]['contract_id'].to_i
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/?contractId=#{contract_id}&variationGroups=operational&variationGroups=billing&#{APP_AGENT_PARAM}",
                                    @oauth
        response.each do |variation|
          expect(variation['variationGroup']).not_to eq('contractual')
        end
      end

      it 'does not get operational variations when variationGroups=contractual and billing' do
        contract_id = @variations[rand(@variations.length)]['contract_id'].to_i
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/?contractId=#{contract_id}&variationGroups=contractual&variationGroups=billing&#{APP_AGENT_PARAM}",
                                    @oauth
        response.each do |variation|
          expect(variation['variationGroup']).not_to eq('operational')
        end
      end

      it 'gets 404 for invalid contract variation id' do
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/?contractId=9&#{APP_AGENT_PARAM}",
                                    @oauth
        expect(response['errors'][0]['code']).to eq(404)
        expect(response['errors'][0]['description']).to eq("Param contractId value 9 does not reference a valid contract")
      end

      it 'gets 422 for negative contract variation id' do
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/?contractId=-9&#{APP_AGENT_PARAM}",
                                    @oauth
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq("Param contractId value must not be less than 1")
      end

      it 'gets 422 for when contract variation id is zero' do
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/?contractId=0&#{APP_AGENT_PARAM}",
                                    @oauth
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq("Param contractId value must not be less than 1")
      end

      it 'gets 422 for when contract variation id is non-numeric' do
        response = response_as_json "#{CONTRACT_VARIATIONS_V3_URL}/?contractId=xye@()&#{APP_AGENT_PARAM}",
                                    @oauth
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq("Param contractId value must be a valid number; " +
                                                               "Search must be done either by accountId or contractId")
      end


    end
  end
end