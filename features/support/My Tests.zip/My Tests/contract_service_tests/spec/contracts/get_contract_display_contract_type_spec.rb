require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'

=begin
  In this test we make sure the displayContractType is
  correct displayed in the response based on the information
  stored in the IJET2 database.
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'display contract type' do
        $contract_ids_by_contract_types.each do |contract|
        it "gets the display contract type for #{contract[0]['contract_type']}" do
          contract_id = contract[0]["contract_id"].to_i
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['displayContractType']).to eq(contract[0]['contract_type'])
        end
      end
    end

  end
end