module IJETTestHelper

  def fly_flight_on_contract(ar_number,contract_id)
    reservation = MidTier::Reservation.create
    reservation.for_account(ar_number)
    .add_booking_agent
    .add_request { |request|
      request.add_leg('KPIT', 'KDEN', Time.now + 2.hours).add_passenger.assign_tail
      request.use_contract(contract_id)
    }
    .save

    timeline = MidTier::Timeline.new(reservation)
    timeline
    .assign_crew
    .move_legs_and_crew_to_tail
    .log_flight_off_and_on_times

    reservation.reservation_id
  end

end