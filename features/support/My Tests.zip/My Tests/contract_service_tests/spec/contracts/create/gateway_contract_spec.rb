require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/factories/contract_json_factory'
require 'data/models/contract_base'
require 'data/models/card'
require 'data/models/account'
require 'data/models/ej_company'
require 'spec/contracts/create/contract_compare'

describe 'gateway card contract' do
  include_context "rest client"
  include CompareContracts

  before(:all) do
    @account_mgmt_oauth = AccountManagementOauth.new
  end

  it 'creates a gateway card contract that is accessible through ijet' do
    gateway_card_contract = ContractJsonFactory.create_gateway_card
    response = post_as_json "#{CONTRACTS_V3_URL}/?#{APP_AGENT_PARAM}",
                            gateway_card_contract, @account_mgmt_oauth.authorized_oauth_header
    wait_for_forwarding_engine(3)
    card_id = response.fetch('cardId')
    new_contract_id = ContractBase.where(card_id: card_id).first.contract_id
    #puts new_contract_id
    contract_from_ijet = MidTier::Contract.retrieve_contract(new_contract_id)
    compare_with_ijet(gateway_card_contract, contract_from_ijet)
    #fly_flight_on_contract(gateway_card_contract['arNumber'], new_contract_id)
  end

  it 'creates a gateway card contract that is accessible through web service' do
    gateway_card_contract = ContractJsonFactory.create_gateway_card
    response = post_as_json "#{CONTRACTS_V3_URL}/?#{APP_AGENT_PARAM}",
                            gateway_card_contract, @account_mgmt_oauth.authorized_oauth_header
    wait_for_forwarding_engine(3)
    card_id = response.fetch('cardId')
    new_contract_id = ContractBase.where(card_id: card_id).first.contract_id
    #puts new_contract_id
    contract_from_ijet = response_as_json "#{CONTRACTS_V3_URL}/#{new_contract_id}?#{APP_AGENT_PARAM}",
                                          @account_mgmt_oauth.authorized_oauth_header
    compare_with_webservice(gateway_card_contract, contract_from_ijet)

  end
end