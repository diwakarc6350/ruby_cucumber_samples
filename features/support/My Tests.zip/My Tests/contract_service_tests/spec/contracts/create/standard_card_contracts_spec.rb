require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/factories/contract_json_factory'
require 'data/models/contract_base'
require 'data/models/card'
require 'data/models/account'
require 'data/models/ej_company'
require 'data/static_data'
require 'spec/contracts/create/contract_compare'

=begin
  As the GCM Project Architect,
  I want Card Contract Data to be set to IJET from the Contract Service,
  so that flights can be booked, scheduled, and billed.
=end

describe 'contract service' do
  include CompareContracts
  include_context "rest client"

  before(:all) do
    @account_mgmt_oauth = AccountManagementOauth.new
    #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"

  end

  context 'when creating a standard 25 hour card' do

    it 'creates a standard 25 hour card contract that is accessible through web service' do
      new_contract = ContractJsonFactory.create_default_card_contract
      response = post_as_json "#{CONTRACTS_V3_URL}/?#{APP_AGENT_PARAM}", new_contract, @account_mgmt_oauth.authorized_oauth_header
      wait_for_forwarding_engine(3)
      card_id = response.fetch('cardId')
      puts "Card Id: #{card_id}"
      new_contract_id = ContractBase.where(card_id: card_id).first.contract_id
      #puts "Contract Id: #{new_contract_id}"
      created_contract = response_as_json "#{CONTRACTS_V3_URL}/#{new_contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
      compare_with_webservice(new_contract, created_contract)
      #fly_flight_on_contract(new_contract['arNumber'], new_contract_id)
    end

    it 'creates a standard 25 hour that is accessible through ijet' do
      new_contract = ContractJsonFactory.create_default_card_contract
      response = post_as_json "#{CONTRACTS_V3_URL}/?#{APP_AGENT_PARAM}", new_contract, @account_mgmt_oauth.authorized_oauth_header
      wait_for_forwarding_engine(3)
      card_id = response.fetch('cardId')
      new_contract_id = ContractBase.where(card_id: card_id).first.contract_id
      #puts new_contract_id
      ijet2_contract = MidTier::Contract.retrieve_contract(new_contract_id)
      compare_with_ijet(new_contract, ijet2_contract)
    end
  end

  context 'when creating a card with bonus hours' do
    it 'creates a standard 25 hr card with bonus hours that is accessible through ijet' do
      new_contract = ContractJsonFactory.create_standard_card_contract_with_bonus_hours
      response = post_as_json "#{CONTRACTS_V3_URL}/?#{APP_AGENT_PARAM}", new_contract, @account_mgmt_oauth.authorized_oauth_header
      wait_for_forwarding_engine(3)
      card_id = response.fetch('cardId')
      new_contract_id = ContractBase.where(card_id: card_id).first.contract_id
      #puts new_contract_id
      ijet2_contract = MidTier::Contract.retrieve_contract(new_contract_id)
      compare_with_ijet(new_contract, ijet2_contract)
    end
  end

  context "creates standard 25 hour card for different aircraft types" do
    random_ac_type = []
    random_ac_type << available_aircraft_types[rand(available_aircraft_types.length)]
    random_ac_type.each do |aircraft_type|
      it "creates a contract for #{aircraft_type}" do
        new_contract = ContractJsonFactory.create_default_card_contract
        new_contract['contracts'][0]['aircraftTypeName'] = aircraft_type
        response = post_as_json "#{CONTRACTS_V3_URL}/?#{APP_AGENT_PARAM}", new_contract, @account_mgmt_oauth.authorized_oauth_header
        wait_for_forwarding_engine(3)
        card_id = response.fetch('cardId')
        new_contract_id = ContractBase.where(card_id: card_id).first.contract_id
        created_contract = response_as_json "#{CONTRACTS_V3_URL}/#{new_contract_id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
        compare_with_webservice(new_contract, created_contract)
      end
    end
  end

  # context "when adding a card to an account" do
  #
  context 'when matching to an account' do
    it 'matches the contract to an account by legal name when Ar Number is invalid' do
      new_contract = ContractJsonFactory.create_default_card_contract
      new_contract['arNumber'] = Faker::Lorem.characters(6)
      response = post_as_json "#{CONTRACTS_V3_URL}/?#{APP_AGENT_PARAM}", new_contract, @account_mgmt_oauth.authorized_oauth_header
      wait_for_forwarding_engine(3)
      card_id = response.fetch('cardId')
      new_contract_id = ContractBase.where(card_id: card_id).first.contract_id
      ijet2_contract = MidTier::Contract.retrieve_contract(new_contract_id)
      new_contract['arNumber'] = '8176'
      compare_with_ijet(new_contract, ijet2_contract)
    end

    it 'matches the contract to an account by legal name when Ar Number is null' do
      new_contract = ContractJsonFactory.create_default_card_contract
      new_contract['arNumber'] = nil
      response = post_as_json "#{CONTRACTS_V3_URL}/?#{APP_AGENT_PARAM}", new_contract, @account_mgmt_oauth.authorized_oauth_header
      wait_for_forwarding_engine(3)
      card_id = response.fetch('cardId')
      new_contract_id = ContractBase.where(card_id: card_id).first.contract_id
      ijet2_contract = MidTier::Contract.retrieve_contract(new_contract_id)
      compare_with_ijet(new_contract, ijet2_contract)
    end

    it 'stores the contract in the MJP holding account when the ar number and legal name are invalid' do
      new_contract = ContractJsonFactory.create_default_card_contract
      new_contract['arNumber'] = nil
      new_contract['legalName'] = Faker::Name.name
      response = post_as_json "#{CONTRACTS_V3_URL}/?#{APP_AGENT_PARAM}", new_contract, @account_mgmt_oauth.authorized_oauth_header
      wait_for_forwarding_engine(3)
      card_id = response.fetch('cardId')
      new_contract_id = ContractBase.where(card_id: card_id).first.contract_id
      ijet2_contract = MidTier::Contract.retrieve_contract(new_contract_id)
      compare_with_ijet(new_contract, ijet2_contract)
    end
  end
  #
  #   it "updates the \"Account Type\" of an active account with a pre-existing active share contract to \"dual\"" do
  #     valid_account = Account.first_active_shares_account
  #
  #     new_contract = ContractJsonFactory.create_default_card_contract
  #     new_contract['ArNumber'] = valid_account.ar_nbr
  #     response = create_contract(new_contract)
  #     valid_account = Account.get_account_by_ar_number(new_contract['ArNumber']).first
  #     expect(valid_account.account_type_cd).to eq(3)
  #   end
  #
  #   it "updates the \"Account Type\" of an active account with no other contracts to \"card\"" do
  #     valid_account = Account.first_active_empty_account
  #
  #     new_contract = ContractJsonFactory.create_default_card_contract
  #     new_contract['ArNumber'] = valid_account['ar_nbr']
  #     response = create_contract(new_contract)
  #     valid_account = Account.get_account_by_ar_number(new_contract['ArNumber'])
  #     expect(valid_account['account_type_cd'].to_i).to eq(1)
  #   end
  #
  #   it "doesn't change the \"Account Type\" of an account with other card contracts from \"card\"" do
  #     valid_account = Account.first_active_card_account
  #
  #     new_contract = ContractJsonFactory.create_default_card_contract
  #     new_contract['ArNumber'] = valid_account['ar_nbr']
  #     response = create_contract(new_contract)
  #     valid_account = Account.get_account_by_ar_number(new_contract['ArNumber'])
  #     expect(valid_account['account_type_cd'].to_i).to eq(1)
  #   end
  #
  # end

end

