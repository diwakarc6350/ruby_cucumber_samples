require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/factories/contract_json_factory'
require 'data/models/contract_base'
require 'data/models/card'
require 'data/models/account'
require 'data/models/ej_company'
require 'spec/contracts/create/contract_compare'

describe 'combo card contract' do
  include_context "rest client"
  include CompareContracts

  before(:all) do
    @account_mgmt_oauth = AccountManagementOauth.new
  end

  it 'creates a combo-card that is accessible through contract ijet' do
    new_contract = ContractJsonFactory.create_combo_card_contract
    response = post_as_json "#{CONTRACTS_V3_URL}/?#{APP_AGENT_PARAM}", new_contract,
                            @account_mgmt_oauth.authorized_oauth_header
    wait_for_forwarding_engine(3)
    card_id = response.fetch('cardId')
    new_contract_id_one = ContractBase.where(card_id: card_id).first.contract_id
    ijet2_contract_one = MidTier::Contract.retrieve_contract(new_contract_id_one)
    new_contract_id_two = ContractBase.where(card_id: card_id).second.contract_id
    ijet2_contract_two = MidTier::Contract.retrieve_contract(new_contract_id_two)

    second_contract = new_contract['contracts'].pop
    compare_with_ijet(new_contract, ijet2_contract_one)
    expect(ijet2_contract_one.matchingComboCardContractId).to eq new_contract_id_two


    new_contract['contracts'].push(second_contract)
    first_contract = new_contract['contracts'].shift
    compare_with_ijet(new_contract, ijet2_contract_two)
    expect(ijet2_contract_two.matchingComboCardContractId).to eq new_contract_id_one
  end

  it 'creates a combo-card that is accessible through contract web service' do
    new_contract = ContractJsonFactory.create_combo_card_contract
    response = post_as_json "#{CONTRACTS_V3_URL}/?#{APP_AGENT_PARAM}", new_contract,
                            @account_mgmt_oauth.authorized_oauth_header
    wait_for_forwarding_engine(3)
    card_id = response.fetch('cardId')
    new_contract_id_one = ContractBase.where(card_id: card_id).first.contract_id
    new_contract_id_two = ContractBase.where(card_id: card_id).second.contract_id
    created_contract_one = response_as_json "#{CONTRACTS_V3_URL}/#{new_contract_id_one}?#{APP_AGENT_PARAM}",
                                            @account_mgmt_oauth.authorized_oauth_header
    created_contract_two = response_as_json "#{CONTRACTS_V3_URL}/#{new_contract_id_two}?#{APP_AGENT_PARAM}",
                                            @account_mgmt_oauth.authorized_oauth_header

    second_contract = new_contract['contracts'].pop
    compare_with_webservice(new_contract, created_contract_one)

    new_contract['contracts'].push(second_contract)
    first_contract = new_contract['contracts'].shift
    compare_with_webservice(new_contract, created_contract_two)
  end
end
