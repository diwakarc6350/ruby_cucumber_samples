require 'spec/spec_helper'
require 'spec/data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/factories/contract_json_factory'
require 'json/common'

=begin
  Test description
=end

describe 'contracts service' do
  context 'version 3 in tomcat' do
    include_context 'rest client'
    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    it 'gets HTTP 422 error when constraints are incorrect' do
      contract_test('crewExpensAmt must be a valid number', 422) { |contract_json|
        contract_json['contracts'][0]['crewExpensAmt'] = 'inv4lid'
      }
    end

    it 'gets an error when the program isn\'t in EjCompany' do
      contract_test('not a valid program', 422) { |contract_json|
        contract_json['contracts'][0]['program'] = 'POO'
      }
    end

    it 'gets an error when tailNbr isn\'t valid on AircraftTail table' do
      contract_test('not a valid tailNbr', 422) { |contract_json|
        contract_json['contracts'][0]['tailNbr'] = 'inv4lid'
      }
    end

    it 'gets an error when aircraftTypeName is not valid on AircraftType table' do
      contract_test('not a valid aircraft type name and/or netjets aircraft', 422) { |contract_json|
        contract_json['contracts'][0]['aircraftTypeName'] = 'inv4lid'
      }
    end

    it 'gets an error when flightRuleId is not in the FlightRule list' do
      contract_test('not a valid flight rule id', 422) { |contract_json|
        contract_json['contracts'][0]['flightRuleId'] = 1000
      }
    end

    it 'gets an error when contractTypeId is not in ContractType list' do
      contract_test('not a valid contract type', 422) { |contract_json|
        contract_json['contracts'][0]['contractTypeId'] = 1000
      }
    end

    it 'gets an error when cardSubTypeId is not in ContractType list' do
      contract_test('not a valid Card Sub Type Id', 422) { |contract_json|
        contract_json['contracts'][0]['cardSubTypeId'] = 1000
      }
    end

    it 'gets an error when contractStatusId is not 1' do
      contract_test('not a valid contractStatus ID', 422) { |contract_json|
        contract_json['contracts'][0]['contractStatusId'] = 2
      }
    end

    it 'gets an error when delayedStartFlag is true with no delayedStartDate' do
      contract_test('value null cant be null', 422) { |contract_json|
        contract_json['contracts'][0]['delayedStartDate'] = nil
      }
    end

    it 'gets an error when delayedStartDuration exists and contractStartDate is null' do
      contract_test('contractStartDate cant be null if delayed start duration exists', 422) { |contract_json|
        contract_json['contracts'][0]['contractStartDate'] = nil
      }
    end

    it 'gets an error when the airportZoneId is invalid' do
      contract_test('must be a valid number', 422) { |contract_json|
        contract_json['contracts'][0]['responseTimeAndCancelMin'][0]['airportZoneId'] = 'abc'
      }
    end

=begin
    it 'gets an error when the contractVarType is invalid' do
      contract_test('contractVarType must be valid', 422) { |contract_json|
        contract_json['contracts'][0]['somePath'] = nil
      }
    end
=end

  end
end

def contract_test(expected_description, expected_code)
  new_contract = ContractJsonFactory.create_default_card_contract
  yield new_contract
  response = post_as_json CONTRACTS_V3_URL, new_contract, @account_mgmt_oauth.authorized_oauth_header
  error_response = response['errors'][0]
  expect(error_response['code'].to_i).to eq(expected_code)
  expect(error_response['description']).to include(expected_description)
end