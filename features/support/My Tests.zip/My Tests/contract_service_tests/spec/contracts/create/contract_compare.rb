require 'spec/contracts/create/ijet_test_helper'

module CompareContracts
  include IJETTestHelper

  def compare_with_ijet(expected, ijet2_contract)
    expected_contract = expected['contracts'][0]
    ijet_charges = ijet2_contract.chargesCRO
    ijet_total_hours = ijet2_contract.hoursCRO.yearlyHoursSuperSummaryCRO.contractYearlyHoursSummaryCROs.to_a[-1]
    ijet_hours =ijet2_contract.hoursCRO.yearlyHoursSuperSummaryCRO.contractYearlyHoursSummaryCROs.to_a
    expected_company_id = EjCompany.find_by_company_name(expected_contract['program']).ej_company_id
    account = Account.where(AR_NBR: expected['arNumber']).first

    expect(ijet2_contract.arNumber).to eq expected['arNumber']
    expect(ijet2_contract.legalName).to eq expected['legalName']
    expect(ijet2_contract.contractTypeID).to eq expected_contract['contractTypeId']
    expect(ijet2_contract.contractTypeDesc).to eq scrub_text(expected['displayContractType'])
    expect(ijet2_contract.aircraftTypeName).to eq expected_contract['aircraftTypeName']
    expect(ijet2_contract.accountStatus).to eq account.account_status_cd
    expect(ijet2_contract.contractStatusID).to eq 1 # 1 is Active Contract
    expect(ijet2_contract.shareSize).to eq expected_contract['shareSize']
    expect(ijet2_contract.accountingCompanyID).to eq expected_company_id
    expect(ijet2_contract.isCommercial).to eq expected_contract['commercial']
    expect(ijet2_contract.cardTypeId).to eq expected_contract['cardSubTypeId']
    expect(ijet2_contract.cardNumber).to eq expected['card']['cardNumber']
    expect(ijet2_contract.contractStartDate).to eq (scrub_zulu_date(expected_contract['contractStartDate']))
    expect(ijet2_contract.contractEndDate).to eq scrub_zulu_date(expected_contract['contractEndDate'])
    expect(ijet2_contract.delayedStartDate).to eq scrub_zulu_date(expected_contract['delayedStartDate'])
    expect(ijet2_contract.extendedTermEnd).to eq scrub_zulu_date(expected_contract['extendedTermEndDate'])
    expect(ijet2_contract.divisionCROs[0].divisionName).to eq 'Default'
    expect(ijet2_contract.divisionCROs[0].isSelected).to eq false
    expect(ijet2_contract.billingCRO.minimumHoursPerLeg).to eq expected_contract['minHoursPerLeg']
    expect(ijet2_contract.billingCRO.minimumHoursPerDay).to eq expected_contract['minHoursPerDay']
    # expect(ijet2_contract.billingCRO.minimumLegWaiversAllotted).to eq expected_contract['minimumLegWaiversAllotted']
    # expect(ijet2_contract.billingCRO.minimumLegWaiversCarriedOver).to eq expected_contract['minimumLegWaiversCarriedOver']
    expect(ijet_charges.crewExpensesAmount).to eq scrub_number(expected_contract['crewExpensAmt'])
    expect(ijet_charges.operatingFundAmount).to eq scrub_number(expected_contract['operatingFundAmt'])
    expect(ijet2_contract.hoursCRO.allowExcessHoursBeyondLimitFlag).to eq expected_contract['allowExcsHoursBeyondLimitFlag']
    expect(ijet2_contract.hoursCRO.levelOneExcessHours).to eq scrub_number(expected_contract['lvlOneExcsHours'])
    expect(ijet2_contract.hoursCRO.levelTwoExcessHours).to eq scrub_number(expected_contract['lvlTwoExcsHours'])
    expect(ijet2_contract.warRiskFlag).to eq expected_contract['warRiskFlag']
    expect(ijet2_contract.eligibleForEXP).to eq expected_contract['expEligibilityFlag']
    expect(ijet2_contract.enablePrepayments).to eq expected_contract['enablePrepaymentFlag']
    expect(ijet2_contract.cardholderName).to eq expected['card']["cardHolderName"]
    expect(ijet_charges.fuelChargeCROs[0].fuelChargeDifferential).to eq expected_contract["fuelcharge"][0]["fuelChargeDifferential"]
    expect(ijet_charges.fuelChargeCROs[0].fuelChargePerHour).to eq expected_contract["fuelcharge"][0]["fuelChargePerHr"]
    expect(ijet_charges.fuelChargeCROs[0].averageFuelPrice).to eq expected_contract["fuelcharge"][0]["averageFuelPrice"]
    expect(ijet_charges.fuelChargeCROs[0].fuelChargePlusMinus).to eq expected_contract["fuelcharge"][0]["fuelChargePlusMinus"]
    expect(ijet_charges.fuelChargeCROs[0].fetFlag).to eq expected_contract["fuelcharge"][0]["fetFlag"]
    expect(ijet2_contract.opportunityId).to eq expected['salesforceOpportunityId']
    expect(ijet2_contract.peakPeriodList).to eq expected_contract['peakDateListCd']
    expect(ijet2_contract.billingRestrictions).to be expected_contract['ppdBillingRestrictions']
    expect(ijet2_contract.operationalRestrictions).to be expected_contract['ppdOperationalRestrictions']
    expect(ijet2_contract.preventFlights).to be expected_contract['ppdPreventFlights']
    expect(ijet2_contract.operationalCRO.ejRightToChangeDepartureHours).to eq expected_contract['ejRightToChangeDeptHours']
    expect(ijet_charges.invoiceCreditTypeID).to eq expected_contract['invoiceCreditTypeId']
    expect(ijet_charges.taxiTime).to eq expected_contract['taxiTm']
    expect(ijet_charges.crewExpensesPaidByCustomerFlag).to be expected_contract['crewExpensePaidByCustFlag']
    expect(ijet_charges.internationalExpensesPaidByCustomerFlag).to be expected_contract['intlExpensePaidByCustFlag']
    expect(ijet_charges.groundExpensesPaidByCustomerFlag).to be expected_contract['gndExpensePaidByCustFlag']
    expect(ijet2_contract.warRiskFlag).to be expected_contract['warRiskFlag']
    expect(ijet_charges.cateringExpensesPaidByCustomerFlag).to be expected_contract['cateringExpensPaidByCustFlag']
    expect(ijet2_contract.euEtsParticipant).to be expected_contract['euEtsParticipantFlag']
    expect(ijet2_contract.isCommercial).to be expected_contract['commercial']
    expect(ijet2_contract.flightRuleID).to eq expected_contract['flightRuleId']
    expect(ijet2_contract.flightRuleCRO.flightRuleIdDomestic).to eq expected_contract['flightRuleId']
    expect(ijet2_contract.flightRuleCRO.flightRuleIdInternational).to eq expected_contract['flightRuleId']

    expect(ijet_charges.isPAYFFET).to eq expected_contract['isPayfFet']
    expect(ijet_charges.isPAYFEscalation).to eq expected_contract['isPayfEscalation']
    expect(ijet_charges.isSplitPayment).to eq expected_contract['splitPaymentFlag']

    unless expected_contract['cardSubTypeId'] == BINDER
      if expected_contract['contractPrepaidChargeInfo'].any?
        initial_hours = expected_contract['contractPrepaidChargeInfo'].map { |prepaid_charge_info| prepaid_charge_info['quantity'].to_f }
        initial_hours = initial_hours.inject { |hours, initial| hours + initial }

        expect(ijet_total_hours.totalAllottedHrs).to eq(initial_hours)
        expect(ijet_total_hours.allottedHrs).to eq(initial_hours)
        expect(ijet_total_hours.remainingAllottedHrs).to eq(initial_hours)
        expect(ijet_total_hours.remainingAvailHrs).to eq 0
        expect(ijet_total_hours.yearNumber).to eq 0
      end
    end

    # expect(ijet_charges.prepaidCharges[0].isBilled).to eq expected['isBillable']
    expect(ijet_charges.isPAYFEscalation).to eq expected_contract['isPayfEscalation']
    expect(ijet_charges.isPAYFFET).to eq expected_contract['isPayfFet']

    ijet2_contract.billingCRO.contractInterchangeCROs.each do |cro|
      expect(cro.interchangeFlatFee).to eq 0
      expect(cro.interchangeAdditionalHourlyRate).to eq 0
    end

    unless expected_contract['cardSubTypeId'] == BINDER
      expect(ijet2_contract.billingCRO.minimumLegTechStopAdditionalFee).to eq(expected_contract['minLegTechStopAddlFee'])
      expect(ijet2_contract.billingCRO.minimumLegWaiverCarryOverFlag).to eq expected_contract['minLegWaiverCarryOverFlag']
      expect(ijet_charges.liabilityForDelayMaximumHours).to eq expected_contract['liabilityForDelayMaxHours']
      expect(ijet2_contract.billingCRO.contractInternationalPositioningMinimumCROs[0].fromDay).to eq expected_contract["intlPostioningMin"][0]["fromDay"]
      expect(ijet2_contract.billingCRO.contractInternationalPositioningMinimumCROs[0].toDay).to eq expected_contract["intlPostioningMin"][0]["toDay"]
      expect(ijet2_contract.billingCRO.contractInternationalPositioningMinimumCROs[0].minimumPerDayHours).to eq expected_contract["intlPostioningMin"][0]["minPerDayHrs"]
    end

    ijet_response_time_mins = ijet2_contract.operationalCRO.responseTimeAndCancelMinCROs.sort_by { |obj| obj.airportZone.airportZoneID }
    expected_response_time_mins = expected_contract["responseTimeAndCancelMin"].sort_by { |obj| obj["airportZoneId"] }

    ijet_response_time_mins.each_with_index do |response_time_mins, index|
      expect(response_time_mins.airportZone.airportZoneID).to eq expected_contract['responseTimeAndCancelMin'][index]["airportZoneId"]
      expect(response_time_mins.responseHours).to eq expected_contract['responseTimeAndCancelMin'][index]["respHrs"]
      expect(response_time_mins.peakDayResponseHours).to eq expected_contract['responseTimeAndCancelMin'][index]["peakDayRespHrs"]
      expect(response_time_mins.cancellationMinimumHours).to eq expected_contract['responseTimeAndCancelMin'][index]["cancelMinHrs"]
      expect(response_time_mins.peakDayCancellationMinimumHours).to eq expected_contract['responseTimeAndCancelMin'][index]["peakDayCancelMinHrs"]
    end

    unless expected['card']['cardType'] == UPGRADE_TYPE
      ijet_billing_variations = ijet2_contract.billingCRO.contractVariationCROs.sort_by { |obj| obj.contractVariationTypeID }

      expected_billing_variations = expected_contract['variation'].select { |variation| variation["variationCategory"].downcase == "billing" }
      expected_billing_variations = expected_billing_variations.sort_by { |obj| obj["contractVarTypeId"] }

      ijet_billing_variations.each_with_index do |contract_variation, index|
        expect(contract_variation.contractVariationTypeID).to eq expected_billing_variations[index]["contractVarTypeId"]
        expect(contract_variation.description).to eq expected_billing_variations[index]["description"]
      end
      ijet_operational_variations = ijet2_contract.operationalCRO.contractVariationCROs.sort_by { |obj| obj.contractVariationTypeID }

      expected_operational_variations = expected_contract['variation'].select { |variation| variation["variationCategory"].downcase == "operational" || variation["variationCategory"].downcase == "account" }
      expected_operational_variations = expected_operational_variations.sort_by { |obj| obj["contractVarTypeId"] }

      descriptions = Set.new
      ijet_operational_variations.each_with_index do |contract_variation|
        descriptions.add(contract_variation.description)
      end

      expected_operational_variations.each do |variation|
        expect(descriptions.include? variation["description"]).to eq true
      end
    end

    # Checks for all of the charges.
    # Database Table Ref :
    # IJET Scree Ref :
    actual_charges = ijet_charges.hourlyRateCROs.sort_by { |obj| obj.hourlyRateTypeID }
    expected_charges = expected_contract['contractCharge'].sort_by { |obj| obj['hourlyRateTypeId'] }
    actual_charges.each_with_index do |charge, index|
      # this check is only done for demo binder, not sure why the hourlyRateTypeId of 5
      # is being translated to hourlyRateTypeId of 99 from ijet. Spoke to Keith and
      # we are not sure about the business reason as to why.
      if expected_contract['cardSubTypeId'] == BINDER and expected_charges[index]['hourlyRateTypeId'] == 5
        expect(charge.hourlyRateTypeID).to eq(99)
      else
        expect(charge.hourlyRateTypeID).to eq expected_charges[index]['hourlyRateTypeId']
      end
      expect(charge.rateAmount).to eq expected_charges[index]['amt']
      expect(charge.rateBillingCycleTs)
      .to eq(com.netjets.bus.common.date.ZuluDateString.new(expected_charges[index]['billingCycleTS'].gsub(/Z$/, '').gsub(/T/, ' ')))
      expect(charge.rateEffectiveDate)
      .to eq(com.netjets.bus.common.date.ZuluDateString.new(expected_charges[index]['effectiveDate'].gsub(/Z$/, '').gsub(/T/, ' ')))
    end

    # Checks for all of the pre-paid charges.
    # Database Table Ref :
    # IJET Scree Ref :
    unless expected_contract['cardSubTypeId'] == BINDER then
      actual_prepaid_charges = ijet_charges.prepaidCharges.sort
      expected_prepaid_charges = expected_contract['contractPrepaidChargeInfo'].sort_by { |obj| obj['chargeTypeCode'] }
      actual_prepaid_charges.each_with_index do |charge, index|
        expect(charge.chargeTypeCode).to eq expected_prepaid_charges[index]['chargeTypeCode']
        expect(charge.qty).to eq expected_prepaid_charges[index]['quantity']
        expect(charge.rate).to eq expected_prepaid_charges[index]['rate']
        expect(charge.totalAmount).to eq expected_prepaid_charges[index]['totalAmount']
        expect(charge.fet).to eq expected_prepaid_charges[index]['fet']
        expect(charge.escalationFlag).to eq expected_prepaid_charges[index]['escalationFlag']
      end
    end

    # Checks for all of the change logs.
    # Database Table Ref :
    # IJET Scree Ref :
    actual_change_logs = ijet2_contract.hoursCRO.contractChangeLogs
    expected_change_logs = expected_contract['changeLog']
    actual_change_logs.each_with_index do |change_log, index|
      expect(change_log.logEntry).to eq expected_change_logs[index]['logEntry']
    end

    # checks for Upgrade card
    if expected['card']['cardType'] == UPGRADE_TYPE
      actual_airport_waivers = ijet2_contract.billingCRO.contractAirportWaiverCROs
      expected_airport_waivers = expected_contract['airportWaiver']
      actual_airport_waivers.each_with_index do |waiver, index|
        expect(waiver.waiverTypeID).to eq expected_airport_waivers[index]['waiverTypeId']
        expect(waiver.unlimitedWaiversFlag).to eq false
        expect(waiver.waiversAllotted).to eq expected_airport_waivers[index]['waiversAllotted']
        expect(waiver.waiversUsed).to eq 0
        expect(waiver.waiverConditions).to include(expected_airport_waivers[index]['waiverConditions'])
        expect(waiver.waiverConditionsIsNull).to eq false
      end
    end
  end

  def compare_with_webservice(expected, actual)
    # this method compares if the data returned by the contract get web-service is correct based
    # on the information that was sent to the contract post service.
    expected_contract = expected['contracts'][0]
    expect(expected_contract['contractTypeId']).to eq actual['contractType']
    expect(expected_contract['contractStartDate']).to eq actual['startDate']
    expect(expected_contract['contractEndDate']).to eq actual['endDate']
    expect(expected_contract['aircraftTypeName']).to eq actual['aircraftType']
    expect(expected_contract['contractStatusId']).to eq actual['statusId']
    expect(expected_contract['shareSize']).to eq actual['shareSize']
    expect(expected_contract['contractStartDate']).to eq actual['currentPeriodStartDate']
    expect(expected_contract['contractEndDate']).to eq actual['currentPeriodEndDate']
    expect(expected_contract['isPayfEscalation']).to eq actual['isPayfEscalation']
    expect(expected_contract['isPayfFet']).to eq actual['isPayfFET']
    expect(expected_contract['commercial']).to eq actual['isCommercial']
    expect(expected_contract['cardSubTypeId']).to eq actual['cardType']
    expect(expected['card']['cardNumber']).to eq actual['cardNumber']
    expected_company_id = EjCompany.find_by_company_name(expected_contract['program']).ej_company_id
    expect(expected_company_id).to eq actual['ejCompanyId']
  end

  def self.compare_distinct_fifty_hour(expected, actual)
    #Nothing yet, just a sample for future use.
  end

  def scrub_text(data)
    data.nil? ? '' : data
  end

  def scrub_number(data)
    data.nil? ? 0.0 : data
  end

  def scrub_zulu_date(date)
    date.nil? ? nil : com.netjets.bus.common.date.ZuluDateString.new(date.gsub(/Z$/, '').gsub(/T/, ' '))
  end

end