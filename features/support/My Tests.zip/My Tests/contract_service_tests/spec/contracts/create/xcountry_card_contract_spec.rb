require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/factories/contract_json_factory'
require 'data/models/contract_base'
require 'data/models/card'
require 'data/models/account'
require 'data/models/ej_company'
require 'spec/contracts/create/contract_compare'
require 'spec/contracts/create/ijet_test_helper'

describe 'x-country card contract' do
  include_context "rest client"
  include CompareContracts
  include IJETTestHelper

  before(:all) do
    @account_mgmt_oauth = AccountManagementOauth.new
  end

  it 'creates a x-country card contract that is accessible through ijet' do
    x_country_card_contract = ContractJsonFactory.create_x_country_card
    response = post_as_json "#{CONTRACTS_V3_URL}/?#{APP_AGENT_PARAM}",
                            x_country_card_contract, @account_mgmt_oauth.authorized_oauth_header
    wait_for_forwarding_engine(3)
    card_id = response.fetch('cardId')
    # puts card_id
    new_contract_id_one = ContractBase.where(card_id: card_id).first.contract_id
    ijet2_contract_one = MidTier::Contract.retrieve_contract(new_contract_id_one)
    new_contract_id_two = ContractBase.where(card_id: card_id).second.contract_id
    ijet2_contract_two = MidTier::Contract.retrieve_contract(new_contract_id_two)

    #puts new_contract_id_one, new_contract_id_two
    second_contract = x_country_card_contract['contracts'].pop
    # fly_flight_on_contract(x_country_card_contract.fetch('arNumber'),new_contract_id_one)
    compare_with_ijet(x_country_card_contract, ijet2_contract_one)
    expect(ijet2_contract_one.matchingComboCardContractId).to eq new_contract_id_two
    expect(ijet2_contract_one.highUtilizationFlag).to be true

    x_country_card_contract['contracts'].push(second_contract)
    first_contract = x_country_card_contract['contracts'].shift
    compare_with_ijet(x_country_card_contract, ijet2_contract_two)
    expect(ijet2_contract_two.matchingComboCardContractId).to eq new_contract_id_one
    expect(ijet2_contract_two.highUtilizationFlag).to be false
  end

  it 'creates a x-country card contract that is accessible through web service' do
    x_country_card_contract = ContractJsonFactory.create_x_country_card
    response = post_as_json "#{CONTRACTS_V3_URL}/?#{APP_AGENT_PARAM}",
                            x_country_card_contract, @account_mgmt_oauth.authorized_oauth_header
    wait_for_forwarding_engine(3)
    card_id = response.fetch('cardId')

    new_contract_id_one = ContractBase.where(card_id: card_id).first.contract_id
    new_contract_id_two = ContractBase.where(card_id: card_id).second.contract_id
    created_contract_one = response_as_json "#{CONTRACTS_V3_URL}/#{new_contract_id_one}?#{APP_AGENT_PARAM}",
                                            @account_mgmt_oauth.authorized_oauth_header
    created_contract_two = response_as_json "#{CONTRACTS_V3_URL}/#{new_contract_id_two}?#{APP_AGENT_PARAM}",
                                            @account_mgmt_oauth.authorized_oauth_header

    second_contract = x_country_card_contract['contracts'].pop
    compare_with_webservice(x_country_card_contract, created_contract_one)

    x_country_card_contract['contracts'].push(second_contract)
    first_contract = x_country_card_contract['contracts'].shift
    compare_with_webservice(x_country_card_contract, created_contract_two)
  end

end
