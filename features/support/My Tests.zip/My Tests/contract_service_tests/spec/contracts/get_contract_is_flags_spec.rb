require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'

=begin
  In this test we make sure the isPayfEscalation, isPayfFET, isCommercial and isPrepaidFET are
  correctly based on the information stored in the IJET2 database
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end


=begin
    context 'when all flags are null' do
      let(:all_flags_not_null) { $Ijet_con.connection.execute(get_all_flags_not_null_sql) }
      it 'isPayfEscalation is null' do
        pending('Test implementation pending')
        expect(all_flags_not_null[0]['isPayfEscalation']).to be_nil
      end
    end

    context 'when all flags are not null' do
      let(:all_flags_null) { $Ijet_con.connection.execute(get_all_flags_is_null_sql) }
      it 'isPayfEscalation is null' do
        pending('Test implementation pending')
        expect(all_flags_null[0]['isPayfEscalation']).to be_nil
      end
    end
=end

    def get_all_flags_not_null_sql
      # sql to get a operational variation, but other variations are not present
      <<-SQL.gsub(/^ {6}/, '')
        select cb.contract_id, is_payf_fet,is_payf_escalation, commercial
        from contract_base cb join contract_detail cd on cb.CONTRACT_ID = cd. CONTRACT_ID
        where is_payf_fet is not null
        and is_payf_escalation  is not null
        and commercial is not null
        and rownum <=1;
      SQL
    end

    def get_all_flags_is_null_sql
      # sql to get a operational variation, but other variations are not present
      <<-SQL.gsub(/^ {6}/, '')
        select cb.contract_id, is_payf_fet,is_payf_escalation, commercial
        from contract_base cb join contract_detail cd on cb.CONTRACT_ID = cd. CONTRACT_ID
        where is_payf_fet is null
        and is_payf_escalation  is null
        and commercial is null
        and rownum <=1
      SQL
    end
  end
end
