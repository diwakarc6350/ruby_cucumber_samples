require 'spec_helper'
require 'rest_shared_context'
require 'host_names'
require 'account_management_oauth'
require 'data_helper'

=begin
  We test ONLY NJE accounts in this test suite. We validate if
  hours, contract type and  interchange information for NJE accounts
  These information comes from ABS database. We call two different
  stored procedures to validate if the information is correct.
=end

describe 'contracts service' do
  context 'version 3 in tomcat' do

    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
    end

    def response_as_json(request)
      begin
        response = rest.get(request, SSL_OPTIONS.merge(@account_mgmt_oauth.authorized_oauth_header))
        JSON response.body
      rescue => error_response
        JSON error_response
      end
    end

    def response_as_json_without_self_info(request)
      json = response_as_json(request)
      json.clear_self_key
      json
    end

    if ENV['ENVIRONMENT'] == 'qa'
      ENV['abs_db'] = 'TB_NETJETS_ABS_DB'
      ENV['abs_password'] = 'f0b53ab3d1e0bcf50f7fdb0e4fef16c6'
    else
      ENV['abs_db'] = 'TB_NETJETS_ABS_DB2'
      ENV['abs_password'] = '8UPq8n5Sv7ZQsx7TRJS'
    end


    class Abs < ActiveRecord::Base
      self.establish_connection(
          :adapter => 'jdbc',
          :username => 'cmh_contract_app',
          :password => "#{ENV['abs_password']}",
          :driver => 'com.microsoft.sqlserver.jdbc.SQLServerDriver',
          :url => "jdbc:sqlserver://LHRQASQL01:1433;databaseName=#{ENV['abs_db']}"
      )
    end

    #puts (Abs.connection.methods - Object.methods).sort

  def get_interchange_data_from_abs_for_contract(contractid)
    #{"InitialHours"=>25.00,"ActualRemainingHours"=>25.807,"ProjectedRemainingHours"=>25.807}
    Abs.connection.select_all("exec sp_CMH_GetInterchangeData \'#{contractid}\'")
  end

  def get_hours_data_from_abs_for_contract(contractid)
    #{"InitialHours"=>25.00,"ActualRemainingHours"=>25.807,"ProjectedRemainingHours"=>25.807}
    Abs.connection.select_all("exec sp_CMH_GetContractData \'#{contractid}\'")[0]
  end

  it 'gets the hours information for NJE accounts' do
    pending('pending open defect')
    nje_account_ids = $all_nje_account_ids
    #expect(nje_account_ids).to have_at_least(1).items
    nje_account_ids.each do |nje_account_id|
      tc_doc = response_as_json_without_self_info "#{CONTRACTS_V3_URL}?#{APP_AGENT_PARAM}&accountId=#{nje_account_id}"
      tc_doc.each do |contract|
        expected_hours = get_hours_data_from_abs_for_contract(contract["contractId"])
        exp_initial_hours = expected_hours["InitialHours"].nil? ? "0.0" :
            expected_hours["InitialHours"].to_f
        exp_actual_remaining_hours = expected_hours["ActualRemainingHours"].nil? ? "0.0" :
            expected_hours["ActualRemainingHours"].to_f
        exp_project_remaining_hours = expected_hours["ProjectedRemainingHours"].nil? ? "0.0" :
            expected_hours["ProjectedRemainingHours"].to_f

        expect(contract["initialHours"]).to eq(exp_initial_hours)
        expect(contract["actualRemainingHours"]).to eq(exp_actual_remaining_hours)
        expect(contract["projectedRemainingHours"]).to eq(exp_project_remaining_hours)
      end
    end
  end

  it 'gets the contract type information for NJE accounts' do
    nje_account_ids = $all_nje_account_ids
    #expect(nje_account_ids).to have_at_least(1).items
    nje_account_ids.each do |nje_account_id|
      tc_doc = response_as_json_without_self_info "#{CONTRACTS_V3_URL}?#{APP_AGENT_PARAM}&accountId=#{nje_account_id}"
      tc_doc.each do |contract|
        contract_type = get_hours_data_from_abs_for_contract(contract["contractId"])
        expected_contract_type = contract_type["ContractType"].nil? ? contract["contractType"] : contract_type["ContractType"]
        expect(contract["contractType"]).to eq(expected_contract_type)
      end
    end
  end

  it 'get the interchange information for NJE account contracts' do
    nje_contract_ids = $all_nje_contract_ids
    #expect(nje_contract_ids).to have_at_least(1).items
    nje_contract_ids.each do |nje_contract_id|
      tc_doc = response_as_json_without_self_info "#{CONTRACTS_V3_URL}/#{nje_contract_id}?#{APP_AGENT_PARAM}&includes=contractInterchanges"
      expected_interchanges = tc_doc["contractInterchanges"]
      actual_interchanges = get_interchange_data_from_abs_for_contract(nje_contract_id)
      #expect(expected_interchanges).to have_at_least(1).items
      expect(actual_interchanges.length).to eq expected_interchanges.length
      actual_interchanges.each do |actual_interchange|
        act_interchange_ratio = actual_interchange["InterchangeRatio"].to_f
        act_aircraft_type = actual_interchange["ToAircraftType"]
        expected_interchanges.each do |expected_interchange|
          if expected_interchange['toAircraftType'] == act_aircraft_type
            exp_interchange = expected_interchange['interChangeRatio']
            expect(act_interchange_ratio).to eq(exp_interchange)
          end
        end
      end
    end
  end
end
end
