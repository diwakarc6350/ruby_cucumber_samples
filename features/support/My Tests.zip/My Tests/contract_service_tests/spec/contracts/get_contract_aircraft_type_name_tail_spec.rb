require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'

=begin
  In this test we make sure the aircraftType and aircraftTypeName is
  correctly based on the information stored in the IJET2 database
=end

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'aircraft type and name' do
      $contract_ids_by_contract_types.each do |contract|
        it "gets aircraft type and full name for #{contract[0]['contract_type']}" do
          contract_id = contract[0]["contract_id"].to_i
          sql = " select cb.aircraft_type_name, at.type_full_name
                  from contract_base cb
                  join aircraft_type at
                  on cb.aircraft_type_name = at.typename
                  where cb.contract_id = #{contract_id}"
          aircraft_info = $Ijet_con.connection.execute(sql)
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
          expect(tc_doc['aircraftType']).to eq(aircraft_info[0]["aircraft_type_name"])
          expect(tc_doc['aircraftTypeName']).to eq(aircraft_info[0]["type_full_name"])
        end
      end
    end

    describe 'aircraft tail number' do
      $contract_ids_by_contract_types.each do |contract|
        it "gets aircraft tail number for #{contract[0]['contract_type']}" do
          contract_id = contract[0]["contract_id"].to_i
          sql = " select at.tail_nbr
                  from aircraft_tail at
                  join contract_base cb
                  on cb.tail_id = at.tailid
                  where cb.contract_id = #{contract_id}"
          tail_info = $Ijet_con.connection.execute(sql)
          tc_doc = response_as_json "#{CONTRACTS_V3_URL}/#{contract_id}?#{APP_AGENT_PARAM}",@account_mgmt_oauth.authorized_oauth_header
          if tail_info.length > 0
            expect(tc_doc['tailNumber']).to eq(tail_info[0]["tail_nbr"])
          else
            expect(tc_doc['tailNumber']).to be_nil
          end
        end
      end
    end

  end
end