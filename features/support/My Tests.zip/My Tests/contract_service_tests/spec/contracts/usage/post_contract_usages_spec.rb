require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/factories/usage_factory'
require 'spec/data/contract_hours'

describe 'contracts service' do
  context "version 3 in tomcat" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    before(:each) do
      skip("WIP")
    end

    context 'posts usage' do

      it 'posts regular hours for single period' do
        post_usages = UsageFactory.single_regular_hour
        invoice_id = post_usages['invoiceId']
        #clean the existing usage info for the invoice id
        $Ijet_con.connection.execute(delete_usage_info(invoice_id))
        response = put_as_json "#{USAGE_V3_URL}", post_usages.to_s, @account_mgmt_oauth.authorized_oauth_header
        expect(response.has_key?('status'))
        expect(response['status']).to eq(200)
        posted_usages = $Ijet_con.connection.execute(get_usage_info(invoice_id))
        expect(posted_usages[0]['contract_id'].to_i).to eq(post_usages['contractId'])
        expect(posted_usages[0]['invoice_id'].to_i).to eq(post_usages['invoiceId'])
        expect(posted_usages[0]['originating_inv_system']).to eq(post_usages['originatingInvSystem'])
        expect(posted_usages[0]['allocation_type'].to_i).to eq(post_usages['usages'][0]['allocationType'])
        expect(posted_usages[0]['period_nbr'].to_i).to eq(post_usages['usages'][0]['periodNumber'])
        expect(posted_usages[0]['used_qty'].to_i).to eq(post_usages['usages'][0]['value'])
        expect(posted_usages[0]['posting_start_dt'].to_datetime).to eq(post_usages['usages'][0]['postingStartDate'].to_datetime)
        expect(posted_usages[0]['posting_end_dt'].to_datetime).to eq(post_usages['usages'][0]['postingEndDate'].to_datetime)
      end

      it 'posts regular hours for multiple period' do
        post_usages = UsageFactory.multiple_regular_hours
        invoice_id = post_usages['invoiceId']
        #clean the existing usage info for the invoice id
        $Ijet_con.connection.execute(delete_usage_info(invoice_id))
        response = put_as_json "#{USAGE_V3_URL}", post_usages.to_s, @account_mgmt_oauth.authorized_oauth_header
        posted_usages = $Ijet_con.connection.execute(get_usage_info(invoice_id))
        expect(response.has_key?('status'))
        expect(response['status']).to eq(200)
        expect(posted_usages.length).to eq(2)
      end

      it 'posts excess hours' do
        post_usages = UsageFactory.single_excess_hour
        invoice_id = post_usages['invoiceId']
        #clean the existing usage info for the invoice id
        $Ijet_con.connection.execute(delete_usage_info(invoice_id))
        response = put_as_json "#{USAGE_V3_URL}", post_usages.to_s, @account_mgmt_oauth.authorized_oauth_header
        expect(response.has_key?('status'))
        expect(response['status']).to eq(200)
      end

      it 'posts short leg waiver' do
        post_usages = UsageFactory.single_short_leg_waiver
        invoice_id = post_usages['invoiceId']
        #clean the existing usage info for the invoice id
        $Ijet_con.connection.execute(delete_usage_info(invoice_id))
        response = put_as_json "#{USAGE_V3_URL}", post_usages.to_s, @account_mgmt_oauth.authorized_oauth_header
        expect(response.has_key?('status'))
        expect(response['status']).to eq(200)
      end

      it 'posts negative used hours' do
        usages = UsageFactory.single_regular_hour
        invoice_id = usages['invoiceId']
        #clean the existing usage info for the invoice id
        $Ijet_con.connection.execute(delete_usage_info(invoice_id))
        usages['usages'][0]['value'] = '-1'
        response = put_as_json "#{USAGE_V3_URL}", usages.to_s, @account_mgmt_oauth.authorized_oauth_header
        expect(response.has_key?('status'))
        expect(response['status']).to eq(200)
      end

    end

    context 'post usage raises error' do

      it 'when contractId is invalid' do
        usages = UsageFactory.single_regular_hour
        usages['contractId'] = '999999999999'
        response = put_as_json "#{USAGE_V3_URL}", usages.to_s, @account_mgmt_oauth.authorized_oauth_header
        error_response = response['errors'][0]
        expect(error_response["code"].to_i).to eq(404)
        expect(error_response["description"]).to include("No matching contract found")
      end

      it 'when allocationType is invalid' do
        usages = UsageFactory.single_regular_hour
        usages['usages'][0]['allocationType'] = '123456789'
        response = put_as_json "#{USAGE_V3_URL}", usages.to_s, @account_mgmt_oauth.authorized_oauth_header
        error_response = response['errors'][0]
        expect(error_response["code"].to_i).to eq(422)
        expect(error_response["description"]).to include("not a valid allocation type code")
      end

      it 'when periodNumber is invalid' do
        usages = UsageFactory.single_regular_hour
        usages['usages'][0]['periodNumber'] = '99'
        response = put_as_json "#{USAGE_V3_URL}", usages.to_s, @account_mgmt_oauth.authorized_oauth_header
        error_response = response['errors'][0]
        expect(error_response["code"].to_i).to eq(404)
        expect(error_response["description"]).to include("No matching period number found")
      end

      it 'when periodNumber is negative' do
        usages = UsageFactory.single_regular_hour
        usages['usages'][0]['periodNumber'] = '-1'
        response = put_as_json "#{USAGE_V3_URL}", usages.to_s, @account_mgmt_oauth.authorized_oauth_header
        error_response = response['errors'][0]
        expect(error_response["code"].to_i).to eq(404)
        expect(error_response["description"]).to include("No matching period number found")
      end

      it 'when postingStartDate is invalid' do
        usages = UsageFactory.single_regular_hour
        usages['usages'][0]['postingStartDate'] = 'invalid'
        response = put_as_json "#{USAGE_V3_URL}", usages.to_s, @account_mgmt_oauth.authorized_oauth_header
        error_response = response['errors'][0]
        expect(error_response["code"].to_i).to eq(422)
        expect(error_response["description"]).to include("postingStartDate must be a valid Date")
      end

      it 'when postingEndDate is invalid' do
        usages = UsageFactory.single_regular_hour
        usages['usages'][0]['postingEndDate'] = 'invalid'
        response = put_as_json "#{USAGE_V3_URL}", usages.to_s, @account_mgmt_oauth.authorized_oauth_header
        error_response = response['errors'][0]
        expect(error_response["code"].to_i).to eq(422)
        expect(error_response["description"]).to include("postingEndDate must be a valid Date")
      end

    end

  end

end
