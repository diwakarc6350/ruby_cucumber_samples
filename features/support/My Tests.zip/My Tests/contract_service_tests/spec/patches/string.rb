class String
  def to_bool
    return true if self =~ (/(true|t|yes|y|1)$/i)
    false
  end

  def strip_control_characters()
    self.chars.inject("") do |str, char|
      unless char.ascii_only? and (char.ord < 32 or char.ord == 127)
        str << char
      end
      str
    end
  end

  def strip_control_and_extended_characters()
    self.chars.inject("") do |str, char|
      if char.ascii_only? and char.ord.between?(32, 126)
        str << char
      end
      str
    end
  end
end

class Object
  include Kernel

  def wait_for_forwarding_engine(seconds)
    sleep(seconds)
  end
end