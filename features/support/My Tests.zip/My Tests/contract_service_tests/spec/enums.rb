module Enums
  module Cards
    BINDER = 11
    XCOUNTRY = 6
    UPGRADE = 7
  end
  module CardTypes
    UPGRADE_TYPE = 5
  end
end
