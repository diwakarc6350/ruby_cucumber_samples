require 'active_record'

$CLASSPATH << "#{Dir.pwd}/lib/ojdbc6-11.2.0.3.jar"
$CLASSPATH << "#{Dir.pwd}/lib/sqljdbc4.jar"

APP_AGENT_PARAM = "appAgent=AccountManagementUser"
APP_AGENT_PARAM_NONE = "appAgent="
APP_AGENT_PARAM_NOT_ALLOWED = "appAgent=AppNotAllowed"

$all_nje_contract_ids = [1398253]

$all_nje_account_ids = [1376092, 1357572]

$all_invalid_account_ids = [-777, 0, 99999999999999999999, '', 'someC8@9!']

$invalid_contract_ids = [-777, 0, 99999999999999999999, '', 'someC8@9!']

$contract_types = {'Card' => 17, 'NJ Owner' => 8, 'NJ Lease' => 7, 'Full Managed' => 10,
                   'Charter Managed' => 9, 'Card Promo' => 19, 'Charter' => 5, 'Demo' => 6, 'NJ Promo' => 11}

$card_types = []
$flight_rules = []
$contract_ids_by_contract_types = []
$all_nja_account_ids = []

case environment
  when :qa
    $Ijet_con = ActiveRecord::Base.establish_connection(
        :adapter => 'jdbc',
        :username => 'CONTRACT_APP_USER',
        :password => 'pr0p4g4t3',
        :driver => 'oracle.jdbc.driver.OracleDriver',
        :url => 'jdbc:oracle:thin:@
                (DESCRIPTION=
                (CONNECT_TIMEOUT=5)
                (TRANSPORT_CONNECT_TIMEOUT=3)
                (RETRY_COUNT=3)
                (LOAD_BALANCE=on)
                (FAILOVER=on)
                (ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=cexa-scan)(PORT=1521))
                (ADDRESS=(PROTOCOL=TCP)(HOST=bexa-scan)(PORT=1521)))
                (CONNECT_DATA=(SERVICE_NAME=EDRThinQAT.netjets.com)))')
    IJET_CONFIG = 'qa'
  when :itg2
    $Ijet_con = ActiveRecord::Base.establish_connection(
        :adapter => 'jdbc',
        :username => 'CONTRACT_APP_USER',
        :password => 'tr4nsm1t',
        :driver => 'oracle.jdbc.driver.OracleDriver',
        :url => "jdbc:oracle:thin:@
                 (DESCRIPTION_LIST=
                 (LOAD_BALANCE=off)
                 (FAILOVER=on)
                 (DESCRIPTION=
                 (ADDRESS_LIST=
                 (LOAD_BALANCE=on)
                 (ADDRESS=(PROTOCOL=TCP)(HOST=cexa-scan)(PORT=1521)))
                 (CONNECT_DATA=(SERVICE_NAME=Ijet2ThinDv5.netjets.com))))")
    IJET_CONFIG = 'itg2'
  when :itg, :itg1
    $Ijet_con = ActiveRecord::Base.establish_connection(
        :adapter => 'jdbc',
        :username => 'CONTRACT_APP_USER',
        :password => 'tr4nsm1t',
        :driver => 'oracle.jdbc.driver.OracleDriver',
        :url => "jdbc:oracle:thin:@
                  (DESCRIPTION=(CONNECT_TIMEOUT=5)
                  (TRANSPORT_CONNECT_TIMEOUT=3)(RETRY_COUNT=3)
                  (LOAD_BALANCE=on)
                  (FAILOVER=on)
                  (ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=cexa-scan)(PORT=1521))
                  (ADDRESS=(PROTOCOL=TCP)(HOST=bexa-scan)(PORT=1521)))
                  (CONNECT_DATA=(SERVICE_NAME=EDRThinITG1.netjets.com))))
              ")
    IJET_CONFIG = 'itg1'
  when :ci
    $Ijet_con = ActiveRecord::Base.establish_connection(
        :adapter => 'jdbc',
        :username => 'CONTRACT_APP_USER',
        :password => 'tr4nsm1t',
        :driver => 'oracle.jdbc.driver.OracleDriver',
        :url => "jdbc:oracle:thin:@
                 (DESCRIPTION_LIST=
                 (LOAD_BALANCE=off)
                 (FAILOVER=on)
                 (DESCRIPTION=
                 (ADDRESS_LIST=
                 (LOAD_BALANCE=on)
                 (ADDRESS=(PROTOCOL=TCP)(HOST=cexa-scan)(PORT=1521)))
                 (CONNECT_DATA=(SERVICE_NAME=EdrThinItg1.netjets.com))))
              ")
    IJET_CONFIG = 'itg1'
  when :patch
    $Ijet_con = ActiveRecord::Base.establish_connection(
        :adapter => 'jdbc',
        :username => 'dandersen',
        :password => '4bs0lut3$',
        :driver => 'oracle.jdbc.driver.OracleDriver',
        :url => "jdbc:oracle:thin:@ijet2pt1:1521:ijet2pt1")
    IJET_CONFIG = 'patch'
  when :local
    $Ijet_con = ActiveRecord::Base.establish_connection(
        :adapter => 'jdbc',
        :username => 'CONTRACT_APP_USER',
        :password => 'tr4nsm1t',
        :driver => 'oracle.jdbc.driver.OracleDriver',
        :url => "jdbc:oracle:thin:@
                 (DESCRIPTION_LIST=
                 (LOAD_BALANCE=off)
                 (FAILOVER=on)
                 (DESCRIPTION=
                 (ADDRESS_LIST=
                 (LOAD_BALANCE=on)
                 (ADDRESS=(PROTOCOL=TCP)(HOST=cexa-scan)(PORT=1521)))
                 (CONNECT_DATA=(SERVICE_NAME=EdrThinItg1.netjets.com))))
              ")
    IJET_CONFIG = 'itg1'
end

#login to ijet
MidTier::Config.establish(IJET_CONFIG.to_sym)

def get_contract_id_by_types
  $contract_types.each do |type, code|
    sql = " select a.accountid, cb.contract_id, ctt.value as contract_type
                  from account a
                  join contract_base cb
                  on a.accountid = cb.acct_id
                  join code_table_trans ctt
                  on cb.contract_type_id = ctt.code
                  where cb.contract_type_id =#{code}
                  and rownum <= 1
                  and ctt.tag = \'ContractType\'"
    x = $Ijet_con.connection.execute(sql)
    $contract_ids_by_contract_types.push(x)
  end
end

def get_card_types
  # get all card types except Referral, code is 9
  # as there are no contracts associated with it.
  sql = " select code, value from code_table_trans
          where tag = 'CardSubType'
          and code <> 9
          order by code"
  $card_types = $Ijet_con.connection.execute(sql)
end

def get_flight_rules
  # get all card types except Referral, code is 9
  # as there are no contracts associated with it.
  sql = " select code, value from code_table_trans
          where tag = 'FlightRule'
          order by code"
  $flight_rules = $Ijet_con.connection.execute(sql)
end

get_contract_id_by_types
get_card_types
get_flight_rules