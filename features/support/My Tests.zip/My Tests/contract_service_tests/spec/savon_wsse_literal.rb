module Savon
  class Header

    def initialize(globals, locals)
      @gyoku_options  = { :key_converter => globals[:convert_request_keys_to] }

      @wsse_auth      = globals[:wsse_auth]
      @wsse_timestamp = globals[:wsse_timestamp]
      @wsse_literal = globals[:wsse_literal]

      @global_header  = globals[:soap_header]
      @local_header   = locals[:soap_header]

      @header = build
    end

    def wsse_literal
      @wsse_literal
    end

    def akami
      wsse = Akami.wsse
      wsse.credentials(*wsse_auth) if wsse_auth
      wsse.timestamp = wsse_timestamp if wsse_timestamp
      wsse.literal = wsse_literal if wsse_literal
      wsse
    end
  end

  class GlobalOptions
    def wsse_literal(signature)
      @options[:wsse_literal] = signature
    end
  end
end

module Akami
  class WSSE

    attr_accessor :literal

    def to_xml
      if literal?
        result = literal.gsub />\s*</, '><'
        '<wsse:Security xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">' + result + '</wsse:Security>'
      elsif signature? and signature.have_document?
        Gyoku.xml wsse_signature.merge!(hash)
      elsif username_token? && timestamp?
        Gyoku.xml wsse_username_token.merge!(wsu_timestamp) {
            |key, v1, v2| v1.merge!(v2) {
              |key, v1, v2| v1.merge!(v2)
          }
        }
      elsif username_token?
        Gyoku.xml wsse_username_token.merge!(hash)
      elsif timestamp?
        Gyoku.xml wsu_timestamp.merge!(hash)
      else
        ""
      end
    end

    def literal?
      !!@literal
    end

    def literal=(literal_wsse_content)
      @literal = literal_wsse_content
    end
  end
end