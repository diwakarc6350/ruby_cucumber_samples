require 'active_record'

class ContractBase < ActiveRecord::Base
  self.table_name = 'ijet.contract_base'
  self.has_one(:contract_detail, :class_name => "ContractDetail")
end