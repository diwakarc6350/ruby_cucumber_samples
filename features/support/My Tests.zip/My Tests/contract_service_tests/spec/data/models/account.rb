require 'active_record'

class Account < ActiveRecord::Base
  self.table_name = 'ijet.account'

  def self.first_active_shares_account
    self.where(account_status_cd: 'A').where("ar_nbr is not null").where(account_type_cd: 2).where(program_id: 1000011).first
  end

  def self.first_active_card_account
    self.where(account_status_cd: 'A').where("ar_nbr is not null").where(account_type_cd: 1).where(program_id: 1000011).first
  end

  def self.first_active_empty_account
    self.where(account_status_cd: 'A').where("ar_nbr is not null").where(account_type_cd: 0).where(program_id: 1000011).first
  end

  def self.get_account_by_ar_number(ar_number)
    self.where(ar_nbr: ar_number)
  end
end
