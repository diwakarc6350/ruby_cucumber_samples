require 'active_record'

class EjCompany < ActiveRecord::Base
  self.table_name = 'ijet.ej_company'

end
