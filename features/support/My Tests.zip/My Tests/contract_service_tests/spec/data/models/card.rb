require 'active_record'
require 'faker'

class Card < ActiveRecord::Base
  self.table_name = 'ijet.card'
  self.has_many(:contract_bases, :class_name => "ContractBase")

  def self.available_card_number
    Card.find_by_sql("select max(card_nbr)+1 as next_card
          from card where (card_nbr not like \'YEAR%\')
          and (card_nbr not like \'CHARTER%\')")[0].next_card
  end

  def self.first_contract_on_card(card_id)
    Card.where(card_id: card_id).first.contract_bases.first
  end
end

