def contract_variation_types_sql
  <<-SQL.gsub(/^ {6}/, '')
    select tag, cast(code as int) as code, value from code_table_trans
    where tag = 'AccountContractVariationType' or
    tag = 'OperationalContractVariationType' or
    tag = 'BillingContractVariationType' or
    tag = 'ContractualVariationType'
    UNION
    select tag, cast(codetableintid as int) as code, value from code_table_int
    where tag = 'ContractualVariationType'
    order by tag,code
  SQL
end

def account_var_sql
  # sql to get contracts with account variations
  <<-SQL.gsub(/^ {6}/, '')
      select * from contract_var
      where account_id is not null
      and rownum <=100
  SQL
end

def account_var_by_id_sql(id)
  # sql to get contracts with account variations
  <<-SQL.gsub(/^ {6}/, '')
      select * from contract_var
      where account_id = #{id}
      order by contract_var_id asc
  SQL
end

def billing_var_sql
  # sql to get contracts with account variations
  <<-SQL.gsub(/^ {6}/, '')
      select * from contract_var
      where billing_contract_id is not null
      and rownum <=100
  SQL
end

def operational_var_sql
  # sql to get contracts with account variations
  <<-SQL.gsub(/^ {6}/, '')
      select * from contract_var
      where operational_contract_id is not null
      and rownum <=100
  SQL
end

def contractual_var_sql
  # sql to get contracts with account variations
  <<-SQL.gsub(/^ {6}/, '')
      select * from contract_var
      where contractual_contract_id is not null
      and rownum <=100
  SQL
end

def get_accounts_id_by_count_sql
  <<-SQL.gsub(/^ {6}/, '')
    select account_id, count(*) as count
    from contract_var where account_id is not null
    group by account_id
    order by count
  SQL
end

def get_variations_sql
  <<-SQL.gsub(/^ {6}/, '')
    select contract_id from contract_base ctr
    where contract_id in (select operational_contract_id from contract_var where operational_contract_id is not null )
    and contract_id  in (select contractual_contract_id from contract_var where contractual_contract_id is not null )
    and contract_id in (select billing_contract_id from contract_var where billing_contract_id is not null )
    and rownum <250
  SQL
end

def get_contract_variations_sql(id)
  <<-SQL.gsub(/^ {6}/, '')
    select * from contract_var
    where operational_contract_id = #{id}
    union
    select * from contract_var
    where billing_contract_id = #{id}
    union
    select * from contract_var
    where contractual_contract_id = #{id}
    order by 1
  SQL
end