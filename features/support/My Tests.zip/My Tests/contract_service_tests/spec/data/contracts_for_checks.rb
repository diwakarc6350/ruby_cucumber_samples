def get_contract_peak_date_list_cd_2_sql
  <<-SQL.gsub(/^ {6}/, '')
      select cd.CONTRACT_START_DAT, cd.CONTRACT_END_DAT, cb.CONTRACT_ID from contract_base cb join contract_detail cd on cb.CONTRACT_ID = cd.contract_id
      where peak_date_list_cd = 2
      and cd.CONTRACT_START_DAT is not null
      and cd.CONTRACT_START_DAT > to_date('2013-12-23','YYYY-MM-DD')
      and rownum < 1000
      order by 1 desc;
  SQL
end

def get_aircrafts_per_day_sql
  <<-SQL.gsub(/^ {6}/, '')
    select cb.contract_id, sum(atl.allotment_amt) as aircraft_per_day
    from contract_base cb join contract_detail cd on cb.CONTRACT_ID = cd.CONTRACT_ID, account act, aircraft_per_day_combo apd, aircraft_type_allotment atl, aircraft_type aty
    where cb.acct_id = act.accountid
    and act.accountid = apd.account_id
    and apd.aircraft_per_day_combo_id = atl.aircraft_per_day_combo_id
    and atl.aircraft_typename = aty.typename
    and cd.CONTRACT_START_DAT is not null
    group by  cb.contract_id
  SQL
end

def get_aircraft_per_day_contract_sql(contract_id)
  <<-SQL.gsub(/^ {6}/, '')
    select cb.contract_id, sum(atl.allotment_amt) as aircraft_per_day
    from contract_base cb join contract_detail cd on cb.CONTRACT_ID = cd.CONTRACT_ID, account act, aircraft_per_day_combo apd, aircraft_type_allotment atl, aircraft_type aty
    where cb.acct_id = act.accountid
    and act.accountid = apd.account_id
    and apd.aircraft_per_day_combo_id = atl.aircraft_per_day_combo_id
    and atl.aircraft_typename = aty.typename
    and cd.CONTRACT_START_DAT is not null
    and cb.contract_id = '#{contract_id}'
    group by  cb.contract_id
  SQL
end

def get_response_times_sql(contract_id, airport_id)
  <<-SQL.gsub(/^ {6}/, '')
    select rt.contract_id, rt.resp_hrs, rt.peak_day_resp_hrs from ijet.resp_tm_and_cancel_min rt, airport airp
    where rt.contract_id=#{contract_id}
    and airp.airportid='#{airport_id}'
    and airp.airport_zone_id=rt.airport_zone_id
  SQL
end

def legs_for_contracts_sql
  <<-SQL.gsub(/^ {6}/, '')
      select al.leg_id, al.etd_tm, cd.contract_id, cb.aircraft_type_name, a.account_name,
      lcc.contract_rem_hrs, al.dep_airport_id
      from aux_leg al
      join leg_contract_charges lcc
      on lcc.leg_id = al.leg_id
      join netjets_activity_invoice nai
      on nai.invoice_id = lcc.netjets_activity_invoice_id
      join contract_base cb
      on cb.CONTRACT_ID = nai.contract_id
      join contract_detail cd
      on cb.contract_id = cd.contract_id
      join account a
      on a.accountid = cb.acct_id
      where rownum<=3000
  SQL
end


def get_accounts_sql
  <<-SQL.gsub(/^ {6}/, '')
    select acct_id , count(*) as cnt from contract_base where acct_id is NOT NULL
    group by acct_id order by cnt desc
  SQL
end

def get_by_variation_id_sql(id)
  <<-SQL.gsub(/^ {6}/, '')
    select *  from contract_var
    where contract_var_id = #{id}
  SQL
end