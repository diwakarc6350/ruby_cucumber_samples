def get_usage_info(invoice_id)
  <<-SQL.gsub(/^ {6}/, '')
    select cxref.CONTRACT_ID ,sralloc.ALLOCATION_TYPE , sralloc.PERIOD_NBR, usage.INVOICE_ID,
    usage.ORIGINATING_INV_SYSTEM, usage.POSTING_START_DT, usage.POSTING_END_DT, usage.USED_QTY
    from CNTR_SERVICE_USAGE usage
    join CNTR_SERVICE_ALLOCATION sralloc
    on sralloc.CNTR_SERVICE_ALLOCATION_ID = usage.CNTR_COMPONENT_SVC_ALLOC_ID
    join CNTR_COMPONENT_SVC_ALLOC csralloc
    on sralloc.CNTR_SERVICE_ALLOCATION_ID  = csralloc.CNTR_COMPONENT_SVC_ALLOC_ID
    join CNTR_CONTRACT_CROSS_REF cxref
    on csralloc.CNTR_CONTRACT_COMPONENT_ID = cxref.CNTR_CONTRACT_COMPONENT_ID
    where usage.INVOICE_ID=#{invoice_id}
  SQL
end

def delete_usage_info(invoice_id)
  <<-SQL.gsub(/^ {6}/, '')
    delete from CNTR_SERVICE_USAGE where INVOICE_ID=#{invoice_id}
  SQL
end


def contract_start_n_end_date_null
  <<-SQL.gsub(/^ {6}/, '')
    select cb.contract_id, contract_start_dat, contract_end_dat
    from contract_base cb join contract_detail cd on cb.contract_id = cd.contract_id
    where rownum <=1
    and contract_end_dat is null and contract_start_dat is null
    order by contract_end_dat
  SQL
end

def contract_extended_start_end_date
  <<-SQL.gsub(/^ {6}/, '')
    select cb.contract_id, extended_term_start, extended_term_end
    from contract_base cb join contract_detail cd on cb.contract_id = cd.contract_id
    where rownum <=1
    and cd.extended_term_start is not null
    and cd.extended_term_end is not null
    order by cd.contract_end_dat
  SQL
end

def contract_extended_start_end_date_null
  <<-SQL.gsub(/^ {6}/, '')
    select cb.contract_id, contract_start_dat, contract_end_dat
    from contract_base cb join contract_detail cd on cb.contract_id = cd.contract_id
    where rownum <=1
    and contract_end_dat is null
    and contract_start_dat is null
    order by contract_end_dat
  SQL
end

def contract_delayed_start
  <<-SQL.gsub(/^ {6}/, '')
    select cb.contract_id, delayed_start
    from contract_base cb join contract_detail cd on cb.contract_id = cd.contract_id
    where rownum <=1
    and delayed_start is not null
  SQL
end

def contract_delayed_start_null
  <<-SQL.gsub(/^ {6}/, '')
    select cb.contract_id, delayed_start
    from contract_base cb join contract_detail cd on cb.contract_id = cd.contract_id
    where rownum <=1
    and delayed_start is null
  SQL
end

def contract_future_activity(date)
  <<-SQL.gsub(/^ {6}/, '')
    select contract_id, activity_start_dat, activity_end_dat, allotted_hrs,
    rem_allotted_hrs, rem_avail_hrs, excs_hrs_billed, contract_year_nbr
    from contract_hrs
    where contract_id
    in (select cb.contract_id from contract_base cb join contract_detail cd on cb.CONTRACT_ID = cd.CONTRACT_ID where contract_start_dat > TO_DATE(\'#{date}\') and rownum <=1 )
    order by contract_id,  activity_start_dat asc
  SQL
end

def contract_past_activity(date)
  <<-SQL.gsub(/^ {6}/, '')
    select contract_id, activity_start_dat, activity_end_dat, allotted_hrs,
    rem_allotted_hrs, rem_avail_hrs, excs_hrs_billed, contract_year_nbr
    from contract_hrs
    where contract_id
    in (select cb.contract_id from contract_base cb join contract_detail cd on cb.CONTRACT_ID = cd.CONTRACT_ID where cd.contract_end_dat < TO_DATE(\'#{date}\') and rownum <=1 )
    order by contract_id,  activity_start_dat asc
  SQL
end

def contract_current_activity(date)
  <<-SQL.gsub(/^ {6}/, '')
    select contract_id, activity_start_dat, activity_end_dat, allotted_hrs,
    rem_allotted_hrs, rem_avail_hrs, excs_hrs_billed, contract_year_nbr
    from contract_hrs
    where contract_id
    in (select cb.contract_id from contract_base cb join contract_detail cd on cb.CONTRACT_ID = cd.CONTRACT_ID where cd.contract_start_dat < TO_DATE(\'#{date}\')
    and cd.contract_end_dat > TO_DATE(\'#{date}\') and rownum <=1)
    order by contract_id asc,  activity_start_dat asc
  SQL
end


def card_contract_current_activity(date)
  <<-SQL.gsub(/^ {6}/, '')
    select contract_id, activity_start_dat, activity_end_dat, allotted_hrs,
    rem_allotted_hrs, rem_avail_hrs, excs_hrs_billed, contract_year_nbr
    from contract_hrs
    where contract_id
    in (select cb.contract_id from contract_base cb join contract_detail cd on cb.CONTRACT_ID = cd.CONTRACT_ID where cd.contract_start_dat < TO_DATE(\'#{date}\')
    and cd.contract_end_dat > TO_DATE(\'#{date}\') and cb.contract_type_id = 17 and rownum <=1)
    order by contract_id asc,  activity_start_dat desc
  SQL
end

def non_card_contract_activity(date)
  <<-SQL.gsub(/^ {6}/, '')
    select contract_id, activity_start_dat, activity_end_dat, allotted_hrs,
    rem_allotted_hrs, rem_avail_hrs, excs_hrs_billed, contract_year_nbr
    from contract_hrs
    where contract_id
    in (select cb.contract_id from contract_base cb join contract_detail cd on cb.CONTRACT_ID = cd.CONTRACT_ID where cd.contract_start_dat < TO_DATE(\'#{date}\')
    and cd.contract_end_dat > TO_DATE(\'#{date}\') and cb.contract_type_id = 8 and rownum <=1)
    order by contract_id asc,  activity_start_dat desc
  SQL
end


def get_hours_info_sql(id)
  # sql to get a operational variation, but other variations are not present
  <<-SQL.gsub(/^ {6}/, '')
        select addl_hrs, allotted_hrs, used_hrs, tot_allotted_hrs, tot_avail_hrs, rem_allotted_hrs, rem_avail_hrs, activity_start_dat, activity_end_dat
        from contract_hrs where contract_id = #{id}
        order by activity_start_dat desc
  SQL
end

def get_card_projected_hours_info_sql(id, as_of_date)
  <<-SQL.gsub(/^ {6}/, '')
         select lc.contract_rem_hrs as contract_rem_hrs,
         nai.billing_cycle_ts as billing_cycle_ts,
         ch.ACTIVITY_START_DAT as asd, ch.ACTIVITY_END_DAT as aed from leg leg
         left outer join leg_contract_charges lc
         on leg.LEGID=lc.leg_id
         left outer join netjets_activity_invoice nai
         on lc.netjets_activity_invoice_id=nai.invoice_id
         left outer join contract_base c
         on nai.contract_id=c.CONTRACT_ID
         left outer join CONTRACT_HRS ch
         on c.CONTRACT_ID=ch.CONTRACT_ID
         where ch.CONTRACT_ID=#{id} and (nai.invoice_status_cd in (1 , 2))
         and (lc.contract_rem_hrs is not null)
         and nai.billing_cycle_ts>=  to_date('#{as_of_date}','yyyy-mm-dd')
         order by nai.billing_cycle_ts desc, leg.etd_tm desc
  SQL
end

def get_non_card_projected_hours_info_sql(id, as_of_date, currentStartDate, currentEndDate)
  <<-SQL.gsub(/^ {6}/, '')
        select lc.contract_rem_hrs as contract_rem_hrs,
        nai.billing_cycle_ts as billing_cycle_ts,
        ch.ACTIVITY_START_DAT as asd, ch.ACTIVITY_END_DAT as aed from leg leg
        left outer join leg_contract_charges lc
        on leg.LEGID=lc.leg_id
        left outer join netjets_activity_invoice nai
        on lc.netjets_activity_invoice_id=nai.invoice_id
        left outer join contract_base c
        on nai.contract_id=c.CONTRACT_ID
        left outer join CONTRACT_HRS ch
        on c.CONTRACT_ID=ch.CONTRACT_ID
        where ch.CONTRACT_ID=#{id}   and (nai.invoice_status_cd in (1 , 2))
        and (lc.contract_rem_hrs is not null)
        and leg.etd_tm >  to_date('#{as_of_date}', 'yyyy-mm-dd')
        and nai.billing_cycle_ts>=  to_date('#{currentStartDate}','yyyy-mm-dd')
        and nai.billing_cycle_ts<= to_date('#{currentEndDate}','yyyy-mm-dd')
        order by nai.billing_cycle_ts desc, leg.etd_tm desc
  SQL
end

def get_current_card_contract_hrs(id)
  <<-SQL.gsub(/^ {6}/, '')
        select * from contract_hrs where contract_id = #{id}
  SQL
end

def get_current_non_card_contract_hrs(id)
  <<-SQL.gsub(/^ {6}/, '')
        select * from contract_hrs where contract_id = #{id}
        and activity_end_dat > SYSDATE and activity_start_dat < SYSDATE
  SQL
end