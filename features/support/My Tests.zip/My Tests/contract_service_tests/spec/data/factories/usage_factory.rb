require 'json'
require 'data/models/contract_detail'
require 'faker'

class UsageFactory

  def self.multiple_regular_hours
    default_card_json = File.read("#{File.dirname(__FILE__)}/../../data/json/usage/create_multiple_regular_hour_usage.json")
    JSON.parse(default_card_json)
  end

  def self.single_regular_hour
    default_card_json = File.read("#{File.dirname(__FILE__)}/../../data/json/usage/create_single_regular_hour_usage.json")
    JSON.parse(default_card_json)
  end

  def self.single_excess_hour
    default_card_json = File.read("#{File.dirname(__FILE__)}/../../data/json/usage/create_single_excess_hour_usage.json")
    JSON.parse(default_card_json)
  end

  def self.single_short_leg_waiver
    default_card_json = File.read("#{File.dirname(__FILE__)}/../../data/json/usage/create_single_short_leg_waiver_usage.json")
    JSON.parse(default_card_json)
  end
end