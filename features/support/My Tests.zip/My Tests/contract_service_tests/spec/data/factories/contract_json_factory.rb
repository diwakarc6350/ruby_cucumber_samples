require 'json'
require 'data/models/card'
require 'faker'

class ContractJsonFactory
  def self.create_default_card_contract
    default_card_json = File.read("#{File.dirname(__FILE__)}/../../data/json/create_standard_card_contract.json")
    new_contract = JSON.parse(default_card_json)
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract
  end

  def self.create_combo_card_contract
    combo_card_json = File.read("#{File.dirname(__FILE__)}/../../data/json/create_combo_card_contract.json")
    new_contract = JSON.parse(combo_card_json)
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract = self.add_variation_type(new_contract)
    new_contract
  end

  def self.create_standard_card_contract_with_bonus_hours
    default_card_json = File.read("#{File.dirname(__FILE__)}/../../data/json/create_standard_card_with_bonus_hours.json")
    new_contract = JSON.parse(default_card_json)
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract
  end

  def self.create_half_card
    new_contract = JSON.parse(File.read("#{File.dirname(__FILE__)}/../../data/json/create_half_card_contract.json"))
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract
  end

  def self.create_fifty_hour_card
    new_contract = JSON.parse(File.read("#{File.dirname(__FILE__)}/../../data/json/create_fifty_hour_card_contract.json"))
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract
  end

  def self.create_china_card
    new_contract = JSON.parse(File.read("#{File.dirname(__FILE__)}/../../data/json/china_card_contract.json"))
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract = self.add_variation_type(new_contract)
    new_contract
  end

  def self.create_x_country_card
    new_contract = JSON.parse(File.read("#{File.dirname(__FILE__)}/../../data/json/xcountry_card_contract.json"))
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract
  end

  def self.create_nj_promo_card
    new_contract = JSON.parse(File.read("#{File.dirname(__FILE__)}/../../data/json/nj_promo_card_contract.json"))
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract
  end

  def self.create_referral_card
    new_contract = JSON.parse(File.read("#{File.dirname(__FILE__)}/../../data/json/referral_card_contract.json"))
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract
  end

  def self.create_redemption_card
    new_contract = JSON.parse(File.read("#{File.dirname(__FILE__)}/../../data/json/redemption_card_contract.json"))
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract
  end

  def self.create_demo_card
    new_contract = JSON.parse(File.read("#{File.dirname(__FILE__)}/../../data/json/demo_card_contract.json"))
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract
  end

  def self.create_gateway_card
    new_contract = JSON.parse(File.read("#{File.dirname(__FILE__)}/../../data/json/gateway_card_contract.json"))
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract
  end

  def self.create_thirty_six_month_card
    new_contract = JSON.parse(File.read("#{File.dirname(__FILE__)}/../../data/json/create_thirty_six_month_card_contract.json"))
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract
  end

  def self.create_pug_standard_card
    new_contract = JSON.parse(File.read("#{File.dirname(__FILE__)}/../../data/json/pug_standard_card_contract.json"))
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract
  end

  def self.create_pug_fifty_hour_card
    new_contract = JSON.parse(File.read("#{File.dirname(__FILE__)}/../../data/json/pug_fifty_hour_card_contract.json"))
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract
  end

  def self.create_pug_combo_card
    new_contract = JSON.parse(File.read("#{File.dirname(__FILE__)}/../../data/json/pug_combo_card_contract.json"))
    new_contract['card']['cardNumber'] = Card.available_card_number
    new_contract
  end

  private
  def self.add_variation_type(json)
    variations = %w(Billing Operational)
    billing_variations = Card.find_by_sql("select * from code_table_trans ctt where ctt.tag = 'BillingContractVariationType'")
    .map(&:attributes).map { |hash| hash['code'].to_i }

    operational_variations = Card.find_by_sql("select * from code_table_trans ctt where ctt.tag = 'OperationalContractVariationType'")
    .map(&:attributes).map { |hash| hash['code'].to_i }

    json['contracts'].each do |contract|
      rand(0..4).times do
        variation = variations.sample
        variation_type = eval("#{variation.downcase}_variations.to_a.sample")
        contract['variation'] << {'description' => Faker::Lorem.sentence, 'variationCategory' => variation, 'contractVarTypeId' => variation_type}
      end
    end

    json
  end

end