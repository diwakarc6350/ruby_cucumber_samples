require 'rest_shared_context'

def response_as_json(request, auth)
  begin
     log.info("Request : #{request}" + "&access_token=#{auth[:headers][:Authorization][7..43]}")
    response = rest.get(request, SSL_OPTIONS.merge(auth))
    JSON response.body
  rescue => rest_exception
    if (rest_exception.response.length == 0)
      rest_exception
    else
      JSON rest_exception.response
    end
  end
end

def post_as_json(request, data, auth)
  begin
    headers = {
        'Content-Type' => 'application/json',
        'appAgent' => 'AccountManagementUser',
        'Authorization' => auth[:headers][:Authorization]
    }
    # log.info("Request : #{request}")
    # log.info("Data : #{data}")
    # log.info("auth : #{headers}")
    response = @rest
    .post(request,
          :body => data, :headers => headers, :verify_ssl => true, :ssl_version => "SSLv23"
    )
    JSON response.body
  rescue => rest_exception
    if rest_exception.response.length == 0
      rest_exception
    else
      JSON rest_exception.response
    end
  end
end

def put_as_json(request, data, auth)
  begin
    headers = {
        'Content-Type' => 'application/json',
        'appAgent' => 'AccountManagementUser',
        'Authorization' => auth[:headers][:Authorization]
    }
    # log.info("Request : #{request}")
    # log.info("Data : #{data}")
    # log.info("auth : #{headers}")
    response = @rest
    .put(request,
         :body => data, :headers => headers, :verify_ssl => true, :ssl_version => "SSLv23"
    )
    JSON response.body
  rescue => rest_exception
    if rest_exception.response.length == 0
      rest_exception
    else
      JSON rest_exception.response
    end
  end
end