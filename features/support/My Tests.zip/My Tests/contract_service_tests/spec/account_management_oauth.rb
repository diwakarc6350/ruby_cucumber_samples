require 'oauth2'
require 'host_names'

class AccountManagementOauth

  attr_reader :oauth

  OAUTH_CLIENT_ID = '63bfa6c7-ebc3-44e3-80e4-bc6b8fa1f55a'
  OAUTH_CLIENT_SECRET = 'ed34b9d6-59f0-4840-82c3-ddb8a7825c29'

  OAUTH_SSL_OPTIONS = {
      ca_file: File.dirname(__FILE__)+"/../resources/cacert.pem",
      verify: true
  }

  def initialize
    @oauth = OAuth2::Client.new(OAUTH_CLIENT_ID, OAUTH_CLIENT_SECRET,
                                :token_url => "https://#{oauth_host}/auth/oauth/v2/token",
                                :ssl => OAUTH_SSL_OPTIONS)
  end

  def oauth_header_template(oauth_token)
    {headers: {Authorization: "Bearer #{oauth_token}"}}
  end

  def invalid_oauth_header
    oauth_header_template '123-456'
  end

  USER_MAP = {
      local: {
          authorized: 'qatest1',
          unauthorized: 'qatest100'
      },
      ci: {
          authorized: 'qatest1',
          unauthorized: 'qatest100'
      },
      itg: {
          authorized: 'qatest1',
          unauthorized: 'qatest100'
      },
      itg1: {
          authorized: 'qatest1',
          unauthorized: 'qatest100'
      },
      itg2: {
          authorized: 'qatest1',
          unauthorized: 'qatest100'
      },
      qa: {
          authorized: 'qatest1',
          unauthorized: 'qatest2'
      },
      patch: {
          authorized: 'qatest3',
          unauthorized: 'qatest100'
      },
      cat: {
          authorized: 'qatest3',
          unauthorized: 'qatest100'
      },
      clone: {
          authorized: 'qatest3',
          unauthorized: 'qatest100'
      },
      train: {
          authorized: 'qatest3',
          unauthorized: 'qatest100'
      },
  }

  def unauthorized_oauth_header
    token = oauth.password.get_token(USER_MAP[environment][:unauthorized], 'Aut0P1l0t!')
    oauth_header_template token.token
  end

  def authorized_oauth_header(force_user='', force_password='')
    if force_user.empty?
      token = oauth.password.get_token(USER_MAP[environment][:authorized], 'Aut0P1l0t!')
      oauth_header_template token.token
    elsif not force_user.empty? and force_password.empty?
      token = oauth.password.get_token(force_user, 'Aut0P1l0t!')
      oauth_header_template token.token
    elsif not force_user.empty? and not force_password.empty?
      token = oauth.password.get_token(force_user, force_password)
      puts
      oauth_header_template token.token
    end
  end

end