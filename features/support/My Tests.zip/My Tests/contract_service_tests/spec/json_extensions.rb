class Hash
  def clear_self_key
    self["self"] = nil
  end
end

class Array
  def clear_self_key
    self.each {|item| item["self"] = nil}
  end
end