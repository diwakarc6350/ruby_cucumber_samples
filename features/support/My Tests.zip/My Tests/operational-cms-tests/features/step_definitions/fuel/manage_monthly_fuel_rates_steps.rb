Given(/^that I am a Product Admin$/) do
  login_to_OCMS
end

Then(/^I can access Fuel Management$/) do
  open_fuel_management
  expect(fuel_type_average_table.first.three_month_average_element.exists?).to be true
end

When(/^I select a month\/year combination$/) do
  login_to_OCMS
  open_fuel_management
  select_fuel_type_rate_date
end

Then(/^the 3 Month Average rate is the sum of the selected month and the previous two months divided by three$/) do
  expected_three_month_averages = calculate_current_three_month_averages('nja')
  expect(fuel_type_and_three_month_average).to match_array(expected_three_month_averages)
end

Then(/^the correct fuel types exist for all companies$/) do
  expected_fuel_types = ['Standard', 'Long Range']

  login_to_OCMS
  open_fuel_management
  select_fuel_type_rate_date('Apr')
  select_company('NJA')
  expect(fuel_types.uniq - expected_fuel_types).to match_array([])
  expect(commercial_statuses.uniq).to match_array(nja_commercial_status)
  select_company('NJE')
  expect(fuel_types.uniq - expected_fuel_types).to match_array([])
  expect(commercial_statuses.uniq).to match_array(['N/A'])
end

When(/^I calculate the average price of fewer than three months$/) do
  login_to_OCMS
  open_fuel_management
  select_first_effective_month
end

Then(/^N\/A is displayed$/) do
  ensure_fuel_rates_are_nonexistent
end

Then(/^the Fuel Type \/ Rate table has data going back 7 years$/) do
  login_to_OCMS
  open_fuel_management
  current_year = Date.today.year.to_s
  highest_selectable_year = effective_years.sort[-1]
  number_of_years_available = effective_years.size
  expect(number_of_years_available).to eq(7)
  expect(highest_selectable_year).to eq(current_year)
end

Then(/^the Fuel Type \/ Rate table has data going forward one month$/) do
  login_to_OCMS
  open_fuel_management
  expect(max_effective_year_month_combination).to eq(expected_max_effective_year_month_combination)
end

Then(/^only NJA and NJE are selectable companies$/) do
  login_to_OCMS
  open_fuel_management
  expect(selectable_companies).to match_array(['NJA', 'NJE'])
end

Then(/^the monthly average rate is positive$/) do
  ensure_fuel_rates_are_positive
end

When(/^I edit an invoiced fuel type monthly average rate$/) do
  login_to_OCMS
  open_fuel_management
  @scenario_context.invoiced_fuel_type = first_invoiced_fuel_type
end

Then(/^I am not able to edit it$/) do
  expect(@scenario_context.invoiced_fuel_type.someField).to be(disabled)
end

When(/^I edit a non\-invoiced fuel type monthly average rate$/) do
  login_to_OCMS
  open_fuel_management
  @scenario_context.non_invoiced_fuel_type = first_non_invoiced_fuel_type
end

Then(/^I am able to edit it$/) do
  expect(@scenario_context.non_invoiced_fuel_type.someField).not_to be(disabled)
end

When(/^I select a future month where no data exists$/) do
  login_to_OCMS
  open_fuel_management
  delete_future_fuel_data
  select_last_effective_month
end

Then(/^the month is populated with the previous month's data$/) do
  expect(fuel_types_and_commercial_statuses).to eq(previous_month_fuel_types)
end

When(/^I select a random month\/year combination$/) do
  login_to_OCMS
  open_fuel_management
  select_random_fuel_type_rate_date
end


When(/^I save a fuel type value$/) do
  login_to_OCMS
  open_fuel_management
  @scenario_context.fuel_rate = Faker::Commerce.price
  set_first_monthly_average_rate(@scenario_context.fuel_rate)
  save_fuel_type_rates
end

Then(/^the value is saved$/) do
  expect(first_monthly_average_rate).to include(@scenario_context.fuel_rate.to_s)
end

And(/^the 3 Month Average is updated$/) do
  company = on(FuelManagementPage).company
  if company == 'NJA'
    calculated_three_month_average_rate = calculate_current_three_month_averages('nja')['Standard Commercial']
  elsif company == 'NJE'
    calculated_three_month_average_rate = calculate_current_three_month_averages('nje')['Standard']
  end
  expect(first_three_month_average).to eq(calculated_three_month_average_rate)
end

Given(/^that I am a Product Admin for (.*)$/) do |company|
  login_to_OCMS(OCMSUsers.const_get("#{company.upcase}_USER"))
end

When(/^I change my default company$/) do
  open_settings
  select_default_company('NJE')
  save_settings
end

Then(/^Then the company Fuel Rate defaults to that company$/) do
  open_fuel_management
  expect(current_company_option).to eq 'NJE'
end