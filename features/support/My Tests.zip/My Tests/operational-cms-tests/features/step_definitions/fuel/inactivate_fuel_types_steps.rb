Given(/^there is an active Fuel Type$/) do
  login_to_OCMS
  open_fuel_management
  expect(active_fuel_types_exist?).to be true
end

When(/^I navigate to a future month$/) do
  advance_to_next_month
end

Then(/^the active Fuel Type is present in the future month$/) do
  expect(current_month_active_fuel_types).to eq(previous_month_unchecked_fuel_types)
end

When(/^I inactivate a Fuel Type in the current month$/) do
  login_to_OCMS
  open_fuel_management
  inactivate_first_fuel_type
  save_changes
end

Then(/^the Fuel Type can be reactivated$/) do
  activate_first_fuel_type
  save_changes
  expect(first_fuel_type_is_active?).to be true
end
