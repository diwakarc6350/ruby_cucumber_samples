When(/^I create a fuel type rate for an aircraft$/) do
  login_to_OCMS
  open_fuel_management
  @scenario_context.ac_type = fuel_rate_data[:create_new_aircraft][:ac_type]
  @scenario_context.fuel_type = fuel_rate_data[:create_new_aircraft][:fuel_type]
  @scenario_context.effective_date = Date.today
  create_ac_type_fuel_rate(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)
end

Then(/^the aircraft fuel rate is added to the fuel rate list$/) do
  saved_ac_type_fuel_rate = find_ac_type_fuel_rate(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)
  expect(@scenario_context.ac_type).to eq saved_ac_type_fuel_rate.ac_type_element.text
  expect(@scenario_context.fuel_type).to eq saved_ac_type_fuel_rate.fuel_type.strip
  expect(@scenario_context.effective_date.strftime('%m/%d/%Y')).to eq saved_ac_type_fuel_rate.effective_date_element.text
  # expect(@new_fuel_rate.variable_rate).to saved_ac_type_fuel_rate.variable_rate
  # expect(@new_fuel_rate.differential).to saved_ac_type_fuel_rate.differential
  # expect(@new_fuel_rate.established_variable).to saved_ac_type_fuel_rate.established_variable
  # expect(@new_fuel_rate.established_rate).to saved_ac_type_fuel_rate.established_rate
end

Given(/^an existing fuel type rate entry$/) do
  @scenario_context.ac_type = fuel_rate_data[:update_new_aircraft][:ac_type]
  @scenario_context.fuel_type = fuel_rate_data[:update_new_aircraft][:fuel_type]
  @scenario_context.effective_date = Date.today
  login_to_OCMS
  open_fuel_management
  create_ac_type_fuel_rate(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)
  @scenario_context.non_invoiced_ac_fuel_rate = ac_type_fuel_rate_attributes(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)
end

When(/^I delete the aircraft fuel type rate$/) do
  delete_rate(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)
end

Then(/^the aircraft fuel type rate is removed$/) do
  expect(ac_type_fuel_rates).to_not include @scenario_context.non_invoiced_ac_fuel_rate
end

When(/^I edit the aircraft fuel type rate$/) do
  @scenario_context.new_established_variable = 0.10
  @scenario_context.new_variable_rate = 3.30
  @scenario_context.edited_fuel_rate = edit_ac_fuel_rate(@scenario_context.ac_type,
                                                         @scenario_context.fuel_type,
                                                         @scenario_context.effective_date,
                                                         established_variable: @scenario_context.new_established_variable,
                                                         variable_rate: @scenario_context.new_variable_rate)
end

Then(/^the aircraft fuel rate is updated$/) do
  edited_ac_type_fuel_rate = find_ac_type_fuel_rate(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)
  expect(edited_ac_type_fuel_rate.established_variable_element.text.gsub('$', '').to_f).to eq @scenario_context.new_established_variable
  expect(edited_ac_type_fuel_rate.variable_rate_element.text.gsub('$', '').to_f).to eq @scenario_context.new_variable_rate

end

When(/^I clone the aircraft fuel type rate$/) do
  @scenario_context.cloned_rate = last_ac_fuel_rate
  @scenario_context.cloned_rate.clone
end

Then(/^the aircraft fuel rate is duplicated$/) do
  new_rate = on(FuelManagementPage).ac_type_fuel_rates[-2]
  expect(@scenario_context.cloned_rate.ac_type_element.text).to eq new_rate.ac_type_element.text
  expect(@scenario_context.cloned_rate.variable_rate_element.text).to eq new_rate.variable_rate_element.text
  expect(@scenario_context.cloned_rate.differential_element.text).to eq new_rate.differential_element.text
  expect(@scenario_context.cloned_rate.established_variable_element.text).to eq new_rate.established_variable_element.text
  expect(@scenario_context.cloned_rate.established_rate_element.text).to eq new_rate.established_rate_element.text
  expect(@scenario_context.cloned_rate.variable_rate_element.text).to eq new_rate.variable_rate_element.text
  expect(@scenario_context.cloned_rate.fuel_type).to eq new_rate.fuel_type
end


Given(/^the aircraft type fuel rate list has effective entries for a previous month$/) do
  login_to_OCMS
  open_fuel_management
  @scenario_context.ac_type = fuel_rate_data[:previous_month_aircraft][:ac_type]
  @scenario_context.fuel_type = fuel_rate_data[:previous_month_aircraft][:fuel_type]
  @scenario_context.effective_date = Date.today - 1.month
  create_ac_type_fuel_rate(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)
  select_fuel_type_rate_date(@scenario_context.effective_date.strftime('%b'))
  @scenario_context.old_ac_fuel_rate = ac_type_fuel_rate_attributes(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)
end

When(/^I create the same fuel rate entry for the current month$/) do
  create_ac_type_fuel_rate(@scenario_context.ac_type, @scenario_context.fuel_type, Date.today.end_of_month)
  @scenario_context.new_ac_fuel_rate = ac_type_fuel_rate_attributes(@scenario_context.ac_type, @scenario_context.fuel_type, Date.today.end_of_month)
end

And(/^I open next month's fuel rates$/) do
  next_month = (Date.today + 1.month).strftime('%b')
  select_fuel_type_rate_date(next_month)
  randomize_monthly_average_rates

end

Then(/^the old fuel rate entry is no longer in the list$/) do
  expect(ac_type_fuel_rates).to_not include @scenario_context.old_ac_fuel_rate
  expect(ac_type_fuel_rates).to include @scenario_context.new_ac_fuel_rate
end

When(/^I open the aircraft type fuel rate manager$/) do
  login_to_OCMS
  open_fuel_management
end

Then(/^the aircraft fuel rates are sorted by rank and effective date$/) do
  sorted_ac_type_fuel_rates = ac_type_fuel_rates.sort_by do |record|
    rank = AcftAircraftType.find_by_aircraft_type_name(record[:ac_type]).display_rnk
    rank ||= 999
  end
  sorted_ac_type_fuel_rates = sorted_ac_type_fuel_rates.sort_by { |record| record[:effective_date] }
  expect(ac_type_fuel_rates).to eq sorted_ac_type_fuel_rates
end

When(/^I add a new aircraft fuel type fuel rate with a negative Established Variable$/) do
  login_to_OCMS
  open_fuel_management
  ac_type = fuel_rate_data[:negative_established_rate][:ac_type]
  fuel_type = fuel_rate_data[:negative_established_rate][:fuel_type]
  effective_date = Date.today
  create_ac_type_fuel_rate(ac_type, fuel_type, effective_date, established_variable: -2)
  @scenario_context.new_ac_fuel_rate = find_ac_type_fuel_rate(ac_type, fuel_type, effective_date)
end

Then(/^the entry is saved with the negative value$/) do
  expect(@scenario_context.new_ac_fuel_rate.established_variable_element.text).to eq '($2.00)'
end

When(/^I add a new aircraft fuel type rate with a negative Differential$/) do
  login_to_OCMS
  open_fuel_management
  edit_last_ac_fuel_rate(differential: -2)
end

When(/^I add a new aircraft fuel type rate with a negative Variable Rate$/) do
  login_to_OCMS
  open_fuel_management
  edit_last_ac_fuel_rate(variable_rate: -4)
end

Then(/^the entry is not saved$/) do
  expect(constraint_error).to eq 'Positive decimals only'
end

Given(/^a cloned aircraft type fuel rate$/) do
  login_to_OCMS
  open_fuel_management
  ac_fuel_rate = last_ac_fuel_rate
  ac_fuel_rate.effective_date
  ac_fuel_rate.editable_effective_date = Date.today.strftime('%m-%d-%Y')
  ac_fuel_rate.submit_effective_date
  ac_fuel_rate.clone
end

When(/^I try to save the rate with the same same information$/) do
  save_changes
end

Then(/^the duplicate aircraft fuel type rate is not saved$/) do
  expect(save_error).to match /Change created non-unique AC Type Rate|New AC Type Rate is not unique/
end

When(/^I filter for an aircraft type$/) do
  ac_type_filter = fuel_rate_data[:filter_aircraft_type][:valid]
  login_to_OCMS
  open_fuel_management
  @scenario_context.ac_type_filter = ac_type_filter
  filter_ac_type(@scenario_context.ac_type_filter = ac_type_filter)
end

Then(/^only the relevant aircraft types are displayed$/) do
  filtered_ac_types = ac_type_fuel_rates.map { |x| x[:ac_type] }
  filtered_ac_types.each do |filtered_ac_type|
    expect(filtered_ac_type).to include(@scenario_context.ac_type_filter)
  end
end

When(/^I filter for an invalid aircraft type$/) do
  ac_type_filter = fuel_rate_data[:filter_aircraft_type][:invalid]
  login_to_OCMS
  open_fuel_management
  @scenario_context.ac_type_filter = ac_type_filter
  filter_ac_type(@scenario_context.ac_type_filter = ac_type_filter)
end

Then(/^no aircraft types should be displayed$/) do
  filtered_ac_types = ac_type_fuel_rates.map { |x| x[:ac_type] }
  expect(filtered_ac_types.length).to eq(0)
end

When(/^I clear aircraft type filter$/) do
  ac_type_filter = fuel_rate_data[:filter_aircraft_type][:valid]
  login_to_OCMS
  open_fuel_management
  @scenario_context.original_results = ac_type_fuel_rates
  @scenario_context.ac_type_filter = ac_type_filter
  filter_ac_type(@scenario_context.ac_type_filter = ac_type_filter)
  filter_ac_type
end

Then(/^I should see the aircraft type fuel rate reset to original state$/) do
  expect(ac_type_fuel_rates.length).to eq(@scenario_context.original_results.length)
end