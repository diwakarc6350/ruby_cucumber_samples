When(/^I select NJA fuel type rates$/) do
  login_to_OCMS
  open_fuel_management
  select_company('NJA')
end

Then(/^they are listed with commercial statuses$/) do
  (expect(nja_statuses_are_visible).to be true) &&
      (expect(nje_statuses_are_visible).to be false)
end

When(/^I select NJE fuel type rates$/) do
  login_to_OCMS
  open_fuel_management
  select_company('NJE')
end

Then(/^they are listed without commercial statuses$/) do
  (expect(nja_statuses_are_visible).to be false) &&
      (expect(nje_statuses_are_visible).to be true)
end

Given(/^a fuel rate for an aircraft$/) do
  @scenario_context.ac_type = fuel_rate_data[:modifiable_aircraft][:ac_type]
  @scenario_context.fuel_type = fuel_rate_data[:modifiable_aircraft][:fuel_type]
  @scenario_context.effective_date = Date.today
  @scenario_context.new_established_variable = Faker::Number.decimal(1)
  login_to_OCMS
  open_fuel_management
  create_ac_type_fuel_rate(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date, established_variable: @scenario_context.new_established_variable)
  @scenario_context.non_invoiced_ac_fuel_rate = ac_type_fuel_rate_attributes(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)
end

When(/^I modify the monthly average fuel cost$/) do
  randomize_monthly_average_rates
end

Then(/^the monthly fuel rate is recalculated using the new monthly average fuel cost$/) do
  expect(monthly_fuel_rates(@scenario_context.ac_type,
                            @scenario_context.fuel_type,
                            @scenario_context.effective_date)).to eq(calculated_monthly_fuel_rates(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date))
end

And(/^the three month fuel rate is recalculated using the new monthly average fuel cost$/) do
  expect(three_month_fuel_rates(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)).to eq(calculated_three_month_fuel_rates(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date))
end

When(/^I modify the established rate$/) do
  @scenario_context.new_established_variable = Faker::Number.decimal(1)
  @scenario_context.edited_fuel_rate = edit_ac_fuel_rate(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date, established_variable: @scenario_context.new_established_variable, variable_rate: @scenario_context.new_established_variable)
end

Then(/^the monthly fuel rate is recalculated using the new established rate$/) do
  expect(monthly_fuel_rates(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)).to eq(calculated_monthly_fuel_rates(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date))
end

And(/^the three month fuel rate is recalculated using the new established rate$/) do
  expect(three_month_fuel_rates(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)).to eq(calculated_three_month_fuel_rates(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date))
end

When(/^I modify the differential$/) do
  @scenario_context.new_differential = Faker::Number.decimal(0)
  @scenario_context.edited_fuel_rate = edit_ac_fuel_rate(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date, differential: @scenario_context.new_differential)
end

Then(/^the monthly fuel rate is recalculated using the new differential$/) do
  expect(monthly_fuel_rates(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)).to eq(calculated_monthly_fuel_rates(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date))
end

And(/^the three month fuel rate is recalculated using the new differential$/) do
  expect(three_month_fuel_rates(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)).to eq(calculated_three_month_fuel_rates(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date))
end

When(/^I modify the fuel variable rate$/) do
  @scenario_context.new_variable_rate = Faker::Number.decimal(1)
  @scenario_context.edited_fuel_rate = edit_ac_fuel_rate(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date, variable_rate: @scenario_context.new_variable_rate)
end

Then(/^the monthly fuel rate is recalculated using the new fuel variable rate$/) do
  expect(monthly_fuel_rates(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)).to eq(calculated_monthly_fuel_rates(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date))
end

And(/^the three month fuel rate is recalculated using the new fuel variable rate$/) do
  expect(three_month_fuel_rates(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date)).to eq(calculated_three_month_fuel_rates(@scenario_context.ac_type, @scenario_context.fuel_type, @scenario_context.effective_date))
end