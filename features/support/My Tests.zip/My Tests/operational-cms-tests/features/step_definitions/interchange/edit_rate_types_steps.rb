Given(/^an existing interchange rate type$/) do
  login_to_OCMS
  open_interchange
  @scenario_context.rate_type = interchange_rate_types[0]
  @scenario_context.rate_type_name = @scenario_context.rate_type.name
end

When(/^I edit the rate type$/) do
  @scenario_context.to = 'NetJets U.S.'
  @scenario_context.from = 'NJA'
  @scenario_context.xrate = Faker::Commerce.price
  @scenario_context.effective_date = (Date.strptime(@scenario_context.rate_type.effective_date, '%m/%d/%Y') + 1.day).strftime('%m/%d/%Y')

  edit_interchange_rate_type(@scenario_context.rate_type, to: @scenario_context.to,
                                                        from: @scenario_context.from,
                                                        effective_date: @scenario_context.effective_date,
                                                        exchange_rate: @scenario_context.xrate)
end

Then(/^the rate type is successfully modified$/) do
  modified_interchange_rate_type = find_interchange_rate_type(@scenario_context.rate_type_name)
  expect(modified_interchange_rate_type.to).to eq @scenario_context.to
  expect(modified_interchange_rate_type.from).to eq @scenario_context.from
  expect(modified_interchange_rate_type.effective_date).to eq @scenario_context.effective_date
  expect(modified_interchange_rate_type.exchange_rate.to_f).to eq @scenario_context.xrate.to_f
end

When(/^I modify the interchange xrate$/) do
  @scenario_context.new_xrate = Faker::Commerce.price
  pending("Rate Type is NOT Active During Given Month!") if @scenario_context.rate_type.nil?
  @scenario_context.rate_type.edit_exchange_rate(@scenario_context.new_xrate)
  save_interchange_rates
end

Then(/^the xrate is saved successfully$/) do
  modified_interchange_rate_type = find_interchange_rate_type(@scenario_context.rate_type_name)
  expect(save_interchange_error.text).to_not include 'error'
  expect(modified_interchange_rate_type.exchange_rate.to_f).to eq @scenario_context.new_xrate.to_f
end

Given(/^an existing interchange rate type for a future month$/) do
  login_to_OCMS
  open_interchange
  current_month_rate_type = interchange_rate_types[0]
  @scenario_context.rate_type_name = current_month_rate_type.name
  @scenario_context.current_month_xrate = current_month_rate_type.exchange_rate
  next_month = (Date.today + 1.month).strftime('%b')
  set_interchange_effective_month(next_month)
  @scenario_context.rate_type = find_interchange_rate_type(@scenario_context.rate_type_name)
end

And(/^the previous month's xrate is not modified$/) do
  current_month = (Date.today).strftime('%b')
  set_interchange_effective_month(current_month)
  previous_months_interchange_rate_type = find_interchange_rate_type(@scenario_context.rate_type_name)
  expect(previous_months_interchange_rate_type.exchange_rate).to include @scenario_context.current_month_xrate.to_s
end

When(/^I modify the name to a non\-unique interchange rate type name$/) do
  non_unique_rate_type_name = interchange_rate_types[1]
  edit_interchange_rate_type_without_update(non_unique_rate_type_name, interchange_name: @scenario_context.rate_type_name)
end

Then(/^the list cannot be saved$/) do
  expect{update_interchange_rate_type}.to raise_error(Watir::Exception::ObjectDisabledException)
end