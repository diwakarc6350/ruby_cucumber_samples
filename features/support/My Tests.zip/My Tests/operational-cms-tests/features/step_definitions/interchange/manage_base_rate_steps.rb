When(/^I select a rate type$/) do
  login_to_OCMS
  open_interchange
  select_rate_type
end

Then(/^the base rate table for that rate type is displayed$/) do
  expect(rate_type_header_information).to eq(rate_type_information)
end

When(/^I select a Base Rate table$/) do
  login_to_OCMS
  open_interchange
  select_rate_type
  show_all_aircraft
end

Then(/^the aircraft types displayed are the common names from AIS$/) do
  expect(interchange_from_aircraft_types).to match_array(interchange_to_aircraft_types)
  expect(ais_common_names).to match_array(interchange_from_aircraft_types)
end

And(/^the rate type information is shown on the rate type header$/) do
  expect(rate_type_header_information).to eq(rate_type_information)
end

When(/^I edit a Base Rate table$/) do
  login_to_OCMS
  open_interchange
  select_rate_type
  @scenario_context.new_base_rate_value = base_rate_value
  edit_base_rate_table_value(@scenario_context.new_base_rate_value)
end

Then(/^the edited values are persisted on the base rate table$/) do
  select_rate_type
  expect(first_base_rate_table_value).to eq(@scenario_context.new_base_rate_value)
end

When(/^I edit a Base Rate table with negative values$/) do
  login_to_OCMS
  open_interchange
  select_rate_type
  @scenario_context.new_base_rate_value = negative_base_rate_value
  edit_base_rate_table_value_without_saving(@scenario_context.new_base_rate_value)
end

Then(/^the edited values cannot be saved$/) do
 expect(first_base_rate_table_error).to eq('Positive numbers only')
end

Given(/^there is an inactive rate type$/) do
  login_to_OCMS
  open_interchange
end

When(/^I select the inactive rate type$/) do
  select_inactive_rate_type
end

Then(/^no values are displayed in base rate table$/) do
  expect(base_rate_table_empty?).to be true
end

When(/^I select a Base Rate table in a future month$/) do
  login_to_OCMS
  open_interchange
  advance_to_next_month
  select_rate_type
end

Given(/^an existing interchange rate type for a given month$/) do
  login_to_OCMS
  open_interchange
  advance_to_next_month
  @scenario_context.rate_type = interchange_rate_types[0]
  select_interchange_rate_type(@scenario_context.rate_type)
  @scenario_context.old_base_rate_value = base_rate_value
  edit_base_rate_table_value(@scenario_context.old_base_rate_value)
end

When(/^I go to the next billing month$/) do
  advance_to_next_month
end

And(/^add a exchange rate for that rate type$/) do
  rate_type = interchange_rate_types[0]
  select_interchange_rate_type(rate_type)
end

Then(/^the base rates from the previou month carry forward$/) do
  new_base_rate_value = first_base_rate_table_value
  expect(new_base_rate_value).to eq @scenario_context.old_base_rate_value
end