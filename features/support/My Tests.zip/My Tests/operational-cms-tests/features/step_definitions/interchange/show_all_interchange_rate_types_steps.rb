Given(/^there are inactive interchange rates for a given billing period$/) do
  login_to_OCMS
  open_interchange
end

When(/^I choose to include all available rates$/) do
  include_inactive_interchange_rate_types
end

Then(/^all the rates in the system are displayed$/) do
  expect(interchange_rate_types_attributes).to match_array expected_interchange_rates
end

And(/^the inactive rates are displayed with an inactive marker$/) do
  inactive_interchange_rate_types = interchange_rate_types.select {|type| type.inactive_date != ''}
  inactive_interchange_rate_types.each do |xrate|
    if Date.strptime(xrate.inactive_date, '%m/%d/%Y') < Date.today && Date.strptime(xrate.inactive_date, '%m/%d/%Y').month < Date.today.month
      expect(xrate.name).to include '(Inactive)'
    end
  end
end