When(/^I select a month\/year combination for rate types$/) do
  login_to_OCMS
  open_interchange
  select_random_interchange_month_year
end

Then(/^only the active rate types are displayed$/) do
  expect(only_active_rate_types_are_displayed?).to be true
end

When(/^I add a rate type with blank a blank base rate table$/) do
  login_to_OCMS
  open_interchange
  @scenario_context.rate_name = "Test Rate ##{interchange_rate_size}"
  create_interchange_rate_type(@scenario_context.rate_name, Date.today.strftime('%m/%d/%Y'))
end

Then(/^the table is updated with the rate type$/) do
  expect(interchange_rate_type_names).to include(@scenario_context.rate_name)
end

When(/^I add a rate type to the table with default rate selected$/) do
  login_to_OCMS
  open_interchange
  @scenario_context.rate_name = "Test Rate ##{interchange_rate_size}"
  @scenario_context.new_rate = Faker::Number.decimal(1)
  create_default_interchange_rate_type(@scenario_context.rate_name, Date.today.strftime('%m/%d/%Y'), exchange_rate: @scenario_context.new_rate)
end

Then(/^the table is updated with the default rate$/) do
  @scenario_context.defaulted_rate_name = 'Dependent Row'
  create_interchange_rate_type(@scenario_context.defaulted_rate_name, Date.today.strftime('%d/%m/%Y'))
  original_row = find_interchange_rate_type(@scenario_context.rate_name)
  dependent_row = find_interchange_rate_type(@scenario_context.defaulted_rate_name)
  expect(original_row.exchange_rate).to eq(dependent_row.exchange_rate)

end

Given(/^I add a rate type to the table without saving$/) do
  login_to_OCMS
  open_interchange
  @scenario_context.rate_name = "Test Rate ##{interchange_rate_size}"
  create_interchange_rate_type(@scenario_context.rate_name, Date.today.strftime('%m/%d/%Y'))
end

When(/^I refresh the page$/) do
  @browser.refresh
end

Then(/^the rate type is not displayed on the table$/) do
  expect(interchange_rate_type_names).to_not include(@scenario_context.rate_name)
end

And(/^the rate is not persisted to future months$/) do
  set_interchange_effective_month(Date.today.next_month.strftime('%b'))
  new_rate = find_interchange_rate_type(@scenario_context.rate_name)
  expect(new_rate.exchange_rate). to eq '-'
end

Then(/^the rate is persisted to future months$/) do
  set_interchange_effective_month(Date.today.next_month.strftime('%b'))
  new_rate = find_interchange_rate_type(@scenario_context.rate_name)
  expect(new_rate.exchange_rate.to_f). to eq @scenario_context.new_rate.to_f
end

And(/^the base rates are blank$/) do
  rate_type = find_interchange_rate_type(@scenario_context.rate_name)
  select_interchange_rate_type(rate_type)
  expect(base_rate_table_empty?).to be true
end