Given(/^existing base rates for an interchange rate type$/) do
  login_to_OCMS
  open_interchange
  @scenario_context.existing_rate_name = on(InterchangePage).rate_type_name
  create_interchange_rate_type(@scenario_context.existing_rate_name, Date.today.strftime('%m/%d/%Y'))
  @scenario_context.rate_type = find_interchange_rate_type(@scenario_context.existing_rate_name)
  set_random_number_of_base_rates_for_interchange_rate_type(@scenario_context.rate_type)
  @scenario_context.rate_type = find_interchange_rate_type(@scenario_context.existing_rate_name)
  @scenario_context.existing_base_rates = base_rates_for_interchange_rate_type(@scenario_context.rate_type).uniq
  save_interchange_rates
end

When(/^I create a new interchange rate type with a copy of the existing interchange rate type's base rates$/) do
  @scenario_context.new_rate_name = on(InterchangePage).rate_type_name
  create_interchange_rate_type(@scenario_context.new_rate_name, Date.today.strftime('%m/%d/%Y'), clonable_base_rate_types: @scenario_context.existing_rate_name)
end

Then(/^the new interchange type base rates match the existing interchange type base rates$/) do
  new_rate_type = find_interchange_rate_type(@scenario_context.new_rate_name)
  select_interchange_rate_type(new_rate_type)
  new_base_rates = base_rates_for_interchange_rate_type(new_rate_type).uniq

  expect(new_base_rates).to match_array @scenario_context.existing_base_rates

end

Given(/^an inactive interchange rate type$/) do
  login_to_OCMS
  open_interchange
  include_inactive_interchange_rate_types
  pending('No Inactive rates found!') if find_interchange_rate_type('(Inactive)').nil?
  @scenario_context.inactive_rate_type_name = find_interchange_rate_type('(Inactive)').name.gsub(/(Inactive)/, '')
end

When(/^I try to create a new interchange rate type$/) do
  create_new_interchange_rate_type
end

Then(/^I cannot copy base rates from the inactive interchange rate type$/) do
  expect(base_rate_copy_options).to_not include @scenario_context.inactive_rate_type_name
end