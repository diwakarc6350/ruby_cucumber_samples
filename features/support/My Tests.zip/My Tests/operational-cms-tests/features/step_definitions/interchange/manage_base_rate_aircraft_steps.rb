When(/^I hide an aircraft$/) do
  login_to_OCMS
  open_interchange
  select_rate_type
  ScenarioContext.hidden_aircraft = fuel_management_data[:hidden_aircraft][:aircraft]
  hide_aircraft(ScenarioContext.hidden_aircraft, nil)
end

Then(/^the aircraft does not appear on the base rate table$/) do
  select_rate_type
  expect(interchange_from_aircraft_types).to_not include(ScenarioContext.hidden_aircraft)
  expect(interchange_to_aircraft_types).to_not include(ScenarioContext.hidden_aircraft)
end

And(/^the aircraft is present on the manage aircraft window$/) do
  expect(managed_aircraft).to include(ScenarioContext.hidden_aircraft)
end

And(/^the aircraft is hidden on To and From by default$/) do
  expect(aircraft_is_hidden_to_and_from?(ScenarioContext.hidden_aircraft)).to be true
end

When(/^I hide a To aircraft$/) do
  login_to_OCMS
  open_interchange
  select_rate_type
  ScenarioContext.hidden_aircraft = fuel_management_data[:hidden_aircraft][:to_aircraft]
  hide_aircraft(ScenarioContext.hidden_aircraft, :from)
end

Then(/^the aircraft is still present as a From aircraft$/) do
  select_rate_type
  expect(interchange_from_aircraft_types).to include(ScenarioContext.hidden_aircraft)
end

When(/^I hide a From aircraft$/) do
  login_to_OCMS
  open_interchange
  select_rate_type
  ScenarioContext.hidden_aircraft = fuel_management_data[:hidden_aircraft][:from_aircraft]
  hide_aircraft(ScenarioContext.hidden_aircraft, :to)
end

Then(/^the aircraft is still present as a To aircraft$/) do
  select_rate_type
  expect(interchange_to_aircraft_types).to include(ScenarioContext.hidden_aircraft)
end

Given(/^an aircraft has been hidden$/) do
  login_to_OCMS
  open_interchange
  select_rate_type
  ScenarioContext.hidden_aircraft = fuel_management_data[:hidden_aircraft][:aircraft]
  hide_aircraft(ScenarioContext.hidden_aircraft, nil)
end

When(/^I unhide the aircraft$/) do
  select_rate_type
  unhide_aircraft(ScenarioContext.hidden_aircraft)
end

Then(/^the aircraft is present on the interchange table$/) do
  pending
end

Then(/^the aircraft is present on the base rate table$/) do
  select_rate_type
  expect(interchange_from_aircraft_types).to include(ScenarioContext.hidden_aircraft)
  expect(interchange_to_aircraft_types).to include(ScenarioContext.hidden_aircraft)
end

And(/^the aircraft is not present on the manage aircraft window$/) do
  expect(managed_aircraft).to_not include(ScenarioContext.hidden_aircraft)
end

And(/^the Show All link displays the number of hidden aircraft$/) do
  select_rate_type
  expect(number_of_hidden_aircraft).to eq(number_of_managed_aircraft)
end

And(/^I change the active rate type$/) do
  @scenario_context.rate_name = "Test Rate ##{interchange_rate_size}"
  create_interchange_rate_type(@scenario_context.rate_name, Date.today.strftime('%m/%d/%Y'))
  select_interchange_rate_type(find_interchange_rate_type(@scenario_context.rate_name))
end

Then(/^the aircraft is no longer hidden$/) do
  expect(interchange_from_aircraft_types).to include(ScenarioContext.hidden_aircraft)
  expect(interchange_to_aircraft_types).to include(ScenarioContext.hidden_aircraft)
end

When(/^I view the hidden aircraft using Show All$/) do
  select_rate_type
  show_all_aircraft
end

Then(/^all aircraft are present on the base rate table$/) do
  expect(interchange_from_aircraft_types).to match_array(interchange_to_aircraft_types)
  expect(interchange_from_aircraft_types).to match_array(ais_common_names)
end

And(/^hidden aircraft are marked with hidden in their names$/) do
  expect(managed_aircraft).to match_array(hidden_aircraft_to_and_from)
end

When(/^I save hidden aircraft$/) do
  login_to_OCMS
  open_interchange
  select_rate_type
  ScenarioContext.hidden_aircraft = fuel_management_data[:hidden_aircraft][:aircraft]
  hide_aircraft(ScenarioContext.hidden_aircraft, nil)
end

Then(/^the hidden aircraft are persisted$/) do
  pending
end

And(/^the aircraft are hidden in future months$/) do
  pending
end