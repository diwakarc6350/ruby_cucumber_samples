Given(/^an existing interchange rate type with a exchange rate$/) do
  login_to_OCMS
  open_interchange
  @scenario_context.rate_type = interchange_rate_types[0]
  select_interchange_rate_type(@scenario_context.rate_type)
end

And(/^an existing base rate for an aircraft combination$/) do
  @scenario_context.new_base_rate_value = base_rate_value
  edit_base_rate_table_value_without_saving(@scenario_context.new_base_rate_value)
  open_interchange_rate_for_current_rate_type
end

Then(/^the interchange rate for that aircraft combination is calculated$/) do
  expect(first_interchange_rate).to eq (@scenario_context.new_base_rate_value * @scenario_context.rate_type.exchange_rate.to_f).round(2)
end

Then(/^the interchange rate for that aircraft combination is recalculated$/) do
  expect(first_interchange_rate).to eq (@scenario_context.new_base_rate_value * @scenario_context.rate_type.exchange_rate.to_f).round(2)
end

Given(/^an existing base rate for an interchange rate type$/) do
  login_to_OCMS
  open_interchange
  @scenario_context.rate_type = interchange_rate_types[0]
  select_interchange_rate_type(@scenario_context.rate_type)
  @scenario_context.new_base_rate_value = base_rate_value
  edit_base_rate_table_value_without_saving(@scenario_context.new_base_rate_value)
  open_interchange_rate_for_current_rate_type
end

When(/^I edit the exchange rate for that interchange rate type$/) do
  @scenario_context.rate_type.edit_exchange_rate Faker::Commerce.price
end