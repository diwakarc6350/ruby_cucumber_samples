Given(/^I am creating a new Service Area$/) do
  login_to_OCMS
  open_areas
end

When(/^I search for an airport by Airport Code$/) do
  @scenario_context.airport_code = airport_codes.sample
  search_by_airport(@scenario_context.airport_code)
end

Then(/^only the airport matching that code is displayed$/) do
  airport_search_results = service_area_search_results.map(&:text)
  airport_search_results.delete("")
  expect(airport_search_results.size).to eq 1
  expect(airport_search_results.first).to eq @scenario_context.airport_code
end

When(/^I search a partial code for an airport$/) do
  @scenario_context.partial_airport_code = Faker::Lorem.characters(2)
  search_by_airport(@scenario_context.partial_airport_code)
end

Then(/^all airports with that search criteria are displayed$/) do
  airport_search_results = service_area_search_results.map(&:text)
  airport_search_results.each do |result|
    expect(result).to include @scenario_context.partial_airport_code.upcase
  end
end

And(/^I search for a different airport by Airport Code$/) do
  @scenario_context.airport_code = airport_codes.sample
  search_by_airport(@scenario_context.airport_code)
end

When(/^I search for a city by City Name$/) do
  @scenario_context.city_name = city_names.sample
  search_by_city(@scenario_context.city_name)
end

Then(/^only the city matching that name is displayed$/) do
  airport_search_results = service_area_search_results.map(&:text)
  airport_search_results.delete("")
  expect(airport_search_results.size).to eq(airport_search_results.uniq.size)
  expect(airport_search_results.first).to include @scenario_context.city_name.upcase
end

When(/^I search a partial city name$/) do
  @scenario_context.partial_city_name = random_letters(3)
  search_by_city(@scenario_context.partial_city_name)
end

Then(/^all cities with that search criteria are displayed$/) do
  airport_search_results = service_area_search_results.map(&:text)
  airport_search_results.each do |result|
    expect(result).to include @scenario_context.partial_city_name.upcase
  end
end

When(/^I search for a state by State Name$/) do
  @scenario_context.state_name = Faker::Address.state
  search_by_state(@scenario_context.state_name)
end

Then(/^only the state matching that name is displayed$/) do
  airport_search_results = service_area_search_results.map(&:text)
  airport_search_results.delete("")
  expect(airport_search_results.size).to eq (airport_search_results.uniq.size)
  expect(airport_search_results.first).to include @scenario_context.state_name
end

When(/^I search for a state by abbreviated State Name$/) do
  @scenario_context.state_name = Faker::Address.state_abbr
  search_by_state(@scenario_context.state_name)
end

Then(/^only the state matching that abbreviated name is displayed$/) do
  airport_search_results = service_area_search_results.map(&:text)
  airport_search_results.delete("")
  state_name = CodeTableStr.get_state_from_abbreviation(@scenario_context.state_name)
  expect(airport_search_results.size).to eq (airport_search_results.uniq.size)
  airport_search_results.each do |state|
    expect(state).to include(@scenario_context.state_name.downcase).or include(state_name)
  end
end