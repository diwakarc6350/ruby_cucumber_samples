When(/^I navigate to the details for that contract$/) do
  login_to_OCMS
  # @scenario_context.contract = OPContract.find(178735)
  # @scenario_context.account = @scenario_context.contract.account
  view_details(@scenario_context.contract)
end

Then(/^the hours information is displayed$/) do
  @scenario_context.contract_component = active_component(@scenario_context.contract)
  expected_detail_hours = expected_detail_hours_by_contract(@scenario_context.contract_component)
  detail_hours = contract_hours

  expect(expected_detail_hours).to match_array(detail_hours)
end

And(/^the correct hours information for the other contract in the combo is displayed$/) do
  open_other_contract_for_combo_card
  @scenario_context.contract_component = active_component(@scenario_context.contract)
  expected_detail_hours = expected_detail_hours_by_contract(@scenario_context.contract_component)
  detail_hours = contract_hours

  expect(expected_detail_hours).to match_array(detail_hours)
end

Then(/^the total allotted hours information is displayed$/) do
  @scenario_context.contract_component = active_component(@scenario_context.contract)
  expected_allotted_hours_information = expected_allotted_hours_by_contract(@scenario_context.contract_component)
  allotted_hours_information = detail_hours_information

  expect(expected_allotted_hours_information).to match_array(allotted_hours_information)
end

And(/^I view the account summary$/) do
  view_account_summary
end

Then(/^all the active contracts for that account are displayed$/) do
  all_contracts_for_account = expected_contract_summaries(@scenario_context.account.op_contracts)
  @scenario_context.contracts_for_account = all_contracts_for_account.select {|contract| contract[:contract_status] != 'Inactive'}
  expect(@scenario_context.contracts_for_account).to match_array(account_contracts_summary)
end

#TODO: Fix `expected_account_contracts_hours_total` method
And(/^the total number of hours for all the contracts are calculated$/) do
  expect(account_contracts_hours_total).to eq expected_account_contracts_hours_total(@scenario_context.contracts_for_account)
end

Then(/^all the contracts for that account are displayed$/) do
  @scenario_context.contracts_for_account = expected_contract_summaries(@scenario_context.account.op_contracts)
  expect( @scenario_context.contracts_for_account).to match_array(account_contracts_summary)
end

And(/^I show all the contracts for the account$/) do
  show_all_contracts_for_account
end