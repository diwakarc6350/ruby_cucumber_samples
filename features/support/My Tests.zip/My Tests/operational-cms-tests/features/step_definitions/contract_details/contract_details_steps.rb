When(/^I select the first contract from contract search$/) do
  view_first_contract
  @account_ar_nbr = current_account_ar_nbr
end

Then(/^the account details for that contract are displayed$/) do
  expect(account_header_information).to match_array(ijet_account_header_information(@account_ar_nbr))
  expect(header_legal_name).to eq(@scenario_context.contract.legal_entity.legal_name)
end

And(/^I select one of its contracts$/) do
  view_first_contract
  @account_ar_nbr = current_account_ar_nbr
end

Then(/^the details for that contract are displayed$/) do
  expect(contract_header_information).to match_array(expected_contract_header_information_attributes(@scenario_context.contract))
end


And(/^I can view the other contract for the combo card$/) do
  open_other_contract_for_combo_card
  expect(on(ContractDetailPage).aircraft_type).to eq @scenario_context.contract.aircraft_type_names[1]
end
