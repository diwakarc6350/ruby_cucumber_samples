Then(/^I can access the Peak Period Day Lists$/) do
  open_peak_period_days
end

When(/^I add a PPD list$/) do
  login_to_OCMS
  open_peak_period_days
  @scenario_context.list_name = "#{Faker::Team.name} List"
  add_ppd_list(@scenario_context.list_name, today_date)
end

Then(/^it appears on the PPD List$/) do
  expect(ppd_list_contains(@scenario_context.list_name)).to be true
end

When(/^I add a PPD List with past dates$/) do
  login_to_OCMS
  open_peak_period_days
  add_ppd_list_without_saving('Invalid List', '05/24/2013')
end

Then(/^the list is not saved/) do
  expect(on(PeakPeriodDaysPage).save_list_element.disabled?).to eq(true)
end

When(/^I add a PPD List with future dates$/) do
  login_to_OCMS
  open_peak_period_days
  add_ppd_list('Valid List', tomorrow_date)
end

Then(/^it is saved to the PPD List$/) do
  expect(ppd_list_contains('Valid List')).to be true
end

When(/^I add a PPD List with an inactive date$/) do
  login_to_OCMS
  open_peak_period_days
  add_ppd_list('Inactive Date List', today_date, tomorrow_date)
end

Then(/^it is saved to the PPD List with an inactive date$/) do
  expect(ppd_list_contains('Inactive Date List')).to be true
end

When(/^I edit a PPD List's name$/) do
  login_to_OCMS
  open_peak_period_days
  add_ppd_list('List To Edit', today_date)
  edit_ppd_list('List To Edit', 'Edited List Name')
end

Then(/^the PPD List is saved with the new name$/) do
  expect(ppd_list_contains('Edited List Name')).to be true
end

Given(/^an existing PPD list$/) do
  login_to_OCMS
  open_peak_period_days
  add_ppd_list('Existing List', today_date)
end

When(/^I create a PPD List with the same name$/) do
  add_ppd_list_without_saving('Existing List', today_date)
end

Then(/^the new list is not saved$/) do
  expect(on(PeakPeriodDaysPage).save_list_element.disabled?).to eq(true)
end

When(/^I select an effective year$/) do
  login_to_OCMS
  open_peak_period_days
  select_random_year
end

Then(/^only lists effective during that year are shown$/) do
  inactive_dates_are_within_current_year
  effective_dates_are_before_next_year
end

Then(/^effective years range from 2014 until the next year$/) do
  login_to_OCMS
  open_peak_period_days
  expect(effective_year_options).to eq(peak_period_day_years)
end

Given(/^a list that expires during the current year$/) do
  login_to_OCMS
  open_peak_period_days
  add_ppd_list('Expiring List', today_date, tomorrow_date)
end

When(/^I select the following year$/) do
  select_year(next_year)
end

Then(/^the list is not accessible$/) do
  expect(ppd_list_contains('Expiring List')).to be false
end

When(/^I create a list with an inactive date prior to the effective date$/) do
  login_to_OCMS
  open_peak_period_days
  add_ppd_list_without_saving('Bad List', tomorrow_date, today_date)
end

Then(/^that list cannot be saved$/) do
  expect(on(PeakPeriodDaysPage).save_list_element.disabled?).to eq(true)
end

When(/^I edit a list with an inactive date prior to the effective date$/) do
  login_to_OCMS
  open_peak_period_days
  add_ppd_list('List To Edit', today_date)
  edit_ppd_list_without_saving('List To Edit', 'Bad List', tomorrow_date, today_date)
end

Given(/^I am creating a new PPD list$/) do
  login_to_OCMS
  open_peak_period_days
  add_new_ppd_list
end

When(/^I select effective dates using the date picker$/) do
  @scenario_context.effective_date = Date.today
  @scenario_context.inactive_date = Date.tomorrow
  pending("Run Manually!")
  select_date_from_from_effective_date_datepicker
  select_date_from_from_inactive_date_datepicker
end

Then(/^the dates are added to the list$/) do
  expect(on(PeakPeriodDaysPage).effective_date).to eq @scenario_context.effective_date
  expect(on(PeakPeriodDaysPage).inactive_date).to eq @scenario_context.inactive_date
end