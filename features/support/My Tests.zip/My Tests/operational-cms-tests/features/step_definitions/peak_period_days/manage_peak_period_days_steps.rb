When(/^I create new ppd for all active ppd lists$/) do
  login_to_OCMS
  open_peak_period_days
  @scenario_context.ppd_date = Date.today
  create_ppd(@scenario_context.ppd_date, peak_period_day_list_names)
end

Then(/^the ppd is saved$/) do
  date_row = find_date_row(@scenario_context.ppd_date)
  expect(@scenario_context.ppd_date.strftime('%m/%d/%Y')).to eq(date_row.date_element.text)
  expect(all_ppd_dates.uniq).to eq all_ppd_dates.uniq
end

And(/^the ppd is added to the correct lists$/) do
  expect(active_peak_period_day_list_names).to match_array(ppd_lists_containing_ppd(@scenario_context.ppd_date))
end

Given(/^an existing ppd$/) do
  login_to_OCMS
  open_peak_period_days
  @scenario_context.ppd_date = Date.today
  create_ppd(@scenario_context.ppd_date, peak_period_day_list_names)
end

When(/^I change the ppd date to tommorrow$/) do
  @scenario_context.new_effective_date = Date.tomorrow
  edit_peak_period_date(@scenario_context.ppd_date, @scenario_context.new_effective_date)
end

Then(/^the ppd is sucessfully updated$/) do
  date_row = find_date_row(@scenario_context.new_effective_date)
  expect(@scenario_context.new_effective_date.strftime('%m/%d/%Y')).to eq(date_row.date_element.text)
end

When(/^I change an existing ppd year to be a year other than the effective year$/) do
  login_to_OCMS
  open_peak_period_days
  edit_last_peak_period_date('05/25/1987')
end

Then(/^the ppd cannot be saved$/) do
  expect(save_error).to include('Peak dates must be inside effective year')
end

Given(/^an existing ppd in the current year$/) do
  login_to_OCMS
  open_peak_period_days
  @scenario_context.ppd_date = Date.today
  create_ppd(@scenario_context.ppd_date, peak_period_day_list_names)
end

When(/^I delete the ppd$/) do
  delete_date_row(@scenario_context.ppd_date)
  save_ppd_changes
end

Then(/^the ppd is removed$/) do
  expect(date_row_effective_dates).to_not include(@scenario_context.ppd_date)
end
