Given(/^a contract for an account$/) do
  @scenario_context.contract = OPContract.random_contract
  @scenario_context.account = @scenario_context.contract.account
  @scenario_context.contracts_for_account = @scenario_context.account.op_contracts
end

Given(/^a card contract for an account$/) do
  #TODO: Eliminate Duplication
  @scenario_context.product_type = Product.sample_non_combo_card_product_name
  @scenario_context.contract = OPContract.sample_card_contract_by_product_name(@scenario_context.product_type)
  while @scenario_context.contract.nil?
    @scenario_context.product_type = Product.sample_non_combo_card_product_name
    @scenario_context.contract = OPContract.sample_card_contract_by_product_name(@scenario_context.product_type)
  end
  @scenario_context.account = @scenario_context.contract.account
  @scenario_context.contracts_for_account = @scenario_context.account.op_contracts
end

Given(/^a combo card contract for an account$/) do
  @scenario_context.product_type = 'Combo'
  @scenario_context.contract = OPContract.sample_card_contract_by_product_name(@scenario_context.product_type)
  while @scenario_context.contract.contract_components.to_a.size == 1
    @scenario_context.contract = OPContract.sample_card_contract_by_product_name(@scenario_context.product_type)
  end
  @scenario_context.account = @scenario_context.contract.account
  @scenario_context.contracts_for_account = @scenario_context.account.op_contracts
end

Given(/^a contract for a non-active account$/) do
  @scenario_context.account = Account.where("account_status_cd != 'A'", "account_status_cd != 'I'").take(100).select { |account| account.contract_bases.first != nil && account.op_contracts.first != nil }.sample
  @scenario_context.contract = @scenario_context.account.op_contracts.first
  @scenario_context.contracts_for_account = @scenario_context.account.op_contracts
end

When(/^I search for that contract by contract id$/) do
  login_to_OCMS
  open_contract_search
  search_for_contract
end

Then(/^the contract information is returned$/) do
  expect(contract_search_results[0].contract_id_element).to be_visible
end

When(/^I search for the contract by full account name$/) do
  login_to_OCMS
  open_contract_search
  search_for_contract_by_account_name(@scenario_context.account.account_name)
  search_for_contract
end

When(/^I search for the contract by partial account name$/) do
  login_to_OCMS
  open_contract_search
  search_for_contract_by_account_name(@scenario_context.account.account_name[0..(@scenario_context.account.account_name.length/2)])
  search_for_contract
end

When(/^I search for the contract by ar number$/) do
  login_to_OCMS
  open_contract_search
  search_for_contract_by_ar_number(@scenario_context.account.ar_nbr)
  search_for_contract
end

When(/^I search for the contract by account status$/) do
  login_to_OCMS
  open_contract_search
  search_for_contract_by_account_status(@scenario_context.account.account_status)
  search_for_contract_by_ar_number(@scenario_context.account.ar_nbr)
  search_for_contract
end

When(/^I search for the contract with multiple account search criteria$/) do
  login_to_OCMS
  open_contract_search
  search_for_contract_by_multiple_fields(account_name: @scenario_context.account.account_name,
                                         ar_number: @scenario_context.account.ar_nbr,
                                         account_status: @scenario_context.account.account_status)
  search_for_contract
end

When(/^I search for the contract by contract number$/) do
  login_to_OCMS
  open_contract_search
  search_for_contract_by_contract_number(@scenario_context.contract.cntr_op_contract_id)
  search_for_contract
end

When(/^I search for the contract by product line$/) do
  login_to_OCMS
  open_contract_search
  search_for_contract_by_ar_number(@scenario_context.account.ar_nbr)
  search_for_contract_by_product_line(@scenario_context.contract.product.product_line)
  search_for_contract
end

When(/^I search for the contract by product type$/) do
  login_to_OCMS
  open_contract_search
  search_for_contract_by_product_type(@scenario_context.product_type)
  search_for_contract_by_ar_number(@scenario_context.account.ar_nbr)
  search_for_contract
end

When(/^I search for the contract by contract status$/) do
  login_to_OCMS
  open_contract_search
  search_for_contract_by_contract_status(contract_status_for_code(@scenario_context.contract.status_cd))
  search_for_contract_by_ar_number(@scenario_context.account.ar_nbr)
  search_for_contract
end

When(/^I search for the contract by card number$/) do
  login_to_OCMS
  open_contract_search
  search_for_contract_by_card_number(@scenario_context.contract.card_nbr)
  search_for_contract
end

Then(/^the information for active contracts on that account are returned$/) do
  search_results = contract_search_results.map(&:attributes)
  expected_contracts = expected_active_contracts_information(@scenario_context.account)

  expect(search_results).to match_array(expected_contracts)
end

Then(/^the information for contracts on that account are returned$/) do
  search_results = contract_search_results.map(&:attributes)
  expected_contracts = expected_active_contracts_information(@scenario_context.account)

  expect(search_results).to match_array(expected_contracts)
end

Then(/^the information for active contracts on that account matching that product line are returned$/) do
  search_results = contract_search_results.map(&:attributes)
  expected_contracts = expected_active_contracts_by_product_line_information(@scenario_context.account, @scenario_context.contract.product.product_line)

  expect(search_results).to match_array(expected_contracts)
end

Then(/^the information for active contracts on that account matching that product type are returned$/) do
  search_results = contract_search_results.map(&:attributes)
  expected_contracts = expected_active_contracts_by_product_information(@scenario_context.account, @scenario_context.contract.product.product_name)

  expect(search_results).to match_array(expected_contracts)
end

Then(/^the information for active contracts on that account matching that contract number are returned$/) do
  search_results = contract_search_results.map(&:attributes)
  expected_contracts = expected_active_contracts_by_contract_number(@scenario_context.account, @scenario_context.contract.cntr_op_contract_id)

  expect(search_results).to match_array(expected_contracts)
end

Then(/^the information for active contracts on that account matching that card number are returned$/) do
  search_results = contract_search_results.map(&:attributes)
  expected_contracts = expected_active_contracts_by_card_number(@scenario_context.account, @scenario_context.contract.card_nbr)

  expect(search_results).to match_array(expected_contracts)
end

Then(/^the information for contracts partially matching that account name are returned$/) do
  search_results = contract_search_results.map(&:account_name)

  search_results.each do |result|
    expect(result.strip.downcase).to include @scenario_context.account.account_name[1..3].strip.downcase
  end

end

When(/^I search for the contract by aircraft type$/) do
  login_to_OCMS
  open_contract_search
  @scenario_context.aircraft_type = OPContract.random_contract.aircraft_type_names[0]
  search_for_contract_by_aircraft_type(@scenario_context.aircraft_type)
  search_for_contract
end

Then(/^then only contracts with that ac type are displayed$/) do
  expect(contract_search_results.map(&:ac_type).uniq).to match_array(@scenario_context.aircraft_type)
end