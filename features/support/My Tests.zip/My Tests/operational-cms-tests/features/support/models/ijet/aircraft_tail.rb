require 'active_record'

class AircraftTail < ActiveRecord::Base
  self.table_name = 'ijet.aircraft_tail'
  self.primary_key = 'tailid'

end
