require 'active_record'

class PeakPeriodDayList < ActiveRecord::Base
  self.table_name = 'prdt_owner.PRDT_PEAK_DAY_LIST'
  self.sequence_name = 'prdt_owner.S_PRDT_PEAK_DAY_LIST'

  def self.retrieve_peak_period_day_list_id(list_name, effective_date)

    db_date = Date.strptime(effective_date, '%m/%d/%Y').strftime('%e-%^b-%Y')
    next_day = Date.strptime(effective_date, '%m/%d/%Y') + 1.day
    next_day = next_day.strftime('%e-%^b-%Y')
    PeakPeriodDayList.find_by_sql("select ppdl.prdt_peak_day_list_id from PRDT_PEAK_DAY_LIST ppdl
    where ppdl.list_nm = '#{list_name}'
    and ppdl.effective_dt >= '#{db_date}'
    and ppdl.effective_dt < '#{next_day}'
    and ppdl.ej_company_id = '1000001'").first.prdt_peak_day_list_id.to_i

  end

end