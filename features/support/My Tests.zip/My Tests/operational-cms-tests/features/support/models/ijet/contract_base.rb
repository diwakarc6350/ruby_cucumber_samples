require 'active_record'

class ContractBase < ActiveRecord::Base
  self.table_name = 'ijet.contract_base'
  self.primary_key = 'contract_id'

  self.has_one(:contract_detail, primary_key: 'contract_id', foreign_key: 'contract_id')
  self.has_many(:contract_hrs, class_name: "ContractHrs", foreign_key: 'contract_id')
  self.belongs_to(:ej_company, class_name: "EjCompany", foreign_key: 'ej_company_id')
  self.has_one(:aircraft_tail, class_name: 'AircraftTail', primary_key: 'tail_id', foreign_key: 'tailid')
end