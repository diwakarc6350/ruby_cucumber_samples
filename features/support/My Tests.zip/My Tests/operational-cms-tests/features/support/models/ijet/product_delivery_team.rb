require 'active_record'

class ProductDeliveryTeam < ActiveRecord::Base
  self.table_name = 'ijet.product_delivery_team'

end