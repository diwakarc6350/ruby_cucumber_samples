require 'active_record'
require 'faker'

class CabinClass < ActiveRecord::Base
  self.table_name = 'acft_owner.acft_cabin_class'

end