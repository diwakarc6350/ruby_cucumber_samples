require 'active_record'

class ContractHrs < ActiveRecord::Base
  self.table_name = 'ijet.contract_hrs'
  self.primary_key = 'contract_hrs_id'

  belongs_to :contract_base
end