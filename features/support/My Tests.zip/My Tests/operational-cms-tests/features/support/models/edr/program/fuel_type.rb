require 'active_record'
require 'faker'

class FuelType < ActiveRecord::Base
  self.table_name = 'prdt_owner.PRDT_FUEL_TYPE'
  self.sequence_name = 'prdt_owner.S_PRDT_FUEL_TYPE'

  def self.calculate_three_month_averages(company, month=nil, year=nil)
    company_id = self.find_by_sql("select ej_company_id from ej_company where company_name = '#{company.upcase}'")[0].ej_company_id
    three_month_rates = self.find_by_sql("select
                                          round(avg(ftc.average_rate_qty),2) as average,
                                           (CASE WHEN ftc.commercial_status_flg is null and ft.fuel_type_name = 'Long Range' THEN 'Long Range'
                                            WHEN ftc.commercial_status_flg is null and ft.fuel_type_name = 'Standard' THEN 'Standard'
                                            WHEN ftc.commercial_status_flg = 'T' and ft.fuel_type_name = 'Standard' THEN 'Standard Commercial'
                                            WHEN ftc.commercial_status_flg = 'T' and ft.fuel_type_name = 'Long Range' THEN 'Long Range Commercial'
                                            WHEN ftc.commercial_status_flg = 'F' and ft.fuel_type_name = 'Standard' THEN 'Standard Non-Commercial'
                                            WHEN ftc.commercial_status_flg = 'F' and ft.fuel_type_name = 'Long Range' THEN 'Long Range Non-Commercial' END) as fuel_type
                                          from PRDT_owner.PRDT_FUEL_TYPE ft, PRDT_owner.PRDT_FUEL_TYPE_COMMERCIAL ftc
                                          where ft.PRDT_FUEL_TYPE_ID = ftc.PRDT_FUEL_TYPE_ID
                                          and ft.effective_dt >= last_day(ADD_MONTHS (SYSDATE, -3))
                                          and ft.effective_dt <= last_day(SYSDATE)
                                          and ft.ej_company_id = '#{company_id}'
                                          group by ft.fuel_type_name, ftc.commercial_status_flg").map(&:attributes)

    three_month_rates = three_month_rates.map { |rate| Hash[rate['fuel_type'] => rate['average'].to_f] }.inject { |sum, rate| rate.merge(sum) }
  end

  def self.previous_month_fuel_types
    self.find_by_sql("select
                     ft.FUEL_TYPE_NAME as fuel_type,
                     (CASE WHEN ftc.commercial_status_flg = 'T' THEN 'Commercial'
                       WHEN ftc.commercial_status_flg = 'F' THEN 'Non-Commercial' END) as commercial_status
                     from PRDT_OWNER.PRDT_FUEL_TYPE ft, PRDT_owner.PRDT_FUEL_TYPE_COMMERCIAL ftc
                     where ft.PRDT_FUEL_TYPE_ID = ftc.PRDT_FUEL_TYPE_ID
                     and ft.EFFECTIVE_DT = (trunc(SYSDATE, 'mm'))").map do |rate|
      rate_list = rate.attributes
      rate_list.delete('prdt_fuel_type_id')
      rate_list
    end
  end

  def self.delete_future_fuel_data
    ActiveRecord::Base.connection.execute("delete from PRDT_OWNER.PRDT_FUEL_TYPE ft
    where ft.EFFECTIVE_DT = add_months(trunc(SYSDATE, 'mm'), 1)")
  end

  def self.first_non_invoiced_fuel_type
    self.where(invoiced: 'F').first
  end

  def self.first_invoiced_fuel_type
    self.where(invoiced: 'T').first
  end

  def self.previous_month_information

  end

  def self.populate_fuel_rates_with_effective_dt(effective_date, opts={})
    effective_date = effective_date.strftime('01-%^b-%y')
    return false unless self.find_by_effective_dt(effective_date).nil?
    fuel_types = ['Long Range', 'Standard']
    commercial_statuses = ['T', 'F']

    fuel_types.each do |fuel_type|
      commercial_statuses.each do |status|

        fuel_cost = Faker::Commerce.price

        next_fuel_type_id = self.find_by_sql('select prdt_owner.S_PRDT_FUEL_TYPE.nextval from dual').first.nextval.to_i
        created_date = Date.today.strftime('%d-%^b-%y')

        self.create({prdt_fuel_type_id: next_fuel_type_id,
                     ej_company_id: 1000001,
                     effective_dt: effective_date,
                     fuel_type_name: fuel_type,
                     average_rate_qty: fuel_cost,
                     active_flg: 'T',
                     commercial_status_flg: status,
                     version_nbr: 1,
                     created_dt: created_date,
                     created_by: 'automation'}.merge(opts))

      end
    end
    true
  end

  def self.clean_fuel_rate_records

    primary_fuel_rate_keys = self.where(created_by: 'automation')

    self.delete(primary_fuel_rate_keys)

  end


end