require 'active_record'
require 'faker'

class AcftAircraftType < ActiveRecord::Base
  self.table_name = 'acft_owner.acft_aircraft_type'
  self.belongs_to(:cabin_class, class_name: 'CabinClass', foreign_key: 'acft_cabin_class_id')
  self.has_one(:aircraft_type_xref, class_name: 'AircraftTypeXref', foreign_key: 'acft_aircraft_type_id')

  def self.all_aircraft_common_names
    common_names = self.find_by_sql("select ac.AIRCRAFT_TYPE_NAME
                      from acft_aircraft_type ac, acft_aircraft_type_xref ax
                      where ax.ACFT_AIRCRAFT_TYPE_ID = ac.ACFT_AIRCRAFT_TYPE_ID").map(&:attributes)

    filtered_common_names = []
    common_names.each do |name|
      filtered_common_names << name['aircraft_type_name']
    end
    filtered_common_names
  end

  def self.cabin_class_for_aircraft(aircraft_type)
    acft_record = self.find_by_aircraft_type_name(aircraft_type)
    acft_record.cabin_class.cabin_class_name
  end

  def self.aircraft_type_xref_id(aircraft_type)
    self.find { |aircraft| aircraft.aircraft_type_name == aircraft_type }.aircraft_type_xref.acft_aircraft_type_xref_id
  end


end
