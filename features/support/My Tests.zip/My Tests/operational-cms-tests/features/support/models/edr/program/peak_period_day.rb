require 'active_record'

class PeakPeriodDay < ActiveRecord::Base
  self.table_name = 'prdt_owner.PRDT_PEAK_DAY'
  self.sequence_name = 'prdt_owner.S_PRDT_PEAK_DAY'


end