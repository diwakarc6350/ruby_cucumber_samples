require 'active_record'

class ServiceUsage < ActiveRecord::Base
  scope :billable, -> { where.not(usage_type: [2,4,5,6,8,9,12]) }
  scope :excess, -> { where(usage_type: [2,9,12]) }

  self.table_name = 'cntr_owner.cntr_service_usage'
  self.primary_key = 'cntr_service_usage_id'
end