require 'active_record'

class ContractDetail < ActiveRecord::Base
  self.table_name = 'ijet.contract_detail'
  self.has_one(:contract_base, primary_key: 'contract_id', foreign_key: 'contract_id')

  def self.first_inactive_contract
    ContractDetail.where(contract_status_id: 2).first.contract_id
  end
end