require 'active_record'

class ContractLegalEntity < ActiveRecord::Base
  self.table_name = 'cntr_owner.cntr_legal_entity'
end