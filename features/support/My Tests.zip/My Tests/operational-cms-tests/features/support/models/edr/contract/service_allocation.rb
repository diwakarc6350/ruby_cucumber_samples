require 'active_record'

class ServiceAllocation < ActiveRecord::Base
  self.table_name = 'cntr_owner.cntr_service_allocation'
  self.primary_key = 'cntr_service_allocation_id'
end