require 'active_record'

class ComponentSvcAlloc < ActiveRecord::Base
  self.table_name = 'cntr_owner.cntr_component_svc_alloc'
  self.primary_key = 'cntr_component_svc_alloc_id'

  has_one(:service_allocation, class_name: "ServiceAllocation", foreign_key: 'cntr_service_allocation_id')
  has_many(:service_usage, class_name: "ServiceUsage", foreign_key: 'cntr_component_svc_alloc_id')
end