require 'active_record'

class Invoice < ActiveRecord::Base
  self.table_name = 'ijet.invoice'

  def self.billing_cycle_info_for_contract(ijet_contract_id)
    find_by_sql("select i.contract_id, max(i.billing_cycle_ts) as billing_cycle_ts
                                                                     from invoice i
                                                                     where i.dtype = 17
                                                                      and i.invoice_status_cd in (4,7)
                                                                      and i.contract_id = #{ijet_contract_id}
                                                                     group by i.contract_id").first
  end

end