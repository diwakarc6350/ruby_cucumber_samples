require 'active_record'

class Individual < ActiveRecord::Base
  self.table_name = 'ijet.individual'

end
