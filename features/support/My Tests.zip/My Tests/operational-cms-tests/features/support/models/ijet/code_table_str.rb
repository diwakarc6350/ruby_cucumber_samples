require 'active_record'

class CodeTableStr < IjetData
  self.table_name = 'ijet.CODE_TABLE_STR'

  def self.get_state_from_abbreviation(abbreviation)
    self.where(code: abbreviation).first['value']
  end

  def self.get_all_states
    self.where(tag: ['USState', 'CAProvince']).map {|record| record['value']}
  end

end