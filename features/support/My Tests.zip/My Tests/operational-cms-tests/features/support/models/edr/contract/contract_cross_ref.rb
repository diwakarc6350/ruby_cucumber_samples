require 'active_record'

class ContractCrossRef < ActiveRecord::Base
  self.table_name = 'cntr_owner.cntr_contract_cross_ref'
  self.primary_key = 'cntr_contract_cross_ref_id'

  belongs_to(:contract_component, class_name: ContractComponent, foreign_key: 'cntr_contract_component_id')
  belongs_to(:contract_base, class_name: 'ContractBase', foreign_key: 'contract_id')
end