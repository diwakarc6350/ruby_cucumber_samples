require 'active_record'

class InterchangeRateType < ActiveRecord::Base
  self.table_name = 'prdt_owner.prdt_interchange_rate_type'

  def self.all_available_interchange_rates
    interchanges = self.select(:from_company_id,
                               :from_program_id,
                               :to_program_id,
                               :rate_type_name,
                               :effective_dt,
                               :inactive_dt).map(&:attributes)


    interchanges.map do |interchange|
      interchange.delete('prdt_interchange_rate_type_id')
      from_company_id = interchange.delete('from_company_id')
      from_program_id = interchange.delete('from_program_id')
      to_program_id = interchange.delete('to_program_id')

      if !from_company_id.nil?
        interchange[:from] = nj_company(from_company_id)
      else
        interchange[:from] = nj_program(from_program_id)
      end
      interchange[:to] = nj_program(to_program_id)
      interchange[:name] = interchange.delete('rate_type_name')
      if interchange[:name] == 'Inactive Rate Type'
        puts interchange.fetch('effective_dt')
        puts interchange.fetch('effective_dt').localtime.strftime('%m/%d/%Y')
      end
      interchange[:effective_date] = interchange.delete('effective_dt').localtime.strftime('%m/%d/%Y')
      interchange[:inactive_date] = interchange['inactive_dt'] ? interchange['inactive_dt'].localtime.strftime('%m/%d/%Y') : ''
      interchange.delete('inactive_dt')
      interchange
    end

    interchanges
  end

  private
  def self.nj_company(company_id)
    self.find_by_sql("select ec.company_name from ej_company ec where ec.ej_company_id = #{company_id}").first.company_name
  end

  def self.nj_program(program_id)
    self.find_by_sql("select p.program_name from program p where p.program_id = #{program_id}").first.program_name
  end

end
