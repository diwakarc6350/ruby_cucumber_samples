require 'active_record'

class OPContract < ActiveRecord::Base
  self.table_name = 'cntr_owner.cntr_op_contract'
  self.primary_key = 'cntr_op_contract_id'
  self.has_many(:contract_components, class_name: "ContractComponent", foreign_key: 'cntr_op_contract_id')
  self.belongs_to(:product, class_name: "Product", foreign_key: 'cntr_product_id')
  self.belongs_to(:legal_entity, class_name: "ContractLegalEntity", foreign_key: 'cntr_legal_entity_id')
  self.has_one(:contract_date, class_name: "ContractContractDate", foreign_key: 'cntr_op_contract_id')

  def share_size
    contract_type = self.class.find_by_sql("select * from CNTR_OP_CONTRACT c
                                         join CNTR_OWNER.CNTR_PRODUCT p
                                         on c.CNTR_PRODUCT_ID = p.CNTR_PRODUCT_ID
                                         where c.CNTR_OP_CONTRACT_ID = #{self.cntr_op_contract_id}").first.product_line

    if contract_type != 'CARD'
      ijet_contract_id = self.contract_components[0].contract_cross_ref.contract_id
      ContractBase.find(ijet_contract_id).share_size
    else
      service_allocations = self.contract_components.all.map do |component|
        component.component_service_allocations.all.map { |comp_allocation| comp_allocation.service_allocation }.select { |alloc| alloc.allocation_type == 1 }
      end.flatten

      service_allocations.reduce(0) { |sum, alloc| sum + alloc.allocated_qty }
    end

  end

  def contract_status
    CodeTableTrans.where(tag: 'ContractStatus', code: self.status_cd).first.value
  end

  def account_id
    ijet_contract_id = self.contract_components[0].contract_cross_ref.contract_id
    ContractBase.find(ijet_contract_id).acct_id
  end

  def account
    Account.where(accountid: self.account_id).first
  end

  def aircraft_type_names
    components = self.contract_components.sort_by { |component| component.aircraft_type_xref.aircraft_type.aircraft_type_ranking_nbr }
    components.map do |component|
      component.aircraft_type_xref.aircraft_type.aircraft_type_name
    end
  end

  def self.sample_card_contract_by_product_name(product_name)
    product_id = Product.where(product_name: product_name).first.cntr_product_id
    self.where(cntr_product_id: product_id).where.not(status_cd: 2).first(100).sample
  end

  def self.random_contract
    contract = self.where(status_cd: 1).sample
    while ['3050', '7043', '8176', '7300'].include? contract.account.ar_nbr
      contract = self.where(status_cd: 1).sample
    end
    contract
  end

  def component_by_aircraft_type(aircraft_type)
    aircraft_id = AcftAircraftType.aircraft_type_xref_id(aircraft_type)

    self.contract_components.find {|component| component.acft_aircraft_type_xref_id == aircraft_id}
  end

end

