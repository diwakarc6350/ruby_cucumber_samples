require 'active_record'

class AircraftTypeXref < ActiveRecord::Base
  self.table_name = 'acft_owner.acft_aircraft_type_xref'
  self.primary_key = 'acft_aircraft_type_xref_id'

  belongs_to(:aircraft_type, class_name: 'AcftAircraftType', foreign_key: 'acft_aircraft_type_id')

end
