require 'active_record'

class Account < ActiveRecord::Base
  self.table_name = 'ijet.account'

  has_many(:contract_bases, class_name: 'ContractBase', foreign_key: 'acct_id')
  has_many(:account_sales_reps, class_name: 'AccountSalesRep', foreign_key: 'account_id')
  has_many(:account_roles, class_name: 'AccountRole', foreign_key: 'accountid')
  belongs_to(:program, class_name: 'Program', foreign_key: 'program_id')
  has_one(:product_delivery_team, class_name: 'ProductDeliveryTeam', foreign_key: 'teamid', primary_key:  'product_delivery_team_id')

  def account_status
    account_status_code = self.account_status_cd
    CodeTableTrans.where(tag: 'AccountStatus', code: account_status_code).first.value
  end

  def op_contracts
    ijet_contract_ids = self.contract_bases.map(&:contract_id)
    ContractCrossRef.where("contract_id in (#{ijet_contract_ids.join(',')})").map do |ref|
      ref.contract_component.op_contract
    end
  end

  def active_op_contracts
    self.op_contracts.select {|contract| contract.contract_status == 'Active'}
  end

  def cross_refs
    ijet_contract_ids = self.contract_bases.map(&:contract_id)
    ContractCrossRef.where("contract_id in (#{ijet_contract_ids.join(',')})")
  end

  def principle_names
    self.account_roles.where(account_role_type_id: 540).map do |role|
      "#{role.individual.first_name} #{role.individual.last_name}"
    end.flatten.sort
  end

  def sales_vp_full_name
    sales_reps = self.account_sales_reps.select do |account_sales_rep|
      account_sales_rep.rank_nbr_before_type_cast == '1' && account_sales_rep.sales_type_id == 1
    end

    sales_reps.map do |account_sales_rep|
      individual_rep = account_sales_rep.sales_rep.individual
      individual_rep.first_name + ' ' + individual_rep.last_name
    end.first
  end

end
