require 'active_record'

class Program < ActiveRecord::Base
  self.table_name = 'ijet.program'

end