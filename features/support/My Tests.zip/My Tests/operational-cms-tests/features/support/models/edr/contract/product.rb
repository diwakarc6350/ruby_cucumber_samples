require 'active_record'

class Product < ActiveRecord::Base
  self.table_name = 'cntr_owner.cntr_product'
  self.primary_key = 'cntr_product_id'

  self.has_many(:product, class_name: "OPContract", foreign_key: 'cntr_product_id')

  def self.sample_card_product_name
    #TODO: BUG FIX, REMOVE REFERRAL, 'REDEMPTION', 'PROMO', 'BINDER'
    self.where(product_line: 'CARD').where("product_name not in (Referral', 'Redemption', 'Promo', 'Binder')").sample.product_name
  end

  def self.sample_non_combo_card_product_name
    #TODO: BUG FIX, REMOVE REFERRAL, 'REDEMPTION', 'PROMO', 'BINDER'
    self.where(product_line: 'CARD').where("product_name not in ('Combo', 'X Country', 'Referral', 'Redemption', 'Promo', 'Binder')").sample.product_name
  end

end