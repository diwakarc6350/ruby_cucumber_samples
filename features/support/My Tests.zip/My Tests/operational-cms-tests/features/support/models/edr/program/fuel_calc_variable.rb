require 'active_record'
require 'faker'

class FuelCalcVariable < ActiveRecord::Base
  self.table_name = 'prdt_owner.PRDT_FUEL_CALC_VARIABLE'
  self.sequence_name = 'prdt_owner.S_PRDT_FUEL_CALC_VARIABLE'

  # def self.fuel_rates_for_past_two_months(ac_type,fuel_type)
  #   find_by_sql("select prdt_fuel_calc_variable_id from PRDT_FUEL_CALC_VARIABLE cv
  #   join ACFT_AIRCRAFT_TYPE_XREF ax
  #   on cv.ACFT_AIRCRAFT_TYPE_XREF_ID = ax.ACFT_AIRCRAFT_TYPE_XREF_ID
  #   join ACFT_AIRCRAFT_TYPE aat
  #   on aat.ACFT_AIRCRAFT_TYPE_ID = ax.ACFT_AIRCRAFT_TYPE_ID
  #   join Prdt_Fuel_Type pft
  #   on Pft.Prdt_Fuel_Type_Id = Cv.Prdt_Fuel_Type_Id
  #   where cv.effective_dt >= trunc(trunc(sysdate,'MM')-1,'MM')
  #   --where Aat.Aircraft_Type_Name = '#{ac_type}'
  #   --and Pft.Fuel_Type_Name = '#{fuel_type}'")
  # end

  def self.retrieve_fuel_calc_variable_id(ac_type, fuel_type, effective_date)
    fuel_calc_variable = find_by_sql("select cv.prdt_fuel_calc_variable_id from PRDT_FUEL_CALC_VARIABLE cv
                                       join ACFT_AIRCRAFT_TYPE_XREF ax
                                       on cv.ACFT_AIRCRAFT_TYPE_XREF_ID = ax.ACFT_AIRCRAFT_TYPE_XREF_ID
                                       join ACFT_AIRCRAFT_TYPE aat
                                       on aat.ACFT_AIRCRAFT_TYPE_ID = ax.ACFT_AIRCRAFT_TYPE_ID
                                       join Prdt_Fuel_Type pft
                                       on Pft.Prdt_Fuel_Type_Id = Cv.Prdt_Fuel_Type_Id
                                       where Aat.Aircraft_Type_Name = '#{ac_type}'
                                       and cv.effective_dt >= to_timestamp('#{effective_date.strftime('%d-%m-%y')}', 'dd-mm-yy')
                                       and cv.effective_dt < to_timestamp('#{effective_date.next.strftime('%d-%m-%y')}', 'dd-mm-yy')
                                       and Pft.Fuel_Type_Name = '#{fuel_type}'")
    fuel_calc_variable.first.prdt_fuel_calc_variable_id.to_i unless fuel_calc_variable.first == nil
  end


  def self.populate_ac_fuel_data(date, opts={})

    ac_fuel_rates_for_next_month = FuelCalcVariable.find_by_sql("select * from prdt_fuel_calc_variable fcv join prdt_owner.prdt_fuel_type ft on fcv.prdt_fuel_type_id = ft.prdt_fuel_type_id where fcv.effective_dt like to_date('#{date.strftime('%m/01/%y')}', 'MM/DD/YYYY')")

    if ac_fuel_rates_for_next_month.empty?
      fuel_types = FuelType.find_by_sql("select * from prdt_owner.prdt_fuel_type ft where ft.effective_dt >= (SELECT TRUNC (SYSDATE, 'month') FROM DUAL)")
      fuel_types.each do |fuel_type|
        aircraft_xref_id = FuelType.find_by_sql('SELECT acft_aircraft_type_xref_id FROM
                      ( SELECT atx.acft_aircraft_type_xref_id FROM acft_aircraft_type_xref atx
                      ORDER BY dbms_random.value )
                      WHERE rownum = 1').first.acft_aircraft_type_xref_id.to_i

        next_variable_id = FuelType.find_by_sql("SELECT #{FuelCalcVariable.sequence_name}.nextval from dual").first.nextval.to_i

        FuelCalcVariable.create(
            {
            prdt_fuel_calc_variable_id: next_variable_id,
            prdt_fuel_type_id: fuel_type.prdt_fuel_type_id,
            acft_aircraft_type_xref_id: aircraft_xref_id,
            effective_dt: date.strftime('01-%^b-%y'),
            established_rate_qty: 1.60,
            plus_minus_qty: 0.05,
            differential_qty: 0.01,
            variable_rate_qty: Faker::Commerce.price,
            version_nbr: 1,
            created_by: 'qatest1'
            }.merge(opts)
        )

      end
    end

  end




end