require 'active_record'

class AccountSalesRep < ActiveRecord::Base
  self.table_name = 'ijet.account_sales_rep'

  belongs_to(:sales_rep, class_name: 'SalesRep', foreign_key: 'sales_rep_id')


end