require 'active_record'

class AccountRole < ActiveRecord::Base
  self.table_name = 'ijet.account_role'

  belongs_to(:individual, class_name: 'Individual', foreign_key: 'individualid')


end
