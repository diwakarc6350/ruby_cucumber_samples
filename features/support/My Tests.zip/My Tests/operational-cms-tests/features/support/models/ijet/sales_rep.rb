require 'active_record'

class SalesRep < ActiveRecord::Base
  self.table_name = 'ijet.sales_rep'

  belongs_to(:individual, class_name: 'Individual', foreign_key: 'individual_id')
end