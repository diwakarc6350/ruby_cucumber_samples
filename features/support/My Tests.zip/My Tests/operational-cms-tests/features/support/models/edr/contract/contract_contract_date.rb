require 'active_record'

class ContractContractDate < ActiveRecord::Base
  self.table_name = 'cntr_owner.cntr_contract_date'
end