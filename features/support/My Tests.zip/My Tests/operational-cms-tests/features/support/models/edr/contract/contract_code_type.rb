require 'active_record'

class ContractCodeType < ActiveRecord::Base
  self.table_name = 'cntr_owner.contract_code_type'
  self.primary_key = 'cntr_code_type_id'
end