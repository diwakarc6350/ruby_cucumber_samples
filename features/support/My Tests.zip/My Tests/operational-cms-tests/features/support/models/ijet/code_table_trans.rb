require 'active_record'

class CodeTableTrans < ActiveRecord::Base
  self.table_name = 'ijet.code_table_trans'
end