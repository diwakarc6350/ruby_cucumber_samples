require 'active_record'
require 'models/edr/contract/op_contract'

class ContractComponent < ActiveRecord::Base
  self.table_name = 'cntr_owner.cntr_contract_component'
  self.primary_key = 'cntr_contract_component_id'
  self.has_one(:contract_cross_ref, class_name: 'ContractCrossRef', foreign_key: 'cntr_contract_component_id')
  self.belongs_to(:aircraft_type_xref, class_name: 'AircraftTypeXref', foreign_key: 'acft_aircraft_type_xref_id')
  self.has_many(:component_service_allocations, class_name: "ComponentSvcAlloc", foreign_key: 'cntr_contract_component_id')
  self.belongs_to(:op_contract, class_name: 'OPContract', foreign_key: 'cntr_op_contract_id')

  def hours_by_code_type(code_type)
    code_type_id = ContractCodeType.find_by_code_type_name(code_type).code_type_class_id

    hours = self.component_service_allocations.all.map { |comp_allocation| comp_allocation.service_allocation }
                .select { |alloc| alloc.allocation_type == code_type_id }.flatten

    hours.reduce(0) { |sum, alloc| sum + alloc.allocated_qty }.to_f
  end

  def usage_hours
    hours = self.component_service_allocations.all.map{ |comp_allocation| comp_allocation.service_usage.billable }.flatten

    hours.reduce(0) { |sum, used| sum + used.used_qty }.to_f
  end

  def excess_hours
    hours = self.component_service_allocations.all.map{ |comp_allocation| comp_allocation.service_usage.excess }.flatten

    hours.reduce(0) { |sum, used| sum + used.used_qty }.to_f
  end
end