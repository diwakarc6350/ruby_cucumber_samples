class OCMS
  def self.log
  unless @log
    log_levels = {debug: Logger::DEBUG, info: Logger::INFO, warn: Logger::WARN, error: Logger::ERROR,
                  fatal: Logger::FATAL, unknown: Logger::UNKNOWN}

    logs_location = "#{File.dirname(__FILE__)}/../../test_logs"
    Dir.mkdir(logs_location) unless Dir.exist?(logs_location)
    @log = Logger.new("#{logs_location}/test.log") #.tap { |l| l.progname = 'OCMS'}
    @log.level = log_levels[ENV['LOG_LEVEL']] || Logger::INFO
  end
  @log
  end
end