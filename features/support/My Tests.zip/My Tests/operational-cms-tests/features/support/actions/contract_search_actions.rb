module ContractSearchActions

  # Searches for a contract on the Contract Search screen
  # Uses the fields filled in by previous methods. If no fields are modified
  # from the default screen, it searches for all active contracts.
  def search_for_contract
    on ContractSearchPage do |page|
      page.search
      page.wait_for_ajax
    end
  end

  # Returns the contract search results from the contract search page
  #
  # @return [PageObject::Sections] The contract search results
  def contract_search_results
    on(ContractSearchPage).wait_for_ajax
    on(ContractSearchPage).contract_search_results
  end

  # Selects the provided account statuses on the contract search page
  #
  # @param [Array] account_statuses An array of the account statuses to be selected
  def search_for_contract_by_account_status(*account_statuses)
    on(ContractSearchPage).account_status_selections
    account_statuses.each do |status|
      on(ContractSearchPage).account_statuses.send(status.gsub(/ /, '_').underscore)
    end
  end

  # Fills in the account number field on the contract search page with the provided value
  #
  # @param [String] ar_number The ar number to be searched upon
  def search_for_contract_by_ar_number(ar_number)
    on(ContractSearchPage).ar_number = ar_number
  end

  # Fills in the account name field on the contract search page with the provided value
  #
  # @param [String] account_name The account name to be searched upon
  def search_for_contract_by_account_name(account_name)
    on(ContractSearchPage).account_name = account_name
  end

  # Fills in the contract number field on the contract search page with the provided value
  #
  # @param [String] contract_number The contract number to be searched upon
  def search_for_contract_by_contract_number(contract_number)
    on(ContractSearchPage).contract_number = contract_number
  end

  # Selects the provided product line on the contract search page
  #
  # @param [String] product_line The product line to be searched upon
  def search_for_contract_by_product_line(product_line)
    on(ContractSearchPage).product_line = product_line
  end

  # Selects the provided product type on the contract search page
  #
  # @param [String] product_type The product type to be searched upon
  def search_for_contract_by_product_type(product_type)
    on(ContractSearchPage).product = product_type
  end

  # Selects the provided contract status on the contract search page
  #
  # @param [String] contract_status The contract status to be searched upon
  def search_for_contract_by_contract_status(contract_status)
    on(ContractSearchPage).contract_status = contract_status
  end

  # Fills in the card number on the contract search page with the provided value
  #
  # @param [String] card_number The card number to be searched upon
  def search_for_contract_by_card_number(card_number)
    on(ContractSearchPage).card_number = card_number
  end

  # Selects the provided aircraft type on the contract search page
  #
  # @param [String] aircraft_type The aircraft type to be searched upon
  def search_for_contract_by_aircraft_type(aircraft_type)
    on(ContractSearchPage).aircraft_type = aircraft_type
  end

  # Fills all specified fields on the contract search page with the provided information
  #
  # @param [Hash] fields The fields to be modified and searched upon
  def search_for_contract_by_multiple_fields(fields = {})
    on(ContractSearchPage).populate_page_with fields
  end

  # Returns the account status name for the provided account status code
  #
  # @param [FixNum] account_status_code The code for the desired account status name
  # @return [String] The desired account status name
  def account_status_for_code(account_status_code)
    CodeTableTrans.where(tag: 'AccountStatus', code: account_status_code).first.value
  end

  # Returns the contracts status name for the provided contract status id
  #
  # @param [FixNum] contract_status_id The id for the desired contract status name
  # @return [String] The desired contract status name
  def contract_status_for_code(contract_status_id)
    CodeTableTrans.where(tag: 'ContractStatus', code: contract_status_id).first.value
  end

  # Returns a hash of contract attributes for the provided account record and specific op_contract on the account
  #
  # @param [ActiveRecord::Base::Account] account_record The account for which details are to be returned
  # @param [ActiveRecord::Base::OPContract] op_contract The op_contract associated with the provided account
  def ijet_account_attributes(account_record, op_contract)
    {account_name: account_record.account_name,
     legal_name: op_contract.legal_entity.legal_name,
     account_number: account_record.ar_nbr,
     contract_id: op_contract.cntr_op_contract_id.to_s,
     contract_status: op_contract.contract_status,
     individual_name: (account_record.principle_names.first.nil? ? '' : account_record.principle_names.first),
     share_size: op_contract.share_size.to_f,
     ac_type: op_contract.aircraft_type_names.join(' / '),
     start_date: op_contract.start_dt.strftime('%m/%d/%Y'),
     end_date: op_contract.end_dt.strftime('%m/%d/%Y'),
     termination_date: op_contract.contract_date.termination_dt.try(:strftime, '%m/%d/%Y'),
     product_line: op_contract.product.attributes['product_line'],
     product_name: op_contract.product.attributes['product_name']
    }

  end

  #
  def expected_contracts_information(account_record)
    account_record.op_contracts.map do |op_contract|
      ijet_account_attributes(account_record, op_contract)
    end.uniq
  end

  def expected_active_contracts_information(account_record)
    account_record.op_contracts.select { |op_contract| op_contract.contract_status != 'Inactive' }.map do |op_contract|
      ijet_account_attributes(account_record, op_contract)
    end.uniq
  end

  def expected_active_contracts_by_product_line_information(account_record, product)
    account_record.op_contracts.select { |op_contract| op_contract.contract_status != 'Inactive' and op_contract.product.product_line == product }.map do |op_contract|
      ijet_account_attributes(account_record, op_contract)
    end.uniq
  end

  def expected_active_contracts_by_product_information(account_record, product)
    account_record.op_contracts.select { |op_contract| op_contract.contract_status != 'Inactive' and op_contract.product.product_name == product }.map do |op_contract|
      ijet_account_attributes(account_record, op_contract)
    end.uniq
  end

  def expected_active_contracts_by_contract_number(account_record, contract_number)
    account_record.op_contracts.select { |op_contract| op_contract.contract_status != 'Inactive' and op_contract.cntr_op_contract_id == contract_number }.map do |op_contract|
      ijet_account_attributes(account_record, op_contract)
    end
  end

  def expected_active_contracts_by_card_number(account_record, card_number)
    account_record.op_contracts.select { |op_contract| op_contract.contract_status != 'Inactive' and op_contract.card_nbr == card_number }.map do |op_contract|
      ijet_account_attributes(account_record, op_contract)
    end.uniq
  end

  def view_first_contract
    sleep 2
    on(ContractSearchPage).contract_search_results.first.contract_id
    sleep 2
    @browser.windows.last.use
    sleep 2
  end

end

World(ContractSearchActions)

