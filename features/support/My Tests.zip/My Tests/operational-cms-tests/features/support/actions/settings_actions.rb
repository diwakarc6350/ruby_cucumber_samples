module SettingsActions

  def select_default_company(company)
    on(SettingsPage).default_company = company
  end

  def save_settings
    on(SettingsPage).save
  end
end

World(SettingsActions)

