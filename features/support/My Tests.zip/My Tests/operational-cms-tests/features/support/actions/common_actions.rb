require 'page-object'
module CommonActions
  include PageObject::PageFactory

  def login_to_OCMS(role=OCMSUsers::ADMIN)
    visit(LoginPage).login_as(role)
  end

  # Returns today's date formatted as "Month/Day/Year", eg. "07/09/2015"
  #
  # @return [String] Today's date formatted as "Month/Day/Year", eg. "12/25/2008"
  def today_date
    Date.today.strftime('%m/%d/%Y')
  end

  # Returns tomorrow's date formatted as "Month/Day/Year", eg. "08/25/1867"
  #
  # @return [String] Tomorrow's date formatted as "Month/Day/Year", eg. "11/24/1963"
  def tomorrow_date
    (Date.today + 1).strftime('%m/%d/%Y')
  end

  # Returns the next calendar year formatted as "Year", eg "1865"
  #
  # @return [String] The next calendar year formatted as "Year", eg "2025"
  def next_year
    (Date.today.>>12).strftime('%Y')
  end

  # Returns an array of the expected effective years
  #
  # @return [Array<String>] The expected effective years
  def expected_effective_years
    year = Date.today.strftime("%Y").to_i
    [(year-7)..(year)].reverse
  end


  # Returns the expected maximum Effective Month year combination (next month)
  #
  # @return [String] The expected maximum Effective Month year combination (next month)
  def expected_max_effective_year_month_combination
    (Date.today>>1).strftime("%Y%m")
  end

  # The NJA Commercial Statuses
  #
  # @return [Array<String>] ['Commercial', 'Non-Commercial']
  def nja_commercial_status
    ['Commercial', 'Non-Commercial']
  end


  # Returns a random value between 1 and 4 rounded to two decimal places
  #
  # @return [FixNum] A random value between 1 and 4 rounded to two decimal places.
  def random_rate
    rate = Random.new
    rate.rand(1.0..4.0).round(2)
  end

  # Returns a string of n length of random alphabetical characters with no repeated characters
  #
  # @input [Integer] length The desired length of the string
  # @return [String] The random alphabetical characters
  def random_letters(length)
    ('a'..'z').to_a.shuffle[0,length].join
  end

end

World(CommonActions)

