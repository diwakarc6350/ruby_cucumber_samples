module InterchangeRateActions

  def select_random_interchange_month_year
    on InterchangePage do |p|
      p.effective_year = p.effective_year_options.sample
      p.effective_month = p.effective_month_options.sample
    end
  end

  def only_active_rate_types_are_displayed?
    on(InterchangePage).only_active_rate_types_are_displayed?
  end

  def create_interchange_rate_type(name, effective_date, opts={})
    on(InterchangePage).create_interchange_rate_type(name, effective_date, opts)
  end

  def create_default_interchange_rate_type(name, effective_date, opts={})
    on(InterchangePage).create_default_interchange_rate_type(name, effective_date, opts)
  end

  def interchange_rate_type_names
    on(InterchangePage).interchange_rate_type_names
  end

  def find_interchange_rate_type(name)
    on(InterchangePage).find_interchange_rate_type(name)
  end

  def set_interchange_effective_month(month)
    on(InterchangePage).effective_month = month
    on(InterchangePage).wait_for_ajax
  end

  def interchange_rate_types_attributes
    on(InterchangePage).wait_for_ajax
    interchange_attributes = []
    on(InterchangePage).interchange_rate_types.each do |xrate|
      xrate_attr = {}
      xrate_attr[:from] = xrate.from
      xrate_attr[:to] = xrate.to
      xrate_attr[:name] = xrate.name.include?('(Inactive)') ? xrate.name.gsub(/ \(Inactive\)/, '') : xrate.name
      xrate_attr[:effective_date] = xrate.effective_date
      xrate_attr[:inactive_date] = xrate.inactive_date
      interchange_attributes << xrate_attr
    end
    interchange_attributes
  end

  def create_new_interchange_rate_type
    on(InterchangePage).add_rate
  end

  def new_interchange_rate_type_name=(name)
    on(InterchangePage).add_rate_table_form.name = name
  end

  def new_interchange_rate_type_effective_period(effective_date, inactive_date = '')
    on(InterchangePage).add_rate_table_form.effective_date = effective_date
    on(InterchangePage).add_rate_table_form.inactive_date = inactive_date
  end

  def base_rate_copy_options
    on(InterchangePage).add_rate_table_form.clonable_base_rate_types_options
  end

  def set_random_number_of_base_rates_for_interchange_rate_type(base_rate_section, number_to_set=5)
    base_rate_section.name_element.click
    on(InterchangePage).wait_for_ajax

    on(InterchangePage).base_rate_links.to_a.shuffle.pop(number_to_set).each do |link|
      link.click
      on(InterchangePage).wait_for_ajax
      on(InterchangePage).base_rate_table[0].base_rate_input = Faker::Number.decimal(1)
      @browser.send_keys(:enter)
      on(InterchangePage).wait_for_ajax
    end
    sleep(2)
    on(InterchangePage).save
  end

  def base_rates_for_interchange_rate_type(base_rate_section)
    on InterchangePage do |page|
      page.wait_for_ajax
      base_rate_section.name_element.click
      page.wait_for_ajax
      page.base_rate_table.map(&:base_rate)
    end
  end

  def expected_interchange_rates
    InterchangeRateType.all_available_interchange_rates
  end

  def interchange_rate_types
      on(InterchangePage).wait_for_ajax
      on(InterchangePage).interchange_rate_types
  end

  def include_inactive_interchange_rate_types
    on(InterchangePage).include_inactive_interchange_rate_types
  end

  #Takes an interchange rate Section Object
  #Options to edit include:
  # name,	from,	to,	effective_date,	inactive_date, and	xrate
  def edit_interchange_rate_type(interchange_rate, opts={})
    interchange_rate.edit
    # opts.each do |k,v|
    #   on(InterchangePage).edit_rate_section.send("#{k}=", v)
    # end
    on InterchangePage do |page|
      page.edit_rate_section.populate_page_with(opts)
      page.edit_rate_section.update
      page.save
    end
  end

  def edit_interchange_rate_type_without_update(interchange_rate, opts={})
    interchange_rate.edit
    # opts.each do |k,v|
    #   on(InterchangePage).edit_rate_section.send("#{k}=", v)
    # end
    on(InterchangePage).edit_rate_section.populate_page_with(opts)
  end

  def save_interchange_rates
    on(InterchangePage).save
    on(InterchangePage).wait_for_ajax
  end

  def update_interchange_rate_type
    on(InterchangePage).edit_rate_section.update
  end

  def save_interchange_error
    on(InterchangePage).error_message_element
  end

  def select_interchange_rate_type(rate_type_section)
    rate_type_section.name_element.click
    on(InterchangePage).wait_for_ajax
  end

  def open_interchange_rate_for_current_rate_type
    on InterchangePage do |page|
      page.interchange_rate
      page.wait_for_ajax
    end
  end

  def first_interchange_rate
    on(InterchangePage).wait_for_ajax
    on(InterchangePage).interchange_rate_table.first.rate_element.text.delete('$').to_f
  end

  def interchange_rate_size
    on(InterchangePage).interchange_rate_types.count
  end
end

World(InterchangeRateActions)