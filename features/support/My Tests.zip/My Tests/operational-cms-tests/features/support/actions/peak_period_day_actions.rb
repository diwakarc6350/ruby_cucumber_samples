module PeakPeriodDayActions

  def add_new_ppd_list
    on(PeakPeriodDaysPage).add_list_element.click
    on(PeakPeriodDaysPage).wait_for_ajax
  end

  def add_ppd_list(list_name, effective_date, inactive_date=nil)
    on PeakPeriodDaysPage do |p|
      p.wait_for_ajax
      p.add_list_element.click
      p.wait_for_ajax
      p.list_name = list_name
      p.effective_date = effective_date
      p.inactive_date = inactive_date unless inactive_date.nil?
      p.save_list
      p.wait_for_ajax
      p.save_ppd_page
      on(FuelManagementPage).wait_for_ajax
      mess = PeakPeriodDateListMess.new(list_name, effective_date, inactive_date)
      Janitor.add_mess(mess)
    end
  end

  def save_ppd_changes
    @browser.button(text: 'OK').click if @browser.button(text: 'OK').exists?
    on(PeakPeriodDaysPage).save_ppd_page
    on(PeakPeriodDaysPage).wait_for_ajax
  end

  def add_ppd_list_without_saving(list_name, effective_date, inactive_date=nil)
    on PeakPeriodDaysPage do |p|
      p.add_list_element.click
      p.list_name = list_name
      p.effective_date = effective_date
      p.inactive_date = inactive_date unless inactive_date.nil?
    end
  end

  def edit_ppd_list(list_name, edited_list_name, effective_date=nil, inactive_date=nil)
    on PeakPeriodDaysPage do |p|
      p.open_list(list_name)
      p.list_name = edited_list_name
      p.effective_date = effective_date unless effective_date.nil?
      p.inactive_date = inactive_date unless inactive_date.nil?
      p.save_list
    end
  end

  def edit_ppd_list_without_saving(list_name, edited_list_name, effective_date=nil, inactive_date=nil)
    on PeakPeriodDaysPage do |p|
      p.open_list(list_name)
      p.list_name = edited_list_name
      p.effective_date = effective_date unless effective_date.nil?
      p.inactive_date = inactive_date unless inactive_date.nil?
    end
  end

  def ppd_list_contains(list_name)
    ppd_lists = on(PeakPeriodDaysPage).get_ppd_lists
    ppd_list_names = []
    (0..(ppd_lists.size - 1)).each do |i|
      ppd_list_names << ppd_lists[i]['list_name']
    end
    ppd_list_names.include? list_name
  end

  def select_random_year
    on(PeakPeriodDaysPage).effective_year=effective_year_options.sample
  end

  def effective_year_options
    on(PeakPeriodDaysPage).effective_year_options.map(&:to_i)
  end

  def peak_period_day_years
    [*2014..(next_year).to_i].reverse
  end

  def select_year(year)
    on(PeakPeriodDaysPage).effective_year = year
  end

  def inactive_dates_are_within_current_year
    current_year = on(PeakPeriodDaysPage).effective_year
    last_year = Date.strptime('01/01/' + (current_year.to_i-1).to_s, '%m/%d/%Y')
    ppd_lists = on(PeakPeriodDaysPage).get_ppd_lists
    (0..(ppd_lists.size - 1)).each do |i|
      if ppd_lists[i]['inactive_date'] != ''
        expect(Date.strptime(ppd_lists[i]['inactive_date'], '%m/%d/%Y') > last_year).to be true
      end
    end
  end

  def effective_dates_are_before_next_year
    current_year = on(PeakPeriodDaysPage).effective_year
    next_year = Date.strptime('01/01/' + (current_year.to_i+1).to_s, '%m/%d/%Y')
    ppd_lists = on(PeakPeriodDaysPage).get_ppd_lists
    (0..(ppd_lists.size - 1)).each do |i|
      expect(Date.strptime(ppd_lists[i]['effective_date'], '%m/%d/%Y') < next_year).to be true
    end
  end

  def create_ppd(peak_period_day_date, list_names=[])
    ppd_mess = PpdMess.new(peak_period_day_date)
    ppd_mess.clean
    on(PeakPeriodDaysPage).create_ppd(peak_period_day_date)
    add_ppd_to_ppd_lists(peak_period_day_date, list_names)
    save_ppd_changes
    ppd_mess = PpdMess.new(peak_period_day_date)
    Janitor.add_mess(ppd_mess)
    on(PeakPeriodDaysPage).wait_for_ajax
  end

  def add_ppd_to_ppd_lists(peak_period_day_date, list_names=[])
    list_names.each do |list_name|
      on(PeakPeriodDaysPage).add_ppd_to_list(peak_period_day_date,list_name)
    end
    close_error_messages
  end

  def close_error_messages
    on(PeakPeriodDaysPage).errors.each do |error|
      error.close
    end
  end

  def peak_period_day_list_names
    on(PeakPeriodDaysPage).peak_period_day_lists.map {|list| list.list_name_element.text}
  end

  def active_peak_period_day_list_names
    on(PeakPeriodDaysPage).peak_period_day_lists.map do |list|
      effective_date = Date.strptime(list.effective_date.gsub('Effective:', ''), '%m/%d/%Y')
      inactive_date = list.inactive_date.empty? ? (Date.today + 1.year) : Date.strptime(list.inactive_date.gsub('Inactive:', ''), '%m/%d/%Y')
      list.list_name_element.text if effective_date <= Date.today && inactive_date >= Date.today
    end.compact
  end

  def ppd_lists_containing_ppd(ppd_date)
    on(PeakPeriodDaysPage).ppd_lists_containing_ppd(ppd_date)
  end

  def find_date_row(effective_date)
    on(PeakPeriodDaysPage).find_date_row(effective_date)
  end

  def all_ppd_dates
    on(PeakPeriodDaysPage).peak_period_rows.map {|ppd| ppd.date_element.text}
  end

  def edit_peak_period_date(effective_date, new_effective_date)
    on(PeakPeriodDaysPage).edit_peak_period_date(effective_date, new_effective_date)
  end

  def edit_last_peak_period_date(new_effective_date)
    on(PeakPeriodDaysPage).peak_period_rows[-1].date
    on(PeakPeriodDaysPage).peak_period_rows[-1].editable_date = new_effective_date
    on(PeakPeriodDaysPage).peak_period_rows[-1].submit_date
  end

  def date_row_effective_dates
    on(PeakPeriodDaysPage).peak_period_rows.map { |row| row.date_element.text }
  end

  def delete_date_row(effective_date)
    ppd = find_date_row(effective_date)
    ppd.delete_element.click
    on(PeakPeriodDaysPage).wait_for_ajax
    on(PeakPeriodDaysPage).delete_row
    on(PeakPeriodDaysPage).wait_for_ajax
    @browser.button(text: 'OK').click
    on(PeakPeriodDaysPage).wait_for_ajax
    close_error_messages
  end

end

World(PeakPeriodDayActions)

