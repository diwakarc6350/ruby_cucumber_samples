module FuelTypeActions

  def active_fuel_types_exist?
    on(FuelManagementPage).active_fuel_types_exist?
  end

  def current_month_active_fuel_types
    on(FuelManagementPage).active_fuel_types
  end

  def previous_month_unchecked_fuel_types
    on(FuelManagementPage).regress_to_previous_month
    on(FuelManagementPage).unchecked_fuel_types
  end

  def inactivate_first_fuel_type
    on(FuelManagementPage).inactivate_first_fuel_type
  end

  def activate_first_fuel_type
    on(FuelManagementPage).activate_first_fuel_type
  end

  def first_fuel_type_is_active?
    on(FuelManagementPage).first_fuel_type_is_active?
  end

end

World(FuelTypeActions)