module BaseRateActions

  # Loads the Fuel Management Data data file
  def fuel_management_data
    YAML.load_file("features/support/data/manage_aircraft_data.yml")
  end

  # Selects the first rate type in the rate type table
  def select_rate_type
    on(InterchangePage).select_rate_type
  end

  # Returns all 'From Aircraft' aircraft types on the base rate table
  #
  # @return [Array<String>] All 'From Aircraft' aircraft types with '(hidden)' removed from each type
  def interchange_from_aircraft_types
    on(InterchangePage).interchange_from_aircraft_types
  end

  # Returns all 'To Aircraft' aircraft types on the base rate table
  #
  # @return [Array<String>] All 'To Aircraft' aircraft types with '(hidden)' removed from each type
  def interchange_to_aircraft_types
    on(InterchangePage).interchange_to_aircraft_types
  end

  # Gets all common names from the AIS database
  #
  # @return [Array] All aircraft type common names from the AIS database
  def ais_common_names
    AcftAircraftType.all_aircraft_common_names
  end

  # Returns the information displayed above the base rate table for the selected rate type
  #
  # @return [Hash<String>] the information displayed above the base rate table
  def rate_type_header_information
    on(InterchangePage).rate_type_header_information
  end

  # Returns the information for the first rate type in the rate type table
  #
  # @return [Hash] the information for the first rate type in the rate type table
  def rate_type_information
    on(InterchangePage).rate_type_information
  end

  # Generates a random value between 1 and 4 rounded to two decimal places
  #
  # @return [FixNum] A random value between 1 and 4 rounded to two decimal places
  def base_rate_value
    rate = Random.new
    rate.rand(1.0..4.0).round(2)
  end

  # Generates a random value between -4 and -1 rounded to two decimal places
  #
  # @return [FixNum] A random value between -4 and -1 rounded to two decimal places
  def negative_base_rate_value
    -(self.base_rate_value)
  end

  # Sets the value of the first cell on the Base Rate table and saves the page
  #
  # @parameter [FixNum] the desired value for the first Base Rate table cell
  def edit_base_rate_table_value(base_rate)
    on(InterchangePage).edit_base_rate_table_value(base_rate)
  end

  # Sets the value of the first cell on the Base Rate table without saving
  #
  # @parameter [FixNum] the desired value for the first Base Rate table cell
  def edit_base_rate_table_value_without_saving(base_rate)
    on(InterchangePage).edit_base_rate_table_value_without_saving(base_rate)
  end

  # Returns the value of the first cell on the Base Rate table
  #
  # @return [Float] the value of the first cell on the base rate table
  def first_base_rate_table_value
    on(InterchangePage).first_base_rate_table_value
  end

  # Returns the error message on the first cell of the Base Rate table
  #
  # @return [String] the error message on the first Base Rate table cell
  def first_base_rate_table_error
    on(InterchangePage).first_base_rate_table_error
  end

  # Includes inactive rate types on the rate type table and selects the last rate type on the table
  # This method only works if there is an existing inactive rate type
  def select_inactive_rate_type
    on(InterchangePage).select_inactive_rate_type
  end

  # Checks that every cell on the base rate table is displaying '-' (the '-' indicates no value)
  #
  # @return [Boolean] true if every cell on the base rate table is '-'
  def base_rate_table_empty?
    on(InterchangePage).base_rate_table_empty?
  end

  # Sets the effective month on the Interchange page to the next calendar month
  def select_next_month
    on(InterchangePage).select_next_month
  end

  # Hides a specified aircraft type in the specified direction on the base rate table
  #
  # @param [String] aircraft_type the specified aircraft type, eg. 'Citation Encore', 'Falcon 2000', 'Phenom 300'
  # @param [String] direction the direction that the aircraft type will NOT be hidden on, 'From' or 'To'
  #                             if direction is nil, the aircraft type is hidden for both directions
  def hide_aircraft(aircraft, direction)
    on(InterchangePage).hide_aircraft(aircraft, direction)
  end

  # Returns the list of unique aircraft hidden on the To and From axes of the Base Rate table
  #
  # @return [Array] the unique aircraft hidden on the To and From axes of the Base Rate table
  def hidden_aircraft_to_and_from
    on(InterchangePage).hidden_aircraft_to_and_from
  end

  # Checks that the specified aircraft is hidden in both directions on the base rate table
  #
  # @return [Boolean] true if the aircraft type is hidden in both directions
  def aircraft_is_hidden_to_and_from?(aircraft)
    on(InterchangePage).aircraft_is_hidden_to_and_from?(aircraft)
  end

  # Unhides the specified aircraft type in both directions
  #
  # @param [String] aircraft_type the aircraft_type to be unhidden
  def unhide_aircraft(aircraft)
    on(InterchangePage).unhide_aircraft(aircraft)
  end

  # Returns a list of all aircraft types that are currently hidden on the base rate table
  #
  # @return [Array] all aircraft types currently hidden on the base rate table
  def managed_aircraft
    on(InterchangePage).managed_aircraft
  end

  # Selects the last rate type in the rate type table
  def change_rate_type
    on(InterchangePage).change_rate_type
  end

  # Returns the number of aircraft types hidden on the base rate table
  #
  # @return [FixNum] the number of aircraft types hidden on the base rate table
  def number_of_hidden_aircraft
    on(InterchangePage).number_of_hidden_aircraft
  end

  # Returns the number of aircraft types hidden on the manage aircraft modal window
  #
  # @return [FixNum] the number of aircraft types hidden on the manage aircraft modal window
  def number_of_managed_aircraft
    on(InterchangePage).number_of_managed_aircraft
  end

  # Shows all hidden aircraft on the base rate table
  def show_all_aircraft
    on(InterchangePage).show_all_aircraft
  end

end

World(BaseRateActions)