module ServiceAreaActions

  # Searches for an airport using the provided airport code
  #
  # @param [String] airport_code The desired airport to be searched for
  def search_by_airport(airport_code)
    on(CreateServiceAreaPage).narrow_results = 'Airport'
    on(CreateServiceAreaPage).service_area_search = airport_code
    @browser.send_keys(:enter)
    on(CreateServiceAreaPage).wait_for_ajax
  end

  # Searches for a city using the provided city name
  #
  # @param [String] city_name The desired city to be searched for
  def search_by_city(city_name)
    on(CreateServiceAreaPage).narrow_results = 'City'
    on(CreateServiceAreaPage).service_area_search = city_name
    @browser.send_keys(:enter)
    on(CreateServiceAreaPage).wait_for_ajax
  end

  # Searches for a state using the provided state name
  #
  # @param [String] state_name The desired state to be searched for
  def search_by_state(state_name)
    on(CreateServiceAreaPage).narrow_results = 'State'
    on(CreateServiceAreaPage).service_area_search = state_name
    @browser.send_keys(:enter)
    on(CreateServiceAreaPage).wait_for_ajax
  end

  # Returns the search results from the Areas page
  #
  # @return [Array] The search results on the Areas page
  def service_area_search_results
    on(CreateServiceAreaPage).search_results
  end

  # Returns a defined array of airport codes
  #
  # @return [Array] Airport codes found in the ocms_data file
  def airport_codes
    YAML.load_file("features/support/data/ocms_data.yml")['airport_codes']
  end

  # Returns a defined array of city names
  #
  # @return [Array] City names found in the ocms_data file
  def city_names
    YAML.load_file("features/support/data/ocms_data.yml")['city_names']
  end

end

World(ServiceAreaActions)