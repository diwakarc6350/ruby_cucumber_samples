module NavigationActions

  def open_fuel_management
    patiently(10) { on(LandingPage).fuel_management }
    patiently(10) { on(LandingPage).wait_for_ajax }
  end

  def open_peak_period_days
    patiently(10) { on(LandingPage).peak_period_days }
    patiently(10) { on(LandingPage).wait_for_ajax }
  end

  def open_interchange
    patiently(10) { on(LandingPage).interchange }
    patiently(10) { on(LandingPage).wait_for_ajax }
  end

  def open_areas
    patiently(10) { on(LandingPage).areas }
    patiently(10) { on(LandingPage).wait_for_ajax }
  end

  def open_contract_search
    patiently(10) { on(LandingPage).contract_search }
    sleep(2)
    patiently(10) { on(LandingPage).wait_for_ajax }
  end
end

World(NavigationActions)

