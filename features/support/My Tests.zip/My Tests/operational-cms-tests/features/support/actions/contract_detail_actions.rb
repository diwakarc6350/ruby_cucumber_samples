module ContractDetailActions
  HoursInfo = Struct.new(:future_hours, :in_progress_flown_hours)

  # Returns the account specific header information for the contract currently being viewed
  #
  # @return [Hash] The account specific header information for the contract currently being viewed
  def account_header_information
    on(ContractDetailPage).account_header_information
  end

  # Returns the contract specific header information for the contract currently being viewed
  #
  # @return [Hash] The contract specific header information for the contract currently being viewed
  def contract_header_information
    on(ContractDetailPage).contract_header_information
  end

  # Returns the AR number for the account currently being viewed
  #
  # @return [String] The AR number for the account currently being viewed
  def current_account_ar_nbr
    on(ContractDetailPage).current_account_ar_nbr
  end

  # Returns the legal name for the account being viewed
  #
  # @return [String] The legal name for the account being viewed
  def header_legal_name
    on(ContractDetailPage).legal_name.gsub('Legal name: ', '')
  end

  # Returns the hours found in the hours detail section
  #
  # @return [Hash] The hours in the hours detail section
  def detail_hours_information
    on(ContractDetailPage).detail_hours_information
  end

  # Returns the account specific header information from IJET
  #
  # @param [FixNum] account_id The ID of the account that header information is being found for
  # @return [Hash] The account specific header information from IJET
  def ijet_account_header_information(account_id)
    account = Account.find_by ar_nbr: account_id
    Hash.new.tap do |header_information|
      header_information['account_name'] = account.account_name
      header_information['account_number'] = account.ar_nbr
      header_information['program'] = account.program.program_name
      header_information['sales_vp'] = account.sales_vp_full_name
      header_information['os_team'] = account.product_delivery_team.team_name
    end
  end

  # Returns the contract specific header information from the EDR
  #
  # @return [Hash] The contract specific header information from the EDR
  def expected_contract_header_information_attributes(op_contract_record)
    Hash.new.tap do |header_information|
      header_information[:end_date] = op_contract_record.end_dt.strftime('%m/%d/%Y')
      header_information[:ac_type] = op_contract_record.aircraft_type_names[0]
      header_information[:contract_number] = op_contract_record.cntr_op_contract_id.to_s
      header_information[:contract_status] = op_contract_record.contract_status
      header_information[:termination_date] = op_contract_record.contract_date.termination_dt.try(:strftime, '%m/%d/%Y') || ''
      header_information[:product_line] = op_contract_record.product.product_line
      header_information[:product] = op_contract_record.product.product_name
      header_information[:funding_date] = op_contract_record.contract_date.funding_dt.strftime('%m/%d/%Y')
      header_information[:delayed_start_date] = op_contract_record.contract_date.delayed_start_dt.try(:strftime, '%m/%d/%Y') || ''
      header_information[:extended_end_date] = op_contract_record.contract_date.extended_end_dt.try(:strftime, '%m/%d/%Y') || ''
      header_information[:cabin_class] = AcftAircraftType.cabin_class_for_aircraft(op_contract_record.aircraft_type_names[0])
      header_information[:accounting_company] = op_contract_record.contract_components[0].contract_cross_ref.contract_base.ej_company.company_name
      header_information[:commercial_status] = op_contract_record.contract_components[0].contract_cross_ref.contract_base.commercial ? 'Commercial' : 'Non-Commercial'
    end
  end

  # Navigates to the other half of a combo card contract
  def open_other_contract_for_combo_card
    on(ContractDetailPage).combo_card_element.click
  end

  # Navigates directly to a contract detail page without going through search
  #
  # @param [OPContract] contract The contract to be navigated to
  def view_details(contract)
    sleep(2)
    @browser.goto("#{base_url}/contractSearch/contractDetails?id=" + contract.attributes['cntr_op_contract_id'].to_s)
    on(ContractDetailPage).wait_until { on(ContractDetailPage).hours_detail.total_hours_element.visible? }
  end

  # Returns the contract hours on the currently displayed contract
  #
  # @return [Hash] The contract hours on the currently displayed contract
  def contract_hours
    on(ContractDetailPage).contract_hours
  end

  # Returns the expected detail hours for the given contract component
  #
  # @param [ContractComponent] contract_component The contract component that details are to be found for
  # @return [Hash] The detail hours for the specified contract component
  def expected_detail_hours_by_contract(contract_component)

    ijet_contract_id = contract_component.contract_cross_ref.contract_id
    OCMS.log.info("Ijet2 ContractID: #{ijet_contract_id}")
    hours_info = ijet2_hours_info(ijet_contract_id)

    in_process_flown_hours = hours_info.in_progress_flown_hours.round(2)
    future_hours = hours_info.future_hours.round(2)

    Hash.new.tap do |hours|
      hours['start_date'] = contract_component.op_contract.contract_date.funding_dt.to_date
      hours['end_date'] = contract_component.op_contract.end_dt.to_date
      hours['occupied_flight_hours'] = contract_component.hours_by_code_type('Occupied Flight Hours')
      hours['additional_hours'] = contract_component.hours_by_code_type('Bonus Hours') + contract_component.hours_by_code_type('Complimentary Hours') + contract_component.hours_by_code_type('Redemption Hours')
      hours['adjusted_hours'] = contract_component.hours_by_code_type('Transferred Hours') + contract_component.hours_by_code_type('Expired Hours')
      hours['total_allotted'] = hours['occupied_flight_hours'] + hours['additional_hours'] + hours['adjusted_hours']
      hours['billed'] = contract_component.usage_hours
      hours['excess_hours'] = contract_component.excess_hours
      hours['in_process_flown'] = in_process_flown_hours
      hours['remaining'] = (hours['total_allotted'] - hours['billed'] - hours['in_process_flown']).round(2)
      hours['future_flights'] = future_hours
      hours['projected_balance_hours'] = (hours['total_allotted'] - hours['billed'] - hours['in_process_flown'] - hours['future_flights']).round(2)
    end
  end

  def ijet2_hours_info(ijet_contract_id)
    billing_cycle_info = Invoice.billing_cycle_info_for_contract(ijet_contract_id)

    last_invoiced_date_for_contract = billing_cycle_info.nil? ? Ijet2Db::Contract.find(ijet_contract_id).contract_start_dat.to_date - 1.month : (billing_cycle_info.billing_cycle_ts.to_date + 1.month)


    requests_for_contract_since_last_billing_cycle = MidTier::Contract.search_requests_by_contract(ijet_contract_id, last_invoiced_date_for_contract)

    requests_in_progress_flown = requests_for_contract_since_last_billing_cycle.select { |request| request.departure_date <= Date.today }
    requests_in_future = requests_for_contract_since_last_billing_cycle.select { |request| request.departure_date > Date.today }

    hours_info = HoursInfo.new
    hours_info.future_hours = requests_in_future.reduce(0) { |sum, request| sum + request.projected_billing_hours }
    hours_info.in_progress_flown_hours = requests_in_progress_flown.reduce(0) { |sum, request| sum + request.projected_billing_hours }
    hours_info
  end

  def expected_allotted_hours_by_contract(contract_component)
    allotted_hours = Hash.new.tap do |hours|
      hours['occupied_flight_hours'] = contract_component.hours_by_code_type('Occupied Flight Hours')
      hours['redemption_hours'] = contract_component.hours_by_code_type('Redemption Hours')
      hours['bonus_hours'] = contract_component.hours_by_code_type('Bonus Hours')
      hours['expired_hours'] = contract_component.hours_by_code_type('Expired Hours')
      hours['transferred_hours'] = contract_component.hours_by_code_type('Transferred Hours')
      hours['complimentary_hours'] = contract_component.hours_by_code_type('Complimentary Hours')
    end
    allotted_hours['total_hours'] = allotted_hours.reduce(0) { |total, (key, val)| total += val }
    allotted_hours
  end

  def expected_contract_summaries(*op_contracts)
    op_contracts.flatten!
    contract_summaries = []
    op_contracts.each do |op_contract|
      op_contract.contract_components.each do |component|

        ijet_contract_id = component.contract_cross_ref.contract_id
        OCMS.log.info("Ijet2 ContractID: #{ijet_contract_id}")
        hours_info = ijet2_hours_info(ijet_contract_id)

        in_process_flown_hours = hours_info.in_progress_flown_hours
        future_hours = hours_info.future_hours

        contract_summaries << Hash.new.tap do |summary|
          summary[:contract_status] = op_contract.contract_status
          summary[:product_line] = op_contract.product.product_line
          summary[:product] = op_contract.product.product_name
          summary[:ac_type] = op_contract.aircraft_type_names[0]
          summary[:tail] = component.contract_cross_ref.contract_base.aircraft_tail ? component.contract_cross_ref.contract_base.aircraft_tail.tail_nbr : ''
          summary[:share_size] = op_contract.share_size.to_f.round(2)
          summary[:contract_card_nbr] = (op_contract.card_nbr || op_contract.cntr_op_contract_id).to_i
          summary[:start_date] = op_contract.contract_date.funding_dt.to_date
          summary[:end_date] = op_contract.contract_date.extended_end_dt.try(:to_date) || op_contract.end_dt.to_date
          summary[:allotted] = expected_allotted_hours_by_contract(component)['total_hours']
          summary[:billed] = component.usage_hours
          summary[:in_process] = in_process_flown_hours.to_f.round(2)
          summary[:future_flights] = future_hours.to_f.round(2)
          summary[:projected_balance] = (summary[:allotted] - summary[:billed] - summary[:in_process] - summary[:future_flights]).round(2)
        end
      end
    end
    contract_summaries
  end

  # Displays all contracts for the account currently being viewed
  def show_all_contracts_for_account
    on(ContractDetailPage).check_show_all
  end

  def account_contracts_summary
    on(ContractDetailPage).account_contracts_information
  end


  def active_component(contract)
    active_aircraft = on(ContractDetailPage).aircraft_type
    contract.component_by_aircraft_type(active_aircraft)
  end

  def expected_account_contracts_hours_total(contract_summary)
    Hash.new.tap do |total_hours|
      total_hours[:allotted] = contract_summary.reduce(0) { |sum, hours| sum + hours[:allotted] }.round(2)
      total_hours[:billed] = contract_summary.reduce(0) { |sum, hours| sum + hours[:billed] }.round(2)
      total_hours[:in_process_flown] = contract_summary.reduce(0) { |sum, hours| sum + hours[:in_process] }.round(2)
      total_hours[:future_flights] = contract_summary.reduce(0) { |sum, hours| sum + hours[:future_flights] }.round(2)
      total_hours[:projected_balance] = contract_summary.reduce(0) { |sum, hours| sum + hours[:projected_balance] }.round(2)
    end
  end

  def account_contracts_hours_total
    on(ContractDetailPage).account_contracts_total_hours.attributes
  end

  def view_account_summary
    on(ContractDetailPage).view_summary
  end

end

World(ContractDetailActions)