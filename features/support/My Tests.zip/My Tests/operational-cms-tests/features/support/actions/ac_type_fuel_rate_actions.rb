module AcTypeFuelRateActions

  # Opens the Fuel page and waits for the page to load
  def open_fuel_management
    on(LandingPage).fuel_management
    on FuelManagementPage do |page|
      page.wait_until(10) { page.effective_month_visible? }
      page.wait_for_ajax
    end
  end

  # Finds the AC Type Rate that matches the given parameters
  #
  # @param ac_type [String] the type of aircraft, eg. 'Challenger 650', 'Hawker 400XP', 'Citation Excel'
  # @param fuel_type [String] the fuel type, either 'Standard' (NJE or NJA) or 'Long Range' (NJA only)
  # @param effective_date [Date] the date on which the fuel rate becomes active
  # @return [Section] the fuel rate section element matching the above parameters
  def find_ac_type_fuel_rate(ac_type, fuel_type, effective_date)
    on(FuelManagementPage).find_ac_type_fuel_rate(ac_type, fuel_type, effective_date)
  end

  # Returns the attributes for a rate with the specified Aircraft Type, Fuel Type and Effective Date
  #
  # @param [String] ac_type The Aircraft Type for the rate being located
  # @param [String] fuel_type The Fuel Type for the rate being located
  # @param [Date] effective_date
  def ac_type_fuel_rate_attributes(ac_type, fuel_type, effective_date)
    ac_type_fuel_rate = on(FuelManagementPage).find_ac_type_fuel_rate_attributes(ac_type, fuel_type, effective_date)
    on(FuelManagementPage).wait_for_ajax
    ac_type_fuel_rate
  end

  def select_fuel_type_rate_date(month=nil, year=nil)
    on FuelManagementPage do |page|
      page.effective_month = month unless month.nil?
      page.effective_year = year unless year.nil?
    end
    on(FuelManagementPage).wait_for_ajax
    sleep(2)
  end

  def select_random_fuel_type_rate_date
    on FuelManagementPage do |page|
      page.effective_year = page.effective_year_options.sample
      page.effective_month = page.effective_month_options.sample
    end
  end

  # def fuel_type_average_table
  #   on(FuelManagementPage).fuel_type_average_table
  # end

  def submit_value
    @browser.send_keys(:enter)
  end

  def constraint_error
    on(FuelManagementPage).error_element.text
  end

  def last_ac_fuel_rate_editable
    on(FuelManagementPage).last_ac_fuel_rate_editable
  end

  # def select_first_effective_month
  #   on FuelManagementPage do |p|
  #     p.effective_year = p.effective_year_options[-1]
  #     p.effective_month = p.effective_month_options[0]
  #   end
  # end

  def edit_last_ac_fuel_rate(opts = {})
    on(FuelManagementPage).edit_last_ac_fuel_rate(opts)
  end

  def last_ac_fuel_rate
    on(FuelManagementPage).last_ac_fuel_rate
  end

  def select_last_effective_month
    on FuelManagementPage do |page|
      page.effective_year = page.effective_year_options[0]
      page.effective_month = page.effective_month_options[0]
    end
  end

  # Chooses the company being viewed on the Fuel page
  #
  # @param company [String] the company, 'NJA' or 'NJE'
  def select_company(company)
    on(FuelManagementPage).company = company
  end

  def nja_commercial_status
    ['Commercial', 'Non-Commercial']
  end

  def commercial_statuses
    on(FuelManagementPage).commercial_statuses
  end

  def fuel_types
    on(FuelManagementPage).fuel_types
  end

  def fuel_types_and_commercial_statuses
    commercial_statuses = self.commercial_statuses
    fuel_types = self.fuel_types
    fuel_types_and_commercial_statuses = []
    (0..(fuel_types.length-1)).each do |row|
      data = {}
      data['fuel_type'] = fuel_types[row]
      data['commercial_status'] = commercial_statuses[row]
      fuel_types_and_commercial_statuses << data
    end
    fuel_types_and_commercial_statuses
  end

  def effective_years
    on(FuelManagementPage).effective_year_options
  end

  def selectable_companies
    on(FuelManagementPage).company_options
  end

  def open_settings
    on(FuelManagementPage).settings
    sleep(2) #TODO: Put id on settings page, ng-app
  end

  def save_monthly_fuel_type_changes
    on(FuelManagementPage).save
  end

  def ensure_fuel_rates_are_positive
    fuel_rates = on(FuelManagementPage).three_month_average_rate
    (0..(fuel_rates.size)-1).each do |fuel_rate|
      expect(fuel_rates[fuel_rate]).to be >= 0
    end
  end

  def expected_effective_years
    year = Date.today.strftime("%Y").to_i
    [(year-7)..(year)].reverse
  end

  def current_company_option
    on(FuelManagementPage).company
  end

  def fuel_type_and_three_month_average
    on(FuelManagementPage).fuel_type_and_three_month_average
  end

  def calculate_current_three_month_averages(company)
    FuelType.calculate_three_month_averages(company)
  end

  def expected_max_effective_year_month_combination
    (Date.today>>1).strftime("%Y%m")
  end

  def delete_future_fuel_data
    FuelType.delete_future_fuel_data
  end

  def ensure_fuel_rates_are_nonexistent
    fuel_rates = on(FuelManagementPage).unparsed_three_month_average_rate
    (0..(fuel_rates.size)-1).each do |price|
      expect(fuel_rates[price]).to match /"$0.00" | "N\/A" /
    end
  end

  def max_effective_year_month_combination
    on(FuelManagementPage).max_effective_year_month_combination
  end

  def previous_month_fuel_types
    FuelType.previous_month_fuel_types
  end

  # Creates an AC Type Rate on the Fuel page
  #
  # @param ac_type [String] the type of aircraft, eg. 'Challenger 650', 'Hawker 400XP', 'Citation Excel'
  # @param fuel_type [String] the fuel type, either 'Standard' (NJE or NJA) or 'Long Range' (NJA only)
  # @param effective_date [Date] the date on which the fuel rate becomes active
  # @param [Hash] opts a hash of the additional fuel rate properties
  # @option opts [FixNum] :established_rate
  # @option opts [FixNum] :established_variable_rate
  # @option opts [FixNum] :differential
  # @option opts [FixNum] :variable_rate
  def create_ac_type_fuel_rate(ac_type, fuel_type, effective_date, opts={})
    mess = ACTypeFuelRateMess.new(ac_type, fuel_type, effective_date)
    mess.clean
    on FuelManagementPage do |page|
      page.add_ac_fuel_rate(ac_type, fuel_type, effective_date, opts)
      Janitor.add_mess(mess)
      page.wait_for_ajax
    end
  end

  # Finds a non-invoice fuel type on the Fuel page
  #
  # @return [Section] a non-invoiced fuel type section element
  def find_non_invoiced_fuel_type_rate
    on(FuelManagementPage).ac_type_fuel_rates.find do |fuel_rate|
      fuel_rate.delete_element.visible?
    end
  end

  # Saves any changes made on the Fuel Page since the previous load of the page
  def save_changes
    on(FuelManagementPage).save_changes
  end

  def ac_type_fuel_rates
    on(FuelManagementPage).wait_for_ajax
    on(FuelManagementPage).ac_type_fuel_rates.map do |rate|
      Hash.new.tap do |rate_record|
        rate_record[:ac_type] = rate.ac_type_element.text
        rate_record[:fuel_type] = rate.fuel_type.strip
        rate_record[:established_rate] = rate.established_rate_element.text
        rate_record[:established_variable] = rate.established_variable_element.text
        rate_record[:differential] = rate.differential_element.text
        rate_record[:variable_rate] = rate.variable_rate_element.text
        rate_record[:effective_date] = rate.effective_date_element.text
      end
    end
  end


  def ac_type_names
    ac_type_names = []
    fuel_rates = ac_type_fuel_rates
    fuel_rates.each do |fuel_rate|
      fuel_rate
    end
  end

  def find_invoiced_fuel_type_rate
    on(FuelManagementPage).ac_type_fuel_rates.find do |fuel_rate|
      !fuel_rate.delete_element.exists?
    end
  end


  def delete_rate(ac_type, fuel_type, effective_date)
    on(FuelManagementPage).delete_rate(ac_type, fuel_type, effective_date)
  end

  def edit_ac_fuel_rate(ac_type, fuel_type, effective_date, opts={})
    on(FuelManagementPage).edit_ac_fuel_rate(ac_type, fuel_type, effective_date, opts)
  end

  def set_first_monthly_average_rate(fuel_rate)
    on FuelManagementPage do |page|
      page.fuel_type_average_table[0].monthly_average_rate_link
      page.fuel_type_average_table[0].monthly_average_rate = fuel_rate
    end
  end

  def save_error
    on(FuelManagementPage).save_error_element.text
  end

  def randomize_monthly_average_rates
    on(FuelManagementPage).randomize_monthly_average_rates
  end

  def save_fuel_type_rates
    on(FuelManagementPage).save_changes
  end

  def first_monthly_average_rate
    on(FuelManagementPage).fuel_type_average_table[0].monthly_average_rate_link_element.text
  end

  def first_three_month_average
    on(FuelManagementPage).fuel_type_average_table[0].three_month_average.gsub(/[,$]/, '').to_f
  end

  def calculated_monthly_fuel_rates(ac_type, fuel_type, effective_date)
    on(FuelManagementPage).calculated_monthly_fuel_rates(ac_type, fuel_type, effective_date)
  end

  def calculated_three_month_fuel_rates(ac_type, fuel_type, effective_date)
    on(FuelManagementPage).calculated_three_month_fuel_rates(ac_type, fuel_type, effective_date)
  end

  def monthly_fuel_rates(ac_type, fuel_type, effective_date)
    on(FuelManagementPage).monthly_fuel_rates(ac_type, fuel_type, effective_date)
  end

  def three_month_fuel_rates(ac_type, fuel_type, effective_date)
    on(FuelManagementPage).three_month_fuel_rates(ac_type, fuel_type, effective_date)
  end

  def nja_statuses_are_visible
    on(FuelManagementPage).nja_statuses_are_visible
  end

  def nje_statuses_are_visible
    on(FuelManagementPage).nje_statuses_are_visible
  end

  def filter_ac_type(filter_by='')
    on(FuelManagementPage).ac_type_filter_box = filter_by
  end

end
World(AcTypeFuelRateActions)