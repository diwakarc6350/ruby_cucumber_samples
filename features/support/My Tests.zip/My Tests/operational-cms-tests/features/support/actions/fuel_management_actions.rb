module FuelManagementActions

  # Loads the Fuel Management Data data file
  def fuel_rate_data
    YAML.load_file("features/support/data/fuel_management_data.yml")
  end

  # Removes all fuel type data from the database that is dated past the last day of the current calendar month
  def delete_future_fuel_data
    FuelType.delete_future_fuel_data
  end

  # Checks that all 3 Months Average values are "N/A"
  def ensure_fuel_rates_are_nonexistent
    fuel_rates = on(FuelManagementPage).unparsed_three_month_average_rate
    (0..(fuel_rates.size)-1).each do |three_month_average|
      expect(fuel_rates[three_month_average]).to eq("N/A")
    end
  end

  # Returns the latest accessible billing month on the fuel page
  #
  # @return [String] The latest accessible billing month on the fuel page
  def max_effective_year_month_combination
    on(FuelManagementPage).max_effective_year_month_combination
  end

  def previous_month_fuel_types
    FuelType.previous_month_fuel_types
  end

  # Sets the Billing Month to the provided date on the Fuel page
  #
  # @param [String] month The desired month for the Billing Month date, must be a three letter abbreviation, defaults to nil
  # @param [String] year The desired year for the Billing Month date
  def select_fuel_type_rate_date(month=nil, year=nil)
    on FuelManagementPage do |page|
      page.effective_month = month unless month.nil?
      page.effective_year = year unless year.nil?
    end
  end

  # Sets the Billing Month the a random date on the fuel page
  def select_random_fuel_type_rate_date
    on FuelManagementPage do |page|
      page.effective_year = page.effective_year_options.sample
      page.effective_month = page.effective_month_options.sample
    end
  end

  # Sets the Billing Month to the first possible date on the fuel page
  def select_first_effective_month
    on FuelManagementPage do |page|
      page.effective_year = page.effective_year_options[1]
      page.effective_month = page.effective_month_options[0]
    end
  end

  # Sets the Billing Month to the last possible date on the fuel page
  def select_last_effective_month
    on FuelManagementPage do |page|
      page.effective_year = page.effective_year_options[0]
      page.effective_month = page.effective_month_options[0]
    end
  end

  # Sets the Company on the Fuel Page to the provided company
  #
  # @param [String] company The desired company to be selected, eg. NJA or NJE
  def select_company(company)
    on FuelManagementPage do |page|
      page.company = company
      page.wait_for_ajax
    end
  end

  def fuel_type_average_table
    on(FuelManagementPage).fuel_type_average_table
  end

  #Data on Fuel Management Page

  def commercial_statuses
    on(FuelManagementPage).commercial_statuses
  end

  def fuel_types
    on(FuelManagementPage).fuel_types
  end

  def fuel_types_and_commercial_statuses
    commercial_statuses = self.commercial_statuses
    fuel_types = self.fuel_types
    fuel_types_and_commercial_statuses = []
    (0..(fuel_types.length-1)).each do |row|
      data = {}
      data['fuel_type'] = fuel_types[row]
      data['commercial_status'] = commercial_statuses[row]
      fuel_types_and_commercial_statuses << data
    end
    fuel_types_and_commercial_statuses
  end

  def effective_years
    on(FuelManagementPage).effective_year_options
  end

  def selectable_companies
    on(FuelManagementPage).company_options
  end

  #Manipulating elements on Fuel Management Page

  def save_monthly_fuel_type_changes
    on(FuelManagementPage).save
  end

  def ensure_fuel_rates_are_positive
    fuel_rates = on(FuelManagementPage).three_month_average_rate
    (0..(fuel_rates.size)-1).each do |fuel_rate|
      expect(fuel_rates[fuel_rate]).to be >= 0
    end
  end

  def current_company_option
    on(FuelManagementPage).company
  end

  def fuel_type_and_three_month_average
    on(FuelManagementPage).fuel_type_and_three_month_average
  end

  def calculate_current_three_month_averages(company)
    FuelType.calculate_three_month_averages(company)
  end

  def advance_to_next_month
    on(FuelManagementPage).advance_to_next_month
  end

end

World(FuelManagementActions)

