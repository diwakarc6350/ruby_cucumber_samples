require 'pages/sections/service_area_search_results_section'

class CreateServiceAreaPage
  include PageObject
  include DataMagic

  text_field(:service_area_search, id: 'searchStringTxt')
  select_list(:narrow_results, id: 'narrowResultsSel')

  page_sections(:search_results, ServiceAreaSearchResultsSection, xpath: "//*[@id='createServiceAreaTabCnt']//tr[@class='ng-scope']")

end