class PeakPeriodDayListsSection
  include PageObject

  link(:list_name, xpath: "./a")
  label(:effective_date, xpath: "./div[1]/label")
  label(:inactive_date, xpath: "./div[2]/label")
end
