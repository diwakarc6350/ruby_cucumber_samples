class HiddenAircraftSection
  include PageObject

  td(:aircraft_type, xpath: './td[1]')
  label(:from_program, xpath: './td[2]/label')
  label(:to_program, xpath: './td[3]/label')
  checkbox(:to_program_checkbox, xpath: './td[3]/input[@type = "checkbox"]')
  checkbox(:from_program_checkbox, xpath: './td[2]/input[@type = "checkbox"]')
end