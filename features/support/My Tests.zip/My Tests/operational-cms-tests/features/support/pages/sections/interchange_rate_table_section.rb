class InterchangeRateTableSection
  include PageObject

  td(:rate, :xpath => './.')

end