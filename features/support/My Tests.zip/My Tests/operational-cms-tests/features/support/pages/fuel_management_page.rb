require 'page-object'
require 'date'
require_relative 'sections/ac_type_fuel_rates_section'
require_relative 'sections/fuel_type_average_section'

class FuelManagementPage
  include PageObject

  # indexed_property(:fuel_type_average_table, [
  #                                              [:td, :fuel_type, {id: 'fuelType_%s'}],
  #                                              [:td, :commercial_status, {id: 'commercialStatus_%s'}],
  #                                              [:link, :monthly_average_rate_link, {xpath: '//*[@id="averageRateQty_%s"]/a'}],
  #                                              [:text_field, :monthly_average_rate, {xpath: '//*[@id="averageRateQty_%s"]/form/div/input'}],
  #                                              [:td, :three_month_average, {id: 'threeMonthsAvg_%s'}],
  #                                              [:checkbox, :inactivate_fuel_type, {id: 'inactivateFuelTypesFromDB_%s'}],
  #                                              [:hidden, :precise_three_month_average, {id: 'average3MonthsWithPrecision_%s'}]
  #                                          ])

  link(:settings, xpath: '//*[@id="settings"]/a')
  div(:error, class: 'editable-error')
  div(:save_error, class: 'growl-message')

  page_sections(:fuel_type_average_table, FuelTypeAverageSection, xpath: '//*[@id="fuelTypeTable"]/tbody/tr/td[not(contains(@class, "ng-hide"))]/ancestor::tr')
  page_sections(:ac_type_fuel_rates, AcTypeFuelRatesSection, xpath: "//*[@id='acTypeFuelRates']/tbody/tr")


  table(:fuel_type_average, id: 'fuelTypeTable')
  select_list(:effective_year, id: 'effectiveYearSel')
  select_list(:effective_month, id: 'effectiveMonthSel')
  select_list(:company, id: 'companySel')
  button(:save, id: 'updateButton')
  button(:create, id: 'createButton')
  text_field(:ac_type_filter_box, id: 'acTypeSearch')
  button(:inactivate_ok, id: 'inactivateConfirmOk')
  button(:inactivate_cancel, id: 'inactivateConfirmCancel')

  # Deletes the specified AC Type Rate on the Fuel page and saves
  #
  # @parameter [String] ac_type the aircraft type for the specified rate being deleted
  # @parameter [String] fuel_type the fuel type for the specified rate being deleted (Standard or Long Range)
  # @parameter [Date] effective_date the Effective Date for the specified rate being deleted
  def delete_rate(ac_type, fuel_type, effective_date)
    rate = self.find_ac_type_fuel_rate(ac_type, fuel_type, effective_date)
    rate.delete
    save_changes
  end

  # Creates a copy of the last rate in the AC Type Rate table
  def clone_last_rate
    self.ac_type_fuel_rates.last.clone
  end

  # Returns a hash of the information for the last rate in the AC Type Rate table
  #
  # @return [Hash] the information for the last rate in the AC Type Rate table
  def last_ac_fuel_rate
    self.wait_for_ajax
    self.ac_type_fuel_rates[-1]
  end

  # Edits the last rate in the AC Type Rate table
  #
  # @param [Hash] opts the options to edit the rate with
  # @option opts [String] :ac_type the aircraft type
  # @option opts [String] :fuel_type the fuel type
  # @option opts [String] :established_rate the established rate
  # @option opts [String] :established_variable the established +/- rate
  # @option opts [String] :differential the differential
  # @option opts [String] :variable_rate the variable rate
  # @option opts [String] :effective_date the effective date
  def edit_last_ac_fuel_rate(opts={})
    self.wait_for_ajax
    opts.each do |k, v|
      self.ac_type_fuel_rates[-1].send(k)
      self.ac_type_fuel_rates[-1].send("editable_#{k}=", v)
      @browser.send_keys(:enter)
    end
  end

  # Adds a rate to the AC Type Rate table
  #
  # @param [String] ac_type the aircraft type for the rate to be added
  # @param [String] fuel_type the fuel type for the rate to be added
  # @param [Date] effective_date the effective date for the rate to be added
  # @param [Hash] opts the options to set on the rate to be added
  # @option opts [String] :established_rate the established rate
  # @option opts [String] :established_variable the established +/- rate
  # @option opts [String] :differential the differential
  # @option opts [String] :variable_rate the variable rate
  # @option opts [String] :effective_date the effective date
  def add_ac_fuel_rate(ac_type, fuel_type, effective_date, opts={})
    self.wait_for_ajax
    self.ac_type_fuel_rates[-1].clone
    self.wait_for_ajax
    self.ac_type_fuel_rates[-1].ac_type
    self.wait_for_ajax
    self.ac_type_fuel_rates[-1].editable_ac_type = ac_type
    self.wait_for_ajax
    self.ac_type_fuel_rates[-1].submit_ac_type
    # self.ac_type_fuel_rates[-1].fuel_type
    self.wait_for_ajax
    self.ac_type_fuel_rates[-1].fuel_type = fuel_type
    self.ac_type_fuel_rates[-1].effective_date
    self.ac_type_fuel_rates[-1].editable_effective_date = effective_date.strftime('%m/%d/%Y')
    self.ac_type_fuel_rates[-1].submit_effective_date
    opts.each do |k, v|
      self.ac_type_fuel_rates[-1].send(k)
      self.ac_type_fuel_rates[-1].send("editable_#{k}=", v)
      @browser.send_keys(:enter)
    end
    self.wait_for_ajax
    self.save_changes

  end

  # Saves all changes to the Fuel page
  def save_changes
    @browser.scroll.to(:top)
    @browser.send_keys(:enter)
    self.save
    self.wait_for_ajax
  end

  # Returns the rate from the AC Type Rate table that matches the given parameters
  #
  # @parameter [String] ac_type the aircraft type of the rate being found
  # @parameter [String] fuel_type the fuel type of the rate being found
  # @parameter [Date] effective_date the effective date of the rate being found
  #
  # @return [Section] the rate that matches the given parameters
  def find_ac_type_fuel_rate(ac_type, fuel_type, effective_date)
    self.ac_type_fuel_rates.find do |fuel_rate|
      fuel_rate.ac_type_element.text == ac_type &&
          fuel_rate.fuel_type.strip == fuel_type &&
          fuel_rate.effective_date_element.text == effective_date.strftime('%m/%d/%Y')
    end
  end

  # Returns the index of the rate in the AC Type Rate table that matches the given parameters
  #
  # @parameter [String] ac_type the aircraft type of the rate being found
  # @parameter [String] fuel_type the fuel type of the rate being found
  # @parameter [Date] effective_date the effective date of the rate being found
  #
  # @return [FixNum] the index of the rate that matches the given parameters
  def find_ac_type_fuel_row(ac_type, fuel_type, effective_date)
    found_rate = nil
    self.ac_type_fuel_rates.each_with_index do |fuel_rate, index|
      return found_rate = ac_type_fuel_rates[index] if (fuel_rate.ac_type_element.text == ac_type &&
          fuel_rate.fuel_type.strip == fuel_type &&
          fuel_rate.effective_date_element.text == effective_date.strftime('%m/%d/%Y'))
    end
  end

  # Finds the rate on the AC Type Rate table matching the given parameters and edits it with the given options
  #
  # @param [String] ac_type the aircraft type for the rate being edited
  # @param [String] fuel_type the fuel type for the rate being edited
  # @param [Date] effective_date the effective date for the rate being edited
  # @param [Hash] opts the options to set on the rate to be edited
  # @option opts [String] :established_rate the established rate
  # @option opts [String] :established_variable the established +/- rate
  # @option opts [String] :differential the differential
  # @option opts [String] :variable_rate the variable rate
  # @option opts [String] :effective_date the effective date
  def edit_ac_fuel_rate(ac_type, fuel_type, effective_date, opts={})
    self.wait_for_ajax
    rate = find_ac_type_fuel_rate(ac_type, fuel_type, effective_date)
    self.wait_for_ajax
    opts.each do |k, v|
      rate.send(k)
      self.wait_for_ajax
      rate.send("editable_#{k}=", v)
      @browser.send_keys(:enter)
    end
    save_changes
  end

  # Returns the number of fuel types in the Fuel Type / Rate table
  #
  # @return [FixNum] the number of fuel types in the Fuel Type / Rate table
  def fuel_type_count
    count = 0
    self.fuel_type_average_element.each { |x| count+=1 }
    count
  end

  # Returns the fuel types listed on the Fuel Type / Rate Table
  #
  # @return [Array<String>] the fuel types listed on the Fuel Type / Rate Table
  def fuel_types
    fuel_types = []
    self.wait_for_ajax
    fuel_type_average_table.each { |type| fuel_types << type.fuel_type }
    fuel_types
  end

  # Returns an hash of three month averages indexed by Fuel Type and Commercial Status
  #
  # @return [Hash<String, FixNum>]
  def fuel_type_and_three_month_average
    self.wait_for_ajax
    fuel_type_and_commercial_status = {}
    fuel_type_average_table.each do |type|
      fuel_type_and_commercial_status["#{type.fuel_type} #{type.commercial_status}"] = type.three_month_average.gsub(/[,$]/, '').to_f
    end
    fuel_type_and_commercial_status
  end

  # Returns an array of all Fuel Types concatenated with their Commercial Statuses
  #
  # @return [Array<String>] Fuel Type concatenated with Commercial Status
  def fuel_type_and_commercial_status
    fuel_type_and_commercial_status = []
    fuel_type_average_table.each { |type| fuel_type_and_commercial_status << type.fuel_type + ' ' + type.commercial_status }
    fuel_type_and_commercial_status
  end

  # Returns an array of all Commercial Statuses
  #
  # @return [Array<String>] Commercial Statuses
  def commercial_statuses
    commercial_statuses = []
    fuel_type_average_table.each { |status| commercial_statuses << status.commercial_status }
    commercial_statuses
  end

  # Returns the attributes for a rate with the specified Aircraft Type, Fuel Type and Effective Date
  #
  # @param [String] ac_type The Aircraft Type for the rate being located
  # @param [String] fuel_type The Fuel Type for the rate being located
  # @param [Date] effective_date
  def find_ac_type_fuel_rate_attributes(ac_type, fuel_type, effective_date)
    self.wait_for_ajax
    ac_type_fuel_rate = self.find_ac_type_fuel_rate(ac_type, fuel_type, effective_date)
    ac_attributes = {}
    self.wait_for_ajax
    ac_attributes[:ac_type] = ac_type_fuel_rate.ac_type_element.text
    ac_attributes[:fuel_type] = ac_type_fuel_rate.fuel_type.strip
    ac_attributes[:established_rate] = ac_type_fuel_rate.established_rate_element.text
    ac_attributes[:established_variable] = ac_type_fuel_rate.established_variable_element.text
    ac_attributes[:differential] = ac_type_fuel_rate.differential_element.text
    ac_attributes[:variable_rate] = ac_type_fuel_rate.variable_rate_element.text
    ac_attributes[:effective_date] = ac_type_fuel_rate.effective_date_element.text
    ac_attributes
  end

  def actual_information
    fuel_type_data = []
    (0..(self.fuel_type_count)-2).each do |i|
      entries = {}
      entries['fuel_type'] = self.fuel_type_average_table[i].fuel_type.to_s
      entries['commercial_status'] = self.fuel_type_average_table[i].commercial_status.to_s
      entries['monthly_average_rate'] = self.fuel_type_average_table[i].monthly_average_rate_link_element.text.gsub(/[^\d\.]/, '').to_f
      entries['three_month_average'] = self.fuel_type_average_table[i].precise_three_month_average.gsub(/[^\d\.]/, '').to_f
      fuel_type_data << entries
    end
    fuel_type_data
  end

  # Returns the three month average rates for all Fuel Types on the page
  #
  # @return [Array<FixNum>] The three month average rate for each Fuel Type on the page
  def three_month_average_rate
    three_month_averages = []
    (0..(self.fuel_type_average_table.size)-1).each do |i|
      three_month_averages << self.fuel_type_average_table[i].three_month_average.delete('$').to_f
    end
    three_month_averages
  end

  # Returns the three month average rates for all Fuel Types on the page formatted as "$X.XX"
  #
  # @return [Array<String>] The three month average rate for each Fuel Type on the page formatted as "$X.XX"
  def unparsed_three_month_average_rate
    three_month_averages = []
    (0..(self.fuel_type_average_table.size)-1).each do |i|
      three_month_averages << self.fuel_type_average_table[i].three_month_average
    end
    three_month_averages
  end

  # Returns the latest accessible billing month on the fuel page
  #
  # @return [String] The latest accessible billing month on the fuel page
  def max_effective_year_month_combination
    year = self.effective_year_options[0]
    month = sprintf '%02d', Date::ABBR_MONTHNAMES.index(self.effective_month_options[0])
    year + month
  end

  # Calculates the expected monthly fuel rates for the given AC Type Rate Row
  #
  # @param [String] ac_type The AC Type used to locate the given AC Type Rate Row
  # @param [String] fuel_type The Fuel Type used to locate the given AC Type Rate Row
  # @param [Date] effective_date The Effective Date used to locate the given AC Type Rate Row
  #
  # @return [Array<FixNum>] The calculated expected monthly fuel rates for the given AC Type Rate Row
  def calculated_monthly_fuel_rates(ac_type, fuel_type, effective_date)
    raw_aircraft_info = self.find_ac_type_fuel_rate(ac_type, fuel_type, effective_date)
    aircraft_info = self.parse_aircraft_row(raw_aircraft_info)
    fuel_rates = self.actual_information.select { |x| x['fuel_type'] == aircraft_info['fuel_type'] }
    company = self.company.downcase
    self.wait_for_ajax
    send("calculate_#{company}_monthly_fuel_rates", fuel_rates, aircraft_info)
  end

  # Calculates the expected three month average fuel rates for the given AC Type Rate Row
  #
  # @param [String] ac_type The AC Type used to locate the given AC Type Rate Row
  # @param [String] fuel_type The Fuel Type used to locate the given AC Type Rate Row
  # @param [Date] effective_date The Effective Date used to locate the given AC Type Rate Row
  #
  # @return [Array<FixNum>] The calculated expected three month average fuel rates for the given AC Type Rate Row
  def calculated_three_month_fuel_rates(ac_type, fuel_type, effective_date)
    raw_aircraft_info = self.find_ac_type_fuel_rate(ac_type, fuel_type, effective_date)
    aircraft_info = self.parse_aircraft_row(raw_aircraft_info)
    fuel_rates = self.actual_information.select { |x| x['fuel_type'] == aircraft_info['fuel_type'] }
    company = self.company.downcase
    send("calculate_#{company}_three_month_fuel_rates", fuel_rates, aircraft_info)
  end

  def calculate_nja_monthly_fuel_rates(fuel_rates, aircraft_info)
    calculated_values = []
    commercial_value = fuel_rates.find { |x| x['commercial_status'] == 'Commercial' }
    noncommercial_value = fuel_rates.find { |x| x['commercial_status'] == 'Non-Commercial' }
    calculated_values << monthly_calculation(commercial_value['monthly_average_rate'], aircraft_info['established_rate'],
                                             aircraft_info['differential'], aircraft_info['variable_rate'])
    calculated_values << monthly_calculation(noncommercial_value['monthly_average_rate'], aircraft_info['established_rate'],
                                             aircraft_info['differential'], aircraft_info['variable_rate'])
    calculated_values
  end

  def calculate_nje_monthly_fuel_rates(fuel_rates, aircraft_info)
    calculated_values = []
    calculated_values << monthly_calculation(fuel_rates[0]['monthly_average_rate'], aircraft_info['established_rate'],
                                             aircraft_info['differential'], aircraft_info['variable_rate'])
    calculated_values
  end

  def calculate_nja_three_month_fuel_rates(fuel_rates, aircraft_info)
    calculated_values = []
    commercial_value = fuel_rates.find { |x| x['commercial_status'] == 'Commercial' }
    noncommercial_value = fuel_rates.find { |x| x['commercial_status'] == 'Non-Commercial' }

    calculated_values << monthly_calculation(commercial_value['three_month_average'].to_f, aircraft_info['established_rate'],
                                             aircraft_info['differential'], aircraft_info['variable_rate'])
    calculated_values << monthly_calculation(noncommercial_value['three_month_average'].to_f, aircraft_info['established_rate'],
                                             aircraft_info['differential'], aircraft_info['variable_rate'])
    calculated_values
  end

  def calculate_nje_three_month_fuel_rates(fuel_rates, aircraft_info)
    calculated_values = []
    calculated_values << monthly_calculation(fuel_rates[0]['three_month_average'].to_f, aircraft_info['established_rate'],
                                             aircraft_info['differential'], aircraft_info['variable_rate'])
    calculated_values
  end

  # Calculates the expected monthly fuel rate value for an AC Type Rate
  #
  # @param [FixNum] monthly_average_fuel_cost The Monthly Average Rate for the AC Type Rate Fuel Type
  # @param [FixNum] established_rate The Established +/- Rate for the AC Type Rate
  # @param [FixNum] differential The Differential for the AC Type Rate
  # @param [FixNum] fuel_variable_rate The Variable Rate for the AC Type Rate
  #
  # @return [FixNum] The calculated expected monthly fuel rate value for an AC Type Rate
  def monthly_calculation(monthly_average_fuel_cost, established_rate, differential, fuel_variable_rate)
    self.wait_for_ajax
    (((monthly_average_fuel_cost - established_rate)/differential) * fuel_variable_rate).round(2).abs
  end

  def monthly_fuel_rates(ac_type, fuel_type, effective_date)
    company = self.company.downcase
    self.wait_for_ajax
    send("get_#{company}_monthly_fuel_rates", ac_type, fuel_type, effective_date)
  end

  def get_nja_monthly_fuel_rates(ac_type, fuel_type, effective_date)
    monthly_fuel_rates = []
    fuel_rates_row = self.find_ac_type_fuel_row(ac_type, fuel_type, effective_date)
    monthly_fuel_rates << fuel_rates_row.commercial_monthly_rate.gsub(/[^\d\.]/, '').to_f
    monthly_fuel_rates << fuel_rates_row.non_commercial_monthly_rate.gsub(/[^\d\.]/, '').to_f
    monthly_fuel_rates
  end

  def get_nje_monthly_fuel_rates(ac_type, fuel_type, effective_date)
    monthly_fuel_rates = []
    fuel_rates_row = self.find_ac_type_fuel_row(ac_type, fuel_type, effective_date)
    monthly_fuel_rates << fuel_rates_row.monthly_rate.gsub(/[^\d\.]/, '').to_f
    monthly_fuel_rates
  end

  def three_month_fuel_rates(ac_type, fuel_type, effective_date)
    company = self.company.downcase
    send("get_#{company}_three_month_fuel_rates", ac_type, fuel_type, effective_date)
  end

  def get_nja_three_month_fuel_rates(ac_type, fuel_type, effective_date)
    three_month_fuel_rates = []
    fuel_rate = self.find_ac_type_fuel_row(ac_type, fuel_type, effective_date)
    three_month_fuel_rates << fuel_rate.commercial_three_month_average_rate.gsub(/[^\d\.]/, '').to_f
    three_month_fuel_rates << fuel_rate.non_commercial_three_month_average_rate.gsub(/[^\d\.]/, '').to_f
    three_month_fuel_rates
  end

  def get_nje_three_month_fuel_rates(ac_type, fuel_type, effective_date)
    three_month_fuel_rates = []
    fuel_rate = self.find_ac_type_fuel_row(ac_type, fuel_type, effective_date)
    three_month_fuel_rates << fuel_rate.three_month_average.gsub(/[^\d\.]/, '').to_f
    three_month_fuel_rates
  end

  # Checks that all NJA specific statuses are visible on the Fuel page
  #
  # @return [Boolean] true if both NJA statuses are visible, false if one or neither is visible
  def nja_statuses_are_visible
    (browser.th(:text, 'Commercial (Monthly)').exists? &&
        browser.th(:text, 'Non-Commercial (Monthly)').exists?)
  end

  # Checks that all NJE specific statuses are visible on the Fuel page
  #
  # @return [Boolean] true if NJE status is visible, false if not visible
  def nje_statuses_are_visible
    (@browser.th(:text, 'Monthly').exists?)
  end

  def parse_aircraft_row(aircraft_info)
    parsed_aircraft_information = {}
    parsed_aircraft_information['ac_type'] = aircraft_info.ac_type_element.text
    parsed_aircraft_information['fuel_type'] = aircraft_info.fuel_type.strip
    parsed_aircraft_information['established_rate'] = aircraft_info.established_rate_element.text.gsub(/[^\d\.]/, '').to_f
    parsed_aircraft_information['established_variable_rate'] =
        aircraft_info.established_variable_element.text.gsub(/[^\d\.]/, '').to_f
    parsed_aircraft_information['differential'] = aircraft_info.differential_element.text.gsub(/[^\d\.]/, '').to_f
    parsed_aircraft_information['variable_rate']= aircraft_info.variable_rate_element.text.gsub(/[^\d\.]/, '').to_f
    parsed_aircraft_information['effective_date'] = aircraft_info.effective_date_element.text
    parsed_aircraft_information
  end

  # Sets the Monthly Average Rate for each Fuel Type on the fuel page to a random value
  def randomize_monthly_average_rates
    rate = Random.new
    self.wait_for_ajax
    fuel_type_average_table.each do |fuel_rate_type|
      @browser.scroll.to :top
      fuel_rate_type.monthly_average_rate_link_element
      fuel_rate_type.monthly_average_rate_link
      fuel_rate_type.monthly_average_rate = rate.rand(30.0..40.0).round(2)
      @browser.send_keys(:enter)
    end
    self.create if self.create_element.exist?
    self.wait_for_ajax
  end

  # Checks if active fuel types exist on the selected Billing Month on the fuel page
  #
  # @return [Boolean] Returns true if active fuel types exist on the selected Billing Month on the fuel page
  def active_fuel_types_exist?
    active_values = []
    fuel_type_average_table.each { |type| active_values << type.inactivate_fuel_type_checkbox_checked? }
    active_values.include?(false)
  end

  # Sets the Billing Month on the Fuel page to the next calendar month
  def advance_to_next_month
    current_month = Date::ABBR_MONTHNAMES.index(self.effective_month)
    next_month = Date::ABBR_MONTHNAMES[(current_month % 12) + 1]
    if next_month == 'Jan'
      (self.effective_year = self.effective_year.to_i + 1)
    end
    self.effective_month = next_month
  end

  # Sets the Billing Month on the Fuel page to the previous calendar month
  def regress_to_previous_month
    current_month = Date::ABBR_MONTHNAMES.index(self.effective_month)
    if current_month == 1
      (self.effective_year = self.effective_year.to_i - 1)
      previous_month = 'Dec'
    else
      previous_month = Date::ABBR_MONTHNAMES[current_month - 1]
    end
    self.effective_month = previous_month
  end

  # Returns a list of active Fuel Types on the fuel page
  #
  # @return [Array<String>] The active Fuel Types on the fuel page
  def active_fuel_types
    fuel_types = []
    self.wait_for_ajax
    fuel_type_average_table.each do |type|
      if type.fuel_type != ''
        fuel_types << type.fuel_type + ' ' + type.commercial_status
      end
    end
    fuel_types
  end

  # Returns a list of unchecked Fuel Types on the fuel page
  #
  # @return [Array<String>]  The unchecked Fuel Types concatenated with their respective Commercial Statuses
  def unchecked_fuel_types
    fuel_types = []
    self.wait_for_ajax
    fuel_type_average_table.each do |type|
      if type.inactivate_fuel_type_checkbox_checked? == false
        fuel_types << type.fuel_type + ' ' + type.commercial_status
      end
    end
    fuel_types
  end

  # Checks if the Billing Month month selection list is visible
  #
  # @return [Boolean] True if the Billing Month month selection list is visible
  def effective_month_visible?
    self.effective_month_element.visible?
  end

  # Inactivates the first fuel type on the Fuel page
  def inactivate_first_fuel_type
    if fuel_type_average_table_section.first.inactivate_fuel_type_checkbox_checked?
      fuel_type_average_table_section.first.inactivate_fuel_type_element.click
      self.wait_for_ajax
      self.inactivate_ok
      self.wait_for_ajax
    end
    fuel_type_average_table_section.first.inactivate_fuel_type_element.click
    self.wait_for_ajax
    self.inactivate_ok
    self.wait_for_ajax
  end

  # Activates the first fuel type on the Fuel page
  def activate_first_fuel_type
    fuel_type_average_table_section.first.inactivate_fuel_type_checkbox_checked? ?
        fuel_type_average_table_section.first.inactivate_fuel_type_element.click : ''
    self.wait_for_ajax

    self.inactivate_ok
    self.wait_for_ajax
  end

  # Checks if the first fuel type on the Fuel page is active
  #
  # @return [Boolean] Returns true if the first fuel type is active
  def first_fuel_type_is_active?
    !fuel_type_average_table_section.first.inactivate_fuel_type_checkbox_checked?
  end

end