require 'page-object'
require_relative 'sections/peak_period_days_section'
require_relative 'sections/peak_period_day_lists_section'
require_relative 'sections/errors_section'

class PeakPeriodDaysPage
  include PageObject

  select_list(:company, id: 'companySelPPD')
  select_list(:effective_year, id: 'effectiveYearSel')
  link(:add_list, link_text: 'Add List')
  link(:add_row, link_text: 'Add Row')
  link(:delete_row, link_text: 'Delete Row')

  button(:save_ppd_page, id: 'savePPD')
  button(:cancel_ppd_page, id: 'cancelPPD')

  table(:peak_period_days_table, id: 'peakDayTable')

  text_field(:list_name, id: 'listName')
  text_field(:effective_date, id: 'effectiveDate')
  text_field(:inactive_date, id: 'inactiveDate')
  button(:cancel_add_list, text: 'Close')
  button(:save_list, id: 'add-ppd-list-btn')

  page_sections(:errors, ErrorsSection, class: 'growl-item')
  page_sections(:peak_period_rows, PeakPeriodDaysSection, xpath: '//*[@id="peakDayTable"]/tbody/tr')
  page_sections(:peak_period_day_lists, PeakPeriodDayListsSection, xpath: '//*[@id="peakDayTable"]/thead/tr/th[position()>1]')

  # Returns an array of hashes of all Peak Period Day Lists present for the selected company and year
  #
  # @return [Array<(Hash)>] An array of Peak Period Day List hashes
  # @option [String] list_name the name of the list
  # @option [Date] effective_date the effective date for the peak period day list
  # @option [Date] inactive_date the inactive date for the peak period day list
  def get_ppd_lists
    self.wait_for_ajax
    ppd_list_data = []
    length = (self.ppd_list_count)-1
    (1..length).each do |i|
      entries = {}
      entries['list_name'] = peak_period_days_table_element[0][i].a.text
      entries['effective_date'] = peak_period_days_table_element[0][i].label_elements[0].text.gsub("Effective:", '')
      entries['inactive_date'] = peak_period_days_table_element[0][i].label_elements[1].text.gsub("Inactive:", '')
      ppd_list_data << entries
    end
    ppd_list_data
  end

  # Returns the number of Peak Period Day lists for the currently selected company and effective year
  #
  # @return [FixNum] number of Peak Period Day lists for currently selected company and effective year
  def ppd_list_count
    count = peak_period_days_table_element[0].to_a.length
  end

  # Opens the first Peak Period Day list's "Edit List" modal for the currently selected company and effective year
  def open_first_list
    @browser.table(id: 'peakDayTable')[0][1].a.click
  end

  # Opens the provided Peak Period Day list's "Edit List" modal
  #
  # @param [String] list_name the name of the Peak Period Day list to be opened
  def open_list(list_name)
    @browser.link(text: list_name).click
  end

  # Adds a Peak Period Day and sets its date to the provided date
  #
  # @param [Date] effective_date the date desired for the Peak Period Day to be added
  def create_ppd(effective_date)
    self.add_row
    self.peak_period_rows[-1].date
    self.peak_period_rows[-1].editable_date = effective_date.strftime('%m/%d/%Y')
    self.peak_period_rows[-1].submit_date
    self.wait_for_ajax
  end

  # Returns the Peak Period Day with the provided date
  #
  # @param [Date] effective_date the date of the Peak Period Day row to be found
  # @return [Section] the Peak Period Day row with the provided date
  def find_date_row(effective_date)
    self.peak_period_rows.find do |ppd_row|
      ppd_row.date_element.text == effective_date.strftime('%m/%d/%Y')
    end
  end

  # Finds the Peak Period Day with the provided date and sets it to the desired date
  #
  # @param [Date] effective_date the date of the Peak Period Day to be found
  # @param [Date] new_effective_date the desired date for the Peak Period Day
  def edit_peak_period_date(effective_date, new_effective_date)
    date_row = self.find_date_row(effective_date)
    date_row.date
    date_row.editable_date = new_effective_date.strftime('%m/%d/%Y')
    self.wait_for_ajax
    date_row.submit_date
    self.wait_for_ajax
  end

  # Adds the specified Peak Period Day to the specified Peak Period Day list
  #
  # @param [Date] peak_period_day_date The date of the Peak Period Day to be added
  # @param [String] list_name the name of the Peak Period Day list the day is to be added to
  def add_ppd_to_list(peak_period_day_date, list_name)
    row_index = find_row_index_for_date(peak_period_day_date)
    column_index = find_column_index_for_list(list_name)
    ppd_to_check = self.peak_period_days_table_element[row_index][column_index]
    ppd_to_check.label.click unless ppd_to_check.checkbox.checked?
  end

  # Finds the index on the Peak Period Days table of the Peak Period Date provided
  #
  # @param [Date] peak_period_day_date the Peak Period Date to be located
  def find_row_index_for_date(peak_period_day_date)
    self.peak_period_rows.each_with_index do |ppd,index|
       return index + 1 if ppd.date_element.text == peak_period_day_date.strftime('%m/%d/%Y')
    end
  end

  # Finds the index on the Peak Period Days table of the Peak Period List provided
  #
  # @param [String] list_name the Peak Period List to be located
  def find_column_index_for_list(list_name)
    self.peak_period_day_lists.each_with_index do |list,index|
      return index + 1 if list.list_name_element.text == list_name
    end
  end

  def ppd_lists_containing_ppd(ppd_date)
    date_index = self.find_row_index_for_date(ppd_date)
    ppd_lists = []
    self.peak_period_days_table_element[date_index].drop(1).each_with_index do |column, index|
      text = self.peak_period_days_table_element[0][index + 1].link.text
      sleep(0.5)
      (ppd_lists << text) if column.checkbox.checked?
    end
    ppd_lists
  end

end