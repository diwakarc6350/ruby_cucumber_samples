class PeakPeriodDaysSection
  include PageObject

  link(:date, xpath: ".//*[contains(@id, 'ppDayDate_')]/a")
  text_field(:editable_date, xpath: ".//*[contains(@id, 'ppDayDate_')]/form/div/input")
  button(:submit_date, xpath: ".//*[contains(@id, 'ppDayDate_')]/form/div/span/button[1]")
  label(:delete, xpath: ".//*[contains(@id, 'ppDayDate_')]/label")
end
