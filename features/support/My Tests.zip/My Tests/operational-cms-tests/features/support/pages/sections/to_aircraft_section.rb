class ToAircraftSection
  include PageObject

  b(:to_aircraft, xpath: './b')
end