class AcTypeFuelRatesSection
  include PageObject

  link(:clone, xpath: ".//*[contains(@id, 'addButtonACTypeRate_')]")
  link(:delete, xpath: ".//*[contains(@id, 'removeButtonACTypeRate_')]")
  link(:ac_type, xpath: ".//*[contains(@id, 'acType_')]/a")
  select_list(:fuel_type, xpath: ".//*[contains(@id, 'fuelTypeSel_')]")
  link(:established_rate, xpath: ".//*[contains(@id, 'establishedRate_')]/div/a")
  link(:established_variable, xpath: ".//*[contains(@id, 'establishedVariable_')]/a")
  link(:differential, xpath: ".//*[contains(@id, 'differential_')]/a")
  link(:variable_rate, xpath: ".//*[contains(@id, 'variableRate_')]/a")
  link(:effective_date, xpath: ".//*[contains(@id, 'effectiveDate_')]/a")
  td(:monthly_rate, xpath: ".//*[starts-with(@id, 'monthlyAvg_')]")
  td(:three_month_average, xpath: ".//*[starts-with(@id, '3MonthAvg_')]")

  text_field(:editable_ac_type, xpath: ".//*[contains(@id, 'acType_')]/form/div/input")
  button(:submit_ac_type, xpath: ".//*[contains(@id, 'acType_')]/form/div/span/button[1]")

  # select_list(:fuel_type, xpath: ".//*[contains(@id, 'fuelTypeSelect_')]/form/div/select")

  text_field(:editable_established_rate, xpath: ".//*[contains(@id, 'establishedRate_')]/div/form/div/input")

  text_field(:editable_established_variable, xpath: ".//*[contains(@id, 'establishedVariable_')]/form/div/input")

  text_field(:editable_differential, xpath: ".//*[contains(@id, 'differential_')]/form/div/input")

  text_field(:editable_variable_rate, xpath: ".//*[contains(@id, 'variableRate_')]/form/div/input")

  text_field(:editable_effective_date, xpath: ".//*[contains(@id, 'effectiveDate_')]/form/div/input")
  button(:submit_effective_date, xpath: ".//*[contains(@id, 'effectiveDate_')]/form/div/span/button[1]")


  td :commercial_monthly_rate, xpath: ".//*[contains(@id, 'commMonthlyAvg_')]"
  td :non_commercial_monthly_rate, xpath: ".//*[contains(@id, 'nonCommMonthlyAvg_')]"
  td :commercial_three_month_average_rate, xpath: ".//*[contains(@id, 'comm3MonthAvg_')]"
  td :non_commercial_three_month_average_rate, xpath: ".//*[contains(@id, 'nonComm3MonthAvg_')]"
  td :monthly_rate, xpath: ".//*[contains(@id, 'monthlyAvg_')]"
  td :three_month_average_rate, xpath: ".//*[contains(@id, '3MonthAvg_')]"


end