class AddRateTableSection
  include PageObject

  text_field(:interchange_name, :name => 'interchangeName')
  select_list(:from, :id => 'selFrom')
  select_list(:to, :id => 'selTo')
  text_field(:exchange_rate, :id => 'exchangeRate')
  label(:always_default, :xpath => '//*[@id="alwaysDefault"]/following::label[1]')
  text_field(:effective_date, :id => 'effDate')
  text_field(:inactive_date, :id => 'inactivateDate')
  button(:cancel_rate, :id => 'cancelRate')
  button(:add_rate, :id => 'addRate')
  select_list(:clonable_base_rate_types, id: 'rateOption')
  radio(:copy_rates, id: 'copyRates')

  def create_interchange_rate_type(name, effective_date, opts={})
    from_choices = from_options
    from_choices.shift
    to_choices = to_options
    to_choices.shift
    ex_rate = Random.new

    self.from = from_choices.sample
    self.to = to_choices.sample
    name = name
    self.interchange_name = name
    self.exchange_rate = ex_rate.rand(1.0..5.0).round(2)
    self.effective_date = effective_date

    # opts.each do |k, v|
    #   self.send(k, v)
    # end

    self.populate_page_with(opts)
    self.select_copy_rates if opts['clonable_base_rate_types']
    self.add_rate

    name
  end

  def create_default_interchange_rate_type(name, effective_date, opts={})
    from_choices = from_options
    from_choices.shift
    to_choices = to_options
    to_choices.shift
    ex_rate = Random.new

    self.interchange_name = name
    self.from = from_choices.sample
    self.to = to_choices.sample
    self.exchange_rate = ex_rate.rand(1.0..5.0).round(2)
    self.effective_date = effective_date
    self.always_default_element.click

    # opts.each do |k, v|
    #   self.send("#{k}=", v)
    # end

    self.populate_page_with(opts)

    self.add_rate
  end

end