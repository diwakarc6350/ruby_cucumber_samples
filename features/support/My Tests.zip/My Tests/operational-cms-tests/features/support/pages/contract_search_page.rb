require 'pages/sections/contract_search_results_section'
require 'pages/sections/account_status_section'

class ContractSearchPage
  include PageObject

  # Search Options
  text_field(:account_name, id: 'accountName')
  text_field(:ar_number, id: 'accountNumber')
  button(:account_status_selections, class: 'multiselect dropdown-toggle form-control')

  text_field(:contract_number, id: 'contractNumber')
  select_list(:product_line, id: 'productLineModel')
  select_list(:product, id: 'product')
  select_list(:contract_status, id: 'contractStatus')
  text_field(:card_number, id: 'cardNumber')
  select_list(:aircraft_type, id: 'aircraftType')

  button(:search, id: 'search_contracts')

  page_sections(:contract_search_results, ContractSearchResultsSection, xpath: '//*[@id="contractListResults"]/tbody/tr')
  page_section(:account_statuses, AccountStatusSection, xpath: '//*[@id="advSearchForm"]/div[3]/div[2]/div/div/ul')
  
end