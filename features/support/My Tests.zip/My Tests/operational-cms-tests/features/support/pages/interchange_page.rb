require 'page-object'
require_relative 'sections/add_rate_table_section'
require_relative 'sections/edit_rate_section'
require_relative 'sections/interchange_rate_types_section'
require_relative 'sections/base_rate_header_section'
require_relative 'sections/base_rate_table_section'
require_relative 'sections/interchange_rate_table_section'
require_relative 'sections/from_aircraft_section'
require_relative 'sections/to_aircraft_section'
require_relative 'sections/manage_aircraft_section'
require_relative 'sections/hidden_aircraft_section'

class InterchangePage
  include PageObject

  select_list(:effective_month, id: 'effectiveMonthSel')
  select_list(:effective_year, id: 'effectiveYearSel')
  label(:include_inactive, xpath: '//*[@id="includeInactive"]/following::label[1]')
  button(:save, id: 'saveButton')
  button(:cancel, id: 'cancelButton')
  link(:manage_aircraft, id: 'manageAircraftHref')
  link(:add_rate, link_text: 'Add Rate Table')
  h4(:error_message, class: 'growl-title')
  link(:show_all_base_rate_aircrafts, id: 'showBaseRateLink')
  link(:hide_all_base_rate_aircrafts, id: 'showBaseRateLink')
  link(:interchange_rate, text: 'Interchange Rate')

  page_sections(:interchange_rate_types, InterchangeRateTypesSection, xpath: "//*[@id='ratesTable']/tbody/tr")
  page_sections(:base_rate_table, BaseRateTableSection, xpath: "//*[contains(@class,'base-rate')]/tbody/tr[position() > 1]/td[position() > 1]")
  page_sections(:interchange_rate_table, InterchangeRateTableSection, xpath: "//*[contains(@class,'interchange-rate')]/tbody/tr[position() > 1]/td[position() > 1]")
  page_section(:add_rate_table_form, AddRateTableSection, id: 'createRateForm')
  page_section(:edit_rate_section, EditRateSection, id: 'createRateForm')
  page_section(:base_rate_header, BaseRateHeaderSection, id: 'baseRateHeader')

  page_section(:manage_aircraft_form, ManageAircraftSection, id: 'manageAircraftForm')
  page_sections(:hidden_aircraft, HiddenAircraftSection, xpath: '//*[@id="hideAircraftTbl"]/tbody/tr[position() > 0]')

  page_sections(:to_aircrafts, ToAircraftSection, xpath: '//*[@id="acTypesTable"]/tbody/tr[1]/td[position() > 1]')
  page_sections(:from_aircrafts, FromAircraftSection, xpath: '//*[@id="acTypesTable"]/tbody/tr[position() > 1]/td[1]')

  # Creates an Interchange Rate on the Interchange Rate table with randomized To, From and Exchange Rate unless specified
  #
  # @param [String] name the name of the interchange rate
  # @param [Date] effective_date the effective date for the interchange rate
  # @param [Hash] opts the options to create an interchange rate with
  # @option opts [String] :from the From company (MJP, NJA, NJI, NetJets U.S., NetJets Europe)
  # @option opts [String] :to the To program (NetJets U.S., NetJets Europe)
  # @option opts [FixNum] :exchange_rate the exchange rate
  # @option opts [Date] :inactive_date the inactive date
  define_method(:base_rate_links) { @browser.links(xpath: "//*[@id='acTypesTable']/tbody/tr[position() > 1]/td[position() > 1]/div/a") }

  def create_interchange_rate_type(name, effective_date, opts={})
    self.add_rate
    self.add_rate_table_form.create_interchange_rate_type(name, effective_date, opts)
    self.wait_for_ajax
    self.save
    self.wait_for_ajax
  end

  # Creates a default Interchange Rate on the Interchange Rate table with randomized To, From and Exchange Rate unless specified
  # The exchange rate value for this rate will persist to future months for this rate type
  #
  # @param [String] name the name of the interchange rate
  # @param [Date] effective_date the effective date for the interchange rate
  # @param [Hash] opts the options to create an interchange rate with
  # @option opts [String] :from the From company (MJP, NJA, NJI, NetJets U.S., NetJets Europe)
  # @option opts [String] :to the To program (NetJets U.S., NetJets Europe)
  # @option opts [FixNum] :exchange_rate the exchange rate
  # @option opts [Date] :inactive_date the inactive date
  def create_default_interchange_rate_type(name, effective_date, opts={})
    add_rate
    add_rate_table_form.create_default_interchange_rate_type(name, effective_date, opts)
    self.wait_for_ajax
    self.save
    self.wait_for_ajax
  end

  def interchange_rate_type_names
    interchange_rate_types.map(&:name)
  end

  def only_active_rate_types_are_displayed?
    current_billing_date = self.current_billing_date
    self.wait_for_ajax
    dates = interchange_rate_types.map(&:inactive_date).reject(&:empty?)
    dates = dates.map {|date| Date.strptime(date, '%m/%d/%Y')}
    dates.select {|date| date < current_billing_date}.empty?
    end

    def current_billing_date
      Date.strptime("#{self.effective_month} 01, #{self.effective_year}", '%b %d, %Y')
    end

    # Finds the Interchange Rate with the given name
    #
    # @param [String] name The name of the Interchange Rate to be found
    # @return [Section] The Interchange Rate matching the given name
    def find_interchange_rate_type(name)
      self.wait_for_ajax
      self.interchange_rate_types.find { |interchange_rate_type| interchange_rate_type.name.include?(name) }
    end

    # Selects the first rate type in the rate type table
    def select_rate_type
      self.wait_for_ajax
      self.interchange_rate_types.first.name_element.click
      self.wait_for_ajax
    end

    # Selects the last rate type in the rate type table
    def change_rate_type
      self.wait_for_ajax
      self.interchange_rate_types[-1].name_element.click
      self.wait_for_ajax
    end

    # Returns all 'From Aircraft' aircraft types on the base rate table
    #
    # @return [Array<String>] All 'From Aircraft' aircraft types with '(hidden)' removed from each type
    def interchange_from_aircraft_types
      from_types = []
      self.wait_for_ajax
      self.from_aircrafts.each do |aircraft|
        aircraft_type = aircraft.from_aircraft
        aircraft_type.slice! '(hidden)'
        from_types << aircraft_type
      end
      from_types.reject(&:empty?)
    end

    # Returns all 'To Aircraft' aircraft types on the base rate table
    #
    # @return [Array<String>] All 'To Aircraft' aircraft types with '(hidden)' removed from each type
    def interchange_to_aircraft_types
      to_types = []
      self.wait_for_ajax
      self.to_aircrafts.each do |aircraft|
        aircraft_type = aircraft.to_aircraft
        aircraft_type.slice! '(hidden)'
        to_types << aircraft_type
      end
      to_types.reject(&:empty?)
    end

    # Returns the information displayed above the base rate table for the selected rate type
    #
    # @return [Hash<String>] the information displayed above the base rate table
    def rate_type_header_information
      self.base_rate_header.rate_type_header_information
    end

    # Returns the information for the first rate type in the rate type table
    #
    # @return [Hash] the information for the first rate type in the rate type table
    def rate_type_information
      first_rate = self.interchange_rate_types.first
      first_rate_information = {}
      first_rate_information['type_name'] = first_rate.name
      first_rate_information['from'] = first_rate.from
      first_rate_information['to'] = first_rate.to
      first_rate_information['effective_date'] = first_rate.effective_date
      first_rate_information['inactive_date'] = first_rate.inactive_date
      first_rate_information['exchange_rate'] = first_rate.exchange_rate
      first_rate_information
    end

    # Sets the value of the first cell on the Base Rate table and saves the page
    #
    # @parameter [FixNum] the desired value for the first Base Rate table cell
    def edit_base_rate_table_value(base_rate)
      self.wait_for_ajax
      self.base_rate_table.first.base_rate_link
      self.base_rate_table.first.base_rate_input = base_rate
      @browser.send_keys(:enter)
      self.save
    end

    # Sets the value of the first cell on the Base Rate table without saving
    #
    # @parameter [FixNum] the desired value for the first Base Rate table cell
    def edit_base_rate_table_value_without_saving(base_rate)
      self.wait_for_ajax
      self.base_rate_table.first.base_rate_link
      self.base_rate_table.first.base_rate_input = base_rate
      @browser.send_keys(:enter)
    end

    # Returns the value of the first cell on the Base Rate table
    #
    # @return [Float] the value of the first cell on the base rate table
    def first_base_rate_table_value
      self.wait_for_ajax
      self.base_rate_table.first.uneditable_base_rate_element.text.delete('$').to_f
    end

    # Returns the error message on the first cell of the Base Rate table
    #
    # @return [String] the error message on the first Base Rate table cell
    def first_base_rate_table_error
      self.base_rate_table.first.error_message
    end

    # Includes inactive rate types on the rate type table and selects the last rate type on the table
    # This method only works if there is an existing inactive rate type
    def select_inactive_rate_type
      self.wait_for_ajax
      self.include_inactive_element.click
      self.wait_for_ajax
      self.interchange_rate_types[-1].name_element.click
    end

    # Checks that every cell on the base rate table is displaying '-' (the '-' indicates no value)
    #
    # @return [Boolean] true if every cell on the base rate table is '-'
    def base_rate_table_empty?
      self.wait_for_ajax
      base_rate_values = []
      self.base_rate_table.each do |rate|
        base_rate_values << rate.base_rate
      end
      base_rate_values.uniq!
      base_rate_values[0] == '-'
    end

    # Sets the effective month on the Interchange page to the next calendar month
    def select_next_month
      next_month = (Date.today + 1.month).strftime('%b')
      self.effective_month = next_month
    end

    def include_inactive_interchange_rate_types
      self.include_inactive_element.click
    end

    # Hides a specified aircraft type in the specified direction on the base rate table
    #
    # @param [String] aircraft_type the specified aircraft type, eg. 'Citation Encore', 'Falcon 2000', 'Phenom 300'
    # @param [String] direction the direction that the aircraft type will NOT be hidden on, 'From' or 'To'
    #                             if direction is nil, the aircraft type is hidden for both directions
    def hide_aircraft(aircraft_type, direction=nil)
      self.manage_aircraft
      self.wait_for_ajax
      self.manage_aircraft_form.aircraft_search = aircraft_type
      @browser.send_keys(:enter)
      hidden_aircraft = self.hidden_aircraft.find { |aircraft| aircraft.aircraft_type == aircraft_type }
      hidden_aircraft.to_program_checkbox_checked? ? '' : hidden_aircraft.to_program_element.click
      hidden_aircraft.from_program_checkbox_checked? ? '' : hidden_aircraft.from_program_element.click
      direction.nil? ? '' : hidden_aircraft.send(direction.to_s + '_program_element').click
      self.manage_aircraft_form.add
      self.save
      self.wait_for_ajax
    end

    # Returns a list of all aircraft types that are currently hidden on the base rate table
    #
    # @return [Array] all aircraft types currently hidden on the base rate table
    def managed_aircraft
      self.manage_aircraft
      self.wait_for_ajax
      managed_aircraft = []
      self.hidden_aircraft.each do |aircraft|
        managed_aircraft << aircraft.aircraft_type
      end
      self.manage_aircraft_form.cancel
      managed_aircraft
    end

    # Checks that the specified aircraft is hidden in both directions on the base rate table
    #
    # @return [Boolean] true if the aircraft type is hidden in both directions
    def aircraft_is_hidden_to_and_from?(aircraft_type)
      self.manage_aircraft
      self.wait_for_ajax
      sleep(1)
      hidden_aircraft = self.hidden_aircraft.find { |aircraft| aircraft.aircraft_type == aircraft_type }
      hidden_aircraft.to_program_checkbox_checked? && hidden_aircraft.from_program_checkbox_checked?
    end

    # Unhides the specified aircraft type in both directions
    #
    # @param [String] aircraft_type the aircraft_type to be unhidden
    def unhide_aircraft(aircraft_type)
      self.manage_aircraft
      self.wait_for_ajax
      hidden_aircraft = self.hidden_aircraft.find { |aircraft| aircraft.aircraft_type == aircraft_type }
      hidden_aircraft.to_program_checkbox_checked? ? hidden_aircraft.to_program_element.click : ''
      hidden_aircraft.from_program_checkbox_checked? ? hidden_aircraft.from_program_element.click : ''
      self.manage_aircraft_form.add
      self.save
    end

    # Returns the number of aircraft types hidden on the base rate table
    #
    # @return [FixNum] the number of aircraft types hidden on the base rate table
    def number_of_hidden_aircraft
      number_of_hidden_aircraft = show_all_base_rate_aircrafts_element.text
      number_of_hidden_aircraft.delete!('Show All (').slice!(')')
      number_of_hidden_aircraft.to_i
    end

    # Returns the number of aircraft types hidden on the manage aircraft modal window
    #
    # @return [FixNum] the number of aircraft types hidden on the manage aircraft modal window
    def number_of_managed_aircraft
      self.manage_aircraft
      self.hidden_aircraft.to_a.size
    end

    # Shows all hidden aircraft on the base rate table
    def show_all_aircraft
      self.show_all_base_rate_aircrafts
    end

    # Returns the list of unique aircraft hidden on the To and From axes of the Base Rate table
    #
    # @return [Array] the unique aircraft hidden on the To and From axes of the Base Rate table
    def hidden_aircraft_to_and_from
      aircraft_hidden = []

      self.to_aircrafts.each do |aircraft|
        if aircraft.to_aircraft.include? '(hidden)'
          aircraft_type = aircraft.to_aircraft
          aircraft_type.slice! '(hidden)'
          aircraft_hidden << aircraft_type
        end
      end

      self.from_aircrafts.each do |aircraft|
        if aircraft.from_aircraft.include? '(hidden)'
          aircraft_type = aircraft.from_aircraft
          aircraft_type.slice! '(hidden)'
          aircraft_hidden << aircraft_type
        end
      end

      aircraft_hidden.uniq!
    end

    def rate_type_name
      "Rate Type ##{self.interchange_rate_types.to_a.size}"
    end
  end
