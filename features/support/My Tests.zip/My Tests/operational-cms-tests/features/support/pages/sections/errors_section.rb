class ErrorsSection
  include PageObject

  button(:close, class: "close")
end
