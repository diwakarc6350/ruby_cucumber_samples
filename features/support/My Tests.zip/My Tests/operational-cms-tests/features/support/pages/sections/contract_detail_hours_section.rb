class ContractDetailHoursSection
  include PageObject

  cell(:start_date, index: 0)
  cell(:end_date, index: 1)
  cell(:occupied_flight_hours, index: 2)
  cell(:additional_hours, index: 3)
  cell(:adjusted_hours, index: 4)
  cell(:total_allotted, index: 5)
  cell(:billed, index: 6)
  cell(:in_process_flown, index: 7)
  cell(:remaining, index: 8)
  cell(:future_flights, index: 9)
  cell(:projected_balance_hours, index: 10)
  cell(:excess_hours, index: 11)


  def hours_information
    Hash.new.tap do |hours|
      hours['start_date'] = Date.strptime(self.start_date, '%m/%d/%Y')
      hours['end_date'] = Date.strptime(self.end_date, '%m/%d/%Y')
      hours['occupied_flight_hours'] = self.occupied_flight_hours.to_f
      hours['additional_hours'] = self.additional_hours.to_f
      hours['adjusted_hours'] = self.adjusted_hours.to_f
      hours['total_allotted'] = self.total_allotted.to_f
      hours['billed'] = self.billed.to_f
      hours['excess_hours'] = self.excess_hours.to_f
      hours['excess_hours'] = self.excess_hours.to_f
      hours['in_process_flown'] = self.in_process_flown.to_f.round(2)
      hours['remaining'] = self.remaining.to_f
      hours['future_flights'] = self.future_flights.to_f
      hours['projected_balance_hours'] = self.projected_balance_hours.to_f
    end
  end

end