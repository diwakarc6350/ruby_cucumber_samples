class ContractDetailHoursDetailSection
  include PageObject

  label(:occupied_flight_hours, xpath: ".//span[contains(. ,'Occupied')]/label")
  label(:redemption_hours, xpath: ".//span[contains(. ,'Redemption')]/label")
  label(:bonus_hours, xpath: ".//span[contains(. ,'Bonus')]/label")
  label(:expired_hours, xpath: ".//span[contains(. ,'Expired')]/label")
  label(:transferred_hours, xpath: ".//span[contains(. ,'Transferred')]/label")
  label(:complimentary_hours, xpath: ".//span[contains(. ,'Complimentary')]/label")
  label(:total_hours, xpath: ".//span[contains(. ,'Total')]/label")

  def detail_hours_information
    Hash.new.tap do |hours|
      hours['occupied_flight_hours'] = self.occupied_flight_hours_element.exists? ? self.occupied_flight_hours_element.text.to_f : 0.0
      hours['redemption_hours'] = self.redemption_hours_element.exists? ? self.redemption_hours_element.text.to_f : 0.0
      hours['bonus_hours'] = self.bonus_hours_element.exists? ? self.bonus_hours_element.text.to_f : 0.0
      hours['expired_hours'] = self.expired_hours_element.exists? ? self.expired_hours_element.text.to_f : 0.0
      hours['transferred_hours'] = self.transferred_hours_element.exists? ? self.transferred_hours_element.text.to_f : 0.0
      hours['complimentary_hours'] = self.complimentary_hours_element.exists? ? self.complimentary_hours_element.text.to_f : 0.0
      hours['total_hours'] = self.total_hours_element.text.to_f
    end
  end
end