class InterchangeRateTypesSection
  include PageObject

  td(:name, index: 1)
  td(:from, index: 2)
  td(:to, index: 3)
  td(:effective_date, index: 4)
  td(:inactive_date, index: 5)
  td(:exchange_rate, index: 6)
  text_field(:editable_xrate, xpath: './/*[contains(@id, "rateXRate_")]/form/span/input')
  link(:edit, xpath: './/*[@id="editRateTypes"]')

  def edit_exchange_rate(new_rate)
    self.exchange_rate_element.link.click
    self.wait_for_ajax
    self.editable_xrate = new_rate
    self.wait_for_ajax
    @browser.send_keys(:enter)
  end

  def interchange_rate_type_names
    Array.new.tap do |interchange_rate_type_names|
      interchange_rate_types.each do |row|
        interchange_rate_type_names << row.name
      end
    end
  end

end
