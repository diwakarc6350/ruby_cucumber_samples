require 'page-object'

class LandingPage
  include PageObject
  link(:fuel_management, id: 'fuel')
  link(:peak_period_days, id: 'peakDay')
  link(:interchange, id: 'interchange')
  link(:areas, id: 'serviceArea')
  link(:contract_search, id: 'contractSearch')
end