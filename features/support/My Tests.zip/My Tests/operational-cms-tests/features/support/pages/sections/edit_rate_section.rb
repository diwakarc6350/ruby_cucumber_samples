class EditRateSection
  include PageObject

  text_field(:interchange_name, name: 'interchangeName')
  select_list(:from, id: 'selFrom')
  select_list(:to, id: 'selTo')
  text_field(:exchange_rate, id: 'exchangeRate')
  label(:always_default, xpath: '//*[@id="alwaysDefault"]/following::label[1]')
  text_field(:effective_date, id: 'effDate')
  text_field(:inactive_date, id: 'inactivateDate')
  button(:cancel_rate, id: 'cancelRate')
  button(:update, id: 'updateRate')


end