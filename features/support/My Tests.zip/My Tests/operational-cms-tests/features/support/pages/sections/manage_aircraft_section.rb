class ManageAircraftSection
  include PageObject

  span(:rate_name, id: 'rateTypeNameSpan')
  span(:from_program_to_program, id: 'rateTypeNameFromTo')
  text_field(:aircraft_search, id: 'acTypeSearch')
  button(:cancel, id: 'cancelManageAircraft')
  button(:add, id: 'addManageAircraft')

end