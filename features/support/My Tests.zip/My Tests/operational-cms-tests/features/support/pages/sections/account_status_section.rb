class AccountStatusSection
  include PageObject

  link(:select_all, xpath: "./li//*[contains(text(),'Select all')]/..")
  link(:restricted, xpath: "./li//*[contains(text(),'Restricted')]/..")
  link(:termination_pending, xpath: "./li//*[contains(text(),'Termination Pending')]/..")
  link(:active, xpath: "./li//*[contains(text(),'Active')]/..")
  link(:credit_hold, xpath: "./li//*[contains(text(),'Credit Hold')]/..")
  link(:credit_watch, xpath: "./li//*[contains(text(),'Credit Watch')]/..")
  link(:inactive, xpath: "./li//*[contains(text(),'Inactive')]/..")
  link(:credit_limit, xpath: "./li//*[contains(text(),'Credit Limit')]/..")
  link(:credit_card_only, xpath: "./li//*[contains(text(),'Credit Card Only')]/..")


end