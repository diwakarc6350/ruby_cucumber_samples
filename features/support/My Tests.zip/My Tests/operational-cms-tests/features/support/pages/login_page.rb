require 'page-object'

class LoginPage
  include PageObject
  include PageObject::PageFactory

  page_url base_url

  text_field(:username, id: 'username')
  text_field(:password, id: 'password')
  button(:login, name: 'action')

  def login_as(role=OCMSUsers::ADMIN)
    self.username = role.fetch(:username)
    self.password = role.fetch(:password)
    self.login
  end
end
