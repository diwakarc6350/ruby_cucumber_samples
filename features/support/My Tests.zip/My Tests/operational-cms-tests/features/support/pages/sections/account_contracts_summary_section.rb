class AccountContractsSummarySection
  include PageObject

  cell(:contract_status, id: 'summaryContractStatus')
  cell(:product_line, id: 'summaryProductLine')
  cell(:product, id: 'summaryProduct')
  cell(:ac_type, id: 'summaryACType')
  cell(:tail, id: 'summaryTail')
  cell(:share_size, id: 'summaryShareSize')
  cell(:contract_card_nbr, id: 'summaryContractCardNbr')
  cell(:start_date, id: 'summaryStartDate')
  cell(:end_date, id: 'summaryEndDate')
  cell(:allotted, id: 'summaryAllotted')
  cell(:billed, id: 'summaryBilled')
  cell(:in_process, id: 'summaryInProcess')
  cell(:future_flights, id: 'summaryFutureFlights')
  cell(:projected_balance, id: 'summaryProjectedBalance')

  def attributes
    Hash.new.tap do |summary|
      summary[:contract_status] = self.contract_status
      summary[:product_line] = self.product_line
      summary[:product] = self.product
      summary[:ac_type] = self.ac_type
      summary[:tail] = self.tail
      summary[:share_size] = self.share_size.to_f.round(2)
      summary[:contract_card_nbr] = self.contract_card_nbr.to_i
      summary[:start_date] = Date.strptime(self.start_date, '%m/%d/%Y')
      summary[:end_date] = Date.strptime(self.end_date, '%m/%d/%Y')
      summary[:allotted] = self.allotted.to_f.round(2)
      summary[:billed] = self.billed.to_f.round(2)
      summary[:in_process] = self.in_process.to_f.round(2)
      summary[:future_flights] = self.future_flights.to_f.round(2)
      summary[:projected_balance] = self.projected_balance.to_f.round(2)
    end
  end
end















