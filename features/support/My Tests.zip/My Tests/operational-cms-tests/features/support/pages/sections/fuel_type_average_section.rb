class FuelTypeAverageSection
  include PageObject

  td(:fuel_type, index: 0)
  td(:commercial_status, index: 1)
  link(:monthly_average_rate_link, xpath: './td[3]/a')
  text_field(:monthly_average_rate, xpath: './td[3]/form/div/input')
  td(:three_month_average, index: 3)
  hidden(:precise_three_month_average, xpath: ".//input[starts-with(@id,'average3MonthsWithPrecision')]")
  label(:inactivate_fuel_type, xpath: './/label')
  checkbox(:inactivate_fuel_type_checkbox, xpath: './/*[contains(@id, "inactivateFuelTypesFromDB_")]')

end
