class ContractSearchResultsSection
  include PageObject

  cell(:account_name, index: 0)
  cell(:legal_name, index: 1)
  cell(:account_number, index: 2)
  link(:contract_id, xpath: ".//*[starts-with(@id, 'contract_')]/a")
  cell(:contract_status, index: 4)
  cell(:product_line, index: 5)
  cell(:product_name, index: 6)
  cell(:individual_name, index: 7)
  cell(:share_size, index: 8)
  cell(:ac_type, index: 9)
  cell(:start_date, index: 10)
  cell(:end_date, index: 11)
  cell(:termination_date, index: 12)

  define_method(:attributes) do
    attributes = {}
    attributes[:account_name] = self.account_name
    attributes[:legal_name] = self.legal_name
    attributes[:account_number] = self.account_number
    attributes[:contract_id] = self.contract_id_element.text
    attributes[:contract_status] = self.contract_status
    attributes[:individual_name] = self.individual_name.gsub(/\...$/, '').strip
    attributes[:share_size] = self.share_size.gsub(/(hrs|%)/, '').to_f
    attributes[:ac_type] = self.ac_type
    attributes[:start_date] = self.start_date
    attributes[:end_date] = self.end_date
    attributes[:termination_date] = (self.termination_date == "") ? nil : self.termination_date
    attributes[:product_line] = self.product_line
    attributes[:product_name] = self.product_name
    attributes
  end

end