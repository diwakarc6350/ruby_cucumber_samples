class FromAircraftSection
  include PageObject

  b(:from_aircraft, xpath: './b')

end