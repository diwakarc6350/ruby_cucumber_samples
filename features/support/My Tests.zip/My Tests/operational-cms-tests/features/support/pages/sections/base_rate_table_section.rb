class BaseRateTableSection
  include PageObject

  link(:base_rate_link, :xpath => './div/a')
  text_field(:base_rate_input, :xpath => '//*[contains(@id, "baseRateId_")]/div/form/span/input')
  div(:error_message, :xpath => './div/form/span/div')
  div(:base_rate, :xpath => './div')
  td(:uneditable_base_rate, :xpath => './.')


end