class AccountContractsTotalHoursSection
  include PageObject

  cell(:allotted, index: 1)
  cell(:billed, index: 2)
  cell(:in_process_flown, index: 3)
  cell(:future_flights, index: 4)
  cell(:projected_balance, index: 5)

  define_method(:attributes) do
    Hash.new.tap do |total_hours|
      total_hours[:allotted] = self.allotted.to_f.round(2)
      total_hours[:billed] = self.billed.to_f.round(2)
      total_hours[:in_process_flown] = self.in_process_flown.to_f.round(2)
      total_hours[:future_flights] = self.future_flights.to_f.round(2)
      total_hours[:projected_balance] = self.projected_balance.to_f.round(2)
    end
  end

end