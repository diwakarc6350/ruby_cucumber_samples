require 'pages/sections/contract_detail_hours_section'
require 'pages/sections/contract_detail_hours_detail_section'
require 'pages/sections/account_contracts_summary_section'
require 'pages/sections/account_contracts_total_hours_section'


class ContractDetailPage
  include PageObject

  span(:account_name, id: 'accountName')
  span(:account_number, id: 'arNumber')
  div(:card_owner_status, xpath: '//*[@id="contractDetails-ng-app"]/form/div//div/div[2]')
  span(:program, id: 'programName')
  span(:sales_vp, id: 'salesVP')
  span(:os_team, id: 'oSTeam')
  span(:legal_name, id: 'legalEntityName')

  span(:commercial_status, id: 'commercialStatus')
  span(:accounting_company, id: 'accountingCompany')
  label(:contract_status, id: 'contractStatus')
  span(:product_line, id: 'productLine')
  span(:product, id: 'productName')
  span(:contract_number, id: 'opContractId')
  span(:aircraft_type, id: 'aircraftType')
  span(:cabin_class, id: 'cabinClass')
  span(:funding_date, id: 'fundingDate')
  span(:delayed_start_date, id: 'delayedStartDate')
  span(:end_date, id: 'endDate')
  span(:extended_end_date, id: 'extendedEndDate')
  span(:termination_date, id: 'terminationDate')
  span(:combo_card, id: 'comboCardLink')

  button(:view_summary, value: 'View Summary')

  checkbox(:show_all, id: 'showAll')

  page_section(:contract_detail_hours, ContractDetailHoursSection, xpath: '//*[@id="hoursTbl"]/tbody/tr')
  page_section(:hours_detail, ContractDetailHoursDetailSection, xpath: '//*[@id="hoursDetailsDiv"]')

  page_section(:account_contracts_total_hours, AccountContractsTotalHoursSection, xpath: '//*[@id="allContractsSummary"]/tbody/tr[last()]')
  page_sections(:account_contracts_summary, AccountContractsSummarySection, xpath: '//*[@id="allContractsSummary"]/tbody/tr[position() < last()]')

  # Returns the account specific header information for the contract currently being viewed
  #
  # @return [Hash] The account specific header information for the contract currently being viewed
  def account_header_information
    Hash.new.tap do |header_information|
      account_number = self.account_number
      account_number.slice! 'Account #: '
      sales_vp = self.sales_vp
      sales_vp == 'Sales VP:' ? sales_vp = nil : sales_vp = sales_vp.gsub('Sales VP: ', '')
      os_team = self.os_team
      os_team.slice! 'OS Team: '

      header_information["account_name"] = self.account_name
      header_information["account_number"] = account_number
      header_information["program"] = self.program
      header_information["sales_vp"] = sales_vp
      header_information["os_team"] = os_team.strip
    end
  end

  def account_contracts_information
    self.account_contracts_summary.map {|summary| summary.attributes}
  end


  # Returns the contract specific header information for the contract currently being viewed
  #
  # @return [Hash] The contract specific header information for the contract currently being viewed
  def contract_header_information
    Hash.new.tap do |header_information|
      header_information[:commercial_status] = self.commercial_status
      header_information[:accounting_company] = self.accounting_company
      header_information[:contract_status] = self.contract_status
      header_information[:product_line] = self.product_line
      header_information[:product] = self.product
      header_information[:contract_number] = self.contract_number
      header_information[:ac_type] = self.aircraft_type
      header_information[:cabin_class] = self.cabin_class
      header_information[:funding_date] = self.funding_date
      header_information[:delayed_start_date] = self.delayed_start_date
      header_information[:end_date] = self.end_date
      header_information[:extended_end_date] = self.extended_end_date
      header_information[:termination_date] = self.termination_date
    end
  end

  # Returns the AR number for the account currently being viewed
  #
  # @return [String] The AR number for the account currently being viewed
  def current_account_ar_nbr
    account_number = self.account_number
    account_number.slice! 'Account #: '
    account_number
  end

  # Opens the hours tab
  def hours_tab
    self.hours_element.click
  end

  # Opens the charges tab
  def charges_tab
    self.charges_element.click
  end

  # Opens the billing tab
  def billing_tab
    self.billing_element.click
  end

  # Returns the contract hours on the currently displayed contract
  #
  # @return [Hash] The contract hours on the currently displayed contract
  def contract_hours
    self.contract_detail_hours.hours_information
  end

  # Returns the hours found in the hours detail section
  #
  # @return [Hash] The hours in the hours detail section
  def detail_hours_information
    self.hours_detail.detail_hours_information
  end

end