require 'page-object'
class SettingsPage
  include PageObject
  include PageObject::PageFactory

  page_url 'http://localhost:8080/operational-cms-web/settings/index'

  select_list(:default_company, id:'company')
  select_list(:date_format, id: 'dateFormat')
  button(:save, id: 'save-button')
end
