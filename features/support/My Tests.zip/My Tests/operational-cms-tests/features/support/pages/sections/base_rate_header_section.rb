class BaseRateHeaderSection
  include PageObject

  span(:rate_type_name, id: 'rateTypeNameSpan')
  span(:rate_type_from_to, id: 'rateTypeNameFromTo')
  span(:rate_type_effective_date, id: 'rateTypeNameEffDt')
  span(:rate_type_inactive_date, id: 'rateTypeNameInActivDt')
  span(:rate_type_exchange_rate, id: 'rateTypeXRate')

  def rate_type_header_information
    header_information = {}
    header_information['type_name'] = self.rate_type_name.strip
    from_to = self.rate_type_from_to.split(' to ')
    header_information['from'] = from_to[0]
    header_information['to'] = from_to[1].strip
    header_information['effective_date'] = self.rate_type_effective_date.delete('Effective Date: ')
    header_information['inactive_date'] = self.rate_type_inactive_date.delete('Inactive Date: ')
    header_information['exchange_rate'] = self.rate_type_exchange_rate.delete('Exchange Rate: ')
    header_information
  end

end