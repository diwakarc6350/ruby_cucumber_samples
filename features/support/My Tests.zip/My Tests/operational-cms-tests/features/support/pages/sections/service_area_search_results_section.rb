class ServiceAreaSearchResultsSection
  include PageObject

  td(:service_area, xpath: './td[1]')
  checkbox(:include, xpath: './input[1]')
  checkbox(:exclude, xpath: './input[2]' )

end