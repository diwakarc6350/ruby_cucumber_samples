module PageObject
  module Javascript

    module AngularJS
      #
      # return the number of pending ajax requests
      #
      def self.pending_requests
        "return angular.element(document.getElementById('ng-app')).injector().get('$http').pendingRequests.length"
      end
    end

  end
end