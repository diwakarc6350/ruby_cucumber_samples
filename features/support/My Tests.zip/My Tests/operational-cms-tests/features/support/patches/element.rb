require 'page-object/nested_elements'
module PageObject
  module Elements
    #
    # Contains functionality that is common across all elements.
    #
    # @see PageObject::Platforms::WatirWebDriver::Element for the Watir version of all common methods
    # @see PageObject::Platforms::SeleniumWebDriver::Element for the Selenium version of all common methods
    #
    class Element
      def method_missing(*args, &block)
        m = args.shift
        begin
          element.send m, *args, &block
        rescue Exception => e
          raise
        end
      end
    end
  end
end
