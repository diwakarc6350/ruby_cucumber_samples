require 'json'
require 'mechanize'

class OCMSAgent
  class << self

    attr_reader :agent

    def browser
      return @agent unless @agent.nil?
      authenticate
    end

    private
    def authenticate
      agent = Mechanize.new
      agent.verify_mode = OpenSSL::SSL::VERIFY_NONE
      login_form = agent.get(base_url).form(class: 'form-horizontal')
      login_form.field(id: 'username').value = OCMSUsers::ADMIN.fetch(:username)
      login_form.field(id: 'password').value = OCMSUsers::ADMIN.fetch(:password)
      agent.submit(login_form, login_form.buttons.first)
      @agent = agent
    end
  end

end
