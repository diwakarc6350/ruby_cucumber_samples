require 'json'
require 'active_record'

class PpdMess

  attr_reader :ppd_mess_json,
              :modify_peak_period_date_url

  def initialize(ppd_date)
    mess_file = File.read("#{File.dirname(__FILE__)}/mess_json/ppd_mess.json")
    @ppd_mess_json = JSON.parse(mess_file)
    @ppd_mess_json["selectedCompany"] = 1000001
    @ppd_mess_json["selectedYear"] = ppd_date.strftime('%Y')
    @ppd_mess_json["updatedRow"][0]["peakDate"] = ppd_date.strftime('%Y-%m-%d')
    @ppd_mess_json["updatedRow"][0]["deleteConfirmed"] = true
    all_ppds = PeakPeriodDay.all.select { |ppd| ppd.peak_dt.to_date == ppd_date }
    all_ppds.each do |ppd|
      ppd_attr = {}
      ppd_attr["id"] = ppd.prdt_peak_day_id
      ppd_attr["ppdListId"] = ppd.prdt_peak_day_list_id
      ppd_attr["selected"] = false
      ppd_attr["changed"] = true
      @ppd_mess_json["updatedRow"][0]["checkboxes"] << ppd_attr
    end

    @modify_peak_period_date_url = "#{base_url}/peakDay/getPeakDayList"
  end

  def self.clean_ppd_mess_for_list(ppd_date, list_id)
    mess_file = File.read("#{File.dirname(__FILE__)}/mess_json/ppd_mess.json")
    @ppd_mess_json = JSON.parse(mess_file)
    @ppd_mess_json["selectedCompany"] = 1000001.to_s
    @ppd_mess_json["selectedYear"] = ppd_date.strftime('%Y')
    all_ppd_for_list = PeakPeriodDay.all.select { |ppd| ppd.prdt_peak_day_list_id == list_id }
    @ppd_mess_json["updatedRow"] = []
    all_ppd_for_list.each_with_index do |list_record, index|
      ppd = {}
      ppd["peakDate"] = list_record.peak_dt.strftime('%Y-%m-%d')
      ppd["deleteConfirmed"] = true
      @ppd_mess_json["updatedRow"] << ppd
      ppd_attr = {}
      ppd_attr["id"] = list_record.prdt_peak_day_id
      ppd_attr["ppdListId"] = list_id
      ppd_attr["selected"] = false
      ppd_attr["changed"] = true
      @ppd_mess_json["updatedRow"][index]["checkboxes"] = []
      @ppd_mess_json["updatedRow"][index]["checkboxes"] << ppd_attr
    end
    @modify_peak_period_date_url = "#{base_url}/peakDay/getPeakDayList"
    rate_to_delete = JSON.parse(@ppd_mess_json.to_json)
    OCMSAgent.browser.put(@modify_peak_period_date_url, rate_to_delete.to_json, {'Content-Type' => 'application/json'})
  end


  def clean
    rate_to_delete = JSON.parse(@ppd_mess_json.to_json)
    OCMSAgent.browser.put(@modify_peak_period_date_url, rate_to_delete.to_json, {'Content-Type' => 'application/json'})
  end
end