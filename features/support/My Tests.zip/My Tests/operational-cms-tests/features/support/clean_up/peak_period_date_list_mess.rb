require 'json'
require 'active_record'
require "#{File.dirname(__FILE__)}/../models/edr/program/peak_period_day_list"

class PeakPeriodDateListMess

  attr_reader :list_name,
              :effective_date,
              :inactive_date,
              :peak_period_list_id,
              :modify_peak_period_date_url

  def initialize(list_name, effective_date, inactive_date)
    @list_name = list_name
    @inactive_date = inactive_date
    @effective_date = effective_date
    @peak_period_list_id = PeakPeriodDayList.retrieve_peak_period_day_list_id(list_name, effective_date)
    @modify_peak_period_date_url = "#{base_url}/peakDay/getPeakDayList"
    @ppd_list_mess_json = {updatedList: [{id: @peak_period_list_id, listName: @list_name, effectiveDate: '01/02/2013', inactiveDate: '01/02/2013', company: 1000001}]}
    @ppd_list_mess_json["selectedYear"] = Date.today.strftime('%Y')
    @ppd_list_mess_json["selectedCompany"] = 1000001
  end

  def clean
    all_associated_ppds = PeakPeriodDay.find_by_sql "select * from PRDT_OWNER.PRDT_PEAK_DAY p where p.PRDT_PEAK_DAY_LIST_ID = #{@peak_period_list_id}"
    all_associated_ppds.each do |ppd_record|
      ppd_date = ppd_record.peak_dt.to_date
      PpdMess.clean_ppd_mess_for_list(ppd_date,peak_period_list_id )
    end
    OCMSAgent.browser.put(@modify_peak_period_date_url, @ppd_list_mess_json.to_json, {'Content-Type' => 'application/json'})
  end
end