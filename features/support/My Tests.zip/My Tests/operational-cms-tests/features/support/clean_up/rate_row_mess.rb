require 'json'
require 'active_record'

class RateRowMess

  attr_reader :interchange_rate_type_name

  def initialize(interchange_rate_type_name)
    @interchange_rate_type_name = interchange_rate_type_name
  end

  def clean

  end
end