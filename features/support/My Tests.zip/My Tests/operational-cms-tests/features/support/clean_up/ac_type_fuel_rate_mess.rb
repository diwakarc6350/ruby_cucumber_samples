require 'json'
require 'active_record'
require "#{File.dirname(__FILE__)}/../models/edr/program/fuel_calc_variable"

class ACTypeFuelRateMess

  attr_reader :ac_type,
              :fuel_type,
              :effective_date,
              :ac_type_fuel_rate_id
              :modify_fuel_rate_url

  def initialize(ac_type, fuel_type, effective_date)
    @ac_type = ac_type
    @fuel_type = fuel_type
    @effective_date = effective_date
    @current_year = Date.today.strftime('%Y')
    @current_month = Date.today.strftime('%^b')
    @ac_type_fuel_rate_id = FuelCalcVariable.retrieve_fuel_calc_variable_id(ac_type, fuel_type, effective_date)
    @modify_fuel_rate_url = "#{base_url}/fuelRate/fuelTypes"
  end


  def clean
    rate_to_delete = JSON.parse({effectiveMonth: @current_month, effectiveYear: @current_year, fuelCalcVarDel: [ { id: @ac_type_fuel_rate_id } ] }.to_json)
    OCMSAgent.browser.put(@modify_fuel_rate_url ,rate_to_delete.to_json, {'Content-Type' => 'application/json'}) if FuelCalcVariable.exists?(ac_type_fuel_rate_id)
  end
end