module OCMSUsers
  ADMIN ||= {:username => "qatest1", :password => "DeP@rture1"}
  NJE_USER ||= {:username => "jecht", :password => "Arkansassucks45"}
  NJA_USER ||= {:username => "qatest1", :password => "DeP@rture1"}
end

World(OCMSUsers)