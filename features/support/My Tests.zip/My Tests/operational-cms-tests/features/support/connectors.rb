require 'active_record'

class IjetData < ActiveRecord::Base
  self.abstract_class = true
  self.establish_connection(
      :adapter => 'jdbc',
      :username => 'GCDM_ETL_USER',
      :password => 'Fu$10ng10w',
      :driver => 'oracle.jdbc.driver.OracleDriver',
      #:url => 'jdbc:oracle:thin:@ED01DB :1521:ED01DB'
      :url => "jdbc:oracle:thin:@
                (DESCRIPTION_LIST=
                (LOAD_BALANCE=off)
                (FAILOVER=on)
                (DESCRIPTION=
                (ADDRESS_LIST=
                (LOAD_BALANCE=on)
                (ADDRESS=(PROTOCOL=TCP)(HOST=bexa-scan)(PORT=1521)))
                  (CONNECT_DATA=(SERVICE_NAME=MRDPRD.netjets.com)))
                (DESCRIPTION=
                (ADDRESS_LIST=
                (LOAD_BALANCE=on)
                (ADDRESS=(PROTOCOL=TCP)(HOST=bexa-scan)(PORT=1521)))
                (CONNECT_DATA=(SERVICE_NAME=MRDPRD.netjets.com))))")
end

class DBConnectors
  def self.ijet
    IjetData.connection
  end

end