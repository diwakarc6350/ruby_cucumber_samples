require 'watir-webdriver'
require 'yaml'
require 'clean_up/janitor'
require 'scenario_context'


TIMEOUT = 600

caps = Selenium::WebDriver::Remote::Capabilities.chrome("chromeOptions" => {"binary" => File.dirname(__FILE__)+"/bin/chromium/chrome.exe"})

http_client = Selenium::WebDriver::Remote::Http::Default.new
http_client.timeout = TIMEOUT

browser = Watir::Browser.new :chrome, :desired_capabilities => caps, :http_client => http_client
browser.driver.manage.window.maximize

@browser = browser

Before do |scenario|
  begin
    @browser = browser
    @scenario_context = ScenarioContext
    OCMS.log.info("SCENARIO: " + scenario.name)
  rescue => e
    puts e
  end
end


After do |scenario|
  begin
    @browser.cookies.clear
    if scenario.failed?
      Dir::mkdir('screenshots') unless File.directory?('screenshots')
      screenshot = "./screenshots/FAILED_#{scenario.name.gsub(' ', '_').gsub(/[^0-9A-Za-z_]/, '')}.png"
      @browser.screenshot.save(screenshot)
      embed screenshot, 'image/png'
    end
  rescue => e
    puts e
  end

  Janitor.clean_messes
  @scenario_context.empty
  while @browser.windows.size > 1
    @browser.windows.last.close
  end
  @browser.windows.first.use
  @browser.goto "#{base_url}/operational-cms-web/j_spring_security_logout"


end

After('@nje') do
  open_settings
  select_default_company('NJA')
  save_settings
end

AfterConfiguration do
  reset_preference_service_json = {company: "NJA",
                                   dateFormat: "MM/DD/YYYY",
                                   preferenceId: "553fe1d5e4b0190782d3181d",
                                   userName: "qatest1"}

  OCMSAgent.browser.post("#{base_url}/settings/userSettings",reset_preference_service_json.to_json, {'Content-Type' => 'application/json'})
end


at_exit do
  @browser.close
end



