$LOAD_PATH << Dir.pwd
require 'active_record'
require 'data_magic'
require 'clean_up/janitor'
require 'clean_up/ac_type_fuel_rate_mess'
require 'clean_up/peak_period_date_list_mess'
require 'clean_up/ocms_agent'

# ActiveRecord::Base.logger = Logger.new(STDOUT)

ActiveSupport::Deprecation.silenced = true
require "#{File.dirname(__FILE__)}/../../../bin/ojdbc7.jar"

db_data = YAML.load_file("#{File.dirname(__FILE__)}/../database.yml")
ActiveRecord::Base.establish_connection(db_data[test_environment.to_sym])

DataMagic.yml_directory = "#{File.dirname(__FILE__)}/../data"

puts "Using #{ActiveRecord::Base.connection.current_database} as database"
