$LOAD_PATH << File.dirname(__FILE__)+"/../."
$LOAD_PATH << File.dirname(__FILE__)+"/../data"
$LOAD_PATH << File.dirname(__FILE__)+"/../patches"
require 'page-object'
require 'watir-scroll'
require 'angularjs'
require 'scenario_context'
require 'enum'
require 'sync_tolerance'
require 'ijet2_midtier'

def test_environment
  ENV['ENVIRONMENT'] ||= 'itg2'
end

def ijet_environment
  ENV['ENVIRONMENT'] == 'local' ? :itg2 : ENV['ENVIRONMENT'].to_sym
end

def base_url
  environments = YAML.load_file "#{File.dirname(__FILE__)}/../environment.yml"
  environments[test_environment.to_sym]
end

puts "Using #{test_environment} to test..."
puts "Using #{base_url} as base url to test..."
puts "Using #{ijet_environment} as ijet env to test..."

MidTier::Config.establish(ijet_environment) rescue warn("\nFailed to establish connection to the IJET2 MidTier! Tests requiring a connection will fail.")

PageObject.javascript_framework = :angularjs