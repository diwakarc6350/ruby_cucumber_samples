require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'asset line item view page' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    asset_line_item = NjSalesforce::AssetLineItem.first['Id']
    visit_object(asset_line_item)
  end

  context 'Left' do
    it 'has Asset Name' do
      expect(on(AssetLineItemViewPage).asset_name_element).to be_visible
    end
    it 'has Product Line' do
      expect(on(AssetLineItemViewPage).product_line_element).to be_visible
    end
    it 'has Operational Company' do
      expect(on(AssetLineItemViewPage).operational_company_element).to be_visible
    end
    it 'has Card Type' do
      expect(on(AssetLineItemViewPage).card_type_element).to be_visible
    end
    it 'has Aircraft 1' do
      expect(on(AssetLineItemViewPage).aircraft_type_1_element).to be_visible
    end
    it 'has Aircraft 2' do
      expect(on(AssetLineItemViewPage).aircraft_type_2_element).to be_visible
    end
    it 'has Hours Purchased' do
      expect(on(AssetLineItemViewPage).hours_purchased_element).to be_visible
    end
    it 'has Bonus Hours' do
      expect(on(AssetLineItemViewPage).bonus_hours_element).to be_visible
    end
    it 'has Referral Hours' do
      expect(on(AssetLineItemViewPage).referral_hours_element).to be_visible
    end
    it 'has Financial Partnership Hour' do
      expect(on(AssetLineItemViewPage).financial_partnership_hour_element).to be_visible
    end
    it 'has Total Hours' do
      expect(on(AssetLineItemViewPage).total_hour_element).to be_visible
    end
  end

  context 'Right' do
    it 'has Agreement' do
      expect(on(AssetLineItemViewPage).agreement_element).to be_visible
    end
    it 'has Legal Entity' do
      expect(on(AssetLineItemViewPage).legal_entity_element).to be_visible
    end
    it 'has Payment Date' do
      expect(on(AssetLineItemViewPage).payment_date_element).to be_visible
    end
    it 'has Grace Period Start Date' do
      expect(on(AssetLineItemViewPage).grace_period_start_date_element).to be_visible
    end
    it 'has contract end date' do
      expect(on(AssetLineItemViewPage).contract_end_date_element).to be_visible
    end
  end
end