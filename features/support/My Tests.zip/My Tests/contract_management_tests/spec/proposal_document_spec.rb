require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'proposal documents' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
  end

  it 'generates proposal for a single standard card product' do
    @new_proposal = NjSalesforce::Proposal
                        .create(Apttus_Proposal__Account__c: TestDataFactory.account.first['Id'],
                                Apttus_Proposal__Proposal_Name__c: 'My Test Standard Proposal',
                                Apttus_Proposal__Opportunity__c: TestDataFactory.opportunity.first['Id'],
                                Apttus_Proposal__Primary_Contact__c: TestDataFactory.contact.first['Id'],
                                Delivery_Email__c: 'qatest1@netjets.com')
    visit_object(@new_proposal)
    configure_products
    open_card_catalog
    add_product_to_cart(@data[:products][:nja][:standard])
    back_to_proposal
    generate_proposal
    attachments = NjSalesforce::Proposal.proposal_documents(@new_proposal)
    downloaded_proposal = NjSalesforce::AttachmentNotes.download(attachments.first['Id'], File.dirname(__FILE__) << '/../downloads')
    expect(File).to exist(File.dirname(__FILE__) << '/../downloads/' << downloaded_proposal)
    NjSalesforce::Proposal.delete(@new_proposal)
  end

  it 'generates proposal for a combo card product' do
    @new_proposal = NjSalesforce::Proposal
                        .create(Apttus_Proposal__Account__c: TestDataFactory.account.first['Id'],
                                Apttus_Proposal__Proposal_Name__c: 'My Test Combo Proposal',
                                Apttus_Proposal__Opportunity__c: TestDataFactory.opportunity.first['Id'],
                                Apttus_Proposal__Primary_Contact__c: TestDataFactory.contact.first['Id'],
                                Delivery_Email__c: 'qatest1@netjets.com')
    visit_object(@new_proposal)
    configure_products
    open_card_catalog
    add_product_to_cart(@data[:products][:nja][:combo])
    back_to_proposal
    generate_proposal
    attachments = NjSalesforce::Proposal.proposal_documents(@new_proposal)
    downloaded_proposal = NjSalesforce::AttachmentNotes.download(attachments.first['Id'], File.dirname(__FILE__) << '/../downloads')
    expect(File).to exist(File.dirname(__FILE__) << '/../downloads/' << downloaded_proposal)
    NjSalesforce::Proposal.delete(@new_proposal)
  end

  it 'generates proposal for a standard and combo card product' do
    @new_proposal = NjSalesforce::Proposal
                        .create(Apttus_Proposal__Account__c: TestDataFactory.account.first['Id'],
                                Apttus_Proposal__Proposal_Name__c: 'My Test Standard-Combo Proposal',
                                Apttus_Proposal__Opportunity__c: TestDataFactory.opportunity.first['Id'],
                                Apttus_Proposal__Primary_Contact__c: TestDataFactory.contact.first['Id'],
                                Delivery_Email__c: 'qatest1@netjets.com')
    visit_object(@new_proposal)
    configure_products
    open_card_catalog
    add_product_to_cart(@data[:products][:nja][:combo])
    add_product_to_cart(@data[:products][:nja][:standard])
    back_to_proposal
    generate_proposal
    attachments = NjSalesforce::Proposal.proposal_documents(@new_proposal)
    downloaded_proposal = NjSalesforce::AttachmentNotes.download(attachments.first['Id'], File.dirname(__FILE__) << '/../downloads')
    expect(File).to exist(File.dirname(__FILE__) << '/../downloads/' << downloaded_proposal)
    NjSalesforce::Proposal.delete(@new_proposal)
  end

end