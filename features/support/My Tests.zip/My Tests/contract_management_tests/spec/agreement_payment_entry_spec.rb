require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'agreement payment entries' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    agreement = NjSalesforce::Agreement
                    .agreement_information.select { |x| x['Funding_State__c'] == 'Pending Funding' }.sample['Id']
    visit_object(agreement)
    on(AgreementViewPage).new_payment
  end

  it 'has payment method' do
    expect(on(AgreementViewPage).payment_entries.payment_method_element).to be_visible
    actual_payment_methods = on(AgreementViewPage).payment_entries.payment_method_options
    expect(actual_payment_methods).to eq(@page_static_data[:agreement][:payment_entry][:payment_method])
  end

  it 'has payment amount' do
    expect(on(AgreementViewPage).payment_entries.payment_amount_element).to be_visible
  end

  it 'has payment date' do
    expect(on(AgreementViewPage).payment_entries.payment_date_element).to be_visible
  end

  it 'has comments' do
    expect(on(AgreementViewPage).payment_entries.comments_element).to be_visible
  end

end