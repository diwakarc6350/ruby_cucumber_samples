require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'legal entity edit page' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    legal_entity = TestDataFactory.clean(NjSalesforce::LegalEntity.where({Name: @data[:legal_entity][:legal_entity_name]}))
    visit_object(legal_entity.first['Id'])
    patiently { on(LegalEntityViewPage).edit }
  end

  describe 'Legal Entity Detail' do

    describe 'Left Column' do
      it 'has Legal Entity Name' do
        expect(on(LegalEntityEditPage).legal_entity_name_element).to be_visible
      end
      it 'has Legal Entity Type' do
        expect(on(LegalEntityEditPage).legal_entity_type_element).to be_visible
      end
      it 'has Legal Entity' do
        expect(on(LegalEntityEditPage).legal_entity_element).to be_visible
      end
    end

    describe 'Right Column' do
      it 'has Legal Phone Number' do
        expect(on(LegalEntityEditPage).legal_phone_number_element).to be_visible
      end
      it 'has Legal Email Address' do
        expect(on(LegalEntityEditPage).legal_email_address_element).to be_visible
      end
    end

  end

end

