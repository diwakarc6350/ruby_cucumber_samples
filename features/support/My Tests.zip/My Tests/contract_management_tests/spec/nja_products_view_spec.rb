require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'nja product page view' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    @nja_products = NjSalesforce::Product.product_information
                       .select { |x| x['Program__c']=='NetJets U.S.' }
  end

  it 'has Description and contains only Delayed Start, Initial Term, Grace Period for Standard card' do
    standard_product = @nja_products.select { |x| x['Card_Type__c']=='Standard' }.first
    visit_object(standard_product['Id'])
    description = on(ProductViewPage).description
    expect(description).to include('Delayed Start')
    expect(description).to include('Initial Term')
    expect(description).to include('Grace Period')
    expect(description).not_to include('Applicable CPI Escalation')
    expect(description).not_to include('Peak Period Day Premium')
  end

  it "has Description and contains Delayed Start, Initial Term, Grace Period, Applicable CPI Escalation and \
        Peak Period Day Premium for 36 month card" do
    pending('36month card does not exist anymore')
    standard_product = @nja_products.select { |x| x['Card_Type__c']=='36-Month' }.first
    visit_object(standard_product['Id'])
    description = on(ProductViewPage).description
    expect(description).to include('Delayed Start')
    expect(description).to include('Initial Term')
    expect(description).to include('Grace Period')
    expect(description).to include('Applicable CPI Escalation')
    expect(description).to include('Peak Period Day Premium')
  end

  it "has Description and contains Delayed Start, Initial Term, Grace Period \
                  Peak Period Day Premium Gateway card" do
    standard_product = @nja_products.select { |x| x['Card_Type__c']=='Gateway' }.first
    visit_object(standard_product['Id'])
    description = on(ProductViewPage).description
    expect(description).to include('Delayed Start')
    expect(description).to include('Initial Term')
    expect(description).to include('Grace Period')
    expect(description).not_to include('Applicable CPI Escalation')
    expect(description).to include('Peak Period Day Premium')
  end

  it "has Description and contains Delayed Start, Initial Term, Grace Period, Applicable CPI Escalation and \
        Peak Period Day Premium X-Country card" do
    standard_product = @nja_products.select { |x| x['Card_Type__c']=='X-Country' }.first
    visit_object(standard_product['Id'])
    description = on(ProductViewPage).description
    expect(description).to include('Delayed Start')
    expect(description).to include('Initial Term')
    expect(description).to include('Grace Period')
    expect(description).not_to include('Applicable CPI Escalation')
    expect(description).to include('Peak Period Day Premium')
  end

end
