require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'shopping cart' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    @new_proposal = NjSalesforce::Proposal
                        .create(Apttus_Proposal__Account__c: TestDataFactory.account.first['Id'],
                                Apttus_Proposal__Proposal_Name__c: 'My Test Proposal',
                                Apttus_Proposal__Opportunity__c: TestDataFactory.opportunity.first['Id'],
                                Apttus_Proposal__Primary_Contact__c: TestDataFactory.contact.first['Id'],
                                Delivery_Email__c: 'qatest1@netjets.com')
    visit_object(@new_proposal)
    on(ProposalViewPage).open_product_config
    open_card_catalog
  end

  after(:all) { NjSalesforce::Proposal.delete(@new_proposal) }

  it 'has the product categories as card, enhancement and miscellaneous' do
    on(ShoppingCartPage) do |p|
      expect(p.miscellaneous_products_element).to be_visible
      expect(p.card_products_element).to be_visible
      expect(p.enhancement_products_element).to be_visible
    end
  end

  it 'has required filters - what type of card, aircraft and how many hours?' do
    on(ShoppingCartPage) do |p|
      expect(patiently { p.what_type_of_card_filter_element }).to be_visible
      expect(patiently { p.what_type_of_aircraft_filter_element }).to be_visible
      expect(patiently { p.how_many_hours_filter_element }).to be_visible
    end
  end

  it 'has option to search products' do
    on(ShoppingCartPage) do |p|
      expect(p.product_search_element).to be_visible
    end
  end

  it 'has product descriptions' do
    on(ShoppingCartPage) do |p|
      expect(@browser.text).to include('Delayed Start')
      expect(@browser.text).to include('Initial Term')
      expect(@browser.text).to include('Grace Period')
    end
  end

  it 'miscellaneous product category displays only demo, promo and redemption card products' do
    on(ShoppingCartPage) do |p|
      open_miscellaneous_catalog
      expected_card_types = get_card_types
      expect(expected_card_types).to include('Demo')
      expect(expected_card_types).to include('Promo')
      expect(expected_card_types).to include('Redemption')
    end
  end

end
