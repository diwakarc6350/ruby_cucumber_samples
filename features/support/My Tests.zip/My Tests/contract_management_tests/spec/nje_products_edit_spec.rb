require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'nje product edit page' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    nje_products = NjSalesforce::Product.product_information.select { |x| x['Program__c']=='NetJets Europe' && x['Name']== @data[:products][:nje][:standard] }
    nje_product = nje_products[rand(nje_products.length)]['Id']
    puts nje_product
    visit_object(nje_product)
    on(ProductPage).edit_product
  end

  it 'has the nje flight rules for nje product' do
    expect(on(ProductPage).flight_rules?).to be(true)
    expect(on(ProductPage).flight_rules_options).to eq(on(ProductPage).expected_values[:nje_flight_rules])
  end

end
