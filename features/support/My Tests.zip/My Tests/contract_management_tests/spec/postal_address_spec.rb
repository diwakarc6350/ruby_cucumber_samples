require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'postal address page' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
  end

  context 'New Postal Address Record Type from CDR' do

    before(:all) do
      visit_object(find_apttus_cdr_with_no_legal_entity['Id'])
      patiently { on(ProposalViewPage).browser.iframe(title: 'CSPostalAddress').button(value: 'New').click }
    end

    it 'has the correct fields' do
      patiently { on(PostalAddressEditPage).street}
      expect(on(PostalAddressEditPage).street_element).to be_visible
      expect(on(PostalAddressEditPage).city_element).to be_visible
      expect(on(PostalAddressEditPage).state_province_element).to be_visible
      expect(on(PostalAddressEditPage).postal_code_element).to be_visible
      expect(on(PostalAddressEditPage).country_element).to be_visible
      expect(on(PostalAddressEditPage).associated_proposal_element).to be_visible
      expect(on(PostalAddressEditPage).address_type_element).to be_visible
    end
  end


end