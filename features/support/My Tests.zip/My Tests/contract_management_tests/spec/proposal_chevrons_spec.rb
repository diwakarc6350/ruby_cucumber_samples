require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'proposal chevrons' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    @proposals = NjSalesforce::Proposal.proposal_information
  end

  it 'displays Draft chevron when Record Type = Proposal and Approval Stage = Draft' do
    proposal = @proposals.select { |x| x['Record_Type_Name__c'] == 'Proposal' &&
        x['Apttus_Proposal__Approval_Stage__c'] == 'Draft' }.sample['Id']
    puts "Proposal ID: #{proposal}"
    visit_object(proposal)
    expect(on(ProposalViewPage).draft_chevron_element).to be_visible
  end

  it 'displays Proposal when Record Type = Proposal and Approval Stage != Draft' do
    proposal = @proposals.select { |x| x['Record_Type_Name__c'] == 'Proposal' &&
        x['Apttus_Proposal__Approval_Stage__c'] != 'Draft' }.sample['Id']
    puts "Proposal ID: #{proposal}"
    visit_object(proposal)
    expect(on(ProposalViewPage).proposal_chevron_element).to be_visible
  end

  it 'displays CDR Created when Record Type = CDR and Approval Stage != In Review or Approved' do
    proposal = @proposals.select { |x| x['Record_Type_Name__c'] == 'CDR' &&
        x['Apttus_Proposal__Approval_Stage__c'] != 'In Review' &&
        x['Apttus_Proposal__Approval_Stage__c'] != 'Approved' }.sample['Id']
    puts "Proposal ID: #{proposal}"
    visit_object(proposal)
    expect(on(ProposalViewPage).cdr_created_chevron_element).to be_visible
  end

  it 'displays Waiting For Approval when Record Type = CDR and Approval Stage = In Review' do
    proposal = @proposals.select { |x| x['Record_Type_Name__c'] == 'CDR' &&
        x['Apttus_Proposal__Approval_Stage__c'] == 'In Review' }.sample['Id']
    puts "Proposal ID: #{proposal}"
    visit_object(proposal)
    expect(on(ProposalViewPage).waiting_for_approval_chevron_element).to be_visible
  end

  it 'displays CDR Approved when Record Type = CDR and Approval Stage = Approved' do
    proposal = @proposals.select { |x| x['Record_Type_Name__c'] == 'CDR' &&
        x['Apttus_Proposal__Approval_Stage__c'] == 'Approved' }.sample['Id']
    puts "Proposal ID: #{proposal}"
    visit_object(proposal)
    expect(on(ProposalViewPage).cdr_approved_chevron_element).to be_visible
  end

end