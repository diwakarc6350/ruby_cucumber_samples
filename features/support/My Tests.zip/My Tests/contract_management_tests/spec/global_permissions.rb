require 'spec_helper'

shared_examples 'global permissions' do |permissions|
  include AllActions

  after(:each) do |example|
    description = example.metadata[:example_group][:full_description] + '_' + example.metadata[:description]
    Dir::mkdir('screenshots') if not File.directory?('screenshots')
    screenshot = "./screenshots/#{description.gsub(' ', '_').gsub(/[^0-9A-Za-z_]/, '')}.png"
    @browser.screenshot.save(screenshot)
  end

  YAML.load_file(permissions).each do |access_descriptor|
    key = access_descriptor.keys.first
    object = access_descriptor[key]
    allowed_permissions = object[:allowed].split('')
    denied_permissions = %w(c r u d) - allowed_permissions

    describe "#{key}" do
      allowed_permissions.each do |allowed_permission|
        it "has #{allowed_permission} permission" do
          object_class = ("NjSalesforce::" << key.to_s).constantize
          case allowed_permission
            when 'c'
              visit_uri(object_class.new)
              @browser.button(value: 'Continue').click if @browser.button(value: 'Continue').exists?
              expect(on(object[:page_class]).save_element).to be_visible
              expect(on(object[:page_class]).cancel_element).to be_visible
            when 'r'
              visit_object(object_class.first['Id'])
              expect(@browser.text).not_to be_empty
              expect(@browser.text).not_to include('cannot be displayed')
              expect(@browser.text).not_to include('do not have sufficient previleges')
            when 'u'
              visit_object(object_class.first['Id'])
              expect(on(object[:page_class]).edit_element).to be_visible
            when 'd'
              visit_object(object_class.first['Id'])
              expect(on(object[:page_class]).delete_element).to be_visible
          end
        end
      end

      denied_permissions.each do |denied_permissions|
        it "has no #{denied_permissions} permission" do
          object_class = ("NjSalesforce::" << key.to_s).constantize
          case denied_permissions
            when 'c'
              visit_uri(object_class.new.chomp('/e') << '/o')
              expect(on(object[:page_class]).new_element).not_to be_visible
            when 'r'
              visit_object(object_class.first['Id'])
              expect(@browser.text).to include('Insufficient Privileges')
            when 'u'
              visit_object(object_class.first['Id'])
              expect(on(object[:page_class]).edit_element).not_to be_visible
            when 'd'
              visit_object(object_class.first['Id'])
              expect(on(object[:page_class]).delete_element).not_to be_visible
          end
        end
      end

    end
  end
end