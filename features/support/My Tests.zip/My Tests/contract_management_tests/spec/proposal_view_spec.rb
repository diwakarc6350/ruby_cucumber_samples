require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'proposal page view' do
  include AllActions
  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    @new_proposal = NjSalesforce::Proposal
                        .create(Apttus_Proposal__Account__c: TestDataFactory.account.first['Id'],
                                Apttus_Proposal__Proposal_Name__c: 'My Test Proposal',
                                Apttus_Proposal__Opportunity__c: TestDataFactory.opportunity.first['Id'],
                                Apttus_Proposal__Primary_Contact__c: TestDataFactory.contact.first['Id'],
                                Delivery_Email__c: 'qatest1@netjets.com')
    visit_object(@new_proposal)
    configure_products
    open_card_catalog
    add_product_to_cart(DataMagic.yml[:products][:nja][:standard])
    back_to_proposal
  end

  context 'Actions' do
    it 'has Configure Products' do
      expect(on(ProposalViewPage).configure_products_element).to be_visible
    end

    it 'has Fuel Rate to Use' do
      expect(on(ProposalViewPage).fuel_rate_to_use_element).to be_visible
    end

    it 'has Generate Proposal' do
      pending('to be implemented iframe related')
      expect(5).to eq(6)
    end

    it 'has Create CDR' do
      expect(on(ProposalViewPage).change_document_element).to be_visible
    end

    it 'has Send Proposal to Customer' do
      expect(on(ProposalViewPage).send_proposal_to_customer_element).to be_visible
    end

    it 'has a Proposal Type' do
      expect(on(ProposalViewPage).proposal_type_element).to be_visible
    end
    it 'has a Proposal Language' do
      expect(on(ProposalViewPage).proposal_language_element).to be_visible
    end
    it 'has a Proposal Line Item' do
      expect(on(ProposalViewPage).proposal_line_item_element).to be_visible
    end
    it 'has a Signatory' do
      expect(on(ProposalViewPage).signatory_element).to be_visible
    end
    it 'has a World Check' do
      expect(on(ProposalViewPage).world_check_element).to be_visible
    end
  end

  context 'Information' do
    it 'has a Proposal Name' do
      expect(on(ProposalViewPage).proposal_name_element).to be_visible
    end
    it 'has a Approval Stage' do
      expect(on(ProposalViewPage).approval_stage_element).to be_visible
    end
    it 'has a Record Type' do
      expect(on(ProposalViewPage).record_type_element).to be_visible
    end

  end


  context 'Entity Information' do
    it 'has Delivery Email and CC' do
      expect(on(ProposalViewPage).delivery_email_1_element).to be_visible
      expect(on(ProposalViewPage).delivery_email_2_element).to be_visible
      expect(on(ProposalViewPage).delivery_cc_email_1_element).to be_visible
      expect(on(ProposalViewPage).delivery_cc_email_2_element).to be_visible
    end

    it 'has a Account' do
      expect(on(ProposalViewPage).account_element).to be_visible
    end
    it 'has a Opportunity' do
      expect(on(ProposalViewPage).opportunity_element).to be_visible
    end
    it 'has a Primary Contact' do
      expect(on(ProposalViewPage).primary_contact_element).to be_visible
    end
    it 'has a Owner Is' do
      expect(on(ProposalViewPage).owner_is_element).to be_visible
    end

  end

  context 'Comments' do
    it 'has a Proposal Comments' do
      expect(on(ProposalViewPage).proposal_comments_element).to be_visible
    end

  end

  context 'System Informaton' do
    it 'has a Created By' do
      expect(on(ProposalViewPage).created_by_element).to be_visible
    end

    it 'has a Last Modified By' do
      expect(on(ProposalViewPage).last_modified_by_element).to be_visible
    end

  end



  after(:all) do
    NjSalesforce::Proposal.delete(@new_proposal)
  end

end