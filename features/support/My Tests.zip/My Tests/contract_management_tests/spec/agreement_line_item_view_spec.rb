require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'agreement line items' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    agreement = NjSalesforce::Agreement
                    .agreement_information.select { |x| x['Apttus__Status__c'] == 'Activated' }.sample['Id']
    visit_object(agreement)
    patiently { (on(AgreementViewPage).agreement_line_items_element[1][1].click) }
  end

  # it 'has regulatory stop fees' do
  #   patiently { expect(on(AgreementLineItemViewPage).regulatory_stop_fee_1_element).to be_visible }
  #   expect(on(AgreementLineItemViewPage).regulatory_stop_fee_2_element).to be_visible
  # end

  context 'Information' do
    it 'has a Line Item Id' do
      expect(on(AgreementLineItemViewPage).line_item_id_element).to be_visible
    end
    it 'has a Description' do
      expect(on(AgreementLineItemViewPage).description_element).to be_visible
    end
    it 'has a Product' do
      expect(on(AgreementLineItemViewPage).product_element).to be_visible
    end
    it 'has a Quantity' do
      expect(on(AgreementLineItemViewPage).quantity_element).to be_visible
    end
    it 'has a Product Line' do
      expect(on(AgreementLineItemViewPage).product_line_element).to be_visible
    end
    it 'has a Card Type' do
      expect(on(AgreementLineItemViewPage).card_type_element).to be_visible
    end
    it 'has a Aircraft 1 Hours' do
      expect(on(AgreementLineItemViewPage).aircraft_1_hours_element).to be_visible
    end
    it 'has a Aircraft 2 Hours' do
      expect(on(AgreementLineItemViewPage).aircraft_2_hours_element).to be_visible
    end
    it 'has a Occupied Flight Hours' do
      expect(on(AgreementLineItemViewPage).occupied_flight_hours_element).to be_visible
    end
    it 'has a Product Hours' do
      expect(on(AgreementLineItemViewPage).product_hours_element).to be_visible
    end
    it 'has a Aircraft 1' do
      expect(on(AgreementLineItemViewPage).aircraft_1_element).to be_visible
    end
    it 'has a Aircraft 2' do
      expect(on(AgreementLineItemViewPage).aircraft_2_element).to be_visible
    end
    it 'has a Annual Cost' do
      expect(on(AgreementLineItemViewPage).annual_cost_element).to be_visible
    end
    it 'has a Interchange Rate' do
      expect(on(AgreementLineItemViewPage).interchange_rate_element).to be_visible
    end
    it 'has a Partnership' do
      expect(on(AgreementLineItemViewPage).partnership_element).to be_visible
    end
    it 'has a Usage' do
      expect(on(AgreementLineItemViewPage).usage_element).to be_visible
    end
    it 'has a Program' do
      expect(on(AgreementLineItemViewPage).program_element).to be_visible
    end
    it 'has a Accounting Company' do
      expect(on(AgreementLineItemViewPage).accounting_company_element).to be_visible
    end
    it 'has a Operational Company' do
      expect(on(AgreementLineItemViewPage).operational_company_element).to be_visible
    end
    it 'has a Can Sub-Contract' do
      expect(on(AgreementLineItemViewPage).can_sub_contract_element).to be_visible
    end
    it 'has a Payment Terms' do
      expect(on(AgreementLineItemViewPage).payment_terms_element).to be_visible
    end
    it 'has a Payment Terms UOM' do
      expect(on(AgreementLineItemViewPage).payment_terms_uom_element).to be_visible
    end
    it 'has a Preferred Bank' do
      expect(on(AgreementLineItemViewPage).preferred_bank_element).to be_visible
    end
    it 'has a Excess Flying Hourly Tax (FET)' do
      expect(on(AgreementLineItemViewPage).excess_flying_hourly_tax_fet_element).to be_visible
    end
    it 'has a Excess Flying Prepay' do
      expect(on(AgreementLineItemViewPage).excess_flying_prepay_element).to be_visible
    end
    it 'has a Flight Rule' do
      expect(on(AgreementLineItemViewPage).flight_rule_element).to be_visible
    end
    it 'has a Ground Handling Fee' do
      expect(on(AgreementLineItemViewPage).ground_handling_fee_element).to be_visible
    end
    it 'has a Tax Percentage' do
      expect(on(AgreementLineItemViewPage).tax_percentage_element).to be_visible
    end
    it 'has a Bank Account' do
      expect(on(AgreementLineItemViewPage).bank_account_element).to be_visible
    end
    it 'has a Delayed Start Amount' do
      expect(on(AgreementLineItemViewPage).delayed_start_amount_element).to be_visible
    end
    it 'has a Delayed Start Unit of Measure (UOM)' do
      expect(on(AgreementLineItemViewPage).delayed_start_unit_of_measure_uom_element).to be_visible
    end
    it 'has a Fuel Tax % (FET)' do
      expect(on(AgreementLineItemViewPage).fuel_tax_fet_element).to be_visible
    end
    it 'has a Peak Period Day Departure Adjustment' do
      expect(on(AgreementLineItemViewPage).peak_period_day_departure_adjustment_element).to be_visible
    end
    it 'has a Peak Period Day Departure Adjustment UOM' do
      expect(on(AgreementLineItemViewPage).peak_period_day_departure_adjustment_uom_element).to be_visible
    end
    it 'has a Customer is Late Amount' do
      expect(on(AgreementLineItemViewPage).customer_is_late_amount_element).to be_visible
    end
    it 'has a Customer is Late UOM' do
      expect(on(AgreementLineItemViewPage).customer_is_late_uom_element).to be_visible
    end
    it 'has a NetJets is Late Amount' do
      expect(on(AgreementLineItemViewPage).netjets_is_late_amount_element).to be_visible
    end
    it 'has a NetJets is Late UOM' do
      expect(on(AgreementLineItemViewPage).netjets_is_late_uom_element).to be_visible
    end
    it 'has a Aircraft Per Day' do
      expect(on(AgreementLineItemViewPage).aircraft_per_day_element).to be_visible
    end
    it 'has a Upgrade from Aircraft' do
      expect(on(AgreementLineItemViewPage).upgrade_from_aircraft_element).to be_visible
    end
    it 'has a Derived From' do
      expect(on(AgreementLineItemViewPage).derived_from_element).to be_visible
    end
    it 'has a Fuel Rate' do
      expect(on(AgreementLineItemViewPage).fuel_rate_element).to be_visible
    end
    it 'has a Fuel Rate 1' do
      expect(on(AgreementLineItemViewPage).fuel_rate_1_element).to be_visible
    end
    it 'has a Fuel Rate 2' do
      expect(on(AgreementLineItemViewPage).fuel_rate_2_element).to be_visible
    end
    it 'has a Prepaid Fuel Type' do
      expect(on(AgreementLineItemViewPage).prepaid_fuel_type_element).to be_visible
    end
    it 'has a Prepaid incidentals' do
      expect(on(AgreementLineItemViewPage).prepaid_incidentals_element).to be_visible
    end
    it 'has a Operating Expense Fund' do
      expect(on(AgreementLineItemViewPage).operating_expense_fund_element).to be_visible
    end
    it 'has a Prepaid Fuel Amount' do
      expect(on(AgreementLineItemViewPage).prepaid_fuel_amount_element).to be_visible
    end
    it 'has a 3 Month Average Fuel Cost' do
      expect(on(AgreementLineItemViewPage).three_month_average_fuel_cost_element).to be_visible
    end
    it 'has a Peak Period Day Premium' do
      expect(on(AgreementLineItemViewPage).peak_period_day_premium_element).to be_visible
    end
    it 'has a Non-Qualifying Premium' do
      expect(on(AgreementLineItemViewPage).non_qualifying_premium_element).to be_visible
    end
    it 'has a Minimum Flight Segment Rules Amount AC1' do
      expect(on(AgreementLineItemViewPage).minimum_flight_segment_rules_amount_ac1_element).to be_visible
    end
    it 'has a Minimum Flight Segment Rules Amount AC2' do
      expect(on(AgreementLineItemViewPage).minimum_flight_segment_rules_amount_ac2_element).to be_visible
    end
    it 'has a Minimum Flight Segment Rules UOM AC1' do
      expect(on(AgreementLineItemViewPage).minimum_flight_segment_rules_uom_ac1_element).to be_visible
    end
    it 'has a Minimum Flight Segment Rules UOM AC2' do
      expect(on(AgreementLineItemViewPage).minimum_flight_segment_rules_uom_ac2_element).to be_visible
    end
    it 'has a Escalation Method' do
      expect(on(AgreementLineItemViewPage).escalation_method_element).to be_visible
    end
    it 'has a Fuel Type AC1' do
      expect(on(AgreementLineItemViewPage).fuel_type_ac1_element).to be_visible
    end
    it 'has a Fuel Type AC2' do
      expect(on(AgreementLineItemViewPage).fuel_type_ac2_element).to be_visible
    end
    it 'has a Regulatory Stop Fee 1' do
      expect(on(AgreementLineItemViewPage).regulatory_stop_fee_1_element).to be_visible
    end
    it 'has a Regulatory Stop Fee 2' do
      expect(on(AgreementLineItemViewPage).regulatory_stop_fee_2_element).to be_visible
    end
    it 'has a Fuel Rate Id 1' do
      expect(on(AgreementLineItemViewPage).fuel_rate_id_1_element).to be_visible
    end
    it 'has a Fuel Rate Id 2' do
      expect(on(AgreementLineItemViewPage).fuel_rate_id_2_element).to be_visible
    end
    it 'has a Agreement' do
      expect(on(AgreementLineItemViewPage).agreement_element).to be_visible
    end
    it 'has a Item Sequence' do
      expect(on(AgreementLineItemViewPage).item_sequence_element).to be_visible
    end
    it 'has a Line Number' do
      expect(on(AgreementLineItemViewPage).line_number_element).to be_visible
    end
    it 'has a Blackout Days' do
      expect(on(AgreementLineItemViewPage).blackout_days_element).to be_visible
    end
    it 'has a Peak Period Days' do
      expect(on(AgreementLineItemViewPage).peak_period_days_element).to be_visible
    end
    it 'has a Bonus Hours' do
      expect(on(AgreementLineItemViewPage).bonus_hours_element).to be_visible
    end
    it 'has a Non-Standard' do
      expect(on(AgreementLineItemViewPage).non_standard_element).to be_visible
    end
    it 'has a To Aircraft' do
      expect(on(AgreementLineItemViewPage).to_aircraft_element).to be_visible
    end
    it 'has a Upgrade Service Area' do
      expect(on(AgreementLineItemViewPage).upgrade_service_area_element).to be_visible
    end
    it 'has a Upgrade Segments' do
      expect(on(AgreementLineItemViewPage).upgrade_segments_element).to be_visible
    end
    it 'has a Upgrade Hours' do
      expect(on(AgreementLineItemViewPage).upgrade_hours_element).to be_visible
    end
    it 'has a Initial Term Amount' do
      expect(on(AgreementLineItemViewPage).initial_term_amount_element).to be_visible
    end
    it 'has a Initial Term Unit of Measure (UOM)' do
      expect(on(AgreementLineItemViewPage).initial_term_unit_of_measure_uom_element).to be_visible
    end
    it 'has a Grace Period Amount' do
      expect(on(AgreementLineItemViewPage).grace_period_amount_element).to be_visible
    end
    it 'has a Grace Period Unit of Measure (UOM)' do
      expect(on(AgreementLineItemViewPage).grace_period_unit_of_measure_uom_element).to be_visible
    end
    it 'has a Taxi Time' do
      expect(on(AgreementLineItemViewPage).taxi_time_element).to be_visible
    end


  end

  context 'Payment Information' do
    it 'has a Pre-Tax Purchase Price' do
      expect(on(AgreementLineItemViewPage).pre_tax_purchase_price_element).to be_visible
    end
    it 'has a Adjustment Total' do
      expect(on(AgreementLineItemViewPage).adjustment_total_element).to be_visible
    end
    it 'has a Waived Premium Discount' do
      expect(on(AgreementLineItemViewPage).waived_premium_discount_element).to be_visible
    end
    it 'has a Tax Amount' do
      expect(on(AgreementLineItemViewPage).tax_amount_element).to be_visible
    end
    it 'has a Total Price' do
      expect(on(AgreementLineItemViewPage).total_price_element).to be_visible
    end
  end

  context 'System Information' do
    it 'has a Created By' do
      expect(on(AgreementLineItemViewPage).created_by_element).to be_visible
    end
    it 'has a Last Modified By' do
      expect(on(AgreementLineItemViewPage).last_modified_by_element).to be_visible
    end

  end

end

