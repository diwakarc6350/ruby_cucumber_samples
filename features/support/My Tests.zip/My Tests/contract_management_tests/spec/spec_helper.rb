$LOAD_PATH << Dir.pwd
$LOAD_PATH << __FILE__ + '../spec'

require 'rspec'
require 'faker'
require 'yaml'
require 'data_magic'
require 'page-object'
require 'nj_salesforce'
require 'sync_tolerance'
require 'test_data_factory'
require 'watir-webdriver'
require 'features/support/patches/page_object'

Dir['features/support/pages/sections/*.rb'].each { |section_file| require section_file }
Dir['features/support/pages/**/*.rb'].each { |file| require file }

DataMagic.yml_directory = 'features/support/data'
DataMagic.load('data.yml')


include PageObject::PageFactory
PageObject.javascript_framework = :jquery

RSpec.configure do |config|
  config.before :all do
    #load all the data related information
    @data = YAML.load_file("features/support/data/data.yml")
    @page_static_data = YAML.load_file("features/support/data/page_static_data.yml")
    browser = Watir::Browser.new :chrome
    browser.driver.manage.window.maximize
    @browser = browser
  end

  # Close that browser after each example.
  config.after :all do
    @browser.quit if @browser
  end

end

def login_info(role)
  puts "Test Environment : #{ENV['ENVIRONMENT']},  Testing as : #{role} "
  info = YAML.load_file('user.yml')
  info[ENV['ENVIRONMENT'].to_sym][role]
end