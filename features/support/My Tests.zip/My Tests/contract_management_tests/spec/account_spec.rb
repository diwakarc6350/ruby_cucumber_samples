require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'accounts page' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    acccount = TestDataFactory.clean(NjSalesforce::Account.where({Name: @data[:accounts][:account_name]}))
    visit_object(acccount.first['Id'])
  end

  it 'has asset line items' do
    on(AccountViewPage) do |p|
      actual_asset_line_items_columns = patiently { p.asset_line_items_element.to_h[0].keys }
      expect(actual_asset_line_items_columns)
          .to eq(@page_static_data[:account][:asset_line_items])
    end
  end
end
