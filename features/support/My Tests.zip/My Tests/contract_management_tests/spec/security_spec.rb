require 'spec_helper'
require 'page-object'
require 'all_actions'
require 'active_support/inflector'
require 'global_permissions'

describe 'global product manager' do
  include_examples 'global permissions', 'features/support/data/product_manager_access.yml'
  before(:all) do
    auth = login_info(:global_product_manager)
    login_to_salesforce(auth[:username], auth[:password])
  end
end

describe 'sales user' do
  include_examples 'global permissions', 'features/support/data/sales_user_access.yml'
  before(:all) do
    auth = login_info(:sales_user)
    login_to_salesforce(auth[:username], auth[:password])
  end
end

describe 'contract administrator' do
  include_examples 'global permissions', 'features/support/data/contract_administrator_access.yml'
  before(:all) do
    auth = login_info(:contract_administrator)
    login_to_salesforce(auth[:username], auth[:password])
  end
end