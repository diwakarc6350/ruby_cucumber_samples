require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'proposal line item edit page' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    @proposal_line_item = NjSalesforce::ProposalLineItem.all_collection.find { |line_item| line_item.Product_Name__c =~ /Card/ }
    visit_object(@proposal_line_item['Id'])
    on(ProposalViewPage).edit
  end

  context 'Information Section' do
    it 'has Escalation Method' do
      expect(on(ProposalLineItemEditPage).esclation_method_element).to be_enabled
    end
  end

  context 'Term Section' do
    it 'has Delayed Start Amount' do
      expect(on(ProposalLineItemEditPage).delayed_start_amount_element).to be_enabled
    end
    it 'has Grace Period Amount' do
      expect(on(ProposalLineItemEditPage).grace_period_amount_element).to be_enabled
    end
    it 'has Initial Term Amount' do
      expect(on(ProposalLineItemEditPage).initial_term_amount_element).to be_enabled
    end
    it 'has Initial Term Unit of Measure (UOM)' do
      expect(on(ProposalLineItemEditPage).initial_term_amount_uom_element).to be_enabled
    end
  end

  context 'Payment Information Section' do

    it 'has Prepaid Fuel Type' do
      expect(on(ProposalLineItemEditPage).prepaid_fuel_type_element).to be_enabled
    end

    it 'has Prepaid Incidentals' do
      expect(on(ProposalLineItemEditPage).prepaid_incidentals_element).to be_enabled
    end

  end

  context 'Liability For NetJets Flight Delay Section' do
    it 'has Liability Max Amount' do
      expect(on(ProposalLineItemEditPage).liability_for_delay_max_amount_element).to be_enabled
    end

    it 'has Liability Credit Type' do
      expect(on(ProposalLineItemEditPage).liability_for_delay_credit_type_element).to be_enabled
    end
  end

end