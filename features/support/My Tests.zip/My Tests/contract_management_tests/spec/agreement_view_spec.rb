require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'agreement view page' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    agreement = NjSalesforce::Agreement.agreement_information
                    .select { |x| x['Apttus__Status_Category__c'] == 'Request' }.sample['Id']
    visit_object(agreement)
  end

  context 'Actions' do
    it 'has a Preview Action' do
      expect(on(AgreementViewPage).preview_element).to be_visible
    end

    it 'has a Generate Contract Document Action' do
      expect(on(AgreementViewPage).generate_element).to be_visible
    end
    it 'has a Send for E Signature Action' do
      agreement = NjSalesforce::Agreement.agreement_information
                      .select { |x| x['Apttus__Status_Category__c'] == 'In Signatures' }
                      .sample['Id']
      visit_object(agreement)
      expect(on(AgreementViewPage).e_signature_element).to be_visible
    end
    it 'has a Send for Review Action' do
      expect(on(AgreementViewPage).review_element).to be_visible
    end
    it 'has a Cancel Request Action' do
      pending('to be implemented iframe issue')
      expect(on(AgreementViewPage).cancel_request_element.exists?).to be true
    end
    it 'has Activate Action' do
      expect(on(AgreementViewPage).activate_element).to be_visible
    end
    it 'has Send Hard Copy to Customer' do
      pending('to be implemented iframe issue')
      expect(on(AgreementViewPage).send_hardcopy_element).to be_visible
    end
    it 'has Certificate of Insurance Request' do
      expect(on(AgreementViewPage).insurance_request_element).to be_visible
    end
    it 'Send Hard Copy to Customer should disabled  when Status is in Request' do
      expect(on(AgreementViewPage).send_hardcopy_element).not_to be_visible
    end

    it 'Send Hard Copy to shoould change the Chevron to Pending' do
      expect(on(AgreementViewPage).send_hardcopy_element).not_to be_visible
    end

  end

  context 'Product Information' do
    it 'has an Card Type' do
      expect(on(AgreementViewPage).card_type_element).to be_visible
    end
    it 'has an Occupied Flight Hours' do
      expect(on(AgreementViewPage).occupied_flight_hours_element).to be_visible
    end
    it 'has an Aircraft Type 1' do
      expect(on(AgreementViewPage).aircraft_type_1_element).to be_visible
    end
    it 'has an Aircraft Type 2' do
      expect(on(AgreementViewPage).aircraft_type_2_element).to be_visible
    end
    it 'has an Product Sub-Type' do
      expect(on(AgreementViewPage).product_sub_type_element).to be_visible
    end
    it 'has an Peak Period Day Premium' do
      expect(on(AgreementViewPage).ppd_premium_element).to be_visible
    end
    it 'has an Aircraft 1 Hours' do
      expect(on(AgreementViewPage).aircraft_1_hours_element).to be_visible
    end
    it 'has an Aircraft 2 Hours' do
      expect(on(AgreementViewPage).aircraft_2_hours_element).to be_visible
    end
  end

  context 'Term' do
    it 'has a Delayed Start Amount and UOM' do
      expect(on(AgreementViewPage).delayed_start_amount_element).to be_visible
      expect(on(AgreementViewPage).delayed_start_amount_uom_element).to be_visible
    end
    it 'has an Initial Term Amount and UOM' do
      expect(on(AgreementViewPage).initial_term_element).to be_visible
      expect(on(AgreementViewPage).initial_term_amount_uom_element).to be_visible
    end
    it 'has a Grace Period Amount and UOM' do
      expect(on(AgreementViewPage).grace_period_element).to be_visible
      expect(on(AgreementViewPage).grace_period_amount_uom_element).to be_visible
    end
    it 'has a Extended Term Amount and UOM' do
      expect(on(AgreementViewPage).extended_term_amount_element).to be_visible
      expect(on(AgreementViewPage).extended_term_amount_uom_element).to be_visible
    end
    it 'has an Funding Date' do
      expect(on(AgreementViewPage).funding_date_element).to be_visible
    end
    it 'has an First Flight Date' do
      expect(on(AgreementViewPage).first_flight_date_element).to be_visible
    end
    it 'has a Effective / Delayed Start Date' do
      expect(on(AgreementViewPage).delayed_start_date_element).to be_visible
    end
    it 'has an Initial Term End Date' do
      expect(on(AgreementViewPage).initial_term_expiration_date_element).to be_visible
    end
    it 'has a Grace Period End Date' do
      expect(on(AgreementViewPage).grace_period_end_date_element).to be_visible
    end
    it 'has a Extended End Date' do
      expect(on(AgreementViewPage).extended_end_date_element).to be_visible
    end
    it 'has a Termination Date' do
      expect(on(AgreementViewPage).termination_date_element).to be_visible
    end
  end

  context 'Entity Information' do
    it 'has an Agreement Number' do
      expect(on(AgreementViewPage).agreement_number_element).to be_visible
    end
    it 'has an Card Number' do
      expect(on(AgreementViewPage).card_number_element).to be_visible
    end
    it 'has an Agreement Name' do
      expect(on(AgreementViewPage).agreement_name_element).to be_visible
    end
    it 'has an Account ' do
      expect(on(AgreementViewPage).account_element).to be_visible
    end
    it 'has a Legal Entity' do
      expect(on(AgreementViewPage).legal_entity_element).to be_visible
    end
    it 'has a Signatory' do
      expect(on(AgreementViewPage).signatory_element).to be_visible
    end
    it 'has a Related Quote/Proposal' do
      expect(on(AgreementViewPage).related_quote_proposal_element).to be_visible
    end
    it 'has a Related Opportunity' do
      expect(on(AgreementViewPage).related_opportunity_element).to be_visible
    end
    it 'has a Primary Sales Executive' do
      expect(on(AgreementViewPage).primary_sales_executive_element).to be_visible
    end
    it 'has a Secondary Sales Executive' do
      expect(on(AgreementViewPage).secondary_sales_executive_element).to be_visible
    end
    it 'has a Account Executive' do
      expect(on(AgreementViewPage).account_executive_element).to be_visible
    end
    it 'has a Requestor' do
      expect(on(AgreementViewPage).requestor_element).to be_visible
    end
    it 'has a Owner' do
      expect(on(AgreementViewPage).owner_element).to be_visible
    end
    it 'has a World Check' do
      expect(on(AgreementViewPage).world_check_element).to be_visible
    end
    it 'has email information' do
      expect(on(AgreementViewPage).delivery_email_1_element).to be_visible
      expect(on(AgreementViewPage).delivery_email_2_element).to be_visible
      expect(on(AgreementViewPage).delivery_cc_email_1_element).to be_visible
      expect(on(AgreementViewPage).delivery_cc_email_2_element).to be_visible
    end


  end

  context 'Payment Information' do
    it 'has a Pre-Tax Purchase Price' do
      expect(on(AgreementViewPage).pre_tax_purchase_price_element).to be_visible
    end
    it 'has a Adjustment Total' do
      expect(on(AgreementViewPage).adjustment_total_element).to be_visible
    end
    it 'has a Waived Premium Discount' do
      expect(on(AgreementViewPage).waived_premium_discount_element).to be_visible
    end
    it 'has a Credit Amount' do
      expect(on(AgreementViewPage).credit_amount_element).to be_visible
    end
    it 'has a Waive FET' do
      expect(on(AgreementViewPage).waive_fet_element).to be_visible
    end
    it 'has a Tax Amount' do
      expect(on(AgreementViewPage).tax_amount_element).to be_visible
    end
    it 'has a Total Price' do
      expect(on(AgreementViewPage).total_price_element).to be_visible
    end
    it 'has a Prepaid Fuel Type' do
      expect(on(AgreementViewPage).prepaid_fuel_type_element).to be_visible
    end
    it 'has a Prepaid Fuel Amount' do
      expect(on(AgreementViewPage).prepaid_fuel_amount_element).to be_visible
    end
    it 'has a Prepaid incidentals' do
      expect(on(AgreementViewPage).prepaid_incidentals_element).to be_visible
    end
    it 'has a Operating Expense Fund' do
      expect(on(AgreementViewPage).operating_expense_fund_element).to be_visible
    end
    it 'has a Total Agreement Value' do
      expect(on(AgreementViewPage).total_agreement_value_element).to be_visible
    end
    it 'has a Funding State' do
      expect(on(AgreementViewPage).funding_state_element).to be_visible
    end
    it 'has a Total Payment Amount' do
      expect(on(AgreementViewPage).total_payment_amount_element).to be_visible
    end
    it 'has a Payment Terms' do
      expect(on(AgreementViewPage).payment_terms_element).to be_visible
    end
    it 'has a  Payment Terms UOM' do
      expect(on(AgreementViewPage).payment_terms_uom_element).to be_visible
    end
    it 'has a AR Number' do
      expect(on(AgreementViewPage).ar_number_element).to be_visible
    end
  end

  context 'Operational Information' do
    it 'has a Fuel Rate 1' do
      expect(on(AgreementViewPage).fuel_variable_rate_1_element).to be_visible
    end
    it 'has a Fuel Rate 2' do
      expect(on(AgreementViewPage).fuel_variable_rate_2_element).to be_visible
    end
    it 'has a PPD Departure Adjustment and UOM' do
      expect(on(AgreementViewPage).ppd_departure_adjustment_amount_element).to be_visible
      expect(on(AgreementViewPage).ppd_departure_adjustment_uom_element).to be_visible
    end
    it 'has a Customer is Late' do
      expect(on(AgreementViewPage).customer_is_late_amount_element).to be_visible
      expect(on(AgreementViewPage).customer_is_late_uom_element).to be_visible
    end
    it 'has a NetJets is Late' do
      expect(on(AgreementViewPage).netjets_is_late_amount_element).to be_visible
      expect(on(AgreementViewPage).netjets_is_late_uom_element).to be_visible
    end
    it 'has Liability for Flight Delay Max Amount' do
      expect(on(AgreementViewPage).liability_for_delay_max_amount_element).to be_visible
    end
    it 'has Liability for Flight Delay Credit Type' do
      expect(on(AgreementViewPage).liability_for_delay_credit_type_element).to be_visible
    end
    it 'has a Can Sub-Contract' do
      expect(on(AgreementViewPage).can_sub_contract_element).to be_visible
    end
  end

  context 'Comments' do
    it 'has a Internal Comments' do
      expect(on(AgreementViewPage).internal_comments_element).to be_visible
    end
    it 'has a Agreement Comments' do
      expect(on(AgreementViewPage).agreement_comments_element).to be_visible
    end
    it 'has a Account Comments' do
      expect(on(AgreementViewPage).account_comments_element).to be_visible
    end
    it 'has a Legal Entity Comments' do
      expect(on(AgreementViewPage).legal_entity_comments_element).to be_visible
    end
  end

  context 'Miscellaneous' do
    it 'has a Company Signed By' do
      expect(on(AgreementViewPage).company_signed_by_element).to be_visible
    end
    it 'has a Company Signed Date' do
      expect(on(AgreementViewPage).company_signed_date_element).to be_visible
    end
    it 'has a Company Signed Title' do
      expect(on(AgreementViewPage).company_signed_title_element).to be_visible
    end
    it 'has a Other Party Signed by' do
      expect(on(AgreementViewPage).other_party_signed_by_element).to be_visible
    end
    it 'has a Other Party Signed By (Unlisted)' do
      expect(on(AgreementViewPage).other_party_signed_by_unlisted_element).to be_visible
    end
    it 'has a Other Party Signed Date' do
      expect(on(AgreementViewPage).other_party_signed_date_element).to be_visible
    end
    it 'has a Other Party Signed Title' do
      expect(on(AgreementViewPage).other_party_signed_title_element).to be_visible
    end
    it 'has a Non Standard Legal Language' do
      expect(on(AgreementViewPage).non_standard_legal_language_element).to be_visible
    end
    it 'has a Risk Rating' do
      expect(on(AgreementViewPage).risk_rating_element).to be_visible
    end
    it 'has a Initiation Type' do
      expect(on(AgreementViewPage).initiation_type_element).to be_visible
    end
    it 'has a Source' do
      expect(on(AgreementViewPage).source_element).to be_visible
    end
    it 'has a Allowable Output Formats' do
      expect(on(AgreementViewPage).allowable_output_formats_element).to be_visible
    end
    it 'has a Is Locked' do
      expect(on(AgreementViewPage).is_locked_element).to be_visible
    end
  end

  context 'System Information' do
    it 'has a Created By' do
      expect(on(AgreementViewPage).created_by_element).to be_visible
    end
    it 'has a Last Modified By' do
      expect(on(AgreementViewPage).last_modified_by_element).to be_visible
    end
    it 'has a Is Internal Review' do
      expect(on(AgreementViewPage).is_internal_review_element).to be_visible
    end
  end

  context 'Custom Links' do
    it 'has a Activate link' do
      expect(on(AgreementViewPage).activate_element).to be_visible
    end
  end

  context 'Temporary Holding' do
    it 'has a CS Exhibit Display or Not NJE' do
      expect(on(AgreementViewPage).cs_exhibit_display_or_not_nje_element).to be_visible
    end
    it 'has a Fuel Rate Id 1' do
      expect(on(AgreementViewPage).fuel_rate_id_1_element).to be_visible
    end
    it 'has a Fuel Rate Id 2' do
      expect(on(AgreementViewPage).fuel_rate_id_2_element).to be_visible
    end
    it 'has a World Check' do
      expect(on(AgreementViewPage).world_check_element).to be_visible
    end
    it 'has a Email AC Type' do
      expect(on(AgreementViewPage).email_ac_type_element).to be_visible
    end
    it 'has a Email Subject' do
      expect(on(AgreementViewPage).email_subject_element).to be_visible
    end
    it 'has a Legal Email Address' do
      expect(on(AgreementViewPage).legal_email_address_element).to be_visible
    end
    it 'has a Entity Address' do
      expect(on(AgreementViewPage).entity_address_element).to be_visible
    end
    it 'has a Legal Entity City' do
      expect(on(AgreementViewPage).legal_entity_city_element).to be_visible
    end
    it 'has a Legal Entity Country' do
      expect(on(AgreementViewPage).legal_entity_country_element).to be_visible
    end
    it 'has a Legal Entity Postal Code' do
      expect(on(AgreementViewPage).legal_entity_postal_code_element).to be_visible
    end
    it 'has a Legal Entity State/Province' do
      expect(on(AgreementViewPage).legal_entity_state_province_element).to be_visible
    end
    it 'has a Legal Entity Street' do
      expect(on(AgreementViewPage).legal_entity_street_element).to be_visible
    end
    it 'has a Migration Tax Amount' do
      expect(on(AgreementViewPage).migration_tax_amount_element).to be_visible
    end
    it 'has a Migration Account Executive' do
      expect(on(AgreementViewPage).migration_account_executive_element).to be_visible
    end
    it 'has a Migration Primary Sales Executive' do
      expect(on(AgreementViewPage).migration_primary_sales_executive_element).to be_visible
    end
    it 'has a Migration Sales VP' do
      expect(on(AgreementViewPage).migration_sales_vp_element).to be_visible
    end
    it 'has a Migration Secondary Sales Executive' do
      expect(on(AgreementViewPage).migration_secondary_sales_executive_element).to be_visible
    end
    it 'has a Specialty Cards' do
      expect(on(AgreementViewPage).specialty_cards_element).to be_visible
    end
    it 'has a CS Peak Period Day Premium' do
      expect(on(AgreementViewPage).cs_peak_period_day_premium_element).to be_visible
    end
    it 'has a Payment Date' do
      expect(on(AgreementViewPage).payment_date_element).to be_visible
    end
    it 'has a Sales VP' do
      expect(on(AgreementViewPage).sales_vp_element).to be_visible
    end
    it 'has a Prevent Setting Funded Contract' do
      expect(on(AgreementViewPage).prevent_setting_funded_contract_element).to be_visible
    end
    it 'has a Price List' do
      expect(on(AgreementViewPage).price_list_element).to be_visible
    end
    it 'has a CS Agreement Number' do
      expect(on(AgreementViewPage).cs_agreement_number_element).to be_visible
    end
    it 'has a Product Line' do
      expect(on(AgreementViewPage).product_line_element).to be_visible
    end
    it 'has a Contract Administrator Group' do
      expect(on(AgreementViewPage).contract_administrator_group_element).to be_visible
    end
    it 'has a Chevron Status' do
      expect(on(AgreementViewPage).chevron_status_element).to be_visible
    end
    it 'has a Tax Percentage' do
      expect(on(AgreementViewPage).tax_percentage_element).to be_visible
    end
    it 'has a AirCraft2 Class Ranking' do
      expect(on(AgreementViewPage).aircraft2_class_ranking_element).to be_visible
    end
    it 'has a CS Hours' do
      expect(on(AgreementViewPage).cs_hours_element).to be_visible
    end
    it 'has a CS Preferred Bank' do
      expect(on(AgreementViewPage).cs_preferred_bank_element).to be_visible
    end
    it 'has a CS Accounting Company' do
      expect(on(AgreementViewPage).cs_accounting_company_element).to be_visible
    end
    it 'has a CS Payment Terms' do
      expect(on(AgreementViewPage).cs_payment_terms_element).to be_visible
    end
    it 'has a CS Initial Term Amount' do
      expect(on(AgreementViewPage).cs_initial_term_amount_element).to be_visible
    end
    it 'has a CS Grace Period Amount' do
      expect(on(AgreementViewPage).cs_grace_period_amount_element).to be_visible
    end
    it 'has a CS Agreement Line Item Exist' do
      expect(on(AgreementViewPage).cs_agreement_line_item_exist_element).to be_visible
    end
    it 'has a CS Exhibit Display or Not' do
      expect(on(AgreementViewPage).cs_exhibit_display_or_not_element).to be_visible
    end
    it 'has a CS Exhibit Flg' do
      expect(on(AgreementViewPage).cs_exhibit_flg_element).to be_visible
    end
    it 'has a Owner Is' do
      expect(on(AgreementViewPage).owner_is_element).to be_visible
    end
    it 'has a Fuel Tax % (FET)' do
      expect(on(AgreementViewPage).fuel_tax_fet_element).to be_visible
    end
    it 'has a CS Credit' do
      expect(on(AgreementViewPage).cs_credit_element).to be_visible
    end
    it 'has a Account Search Field' do
      expect(on(AgreementViewPage).account_search_field_element).to be_visible
    end
    it 'has a Agreement Category' do
      expect(on(AgreementViewPage).agreement_category_element).to be_visible
    end
    it 'has a Agreement Number_Auto (INTERNAL)' do
      expect(on(AgreementViewPage).agreement_number_auto_internal_element).to be_visible
    end
    it 'has a Agreement Start Date' do
      expect(on(AgreementViewPage).agreement_start_date_element).to be_visible
    end
    it 'has a Agreement Number_Num (INTERNAL)' do
      expect(on(AgreementViewPage).agreement_number_num_internal_element).to be_visible
    end
    it 'has a Amend' do
      expect(on(AgreementViewPage).amend_element).to be_visible
    end
    it 'has a Approval Required' do
      expect(on(AgreementViewPage).approval_required_element).to be_visible
    end
    it 'has a Amendment Effective Date' do
      expect(on(AgreementViewPage).amendment_effective_date_element).to be_visible
    end
    it 'has a Auto Activate Order ?' do
      expect(on(AgreementViewPage).auto_activate_order_element).to be_visible
    end
    it 'has a Auto Renew' do
      expect(on(AgreementViewPage).auto_renew_element).to be_visible
    end
    it 'has a Executed Copy Mailed Out Date' do
      expect(on(AgreementViewPage).executed_copy_mailed_out_date_element).to be_visible
    end
    it 'has a Expire' do
      expect(on(AgreementViewPage).expire_element).to be_visible
    end
    it 'has a Fax' do
      expect(on(AgreementViewPage).fax_element).to be_visible
    end
    it 'has a Generate' do
      expect(on(AgreementViewPage).generate_span_element).to be_visible
    end
    # it 'has a Generate' do
    #   expect(on(AgreementViewPage).generate_2_element).to be_visible
    # end
    # it 'has a Generate Protected (OBSOLETE)' do
    #   expect(on(AgreementViewPage).generate_protected_obsolete_element).to be_visible
    # end
    it 'has a Generate Supporting Document' do
      expect(on(AgreementViewPage).generate_supporting_document_element).to be_visible
    end
    # it 'has a Generate Unprotected (OBSOLETE)' do
    #   expect(on(AgreementViewPage).generate_unprotected_obsolete_element).to be_visible
    # end
    it 'has a Initiate Termination' do
      expect(on(AgreementViewPage).initiate_termination_element).to be_visible
    end
    it 'has a Internal Renewal Notification Days' do
      expect(on(AgreementViewPage).internal_renewal_notification_days_element).to be_visible
    end
    it 'has a Internal Renewal Start Date' do
      expect(on(AgreementViewPage).internal_renewal_start_date_element).to be_visible
    end
    it 'has a Is System Update' do
      expect(on(AgreementViewPage).is_system_update_element).to be_visible
    end
    it 'has a Is Transient' do
      expect(on(AgreementViewPage).is_transient_element).to be_visible
    end
    it 'has a Language' do
      expect(on(AgreementViewPage).language_element).to be_visible
    end
    it 'has a Pricing Date' do
      expect(on(AgreementViewPage).pricing_date_element).to be_visible
    end
    it 'has a Primary Contact' do
      expect(on(AgreementViewPage).primary_contact_element).to be_visible
    end
    it 'has a Primary Phone' do
      expect(on(AgreementViewPage).primary_phone_element).to be_visible
    end
    it 'has a Product Description' do
      expect(on(AgreementViewPage).product_description_element).to be_visible
    end
    it 'has a Recall E-Signature Request' do
      expect(on(AgreementViewPage).recall_e_signature_request_element).to be_visible
    end
    it 'has a Record Type' do
      expect(on(AgreementViewPage).record_type_element).to be_visible
    end
    it 'has a Regenerate' do
      expect(on(AgreementViewPage).regenerate_span_element).to be_visible
    end
    it 'has a Regenerate' do
      expect(on(AgreementViewPage).regenerate_2_element).to be_visible
    end
    it 'has a Remaining Contracted Days' do
      expect(on(AgreementViewPage).remaining_contracted_days_element).to be_visible
    end
    it 'has a Renew' do
      expect(on(AgreementViewPage).renew_element).to be_visible
    end
    it 'has a Renewal Consent' do
      expect(on(AgreementViewPage).renewal_consent_element).to be_visible
    end
    it 'has a Renewal Notice Date' do
      expect(on(AgreementViewPage).renewal_notice_date_element).to be_visible
    end
    it 'has a Request Date' do
      expect(on(AgreementViewPage).request_date_element).to be_visible
    end
    it 'has a Renewal Terms' do
      expect(on(AgreementViewPage).renewal_terms_element).to be_visible
    end
    it 'has a Renewal Term (Months)' do
      expect(on(AgreementViewPage).renewal_term_months_element).to be_visible
    end
    it 'has a Renewal Notice Days' do
      expect(on(AgreementViewPage).renewal_notice_days_element).to be_visible
    end
    it 'has a Terminate' do
      expect(on(AgreementViewPage).terminate_element).to be_visible
    end
    it 'has a Third Party Liability Insurance' do
      expect(on(AgreementViewPage).third_party_liability_insurance_element).to be_visible
    end
    it 'has a Total' do
      expect(on(AgreementViewPage).total_element).to be_visible
    end
    it 'has a Total Agreement Value' do
      expect(on(AgreementViewPage).total_agreement_value_element).to be_visible
    end
    it 'has a Activate' do
      expect(on(AgreementViewPage).activate_element).to be_visible
    end
    it 'has a Activated By' do
      expect(on(AgreementViewPage).activated_by_element).to be_visible
    end
    it 'has a Activated Date' do
      expect(on(AgreementViewPage).activated_date_element).to be_visible
    end
    it 'has a AirCraft1 Class Ranking' do
      expect(on(AgreementViewPage).aircraft1_class_ranking_element).to be_visible
    end
    it 'has a CS Half Occupied Flight Hours' do
      expect(on(AgreementViewPage).cs_half_occupied_flight_hours_element).to be_visible
    end
    it 'has a CS Legal Entity Name' do
      expect(on(AgreementViewPage).cs_legal_entity_name_element).to be_visible
    end
    it 'has a CS Legal Entity Type' do
      expect(on(AgreementViewPage).cs_legal_entity_type_element).to be_visible
    end
    it 'has a CS Taxi Time' do
      expect(on(AgreementViewPage).cs_taxi_time_element).to be_visible
    end
    it 'has a CS Title' do
      expect(on(AgreementViewPage).cs_title_element).to be_visible
    end
    it 'has a CS Customer is Late Amount' do
      expect(on(AgreementViewPage).cs_customer_is_late_amount_element).to be_visible
    end
    it 'has a CS NetJets is Late Amount' do
      expect(on(AgreementViewPage).cs_netjets_is_late_amount_element).to be_visible
    end
    it 'has a CS Delayed Start Amount' do
      expect(on(AgreementViewPage).cs_delayed_start_amount_element).to be_visible
    end
    it 'has a CS PPD Departure Adjustment' do
      expect(on(AgreementViewPage).cs_ppd_departure_adjustment_element).to be_visible
    end
    it 'has a Price List Name' do
      expect(on(AgreementViewPage).price_list_name_element).to be_visible
    end
    it 'has a 3 Month Average Fuel Cost' do
      expect(on(AgreementViewPage).three_month_average_fuel_cost_element).to be_visible
    end
    it 'has a CS Prepaid Incidentals' do
      expect(on(AgreementViewPage).cs_prepaid_incidentals_element).to be_visible
    end
    it 'has a Waive Premium' do
      expect(on(AgreementViewPage).waive_premium_element).to be_visible
    end
    it 'has a CS Waived Premium Discount' do
      expect(on(AgreementViewPage).cs_waived_premium_discount_element).to be_visible
    end
    it 'has a Billing Preference' do
      expect(on(AgreementViewPage).billing_preference_element).to be_visible
    end
    it 'has a Business Hours' do
      expect(on(AgreementViewPage).business_hours_element).to be_visible
    end
    it 'has a Bill To' do
      expect(on(AgreementViewPage).bill_to_element).to be_visible
    end
    it 'has a Configuration Finalized Date' do
      expect(on(AgreementViewPage).configuration_finalized_date_element).to be_visible
    end
    it 'has a Contracted Days' do
      expect(on(AgreementViewPage).contracted_days_element).to be_visible
    end
    it 'has a Contract Duration (Days)' do
      expect(on(AgreementViewPage).contract_duration_days_element).to be_visible
    end
    it 'has a Configure Products' do
      expect(on(AgreementViewPage).configure_products_element).to be_visible
    end
    it 'has a Configuration Sync Date' do
      expect(on(AgreementViewPage).configuration_sync_date_element).to be_visible
    end
    it 'has a CS Display Terms and Conditions' do
      expect(on(AgreementViewPage).cs_display_terms_and_conditions_element).to be_visible
    end
    it 'has a CS Half Occupied Flight Hours Word' do
      expect(on(AgreementViewPage).cs_half_occupied_flight_hours_word_element).to be_visible
    end
    it 'has a CS Occupied Flight Hours' do
      expect(on(AgreementViewPage).cs_occupied_flight_hours_element).to be_visible
    end
    it 'has a Description' do
      expect(on(AgreementViewPage).description_element).to be_visible
    end
    it 'has a Display Aircraft' do
      expect(on(AgreementViewPage).display_aircraft_element).to be_visible
    end
    it 'has a Latest Doc ID' do
      expect(on(AgreementViewPage).latest_doc_id_element).to be_visible
    end
    it 'has a Lead Passenger' do
      expect(on(AgreementViewPage).lead_passenger_element).to be_visible
    end
    it 'has a Line Item Approval Status' do
      expect(on(AgreementViewPage).line_item_approval_status_element).to be_visible
    end
    it 'has a Location' do
      expect(on(AgreementViewPage).location_element).to be_visible
    end
    it 'has a Method of Delivery' do
      expect(on(AgreementViewPage).method_of_delivery_element).to be_visible
    end
    it 'has a Non Standard' do
      expect(on(AgreementViewPage).non_standard_element).to be_visible
    end
    it 'has a Other Party Returned Date' do
      expect(on(AgreementViewPage).other_party_returned_date_element).to be_visible
    end
    it 'has a Other Party Sent Date' do
      expect(on(AgreementViewPage).other_party_sent_date_element).to be_visible
    end
    it 'has a Outstanding Days' do
      expect(on(AgreementViewPage).outstanding_days_element).to be_visible
    end
    it 'has a Owner Expiration Notice' do
      expect(on(AgreementViewPage).owner_expiration_notice_element).to be_visible
    end
    it 'has a Parent Agreement' do
      expect(on(AgreementViewPage).parent_agreement_element).to be_visible
    end
    it 'has a Payment Term' do
      expect(on(AgreementViewPage).payment_term_element).to be_visible
    end
    it 'has a Partnership' do
      expect(on(AgreementViewPage).partnership_element).to be_visible
    end
    it 'has a Perpetual' do
      expect(on(AgreementViewPage).perpetual_element).to be_visible
    end
    # it 'has a Preview' do
    #   expect(on(AgreementViewPage).preview_element).to be_visible
    # end
    it 'has a Return To Requestor' do
      expect(on(AgreementViewPage).return_to_requestor_element).to be_visible
    end
    it 'has a Retention Policy' do
      expect(on(AgreementViewPage).retention_policy_element).to be_visible
    end
    it 'has a Retention Date' do
      expect(on(AgreementViewPage).retention_date_element).to be_visible
    end
    it 'has a Secondary Phone' do
      expect(on(AgreementViewPage).secondary_phone_element).to be_visible
    end
    it 'has a Send For Signatures' do
      expect(on(AgreementViewPage).send_for_signatures_element).to be_visible
    end
    it 'has a Send To Other Party (OBSOLETE)' do
      expect(on(AgreementViewPage).send_to_other_party_obsolete_element).to be_visible
    end
    it 'has a Ship To' do
      expect(on(AgreementViewPage).ship_to_element).to be_visible
    end
    it 'has a Special Terms' do
      expect(on(AgreementViewPage).special_terms_element).to be_visible
    end
    it 'has a Submit For Changes' do
      expect(on(AgreementViewPage).submit_for_changes_element).to be_visible
    end
    it 'has a Submit Request' do
      expect(on(AgreementViewPage).submit_request_element).to be_visible
    end
    it 'has a Submit Request Mode' do
      expect(on(AgreementViewPage).submit_request_mode_element).to be_visible
    end
    it 'has a Subtype' do
      expect(on(AgreementViewPage).subtype_element).to be_visible
    end
    it 'has a Synchronize with Opportunity' do
      expect(on(AgreementViewPage).synchronize_with_opportunity_element).to be_visible
    end
    it 'has a Taxi Time' do
      expect(on(AgreementViewPage).taxi_time_element).to be_visible
    end
    it 'has a Term (Months)' do
      expect(on(AgreementViewPage).term_months_element).to be_visible
    end
    it 'has a Term Exception Approval Status' do
      expect(on(AgreementViewPage).term_exception_approval_status_element).to be_visible
    end
    it 'has a Version (OBSOLETE)' do
      expect(on(AgreementViewPage).version_obsolete_element).to be_visible
    end
    it 'has a Termination Notice Issue Date' do
      expect(on(AgreementViewPage).termination_notice_issue_date_element).to be_visible
    end
    it 'has a Termination Notice Days' do
      expect(on(AgreementViewPage).termination_notice_days_element).to be_visible
    end
    it 'has a Termination Comments' do
      expect(on(AgreementViewPage).termination_comments_element).to be_visible
    end
    it 'has a View E-Signature Document' do
      expect(on(AgreementViewPage).view_e_signature_document_element).to be_visible
    end
    it 'has a Version Number' do
      expect(on(AgreementViewPage).version_number_element).to be_visible
    end
    it 'has a Workflow Trigger Generated Agreement' do
      expect(on(AgreementViewPage).workflow_trigger_generated_agreement_element).to be_visible
    end
    it 'has a CDR Approval Date' do
      expect(on(AgreementViewPage).cdr_approval_date_element).to be_visible
    end
    it 'has a Total Bonus Hours' do
      expect(on(AgreementViewPage).total_bonus_hours_element).to be_visible
    end
    it 'has a Total Business Partnership Hour' do
      expect(on(AgreementViewPage).total_business_partnership_hour_element).to be_visible
    end
    it 'has a Non-Qualifying Premium' do
      expect(on(AgreementViewPage).non_qualifying_premium_element).to be_visible
    end

  end


  context 'Agreement Line Items' do
    it 'has the Agreement Line Items' do
      on(AgreementViewPage) do |p|
        actual_agreement_line_items_columns = patiently { p.agreement_line_items_element.to_h[0].keys }
        expect(actual_agreement_line_items_columns)
            .to eq(@page_static_data[:agreement][:agreement_line_items][:expected_line_items])
      end
    end
  end

  context 'Postal Addresses' do
    it 'has Postal Addresses' do
      on(AgreementViewPage) do |p|
        postal_addresses_columns = patiently { p.postal_addresses_element.to_h[0].keys }
        expect(postal_addresses_columns)
            .to eq(@page_static_data[:agreement][:postal_addresses][:expected_line_items])
      end
    end
  end

end
