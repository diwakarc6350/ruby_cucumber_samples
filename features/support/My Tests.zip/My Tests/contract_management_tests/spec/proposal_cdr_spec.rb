require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'proposal contract document request page' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    @new_proposal = NjSalesforce::Proposal
                        .create(Apttus_Proposal__Account__c: TestDataFactory.account.first['Id'],
                                Apttus_Proposal__Proposal_Name__c: 'My Test Proposal',
                                Apttus_Proposal__Opportunity__c: TestDataFactory.opportunity.first['Id'],
                                Apttus_Proposal__Primary_Contact__c: TestDataFactory.contact.first['Id'],
                                Delivery_Email__c: 'qatest1@netjets.com')
    visit_object(@new_proposal)
    configure_products
    open_card_catalog
    add_product_to_cart(DataMagic.yml[:products][:nja][:standard])
    back_to_proposal
    default_data = on(ProposalViewPage).data_for(:proposal_to_cdr_required_fields)
    default_data.delete(:primary_phone)
    change_proposal_to_CDR(default_data)
  end

  context 'Actions' do
    it 'has a Configure Products' do
      expect(on(ProposalViewPage).configure_products_element).to be_visible
    end
    it 'has a Send for Approval' do
      expect(on(ProposalViewPage).send_for_approval_element).to be_visible
    end
    it 'has a Waive Premium' do
      expect(on(ProposalViewPage).waive_premium_element).to be_visible
    end
    it 'has a Waive FET' do
      expect(on(ProposalViewPage).waive_fet_element).to be_visible
    end
    it 'has a Adjustment Type' do
      expect(on(ProposalViewPage).adjustment_type_element).to be_visible
    end
    it 'has a Adjustment Amount' do
      expect(on(ProposalViewPage).adjustment_amount_element).to be_visible
    end
    it 'has a World Check' do
      expect(on(ProposalViewPage).world_check_element).to be_visible
    end
    it 'has a Create Proposal' do
      expect(on(ProposalViewPage).create_proposal_element).to be_visible
    end


  end


  context 'Information' do
    it 'has Proposal Name' do
      expect(on(ProposalViewPage).proposal_name_element).to be_visible
    end
    it 'has Proposal Total' do
      pending('deprecated?')
      expect(on(ProposalViewPage).proposal_total_element).to be_visible
    end
    it 'has Fuel Rate' do
      pending('deprecated?')
      expect(on(ProposalViewPage).fuel_rate_element).to be_visible
    end
    it 'has What Type of Card? as read-only' do
      expect(on(ProposalViewPage).what_type_of_card_element).to be_visible
    end
    it 'has Record Type' do
      expect(on(ProposalViewPage).change_document_element).to be_visible
    end
    it 'has Approval Stage' do
      expect(on(ProposalViewPage).approval_stage_element).to be_visible
    end
    it 'has Approval Status' do
      expect(on(ProposalViewPage).approval_status_element).to be_visible
    end
  end

  context 'Entity Information' do
    it 'has Account' do
      expect(on(ProposalViewPage).account_element).to be_visible
    end
    it 'has Legal Entity' do
      expect(on(ProposalViewPage).legal_entity_element).to be_visible
    end
    it 'has New Legal Entity' do
      expect(on(ProposalViewPage).new_legal_entity_element).to be_visible
    end
    it 'has Opportunity' do
      expect(on(ProposalViewPage).opportunity_element).to be_visible
    end
    it 'has Owner Is' do
      expect(on(ProposalViewPage).owner_is_element).to be_visible
    end
    it 'has Lead Passenger' do
      expect(on(ProposalViewPage).lead_passenger_element).to be_visible
    end
    it 'has Primary Contact' do
      expect(on(ProposalViewPage).primary_contact_element).to be_visible
    end
    it 'has Signatory' do
      #refer story
      expect(on(ProposalViewPage).signatory_element).to be_visible
    end
    it 'has Method of Delivery that defaults to DocuSign' do
      expect(on(ProposalViewPage).method_of_delivery_element).to be_visible
      expect(on(ProposalViewPage).method_of_delivery).to eq 'DocuSign'
    end
    it 'has Primary Phone that defaults to Work Phone 1 from the contact' do
      contact = TestDataFactory.contact.first
      expect(on(ProposalViewPage).primary_phone_element).to be_visible
      expect(on(ProposalViewPage).primary_phone).to eq contact['Work_Phone_1__c']
    end
    it 'has Secondary Phone' do
      expect(on(ProposalViewPage).secondary_phone_element).to be_visible
    end
    it 'has Fax' do
      expect(on(ProposalViewPage).fax_element).to be_visible
    end
    it 'has Delivery Email and CC' do
      expect(on(ProposalViewPage).delivery_email_1_element).to be_visible
      expect(on(ProposalViewPage).delivery_email_2_element).to be_visible
      expect(on(ProposalViewPage).delivery_cc_email_1_element).to be_visible
      expect(on(ProposalViewPage).delivery_cc_email_2_element).to be_visible
    end
  end

  context 'Comments' do
    it 'has internal comments' do
      expect(on(ProposalViewPage).internal_comments_element).to be_visible
    end
  end

  context 'System Information' do
    it 'has a Created By' do
      expect(on(ProposalViewPage).created_by_element).to be_visible
    end
    it 'has a Price List Name' do
      expect(on(ProposalViewPage).price_list_name_element).to be_visible
    end
    it 'has a Last Modified By' do
      expect(on(ProposalViewPage).last_modified_by_element).to be_visible
    end
    it 'has a Price List' do
      expect(on(ProposalViewPage).price_list_element).to be_visible
    end
    it 'has a Initial Term Amount' do
      expect(on(ProposalViewPage).initial_term_amount_element).to be_visible
    end
    it 'has a Specialty Cards' do
      expect(on(ProposalViewPage).specialty_cards_element).to be_visible
    end

  end

  context 'Address' do
    it 'has Postal Addresses' do
      expect(on(ProposalViewPage).browser.iframe(title: 'CSPostalAddress')).to be_visible
    end
  end


  after(:all) do
    NjSalesforce::Proposal.destroy(@new_proposal)
  end
end