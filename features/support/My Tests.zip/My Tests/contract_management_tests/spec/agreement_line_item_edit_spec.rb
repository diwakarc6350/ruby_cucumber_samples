require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'agreement line items' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    agreement = NjSalesforce::Agreement
                    .agreement_information.select { |x| x['Apttus__Status__c'] == 'Activated' }.sample['Id']
    visit_object(agreement)
    patiently { on(AgreementViewPage).agreement_line_items_element[1][1].click }
    patiently { on(AgreementLineItemViewPage).edit_agreement_line_item}
  end

  it 'has regulatory stop fees' do
    patiently { expect(on(AgreementLineItemEditPage).regulatory_stop_fee_1_element).to be_visible }
    expect(on(AgreementLineItemEditPage).regulatory_stop_fee_2_element).to be_visible
  end
end