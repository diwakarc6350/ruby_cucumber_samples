require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'upgrade 1:1 enhancement' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    @data = YAML.load_file("features/support/data/data.yml")
    login_to_salesforce(auth[:username], auth[:password])
    @new_proposal = NjSalesforce::Proposal
                        .create(Apttus_Proposal__Account__c: TestDataFactory.account.first['Id'],
                                Apttus_Proposal__Proposal_Name__c: 'My Test Proposal',
                                Apttus_Proposal__Opportunity__c: TestDataFactory.opportunity.first['Id'],
                                Apttus_Proposal__Primary_Contact__c: TestDataFactory.contact.first['Id'],
                                Delivery_Email__c: 'qatest1@netjets.com')
    visit_object(@new_proposal)
    configure_products
    open_card_catalog
    add_product_to_cart(@data[:products][:nja][:standard])
    open_enhancements_catalog
    add_enhancement_to_cart('Upgrade at 1:1')
    @expected_data = YAML.load_file("features/support/data/page_static_data.yml")
  end

  after(:all) do
    NjSalesforce::Proposal.delete(@new_proposal)
  end

  context 'Defaults' do
    it 'uses contract start date' do
      expect(on(ShoppingCartPage).upgrade_at_1_to_1.use_contract_start_date_checked?).to be true
    end

    it 'uses contract end date' do
      expect(on(ShoppingCartPage).upgrade_at_1_to_1.use_contract_end_date_checked?).to be true
    end

    it 'has Contiguous 48 US in the Upgrade Service Area Chosen' do
      expect(on(ShoppingCartPage).upgrade_at_1_to_1.chosen_upgrade_service_area_options)
          .to match_array(['Contiguous US (lower 48)'])
    end

    it 'does not have Contiguous 48 US chosen for an NJE User' do
      #PENDING
    end

    it 'restricts Blackout Days' do
      expect(on(ShoppingCartPage).upgrade_at_1_to_1.blackout_days).to eq('Restrict')
    end

    it 'restricts Peak Period Days' do
      expect(on(ShoppingCartPage).upgrade_at_1_to_1.peak_period_days).to eq('Restrict')
    end
  end

  context 'Information' do
    it 'has the correct options in the upgrade type' do
      expect(on(ShoppingCartPage).upgrade_at_1_to_1.upgrade_type_options)
          .to match_array(@expected_data[:product_catalog][:upgrade_one_to_one][:upgrade_type])
    end

    it 'has the correct options in the blackout days' do
      expect(on(ShoppingCartPage).upgrade_at_1_to_1.blackout_days_options)
          .to match_array (@expected_data[:product_catalog][:upgrade_one_to_one][:blackout_days])
    end

    it 'has the correct options in the Upgrade Service Area Available' do
      expect(on(ShoppingCartPage).upgrade_at_1_to_1.available_upgrade_service_area_options)
          .to match_array(@expected_data[:product_catalog][:upgrade_one_to_one][:upgrade_service_area_available])
    end

    it 'has the correct options in the peak period days' do
      expect(on(ShoppingCartPage).upgrade_at_1_to_1.peak_period_days_options)
          .to match_array(@expected_data[:product_catalog][:upgrade_one_to_one][:peak_period_days])
    end

  end
end