Dir['features/support/actions/*.rb'].each { |file| require file }

module AllActions
  include LoginActions
  include NavigationActions
  include ProposalActions
  include ShoppingCartActions
  include AgreementActions
  include CDRActions
  include OpportunityActions
  include ProposalLineItemEditActions
end