require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'agreement chevrons' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    @agreements = NjSalesforce::Agreement.agreement_information
  end

  it 'displays Pending chevron when Status Category = In Signatures, Status = Other Party Signatures' do
    agreement = @agreements.select { |x|
      x['Apttus__Status_Category__c'] == 'In Signatures' &&
          x['Apttus__Status__c'] == 'Other Party Signatures' &&
          x['Apttus_Approval__Approval_Status__c'] == 'Not Submitted' }
    if agreement.empty? || agreement.nil?
      skip('no data to test')
    else
      object_id = agreement.sample['Id']
      visit_object(object_id)
      expect(on(AgreementViewPage).pending_chevron_element).to be_visible
    end
  end

  it 'displays Create Contract chevron when Status Category = Request' do
    agreement = @agreements.select { |x| x['Apttus__Status_Category__c'] == 'Request' &&
        x['Apttus_Approval__Approval_Status__c'] == 'Not Submitted' }
    if agreement.empty? || agreement.nil?
      skip('no data to test')
    else
      object_id = agreement.sample['Id']
      visit_object(object_id)
      expect(on(AgreementViewPage).create_contract_chevron_element).to be_visible
    end
  end

  it 'displays Generated chevron when Status Category = In Signatures, Status = Ready for Signatures' do
    agreement = @agreements.select { |x| x['Apttus__Status_Category__c'] == 'In Signatures' &&
        x['Apttus__Status__c'] == 'Ready for Signatures' &&
        x['Apttus_Approval__Approval_Status__c'] == 'None' }
    if agreement.empty? || agreement.nil?
      skip('no data to test')
    else
      object_id = agreement.sample['Id']
      visit_object(object_id)
      expect(on(AgreementViewPage).generated_chevron_element).to be_visible
    end
  end

  it 'displays Legal Review chevron when Approval Status = Approval Required' do
    agreement = @agreements.select { |x| x['Apttus_Approval__Approval_Status__c'] == 'Approval Required' &&
        x['Apttus__Status_Category__c'] == 'In Signatures' }
    if agreement.empty? || agreement.nil?
      skip('no data to test')
    else
      object_id = agreement.sample['Id']
      visit_object(object_id)
      expect(on(AgreementViewPage).legal_review_chevron_element).to be_visible
    end
  end

  it 'displays Legal Review chevron when Approval Status = Pending Approval' do
    agreement = @agreements.select { |x|
      x['Apttus_Approval__Approval_Status__c'] == 'Pending Approval' &&
          x['Apttus__Status_Category__c'] == 'In Signatures' }
    if agreement.empty? || agreement.nil?
      skip('no data to test')
    else
      object_id = agreement.sample['Id']
      visit_object(object_id)
      expect(on(AgreementViewPage).legal_review_chevron_element).to be_visible
    end
  end

  it 'displays Legal Review chevron when Approval Status = Approved' do
    agreement = @agreements.select { |x|
      x['Apttus_Approval__Approval_Status__c'] == 'Approved' &&
          x['Apttus__Status_Category__c'] == 'In Signatures' }
    if agreement.empty? || agreement.nil?
      skip('no data to test')
    else
      object_id = agreement.sample['Id']
      visit_object(object_id)
      expect(on(AgreementViewPage).legal_review_chevron_element).to be_visible
    end
  end

  it 'displays Legal Review chevron when Approval Status = Rejected' do
    agreement = @agreements.select { |x| x['Apttus_Approval__Approval_Status__c'] == 'Rejected' && x['Apttus__Status_Category__c'] == 'In Signatures' }
    if agreement.empty? || agreement.nil?
      skip('no data to test')
    else
      object_id = agreement.sample['Id']
      visit_object(object_id)
      expect(on(AgreementViewPage).legal_review_chevron_element).to be_visible
    end
  end

  it 'displays Cancelled chevron when Status Category = Cancelled, Status = Cancelled Request' do
    agreement = @agreements.select { |x| x['Apttus__Status_Category__c'] == 'Cancelled' && x['Apttus__Status__c'] == 'Cancelled Request' }
    if agreement.empty? || agreement.nil?
      skip('no data to test')
    else
      object_id = agreement.sample['Id']
      visit_object(object_id)
      expect(on(AgreementViewPage).cancelled_chevron_element).to be_visible
    end
  end

  it 'displays Active chevron when Status Category = In Effect, Status = Activated' do
    agreement = @agreements.select { |x| x['Apttus__Status_Category__c'] == 'In Effect' && x['Apttus__Status__c'] == 'Activated' }
    if agreement.empty? || agreement.nil?
      skip('no data to test')
    else
      object_id = agreement.sample['Id']
      visit_object(object_id)
      expect(on(AgreementViewPage).activated_chevron_element).to be_visible
    end
  end

  it 'displays Active chevron when Funding State = Funded Contract' do
    agreement = @agreements.select { |x| x['Funding_State__c'] == 'Funded Contract' }
    if agreement.empty? || agreement.nil?
      skip('no data to test')
    else
      object_id = agreement.sample['Id']
      visit_object(object_id)
      expect(on(AgreementViewPage).activated_chevron_element).to be_visible
    end
  end

end