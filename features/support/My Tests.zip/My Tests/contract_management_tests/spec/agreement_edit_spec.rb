require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'agreement edit page' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    agreement = NjSalesforce::Agreement.agreement_information
                    .select { |x| x['Apttus__Status_Category__c'] == 'Request' }
                    .sample['Id']
    visit_object(agreement)
    on(AgreementViewPage).edit_agreement
  end

  context 'Actions' do
    it 'has a Status Category' do
      on(AgreementEditPage) do |p|
        expect(p.status_category_element).to be_visible
        expect(p.status_category_options).to eq(p.expected_values[:status_category])
      end
    end
    it 'has a Status' do
      on(AgreementEditPage) do |p|
        expect(on(AgreementEditPage).status_element).to be_visible
        #this test will needs to be written, the list is dynamic based on status category
      end
    end
    it 'has a Signing State' do
      on(AgreementEditPage) do |p|
        expect(p.signing_state_element).to be_visible
        expect(p.signing_state_options).to eq(p.expected_values[:signing_state])
      end
    end
    it 'has a Approval Status' do
      on(AgreementEditPage) do |p|
        expect(p.approval_status_element).to be_visible
        expect(p.approval_status_options).to eq(p.expected_values[:approval_status])
      end
    end
  end


  context 'Product Information' do
    it 'has a Card Type' do
      expect(on(AgreementEditPage).card_type_element).to be_visible
    end
    it 'has Occupied Flight Hours' do
      expect(on(AgreementEditPage).occupied_flight_hours_element).to be_visible
    end
    it 'has an Aircraft Type 1' do
      expect(on(AgreementEditPage).aircraft_type_1_element).to be_visible
    end
    it 'has an Aircraft Type 2' do
      expect(on(AgreementEditPage).aircraft_type_2_element).to be_visible
    end
    it 'has a Product Sub-Type' do
      expect(on(AgreementEditPage).product_sub_type_element).to be_visible
    end
    it 'has a Peak Period Day Premium' do
      expect(on(AgreementEditPage).ppd_premium_element).to be_visible
    end
  end

  context 'Term' do
    it 'has Delayed Start Amount and UOM' do
      on(AgreementEditPage) do |p|
        expect(p.delayed_start_amount_element).to be_visible
        expect(p.delayed_start_amount_options).to eq(p.expected_values[:delayed_start_amount])
        #expect(on(AgreementEditPage).delayed_start_amount_uom_element).to be_visible
      end
    end
    it 'has Initial Term Amount and UOM' do
      on(AgreementEditPage) do |p|
        expect(p.initial_term_amount_element).to be_visible
        expect(p.initial_term_amount_options).to eq(p.expected_values[:initial_term_amount])
        #expect(on(AgreementEditPage).initial_term_amount_uom_element).to be_visible
      end
    end
    it 'has Grace Period Amount and UOM' do
      on(AgreementEditPage) do |p|
        expect(p.grace_period_amount_element).to be_visible
        expect(p.grace_period_amount_options).to eq(p.expected_values[:grace_period_amount])
        #expect(on(AgreementEditPage).grace_period_amount_uom_element).to be_visible
      end
    end
    it 'has Extended Term Amount and UOM' do
      on(AgreementEditPage) do |p|
        expect(p.extended_term_amount_element).to be_visible
      end
    end

    it 'has Funding Date' do
      expect(on(AgreementEditPage).funding_date_element).to be_visible
    end
    it 'has First Flight Date' do
      expect(on(AgreementEditPage).first_flight_date_element).to be_visible
    end
    it 'has Effective / Delayed Start Date' do
      expect(on(AgreementEditPage).delayed_start_date_element).to be_visible
    end
    it 'has Initial Term Expiration Date' do
      expect(on(AgreementEditPage).initial_term_expiration_date_element).to be_visible
    end
    it 'has Grace Period End Date' do
      expect(on(AgreementEditPage).grace_period_end_date_element).to be_visible
    end
    it 'has Termination Date' do
      expect(on(AgreementEditPage).termination_date_element).to be_visible
    end
  end

  context 'Entity Information' do
    it 'has an Card Number' do
      expect(on(AgreementEditPage).card_number_element).to be_visible
    end
    it 'has an Agreement Name' do
      expect(on(AgreementEditPage).agreement_name_element).to be_visible
    end
    it 'has an account' do
      expect(on(AgreementEditPage).account_element).to be_visible
    end
    it 'has an Legal Entity' do
      expect(on(AgreementEditPage).legal_entity_element).to be_visible
    end
    it 'has an Signatory' do
      expect(on(AgreementEditPage).signatory_element).to be_visible
    end
    it 'has an Related Quote/Proposal' do
      expect(on(AgreementEditPage).related_quote_proposal_element).to be_visible
    end
    it 'has an Related Opportunity' do
      expect(on(AgreementEditPage).related_oportunity_element).to be_visible
    end
    it 'has an Requestor' do
      expect(on(AgreementEditPage).requestor_element).to be_visible
    end
    it 'has an Delivery Email 1' do
      expect(on(AgreementEditPage).delivery_email_1_element).to be_visible
    end
    it 'has an Delivery Email 2' do
      expect(on(AgreementEditPage).delivery_email_2_element).to be_visible
    end
    it 'has an Delivery CC Email 1' do
      expect(on(AgreementEditPage).delivery_cc_email_1_element).to be_visible
    end
    it 'has an Delivery CC Email 2' do
      expect(on(AgreementEditPage).delivery_cc_email_2_element).to be_visible
    end
  end

  context 'Payment Information' do
    it 'has Credit' do
      expect(on(AgreementEditPage).credit_element).to be_visible
    end
    it 'has Waive FET' do
      expect(on(AgreementEditPage).credit_element).to be_visible
    end
    it 'has Prepaid Fuel Type' do
      expect(on(AgreementEditPage).prepaid_fuel_type_element).to be_visible
    end
    it 'has Prepaid incidentals' do
      expect(on(AgreementEditPage).prepaid_incidentals_element).to be_visible
    end
    it 'has Operating Expense Fund' do
      expect(on(AgreementEditPage).operating_expense_fund_element).to be_visible
    end
    it 'has Funding State' do
      expect(on(AgreementEditPage).funding_state_element).to be_visible
    end
    it 'has Payment Terms' do
      expect(on(AgreementEditPage).payment_terms_element).to be_visible
    end
    it 'has Payment Terms UOM' do
      expect(on(AgreementEditPage).payment_terms_uom_element).to be_visible
    end
    it 'has AR Number' do
      expect(on(AgreementEditPage).ar_number_element).to be_visible
    end
  end

  context 'Operational Information' do
    it 'has Fuel Variable Rate 1 and 2' do
      expect(on(AgreementEditPage).fuel_variable_rate_1_element).to be_visible
      expect(on(AgreementEditPage).fuel_variable_rate_2_element).to be_visible
    end
    it 'has PPD Departure Adjustment Amount' do
      on(AgreementEditPage) do |p|
        expect(p.ppd_departure_adjustment_amount_element).to be_visible
        expect(p.ppd_departure_adjustment_amount_options).to eq(p.expected_values[:ppd_departure_adjustment_amount])
        #expect(on(AgreementEditPage).delayed_start_amount_uom_element).to be_visible
      end
    end
    it 'has Customer is Late Amount' do
      on(AgreementEditPage) do |p|
        expect(p.customer_is_late_amount_element).to be_visible
        expect(p.customer_is_late_amount_options).to eq(p.expected_values[:customer_is_late_amount])
        #expect(on(AgreementEditPage).initial_term_amount_uom_element).to be_visible
      end
    end
    it 'has NetJets is Late Amount' do
      on(AgreementEditPage) do |p|
        expect(p.netjets_is_late_amount_element).to be_visible
        expect(p.netjets_is_late_amount_options).to eq(p.expected_values[:netjets_is_late_amount])
        #expect(on(AgreementEditPage).grace_period_amount_uom_element).to be_visible
      end
    end
    it 'has Can Sub-Contract' do
      expect(on(AgreementEditPage).can_sub_contract_element).to be_visible
    end
    it 'has Liability for Flight Delay Max Amount' do
      expect(on(AgreementEditPage).liability_for_flight_delay_max_amount_element).to be_visible
    end
    it 'has Liability for Flight Delay Credit Type' do
      expect(on(AgreementEditPage).liability_for_flight_delay_credit_type_element).to be_visible
    end
  end

end