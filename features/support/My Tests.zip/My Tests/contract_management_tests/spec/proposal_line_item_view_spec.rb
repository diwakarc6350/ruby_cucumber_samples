require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'proposal line item view page' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    proposal_line_item = NjSalesforce::ProposalLineItem.all
                              .select { |x| x['Aircraft_1__c'] !=nil && x['Aircraft_2__c'] !=nil }.first
    visit_object(proposal_line_item['Id'])
  end

  context 'Information Section' do
    describe 'Left' do
      it 'has Quote/Proposal' do
        expect(on(ProposalLineItemPage).quote_proposal_element).to be_visible
      end
      it 'has Product Line' do
        expect(on(ProposalLineItemPage).product_line_element).to be_visible
      end
      it 'has Card Type' do
        expect(on(ProposalLineItemPage).card_type_element).to be_visible
      end
      it 'has Product' do
        expect(on(ProposalLineItemPage).product_element).to be_visible
      end
      it 'has Product Name' do
        expect(on(ProposalLineItemPage).product_name_element).to be_visible
      end
      it 'has CDR' do
        expect(on(ProposalLineItemPage).cdr_element).to be_visible
      end
      it 'has Waive Premium' do
        expect(on(ProposalLineItemPage).waive_premium_element).to be_visible
      end
      it 'has Peak Period Day Premium Amount' do
        pending('removed?')
        expect(on(ProposalLineItemPage).peak_period_day_premium_amount_element).to be_visible
      end
      it 'has Specialty Cards' do
        expect(on(ProposalLineItemPage).specialty_cards_element).to be_visible
        end
      it 'has Escalation Method Cards' do
        expect(on(ProposalLineItemPage).escalation_method_element).to be_visible
      end
    end
    describe 'Right' do
      it 'has Product Hours' do
        expect(on(ProposalLineItemPage).product_hours_element).to be_visible
      end
      it 'has Aircraft 1' do
        expect(on(ProposalLineItemPage).aircraft_1_element).to be_visible
      end
      it 'has Aircraft 2' do
        expect(on(ProposalLineItemPage).aircraft_2_element).to be_visible
      end
      it 'has Bonus Hours' do
        expect(on(ProposalLineItemPage).bonus_hours_element).to be_visible
      end
      it 'has Upgrade Hours' do
        expect(on(ProposalLineItemPage).upgrade_hours_element).to be_visible
      end
      it 'has Upgrade from Aircraft' do
        expect(on(ProposalLineItemPage).upgrade_from_aircraft_element).to be_visible
      end
    end
  end

  context 'Term Section' do
    describe 'Left' do
      it 'has Delayed Start Amount' do
        expect(on(ProposalLineItemPage).delayed_start_amount_element).to be_visible
      end
      it 'has Delayed Start Amount UOM' do
        expect(on(ProposalLineItemPage).delayed_start_amount_uom_element).to be_visible
      end
      it 'has Initial Term Amount' do
        expect(on(ProposalLineItemPage).initial_term_amount_element).to be_visible
      end
      it 'has Initial Term Unit of Measure (UOM)' do
        expect(on(ProposalLineItemPage).initial_term_amount_uom_element).to be_visible
      end
      it 'has Grace Period Amount' do
        expect(on(ProposalLineItemPage).grace_period_amount_element).to be_visible
      end
      it 'has Grace Period Unit of Measure (UOM)' do
        expect(on(ProposalLineItemPage).grace_period_amount_uom_element).to be_visible
      end
    end
    describe 'Right' do
      it 'has 3 Month Average Fuel Cost' do
        expect(on(ProposalLineItemPage).three_month_avg_fuel_cost_element).to be_visible
      end
      it 'has Fuel Annual' do
        expect(on(ProposalLineItemPage).fuel_annual_element).to be_visible
      end
      it 'has Aircraft 1 Hours' do
        expect(on(ProposalLineItemPage).aircraft_1_hours_element).to be_visible
      end
      it 'has Aircraft 2 Hours' do
        expect(on(ProposalLineItemPage).aircraft_2_hours_element).to be_visible
      end
      it 'has Occupied Flight Hours' do
        expect(on(ProposalLineItemPage).occupied_flight_hours_element).to be_visible
      end
    end
  end

  context 'Payment Information Section' do
    describe 'Left' do
      it 'has Pre-Tax Purchase Price' do
        expect(on(ProposalLineItemPage).pre_tax_purchase_price_element).to be_visible
      end
      it 'has Adjustment Total' do
        expect(on(ProposalLineItemPage).adjustment_total_element).to be_visible
      end
      it 'has Net Adjustment (%)' do
        expect(on(ProposalLineItemPage).net_adjustment_percent_element).to be_visible
      end
      it 'has Waived Premium Discount' do
        expect(on(ProposalLineItemPage).waived_premium_discount_element).to be_visible
      end
      it 'has Tax Amount' do
        expect(on(ProposalLineItemPage).tax_amount_element).to be_visible
      end
      it 'has Total Price' do
        expect(on(ProposalLineItemPage).total_price_element).to be_visible
      end
      it 'has Prepaid Fuel Type' do
        expect(on(ProposalLineItemPage).prepaid_fuel_type_element).to be_visible
      end
      it 'has Prepaid Fuel Amount' do
        expect(on(ProposalLineItemPage).prepaid_fuel_amount_element).to be_visible
      end
      it 'has Prepaid Incidentals' do
        expect(on(ProposalLineItemPage).prepaid_incidentals_element).to be_visible
      end
      it 'has Operating Expense Fund' do
        expect(on(ProposalLineItemPage).operating_expense_fund_element).to be_visible
      end
      it 'has Total Agreement Value' do
        expect(on(ProposalLineItemPage).total_agreement_value_element).to be_visible
      end
    end
    describe 'Right' do
      it 'has Program' do
        expect(on(ProposalLineItemPage).program_element).to be_visible
      end
      it 'has Accounting Company' do
        expect(on(ProposalLineItemPage).accounting_company_element).to be_visible
      end
      it 'has Preferred Bank' do
        expect(on(ProposalLineItemPage).preferred_bank_element).to be_visible
      end
      it 'has Payment Terms' do
        expect(on(ProposalLineItemPage).payment_terms_element).to be_visible
      end
      it 'has Payment Terms UOM' do
        expect(on(ProposalLineItemPage).payment_terms_uom_element).to be_visible
      end
    end
  end

  context 'Liability for NetJets Flight Delay Section' do
    it 'has Max Amount' do
      expect(on(ProposalLineItemPage).liability_for_delay_max_amount_element).to be_visible
    end

    it 'has Credit Type' do
      expect(on(ProposalLineItemPage).liability_for_delay_credit_type_element).to be_visible
    end
  end

end