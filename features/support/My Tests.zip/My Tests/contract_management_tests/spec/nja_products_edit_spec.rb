require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'product page edit' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    nja_products = NjSalesforce::Product.product_information
                       .select { |x| x['Program__c']=='NetJets U.S.' && x['Name']== @data[:products][:nja][:standard] }
    nja_product = nja_products[rand(nja_products.length)]['Id']
    visit_object(nja_product)
    on(ProductPage).edit_product
  end

  it 'has the operating expense fund' do
    expect(on(ProductPage).operating_expense_fund?).to be(true)
  end

  it 'has the excess flying hourly tax (fet)' do
    expect(on(ProductPage).excess_flying_hourly_tax?).to be(true)
  end

  it 'has the ground handling fee' do
    expect(on(ProductPage).ground_handling_fee?).to be(true)
  end

  it 'has the nja flight rules for nja product' do
    index = on(ProductPage).flight_rules_options.index('--None--')
    actual_flight_rules = on(ProductPage).flight_rules_options
    actual_flight_rules.delete_at(index)
    expect(actual_flight_rules).to eq(on(ProductPage).expected_values[:nja_flight_rules])
  end

  it 'has the excess flying prepay' do
    expect(on(ProductPage).excess_flying_prepay_options).to eq(on(ProductPage).expected_values[:excess_flying_prepay])
  end

  it 'has the nja accounting companies for nja products' do
    index = on(ProductPage).nja_accounting_company_options.index('--None--')
    actual_companies = on(ProductPage).nja_accounting_company_options
    actual_companies.delete_at(index)
    expect(actual_companies).to eq(on(ProductPage).expected_values[:nja_accounting_companies])
  end

  it 'has the upgrade from aircraft' do
    expect(on(ProductPage).upgrade_from_aircraft?).to be(true)
    expect(on(ProductPage).upgrade_from_aircraft_options).to include('No Restrictions')
  end

  it 'has the aircraft per day' do
    expect(on(ProductPage).aircraft_per_day_options).to eq(on(ProductPage).expected_values[:aircraft_per_day])
    expect(on(ProductPage).aircraft_per_day).to eq(on(ProductPage).expected_default_value[:aircraft_per_day])
  end

  it 'has the fuel tax % (fet)' do
    expect(on(ProductPage).fuel_tax_percent_fet?).to be(true)
  end

  it 'has the peak period day premium percent amount' do
    expect(on(ProductPage).ppd_premium_percent_amount?).to be(true)
  end

  it 'has the peak period day premium effective date' do
    expect(on(ProductPage).ppd_premium_effective_date?).to be(true)
    expect(on(ProductPage).ppd_premium_effective_date_options).to eq(on(ProductPage).expected_values[:ppd_premium_effective_date])
  end

  it 'has delayed start amount and uom with correct default values' do
    on(ProductPage) do |p|
      expect(p.delayed_start_amount_options).to eq(p.expected_values[:delayed_start_amount])
      #expect(p.delayed_start_amount).to eq(p.expected_default_value[:delayed_start_amount])
      expect(p.delayed_start_uom_options).to eq(p.expected_values[:delayed_start_uom])
      expect(p.delayed_start_uom).to eq(p.expected_default_value[:delayed_start_uom])
    end
  end

  it 'has peak period day departure adjustment and uom with correct default values' do
    on(ProductPage) do |p|
      expect(p.peak_period_departure_adj_options).to eq(p.expected_values[:peak_period_departure_adj])
      #expect(p.peak_period_departure_adj).to eq(p.expected_default_value[:peak_period_departure_adj])
      expect(p.peak_period_departure_adj_uom_options).to eq(p.expected_values[:peak_period_departure_adj_uom])
      expect(p.peak_period_departure_adj_uom).to eq(p.expected_default_value[:peak_period_departure_adj_uom])
    end
  end

  it 'has customer is late amount and uom with correct default values' do
    on(ProductPage) do |p|
      expect(p.customer_is_late_amount_options).to eq(p.expected_values[:customer_is_late])
      expect(p.customer_is_late_amount).to eq(p.expected_default_value[:customer_is_late])
      expect(p.customer_is_late_uom_options).to eq(p.expected_values[:customer_is_late_uom])
      expect(p.customer_is_late_uom).to eq(p.expected_default_value[:customer_is_late_uom])
    end
  end

  it 'has netjets is late amount and uom with correct default values' do
    on(ProductPage) do |p|
      expect(p.netjets_is_late_amount_options).to eq(p.expected_values[:netjets_is_late])
      #expect(p.netjets_is_late_amount).to eq(p.expected_default_value[:netjets_is_late])
      expect(p.netjets_is_late_uom_options).to eq(p.expected_values[:netjets_is_late_uom])
      expect(p.netjets_is_late_uom).to eq(p.expected_default_value[:netjets_is_late_uom])
    end
  end

  it 'has same day usage waiver amount and uom with correct default values' do
    on(ProductPage) do |p|
      expect(p.same_day_usage_waiver_ac_1_options).to eq(p.expected_values[:same_day_usage_waiver_amount])
      #refactor this!
      #expect(p.same_day_usage_waiver_ac_1).to eq(p.expected_default_value[:same_day_usage_waiver_amount])
      expect(p.same_day_usage_waiver_uom_ac_1_options).to eq(p.expected_values[:same_day_usage_waiver_uom])
      expect(p.same_day_usage_waiver_uom_ac_1).to eq(p.expected_default_value[:same_day_usage_waiver_uom])

      expect(p.same_day_usage_waiver_ac_2?).to be(true)
      expect(p.same_day_usage_waiver_uom_ac_2?).to be(true)
    end
  end

  it 'has minimum flight segment rules amount and uom with correct default values' do
    pending('open defect')
    on(ProductPage) do |p|
      expect(p.min_flight_segment_rules_amount_ac1_options).to eq(p.expected_values[:min_flight_segment_rules_amount])
      expect(p.min_flight_segment_rules_uom_ac1_options).to eq(p.expected_values[:min_flight_segment_rules_uom])
      expect(p.min_flight_segment_rules_amount_ac2_options).to eq(p.expected_values[:min_flight_segment_rules_amount])
      expect(p.min_flight_segment_rules_uom_ac2_options).to eq(p.expected_values[:min_flight_segment_rules_uom])
    end
  end

  it 'has esclation method' do
    on(ProductPage) do |p|
      expect(p.escalation_method_options).to eq(p.expected_values[:escalation_method])
    end
  end

  it 'populates the aircraft picklists with the active aircrafts' do
    on(ProductPage) do |p|
      active_aircrafts = NjSalesforce::AircraftList.all.select { |x| x['Active__c'] == TRUE }
      active_aircraft_names = []
      active_aircrafts.each { |aircraft| active_aircraft_names << aircraft['Name'] }
      expect(p.primary_aircraft_picklist_options).to match_array(active_aircraft_names)
      secondary_active_aircraft_names= ['--None--'] + active_aircraft_names
      expect(p.secondary_aircraft_picklist_options).to match_array(secondary_active_aircraft_names)
    end
  end

  it 'has liability for flight delay information' do
    on(ProductPage) do |page|
      expect(page.liability_for_delay_max_amount?).to be(true)
      expect(page.liability_for_delay_credit_type?).to be(true)
    end
  end

end