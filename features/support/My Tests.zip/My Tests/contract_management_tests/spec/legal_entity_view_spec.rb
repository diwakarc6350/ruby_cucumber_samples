require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'legal entity page' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    legal_entity = TestDataFactory.clean(NjSalesforce::LegalEntity.where({Name: @data[:legal_entity][:legal_entity_name]}))
    visit_object(legal_entity.first['Id'])
  end

  describe 'Legal Entity Detail' do
    describe 'Left Column' do
      it 'has Legal Entity Name' do
        expect(on(LegalEntityViewPage).legal_entity_name_element).to be_visible
      end
      it 'has Legal Entity Type' do
        expect(on(LegalEntityViewPage).legal_entity_type_element).to be_visible
      end

    end
    describe 'Right Column' do
      it 'has Legal Phone Number' do
        expect(on(LegalEntityViewPage).legal_phone_number_element).to be_visible
      end
      it 'has Legal Email Address' do
        expect(on(LegalEntityViewPage).legal_email_address_element).to be_visible
      end
    end
  end

  it 'has asset line items' do
    patiently { expect(on(LegalEntityViewPage).asset_line_items).not_to be_empty }
    if on(LegalEntityViewPage).asset_line_items != 'No records to display'
      on(LegalEntityViewPage) do |p|
        actual_asset_line_items_columns = patiently { p.asset_line_items_element.to_h[0].keys }
        expect(actual_asset_line_items_columns)
            .to eq(@page_static_data[:legal_entity][:asset_line_items])
      end
    end
  end

  it 'has Account Legal Entities' do
    patiently { expect(on(LegalEntityViewPage).account_legal_entities).not_to be_empty }
    expect(on(LegalEntityViewPage).new_account_legal_entity_element).to be_visible
  end

end