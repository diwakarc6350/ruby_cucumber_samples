require 'spec_helper'
require 'page-object'
require 'all_actions'
require 'test_data_factory'

describe 'opportunity page' do
  include AllActions

  before(:all) do
    auth = login_info(:salesforce_administrator)
    login_to_salesforce(auth[:username], auth[:password])
    opportunity = TestDataFactory.open_apttus_opportunity
    visit_object(opportunity)
  end

  it 'has an Owner Is' do
    on(OpportunityViewPage) do |p|
      expect(p.owner_is_element).to be_visible
    end
  end
end