require 'spec_helper'
require 'page-object'
require 'all_actions'

describe 'aircraft product image' do
  include AllActions

  before(:all) { auth = login_info(:salesforce_administrator)
  login_to_salesforce(auth[:username], auth[:password]) }

  before(:each, :new => true) { visit_uri(NjSalesforce::AircraftImage.new) }
  before(:each, :view => true) { visit_object(NjSalesforce::AircraftImage.first['Id']) }
  before(:each, :edit => true) { visit_uri(NjSalesforce::AircraftImage.edit(NjSalesforce::AircraftImage.first['Id'])) }

  context 'for new aircraft image' do
    it 'has aircraft type, product image name and product image', :new do
      on(AircraftImageEditPage) do |p|
        expect(p.aircraft_type_element).to be_visible
        expect(p.product_image_name_element).to be_visible
        expect(p.netjets_logo_element).to be_visible
        expect(p.search_aircraft_element).to be_visible
      end
    end
  end

  context 'when editing an existing aircraft image' do
    it 'has aircraft type, product image name, logo, search aircraft', :edit do
      on(AircraftImageEditPage) do |p|
        expect(p.aircraft_type_element).to be_visible
        expect(p.product_image_name_element).to be_visible
        expect(p.netjets_logo_element).to be_visible
        expect(p.search_aircraft_element).to be_visible
      end
    end
  end

  context 'when viewing an existing aircraft image' do
    it 'has aircraft type, product image name, logo, upload and image', :view do
      on(AircraftImageViewPage) do |p|
        expect(p.aircraft_type_element).to be_visible
        expect(p.product_image_name_element).to be_visible
        expect(p.netjets_logo_element).to be_visible
        expect(p.upload_element).to be_visible
      end
    end
  end
end