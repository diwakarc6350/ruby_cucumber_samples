module SyncTolerance
  RETRY_ERRORS = %w[
    Spec::Expectations::ExpectationNotMetError
    RSpec::Expectations::ExpectationNotMetError
    Selenium::WebDriver::Error::StaleElementReferenceError
    Selenium::WebDriver::Error::NoAlertPresentError
    Selenium::WebDriver::Error::ElementNotVisibleError
    Selenium::WebDriver::Error::NoSuchFrameError
    Selenium::WebDriver::Error::NoAlertPresentError
    Watir::Exception::UnknownObjectException
    Watir::Exception::UnknownFrameException
    Selenium::WebDriver::Error::InvalidSelectorError
  ]

  def patiently(seconds=30)
    start_time = Time.now
    begin
      yield
    rescue Exception => e
      raise e unless RETRY_ERRORS.include?(e.class.name)
      raise e if (Time.now - start_time) >= seconds
      sleep(0.05)
      retry
    end
  end
end

World(SyncTolerance) if File.basename($PROGRAM_NAME) == 'cucumber'