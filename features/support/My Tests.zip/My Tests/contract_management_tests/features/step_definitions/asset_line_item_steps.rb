Given(/^an agreement is activated$/) do
  login_to_salesforce
  @new_proposal = create_default_proposal(Apttus_Proposal__Proposal_Name__c: 'My Test Standard Proposal')
  visit_object(@new_proposal)
  configure_products
  open_card_catalog
  add_product_to_cart(DataMagic.yml[:products][:nja][:combo])
  back_to_proposal
  change_proposal_to_CDR(on(ProposalViewPage).data_for :proposal_to_cdr_required_fields)
  mark_all_postal_address_as_primary
  send_for_approval
  @agreement = TestDataFactory.clean(NjSalesforce::Agreement.where({Apttus_QPComply__RelatedProposalId__c: @new_proposal})).first['Id']
  visit_object(@agreement)
  payment = (total_agreement_value - total_payment_amount)
  fund_agreement(payment)
  visit_object(@agreement)
  change_agreement_status_to_funded
  @asset = TestDataFactory.clean(NjSalesforce::AssetLineItem.where({Agreement__c: @agreement}))
end

Then(/^the asset line item are automatically created$/) do
  expect(@asset.length).to eq(1)
  expect(@asset.first['Product_Line__c']).to eq('Card')
  expect(@asset.first['Aircraft_1__c']).to eq('Citation Encore')
  expect(@asset.first['Aircraft_2__c']).to eq('Citation Excel')
end

And(/^the asset line items are associated with the legal entity$/) do
  @asset = TestDataFactory.clean(NjSalesforce::AssetLineItem.where({Agreement__c: @agreement, Legal_Entity__c: @asset.first['Legal_Entity__c']}))
  expect(@asset.length).to eq(1)
end

And(/^the asset line items are associated with the account$/) do
  @asset = TestDataFactory.clean(NjSalesforce::AssetLineItem.where({Agreement__c: @agreement, Account__c: @asset.first['Account__c']}))
  expect(@asset.length).to eq(1)
end