Given(/^there is a nja proposal for (.*)$/) do |product_type|
  auth = login_info(:sales_user)
  login_to_salesforce(auth[:username], auth[:password])
  visit_object(TestDataFactory.opportunity.first['Id'])
  create_proposal
  open_card_catalog
  add_product_to_cart(@data[:products][:nja][product_type.underscore.to_sym])
  back_to_proposal
  @scenario_context.proposal_id = WatirHelper.get_id(@browser.url)
  change_proposal_to_CDR(on(ProposalPage).data_for :proposal_to_cdr_required_fields)
  mark_all_postal_address_as_primary
end

When(/^the nja proposal is updated with (.*)$/) do |nja_proposal_changes|
  make_proposal_changes(nja_proposal_changes)
  send_for_approval
  approve_all_requests
end

And(/^the nja agreement is updated with (.*)$/) do |nja_agreement_changes|
  #@scenario_context.agreement=TestDataFactory.related_agreements('a2xM0000000FhEe').first
  @scenario_context.agreement=TestDataFactory.related_agreements(@scenario_context.proposal_id).first
  auth = login_info(:contract_administrator)
  login_to_salesforce(auth[:username], auth[:password])
  visit_object(@scenario_context.agreement['Id'])
  make_agreement_changes(nja_agreement_changes)
  generate_agreement
  @scenario_context.agreement_file = TestDataFactory.save_generated_agreement(@scenario_context.agreement['Id'])
end

Then(/^the nja agreement document is generated$/) do
  expect(File.exist?(@scenario_context.agreement_file)).to be true
end

And(/^nja schedule one has the right information from the agreement$/) do
  pending
end

And(/^nja closing statement has the right information from the agreement$/) do
  pending
end