Given(/^there is a proposal with combo card product$/) do
  login_to_salesforce
  proposal_line_item = NjSalesforce::ProposalLineItem.all
                           .select { |x| (x['P1_Calculated_Product_Name__c']!=nil) &&
      (x['P1_Calculated_Product_Name__c'].include? 'Combo') }.first
  visit_object(proposal_line_item['Id'])
end

Then(/^sum of aircraft one hours plus sum of aircraft two hours should equal occupied flight hours$/) do
  on(ProposalLineItemPage) do |p|
    expect(p.occupied_flight_hours.to_f).to eq(p.aircraft_1_hours.to_f + p.aircraft_2_hours.to_f)
  end
end

When(/^I enter hour in aircraft one hours and aircraft two hours that does not equal to occupied flight hours$/) do
  on(ProposalLineItemPage).edit_proposal_line_item
  on(ProposalLineItemEditPage).aircraft_1_hours = rand(10..50)
  on(ProposalLineItemEditPage).aircraft_2_hours = rand(10..50)
  on(ProposalLineItemEditPage).occupied_flight_hours = rand(101..200)
  save_proposal_line_item(raise_error=true)
end

Then(/^"([^"]*)" is displayed$/) do |error_message|
  on(ProposalLineItemEditPage) do |p|
    expect(p.text).to include(error_message)
  end
end

When(/^I enter hour in aircraft one hours and aircraft two hours that equals to occupied flight hours$/) do
  @pretax_purchase_price_original = proposal_line_pre_tax_purchase_price
  @occupied_flight_hours_original = on(ProposalLineItemPage).occupied_flight_hours.to_f
  @aircraft_hours_1 = rand(10..25)
  @aircraft_hours_2 = rand(10..25)
  @total_hours = @aircraft_hours_1 + @aircraft_hours_2
  on(ProposalLineItemPage).edit_proposal_line_item
  on(ProposalLineItemEditPage).aircraft_1_hours = @aircraft_hours_1
  on(ProposalLineItemEditPage).aircraft_2_hours = @aircraft_hours_2
  on(ProposalLineItemEditPage).occupied_flight_hours = @total_hours
  save_proposal_line_item
end

Then(/^the pre\-tax purchase price gets recalculated$/) do
  expected_pretax_purchase_price = (@pretax_purchase_price_original/@occupied_flight_hours_original) * @total_hours
  expect(proposal_line_pre_tax_purchase_price).to eq(expected_pretax_purchase_price)
end

Given(/^there is a (.*) proposal$/) do |card_type|
  login_to_salesforce
  proposal_line_item =
      NjSalesforce::ProposalLineItem.all
          .select { |x| (x['P1_Calculated_Product_Name__c']!=nil) &&
          (x['P1_Calculated_Product_Name__c'].include? card_type) }.first
  if proposal_line_item.nil?
    pending("no data to test")
  end
  visit_object(proposal_line_item['Id'])
end

When(/^I enter hour in aircraft one hours and aircraft two hours that does not equal to twenty\-five or fifty hours$/) do
  on(ProposalLineItemPage).edit_proposal_line_item
  on(ProposalLineItemEditPage).aircraft_1_hours = rand(10..50)
  on(ProposalLineItemEditPage).aircraft_2_hours = rand(10..50)
  on(ProposalLineItemEditPage).occupied_flight_hours = rand(101..200)
  save_proposal_line_item(raise_error=true)
end


Given(/^there is a proposal with standard product$/) do
  login_to_salesforce
  proposal_line_item = NjSalesforce::ProposalLineItem.all.select { |x| x['Aircraft_1__c'] !=nil && x['Aircraft_2__c'] ==nil && x['Card_Type__c']=='Standard' }.first
  if proposal_line_item.nil?
    pending("no data to test")
  end
  visit_object(proposal_line_item['Id'])
end

When(/^I enter hours for the second aircraft$/) do
  on(ProposalLineItemPage).edit_proposal_line_item
  on(ProposalLineItemEditPage).aircraft_2_hours = rand(10..50)
  save_proposal_line_item(raise_error=true)
end

Given(/^there is a proposal with product initial term as twelve$/) do
  login_to_salesforce
  #we are choosing Citation X becuse the default product initial term is 24
  proposal_line_item = NjSalesforce::ProposalLineItem.where({Initial_Term_Amount__c: 12, Aircraft_1__c: "Citation Encore"}).first
  visit_object(proposal_line_item['Id'])
end

Then(/^the delayed start amount and grace period amount will be set to zero$/) do
  patiently {
    expect(on(ProposalLineItemPage).delayed_start_amount.to_i).to eq(0)
    expect(on(ProposalLineItemPage).grace_period_amount.to_i).to eq(0)
  }
end

When(/^I change the initial term amount to thirty\-six$/) do
  on(ProposalLineItemPage).edit_proposal_line_item
  on(ProposalLineItemEditPage).initial_term_amount = 36
  save_proposal_line_item
end


When(/^I change the occupied flight hours to be less than 25$/) do
  on(ProposalLineItemPage).edit_proposal_line_item
  patiently { on(ProposalLineItemEditPage).occupied_flight_hours = rand(0..24) }
  save_proposal_line_item(raise_error=true)
end