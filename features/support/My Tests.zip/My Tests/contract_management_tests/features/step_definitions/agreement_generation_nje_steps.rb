Given(/^there is a nje proposal for (.*)$/) do |product_type|
  auth = login_info(:nje_sales_user)
  login_to_salesforce(auth[:username], auth[:password])
  visit_object(TestDataFactory.opportunity.first['Id'])
  create_proposal
  open_card_catalog
  add_product_to_cart(@data[:products][:nje][product_type.underscore.to_sym])
  back_to_proposal
  @scenario_context.proposal_id = WatirHelper.get_id(@browser.url)
  change_proposal_to_CDR(on(ProposalViewPage).data_for :proposal_to_cdr_required_fields)
  world_check
  mark_all_postal_address_as_primary
end

When(/^the nje proposal is updated with (.*)$/) do |proposal_changes|
  make_proposal_changes(proposal_changes)
  send_for_approval
  approve_all_requests
end

And(/^the nje agreement is updated with (.*)$/) do |agreement_changes|
  #@scenario_context.agreement=TestDataFactory.related_agreements('a2xM0000000FhEe').first
  @scenario_context.agreement=TestDataFactory.related_agreements(@scenario_context.proposal_id).first
  auth = login_info(:contract_administrator)
  login_to_salesforce(auth[:username], auth[:password])
  visit_object(@scenario_context.agreement['Id'])
  make_agreement_changes(agreement_changes)
  generate_agreement
  @scenario_context.agreement_file = TestDataFactory.save_generated_agreement(@scenario_context.agreement['Id'])
end

Then(/^the nje agreement document is generated$/) do
  expect(File.exist?(@scenario_context.agreement_file)).to be true
end

And(/^nje schedule one has the right information from the agreement$/) do
  actual_s1 = DocParser.new(@scenario_context.agreement_file, 'nje').schedule_one
  expect(@scenario_context.agreement['Aircraft_1__c']).to include(actual_s1[:aircraft_types])
  expect(@scenario_context.agreement['Occupied_Flight_Hours__c'] + ' Standard Hours').to include(actual_s1[:occupied_flight_hours])
  expect(@scenario_context.agreement['Total_Agreement_Value__c']).to eq(actual_s1[:purchase_prices].tr('EU,', '').to_f)
  if !@scenario_context.agreement['Fuel_Rate_1__c'].nil?
    expect(@scenario_context.agreement['Fuel_Rate_1__c']).to eq(actual_s1[:fuel_variable_rates].to_f)
  end
end

And(/^nje closing statement has the right information from the agreement$/) do
  actual_cs = DocParser.new(@scenario_context.agreement_file, 'nje').closing_statement
  expect(actual_cs).to include('Purchase Price -- ' + @scenario_context.agreement['Aircraft_1__c'])
  expected_purchase_price = ActiveSupport::NumberHelper.number_to_currency(
      @scenario_context.agreement['Extended_Price_Before_Tax__c'], precison: 2, :unit => "EU",)
  expect(actual_cs).to include(expected_purchase_price)
  vat = 'EU0.00'
  expect(actual_cs).to include(vat)
end

And(/^nje exhibit\-a has the right information$/) do
  actual_ea = DocParser.new(@scenario_context.agreement_file, 'nje').exhibit_a
  expect(actual_ea.length).not_to be_zero
  expected_content = @agreement_content
end