Given(/^a CDR with a combo card product$/) do
  login_to_salesforce
  #use_salesforce_as_contract_admin
  @opportunity = TestDataFactory.opportunity
  # puts "opportunity id: #{@opportunity}"
  visit_object(@opportunity[0]['Id'])
  create_proposal
  open_card_catalog
  add_product_to_cart("Combo")
  back_to_proposal
  change_proposal_to_CDR(on(ProposalViewPage).data_for :proposal_to_cdr_required_fields)
end

When(/^I select a premium for the cabin class relationship between the aircrafts$/) do
  edit_product_line_item("Combo")
  @expected_waiver_amount = NjSalesforce::ComboCardPremium.waiver_amount(proposal_aircraft_1, proposal_aircraft_2)['Premium__c']
  edit_line_item(cdr: true, waive_premium: true)
  save_proposal_line_item
  mark_all_postal_address_as_primary
  send_for_approval
  approve_all_requests
  open_first_agreement
end

Then(/^the premium amount is added to the contract cost$/) do
  calculated_total_price = (agreement_pre_tax_purchase_price - agreement_waived_premium_discount + agreement_tax_amount).round(2)

  expect(agreement_waived_premium_discount).to eq @expected_waiver_amount
  expect(calculated_total_price).to eq agreement_total_price
  expect(calculated_total_price + agreement_operating_expense_fund).to eq total_agreement_value
end


Given(/^a CDR with a product$/) do
  login_to_salesforce
  #use_salesforce_as_contract_admin
  @opportunity = TestDataFactory.opportunity
  # puts "opportunity id: #{@opportunity}"
  visit_object(@opportunity[0]['Id'])
  create_proposal
  open_card_catalog
  add_product_to_cart("25 Hour")
  back_to_proposal
  change_proposal_to_CDR(on(ProposalViewPage).data_for :proposal_to_cdr_required_fields)
end

When(/^I apply a percentage discount to the product$/) do
  edit_cdr
  @percentage_reduced = 50
  discount_percentage_for_product(@percentage_reduced)
  save_cdr_changes
  mark_all_postal_address_as_primary
  send_for_approval
  approve_all_requests
  open_first_agreement
end

Then(/^the product cost is reduced by that percentage$/) do
  expect(agreement_adjustment_total).to eq agreement_pre_tax_purchase_price/(100/@percentage_reduced)

  calculated_total_price = (agreement_pre_tax_purchase_price - agreement_adjustment_total) - agreement_waived_premium_discount + agreement_tax_amount

  expect(calculated_total_price).to eq agreement_total_price
  expect(calculated_total_price + agreement_operating_expense_fund).to eq total_agreement_value
end

When(/^I apply a discount amount to the product$/) do
  edit_cdr
  @amount_reduced = 1000
  discount_amount_for_product(@amount_reduced)
  save_cdr_changes
  mark_all_postal_address_as_primary
  send_for_approval
  approve_all_requests
  open_first_agreement
end

Then(/^the product cost is reduced by that amount$/) do
  expect(agreement_adjustment_total).to eq @amount_reduced

  calculated_total_price = (agreement_pre_tax_purchase_price - agreement_adjustment_total) - agreement_waived_premium_discount + agreement_tax_amount

  expect(calculated_total_price).to eq agreement_total_price
  expect(calculated_total_price + agreement_operating_expense_fund).to eq total_agreement_value
end

When(/^I apply a discount amount of over 10,000 to the product$/) do
  edit_cdr
  @amount_reduced = 50
  discount_percentage_for_product(@amount_reduced)
  save_cdr_changes
  mark_all_postal_address_as_primary
  send_for_approval
end

Then(/^an approval from the SVP Global Sales, Marketing, Owner Services is required$/) do
  expect(all_approvals_needed_to_create_agreement.to_s).to include 'SVP Global Sales Marketing & Owner Services'
end

When(/^I apply a discount amount of under 10,000 to the product$/) do
  edit_cdr
  @amount_reduced = 5
  discount_percentage_for_product(@amount_reduced)
  save_cdr_changes
  mark_all_postal_address_as_primary
  send_for_approval
end

Then(/^an approval from the Chairman and CEO is required$/) do
  expect(all_approvals_needed_to_create_agreement.to_s).to include 'Chairman & CEO'
end