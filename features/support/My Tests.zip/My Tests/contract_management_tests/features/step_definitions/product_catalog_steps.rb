Given(/^an existing opportunity$/) do
  login_to_salesforce
  visit_object(TestDataFactory.open_apttus_opportunity)
end

When(/^I add multiple products from the product catalog for a new proposal$/) do
  create_proposal
  open_card_catalog
  add_product_to_cart(DataMagic.yml[:products][:nja][:combo])
  add_product_to_cart(DataMagic.yml[:products][:nja][:standard])
end

Then(/^I cannot directly create a CDR$/) do
  go_to_CDR
  expect(cdr_creation_error(error=true).text).to include 'Please return to previous page'
end

When(/^I add a single product from the product catalog for a new proposal$/) do
  create_proposal
  open_card_catalog
  add_product_to_cart(DataMagic.yml[:products][:nja][:combo])
end

Then(/^I can directly create a CDR$/) do
  go_to_CDR
  expect(cdr_creation_error(error=false).element).to_not exist
end

And(/^I add an enhancement$/) do
  open_enhancements_catalog
  add_enhancement_to_cart('Bonus Hour')
  configure_bonus_hours(2)
end