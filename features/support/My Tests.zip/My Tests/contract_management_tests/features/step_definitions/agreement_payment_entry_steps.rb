Given(/^there is a Pending Funding Agreement$/) do
  login_to_salesforce
  @agreement = find_pending_funding_apttus_agreement
  visit_object(@agreement)
end

When(/^I fund the agreement in multiple payments on the Agreement$/) do
  payment = (total_agreement_value - total_payment_amount) / 2
  2.times do
    fund_agreement(payment)
    visit_object(@agreement)
  end
  change_agreement_status_to_funded
end

Then(/^the Total Payment Amount is the sum of the payments on the Agreement$/) do
  expect(total_payment_amount).to be_within(0.02).of(total_agreement_value)
end

And(/^the card number is generated$/) do
  expect(card_number).to eq(NjSalesforce::CustomSetting.card_number.to_i)
end

Given(/^there is a Funded Contract Agreement$/) do
  login_to_salesforce
  @agreement = find_funded_contract_apttus_agreement
  visit_object(@agreement)
end

Then(/^payment information cannot be edited$/) do
  fund_agreement
  expect(funding_error).to include('When Funding State = "Funded Contract" or "Funded, Needs Approval", then the payment information cannot be edited/deleted.')
end

Given(/^there is a Funded, Needs Approval Agreement$/) do
  login_to_salesforce
  @agreement = find_funded_needs_approval_apttus_agreement
  visit_object(@agreement)
end

When(/^I fund a Contract Agreement$/) do
  login_to_salesforce
  @new_proposal = create_default_proposal(Apttus_Proposal__Proposal_Name__c: 'My Test Standard Proposal')
  visit_object(@new_proposal)
  configure_products
  open_card_catalog
  add_product_to_cart(DataMagic.yml[:products][:nja][:combo])
  back_to_proposal
  change_proposal_to_CDR(on(ProposalViewPage).data_for :proposal_to_cdr_required_fields)
  mark_all_postal_address_as_primary
  send_for_approval
  @agreement = NjSalesforce::Agreement.where({Apttus_QPComply__RelatedProposalId__c: @new_proposal}).to_a
                   .map { |obj| obj.to_h }
                   .each { |obj| obj.delete('attributes') }.first['Id']
  visit_object(@agreement)
  payment = (total_agreement_value - total_payment_amount) / 2
  2.times do
    fund_agreement(payment)
    visit_object(@agreement)
  end
  change_agreement_status_to_funded

end

Then(/^the Funding Date is the most recent payment date$/) do
  expect(most_recent_payment_date(@agreement)).to eq(agreement_funding_date)
end

And(/^the Effective \/ Delayed Start Date is the Funding Date plus the Delayed Start Amount$/) do
  expect(effective_delayed_start_date).to eq(agreement_funding_date + delayed_start_amount)
end

And(/^the Initial Term Expiration Date is the Effective \/ Delayed Start date plus the Initial Term Amount$/) do
  expect(initial_term_expiration_date).to eq(effective_delayed_start_date + initial_term_amount)
end

And(/^the Grace Period End Date is the Initial Term Expiration Date plus the Grace Period Amount$/) do
  expect(grace_period_end_date).to eq(initial_term_expiration_date + grace_period_amount)
end

And(/^the Extended End Date is the Grace Period End Date plus the Extended Term Amount$/) do
  #expect(extended_end_date).to eq(grace_period_end_date + extended_term_amount)
end

