Given(/^I have an agreement that is not active$/) do
  auth = login_info(:sales_user)
  login_to_salesforce(auth[:username], auth[:password])
  agreement = TestDataFactory.inactive_agreement.sample
  visit_object(agreement['Id'])
end

Then(/^I should be able to cancel the agreement$/) do
  patiently { @browser.iframe(:xpath => "//iframe[@title='CS_CancellationofAgreement']").button(value: 'Cancel Agreement').click }
  patiently { expect(on(AgreementViewPage).cancelled_chevron_element).to be_visible }
end

Given(/^I have an agreement that is active$/) do
  auth = login_info(:sales_user)
  login_to_salesforce(auth[:username], auth[:password])
  agreement = TestDataFactory.active_agreement.sample
  visit_object(agreement['Id'])
end

Then(/^I should not be able to cancel the agreement$/) do
  expect(on(AgreementViewPage).cancel_request_element).not_to be_visible
  patiently { expect(@browser.iframe(:xpath => "//iframe[@title='CS_CancellationofAgreement']").button(value: 'Cancel Agreement').enabled?).to be false }
end

Given(/^I am viewing an agreement as a contract administrator$/) do
  auth = login_info(:contract_administrator)
  login_to_salesforce(auth[:username], auth[:password])
  agreement = TestDataFactory.inactive_agreement.sample
  visit_object(agreement['Id'])
end