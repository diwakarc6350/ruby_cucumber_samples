Given(/^an existing CDR with no legal entity$/) do
  login_to_salesforce
  #use_salesforce_as_contract_admin
  @cdr = find_apttus_cdr_with_no_legal_entity
  pending('cannot find test data') unless !@cdr.nil?
  visit_object(@cdr['Id'])
end

When(/^I create an individual legal entity from the CDR$/) do
  @new_legal_entity_name = Faker::Name.name
  create_new_legal_entity_for_cdr(@new_legal_entity_name, 'Individual - US', on(ProposalViewPage).data_for(:individual_legal_entity))
  add_legal_entity_to_cdr(@new_legal_entity_name)
  patiently { on(ProposalViewPage).legal_entity_element.link.click }
end

Then(/^the individual legal entity exists$/) do
  patiently { on_page(LegalEntityViewPage).postal_addresses }
  @browser.windows.last.use do
    expect(on_page(LegalEntityViewPage).legal_entity_name).to eq(@new_legal_entity_name)
    expect(on_page(LegalEntityViewPage).legal_entity_type).to include('Individual - US')
    expect(on_page(LegalEntityViewPage).legal_phone_number_element).to be_visible
    expect(on_page(LegalEntityViewPage).legal_email_address_element).to be_visible
    expect(on_page(LegalEntityViewPage).postal_addresses).to include('Legal Entity Address', 'Legal Notice Address')
  end
  visit_object(@cdr['Id'])
  clear_legal_entity
end

When(/^I create a EUR legal entity from the CDR$/) do
  @new_legal_entity_name = Faker::Name.name
  create_new_legal_entity_for_cdr(@new_legal_entity_name, 'Individual - EUR', on(ProposalViewPage).data_for(:individual_legal_entity_eur))
  add_legal_entity_to_cdr(@new_legal_entity_name)
  patiently { on(ProposalViewPage).legal_entity_element.link.click }
end

Then(/^the individual EUR legal entity exists$/) do
  patiently { on_page(LegalEntityViewPage).postal_addresses }
  @browser.windows.last.use do
    expect(on_page(LegalEntityViewPage).legal_entity_name).to eq(@new_legal_entity_name)
    expect(on_page(LegalEntityViewPage).legal_entity_type).to include('Individual - EUR')
    expect(on_page(LegalEntityViewPage).legal_phone_number_element).to be_visible
    expect(on_page(LegalEntityViewPage).legal_email_address_element).to be_visible
    expect(on_page(LegalEntityViewPage).postal_addresses).to include('Legal Entity Address', 'Billing Address', 'Correspondence Address')
  end
  visit_object(@cdr['Id'])
  clear_legal_entity
end