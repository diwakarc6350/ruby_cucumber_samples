Given(/^I have added a Gateway card with Peak Period Day Premium amount to a proposal$/) do
  @data = YAML.load_file("features/support/data/data.yml")
  login_to_salesforce
  @new_proposal = create_default_proposal(Apttus_Proposal__Proposal_Name__c: 'My Test Standard Proposal')
  puts @new_proposal
  visit_object(@new_proposal)
  configure_products
  open_card_catalog
  add_product_to_cart(@data[:products][:nja][:gateway])
  back_to_proposal
  change_proposal_to_CDR(on(ProposalViewPage).data_for :proposal_to_cdr_required_fields)
  puts @new_proposal
  mark_all_postal_address_as_primary
  send_for_approval
  @agreement = NjSalesforce::Agreement.where({Apttus_QPComply__RelatedProposalId__c: @new_proposal}).to_a
                   .map { |obj| obj.to_h }
                   .each { |obj| obj.delete('attributes') }.first
  visit_object(@agreement['Id'])
  generate_agreement
  attachments = NjSalesforce::Agreement.agreement_documents(@agreement['Id'])
  downloaded_agreement = NjSalesforce::AttachmentNotes
                             .download(attachments.first['Id'], File.dirname(__FILE__) << '/../../downloads')
  @agreement_doc = Docx::Document.open(File.dirname(__FILE__) << '/../../downloads/' << downloaded_agreement)
end

Then(/^the changed peak period day premium is on the agreement document$/) do
  @schedule_1 = parse_gateway_agreement_doc(@agreement_doc)
  expect(@schedule_1[:additional_details][:peak_period_day_premium]).to eq(@agreement['Peak_Period_Day_Premium__c'])
  expect(@schedule_1[:additional_details][:flight_hours_multiplier]).to eq(@agreement['Peak_Period_Day_Premium__c'] + 100)
  expect(@schedule_1[:additional_details][:full_text]).to include("PPD Details: Flights taking place on a PPD will be charged")
end

And(/^the agreement document has the right aircraft type$/) do
  expect(@schedule_1[:aircraft]).to include(@agreement['Aircraft_1__c'])
end

And(/^the agreement document has the right occupied flight hours$/) do
  expect(@schedule_1[:occupied_flight_hours]).to include(@agreement['Occupied_Flight_Hours__c'])
end

And(/^the agreement document has the right pre\-tax purchase price$/) do
  expect(@schedule_1[:pretax_purchase_price]).to eq(@agreement['Purchase_Price_After_Adjustment__c'])
end

And(/^the agreement document has the right total purchase price$/) do
  expect(@schedule_1[:total_purchase_price]).to eq(@agreement['Total_Agreement_Value__c'])
end

And(/^the agreement document has the right fuel variable rate$/) do
  pending('open defect')
  expect(@schedule_1[:fuel_variable_rate]).to eq(@agreement['Fuel_Rate_1__c'])
end

And(/^the agreement document has the right passenger and third party liability insurance price$/) do
  expect(@schedule_1[:liability_insurance].to_s).to eq(@agreement['CS_Third_Party_Liability_Insurance__c'])
end

And(/^the agreement document has the correct minimum advance notice for scheduling flights$/) do
  expect(@schedule_1[:minimum_advance_notice].nil?).to be false
end

And(/^the agreement document has the correct additional details$/) do
  expect(@schedule_1[:additional_details][:taxi_time].nil?).to be false
end

Given(/^I have added a Standard card to a proposal$/) do
  @data = YAML.load_file("features/support/data/data.yml")
  login_to_salesforce
  @new_proposal = create_default_proposal(Apttus_Proposal__Proposal_Name__c: 'My Test Standard Proposal')
  visit_object(@new_proposal)
  configure_products
  open_card_catalog
  add_product_to_cart(@data[:products][:nja][:standard])
  back_to_proposal
  change_proposal_to_CDR(on(ProposalViewPage).data_for :proposal_to_cdr_required_fields)
  mark_all_postal_address_as_primary
  send_for_approval
  @agreement = NjSalesforce::Agreement.where({Apttus_QPComply__RelatedProposalId__c: @new_proposal}).to_a
                   .map { |obj| obj.to_h }
                   .each { |obj| obj.delete('attributes') }.first
  visit_object(@agreement['Id'])
  generate_agreement
  attachments = NjSalesforce::Agreement.agreement_documents(@agreement['Id'])
  downloaded_agreement = NjSalesforce::AttachmentNotes
                             .download(attachments.first['Id'], File.dirname(__FILE__) << '/../../downloads')

  @agreement_doc = Docx::Document.open(File.dirname(__FILE__) << '/../../downloads/' << downloaded_agreement)
end

Then(/^there is no peak period day premium on the agreement document$/) do
  @schedule_1 = parse_agreement_doc(@agreement_doc)
  expect(@schedule_1[:additional_details][:peak_period_day_premium]).nil?
  expect(@schedule_1[:additional_details][:flight_hours_multiplier]).nil?
end

Given(/^I have added an X\-Country Card Agreement for thirty\-six months to a proposal$/) do
  pending('open defect')
  @data = YAML.load_file("features/support/data/data.yml")
  login_to_salesforce
  @new_proposal = create_default_proposal(Apttus_Proposal__Proposal_Name__c: 'My Test Standard Proposal')
  visit_object(@new_proposal)
  configure_products
  open_card_catalog
  add_product_to_cart(@data[:products][:nja][:xcountry])
  back_to_proposal
  change_proposal_to_CDR(on(ProposalViewPage).data_for :proposal_to_cdr_required_fields)
  proposal_line_item = NjSalesforce::ProposalLineItem.where({Apttus_Proposal__Proposal__c: @new_proposal}).first
  visit_object(proposal_line_item['Id'])
  patiently { on(ProposalLineItemPage).edit_proposal_line_item }
  patiently { on(ProposalLineItemEditPage).initial_term_amount = 36 }
  save_proposal_line_item

  visit_object(@new_proposal)
  mark_all_postal_address_as_primary
  send_for_approval
  approve_all_requests
  @agreement = NjSalesforce::Agreement.where({Apttus_QPComply__RelatedProposalId__c: @new_proposal}).to_a
                   .map { |obj| obj.to_h }
                   .each { |obj| obj.delete('attributes') }.first
  visit_object(@agreement['Id'])
  generate_agreement
  attachments = NjSalesforce::Agreement.agreement_documents(@agreement['Id'])
  downloaded_agreement = NjSalesforce::AttachmentNotes
                             .download(attachments.first['Id'], File.dirname(__FILE__) << '/../../downloads')

  @agreement_doc = Docx::Document.open(File.dirname(__FILE__) << '/../../downloads/' << downloaded_agreement)
  #@agreement_doc = Docx::Document.open("C:\\Users\\dchandrasekaran\\workspace\\contract_management_tests\\downloads\\New - Dharma LLC, Card, Citation Excel_Citation X - 25 Hour Cross Country Card_Original_Standard Card Contract - NJA_2015-07-29.doc")
end

And(/^the agreement document has the thirty\-six month term clause$/) do
  expect(@agreement_doc.text).to include("The term of this Agreement will begin the date on which Card Owner pays the Purchase Price")
  expect(@agreement_doc.text).to include("This Agreement will automatically terminate thirty-six (36) months after the Effective Date")
end

Given(/^I have an Agreement for a Combo Card with the premium waived$/) do
  @data = YAML.load_file("features/support/data/data.yml")
  login_to_salesforce
  @new_proposal = create_default_proposal(Apttus_Proposal__Proposal_Name__c: 'My Test Standard Proposal')
  visit_object(@new_proposal)
  configure_products
  open_card_catalog
  add_product_to_cart(@data[:products][:nja][:combo])
  back_to_proposal
  change_proposal_to_CDR(on(ProposalViewPage).data_for :proposal_to_cdr_required_fields)
  edit_product_line_item("Combo")
  @expected_waiver_amount = NjSalesforce::ComboCardPremium.waiver_amount(proposal_aircraft_1, proposal_aircraft_2)['Premium__c']

  edit_line_item(cdr: true, waive_premium: true)
  save_proposal_line_item
  mark_all_postal_address_as_primary
  send_for_approval
  approve_all_requests
  open_first_agreement
  @agreement = NjSalesforce::Agreement.where({Apttus_QPComply__RelatedProposalId__c: @new_proposal}).to_a
                   .map { |obj| obj.to_h }
                   .each { |obj| obj.delete('attributes') }.first
  generate_agreement
  attachments = NjSalesforce::Agreement.agreement_documents(@agreement['Id'])
  downloaded_agreement = NjSalesforce::AttachmentNotes
                             .download(attachments.first['Id'], File.dirname(__FILE__) << '/../../downloads')

  @agreement_doc = Docx::Document.open(File.dirname(__FILE__) << '/../../downloads/' << downloaded_agreement)
  @schedule_1 = parse_agreement_doc(@agreement_doc)
end

And(/^the closing statement has the correct purchase price$/) do
  parsed_agreement = parse_agreement_doc(@agreement_doc)

  expect(parsed_agreement[:closing_statement][:purchase_price]).to eq @agreement['Purchase_Price_After_Adjustment__c']
  expect(parsed_agreement[:closing_statement][:federal_excise_tax]).to eq @agreement['Tax_Amount__c']
  expect(parsed_agreement[:closing_statement][:total_amount_due]).to eq @agreement['Total_Payment_Difference__c']

end


Given(/^I have an standard X\-Country Card Agreement$/) do
  @data = YAML.load_file("features/support/data/data.yml")
  login_to_salesforce
  @new_proposal = NjSalesforce::Proposal
                      .create(Apttus_Proposal__Account__c: TestDataFactory.account.first['Id'],
                              Apttus_Proposal__Proposal_Name__c: 'My Test Standard Proposal',
                              Apttus_Proposal__Opportunity__c: TestDataFactory.opportunity.first['Id'],
                              Apttus_Proposal__Primary_Contact__c: TestDataFactory.contact.first['Id'],
                              Delivery_Email__c: 'qatest1@netjets.com')
  visit_object(@new_proposal)
  configure_products
  open_card_catalog
  add_product_to_cart(@data[:products][:nja][:xcountry])
  back_to_proposal
  change_proposal_to_CDR(on(ProposalViewPage).data_for :proposal_to_cdr_required_fields)
  mark_all_postal_address_as_primary
  send_for_approval
  approve_all_requests
  puts @new_proposal
  @agreement = NjSalesforce::Agreement.where({Apttus_QPComply__RelatedProposalId__c: @new_proposal}).to_a
                   .map { |obj| obj.to_h }
                   .each { |obj| obj.delete('attributes') }.first
  visit_object(@agreement['Id'])
  generate_agreement
  attachments = NjSalesforce::Agreement.agreement_documents(@agreement['Id'])
  downloaded_agreement = NjSalesforce::AttachmentNotes
                             .download(attachments.first['Id'], File.dirname(__FILE__) << '/../../downloads')
  @agreement_doc = Docx::Document.open(File.dirname(__FILE__) << '/../../downloads/' << downloaded_agreement)

end


Then(/^a standard x\-country agreement document is generated with x\-country exhibit\-a line items$/) do
  @expected_xcountry_content = YAML.load_file("features/support/data/agreement_document_content.yml")
  doc = @agreement_doc.text.encode
  program_clause = @expected_xcountry_content[:x_country][:exhibit_a][:program_clause] %
      [@agreement['Aircraft_1__c'], @agreement['Aircraft_2__c']]
  expect(doc).to include(program_clause)
  interchange_clause = @expected_xcountry_content[:x_country][:exhibit_a][:interchange_clause] %
      [@agreement['Aircraft_1__c'], @agreement['Aircraft_2__c']]
  expect(doc).to include(interchange_clause)
  exchange_to_other_aircraft_clause = @expected_xcountry_content[:x_country][:exhibit_a][:exchange_to_other_aircraft_clause] %
      [@agreement['Aircraft_1__c'], @agreement['Aircraft_2__c'], @agreement['Aircraft_2__c']]
  expect(doc).to include(exchange_to_other_aircraft_clause)
  flight_location_clause = @expected_xcountry_content[:x_country][:exhibit_a][:flight_locations_clause] %
      [@agreement['Aircraft_1__c']]
  expect(doc).to include(flight_location_clause)
  expect(doc).to include(@expected_xcountry_content[:x_country][:exhibit_a][:group_a_usa])
  expect(doc).to include(@expected_xcountry_content[:x_country][:exhibit_a][:group_a_canada])
  expect(doc).to include(@expected_xcountry_content[:x_country][:exhibit_a][:group_b_usa])
  expect(doc).to include(@expected_xcountry_content[:x_country][:exhibit_a][:group_b_canada])
  expect(doc).to include(@expected_xcountry_content[:x_country][:exhibit_a][:group_c])
  expect(doc).to include(@expected_xcountry_content[:x_country][:exhibit_a][:group_d])
  min_flight_seg_clause = @expected_xcountry_content[:x_country][:exhibit_a][:minimum_flight_segment_length] %
      [$in_words[@agreement['Minimum_Flight_Segment_Rules_Amount_AC1__c'].to_f],
       @agreement['Minimum_Flight_Segment_Rules_Amount_AC1__c'], @agreement['Aircraft_1__c'],
       $in_words[@agreement['Minimum_Flight_Segment_Rules_Amount_AC2__c'].to_f],
       @agreement['Minimum_Flight_Segment_Rules_Amount_AC2__c'], @agreement['Aircraft_2__c'],]
  #expect(doc).to include(min_flight_seg_clause)
  hawaii_travel_clause =@expected_xcountry_content[:x_country][:exhibit_a][:hawaii_travel] %
      [@agreement['Aircraft_1__c'], @agreement['Peak_Period_Day_Premium__c'].to_i.to_s+'%',
       (@agreement['Peak_Period_Day_Premium__c']+100).to_i.to_s+'%', @agreement['Aircraft_1__c']]
  expect(doc).to include(hawaii_travel_clause)
  expect(doc).to include(@expected_xcountry_content[:x_country][:exhibit_a][:special_gaurantees_for_gateway_line1])
  special_gaureentee_clause = @expected_xcountry_content[:x_country][:exhibit_a][:special_gaurantees_for_gateway_line1] %
      [@agreement['Aircraft_1__c']]
  expect(doc).to include(special_gaureentee_clause)
end


Given(/^I have a 50 hour combo card Agreement with FET waiver$/) do
  @data = YAML.load_file("features/support/data/data.yml")
  login_to_salesforce
  @new_proposal = create_default_proposal(Apttus_Proposal__Proposal_Name__c: 'My Test Standard Proposal')
  visit_object(@new_proposal)
  configure_products
  open_card_catalog
  add_product_to_cart(@data[:products][:nja][:combo50])
  back_to_proposal
  change_proposal_to_CDR(on(ProposalViewPage).data_for :proposal_to_cdr_required_fields)
end

Then(/^the proposal line item has the tax amount calculated as zero$/) do
  on(ProposalViewPage).waive_FET
  line_items = on(ProposalViewPage).proposal_line_items_struct[0]
  expect(line_items[:tax_amount]).to eq('USD 0.00')
end

And(/^the agreement has the tax amount calculated as zero$/) do
  mark_all_postal_address_as_primary
  send_for_approval
  @agreement = NjSalesforce::Agreement.where({Apttus_QPComply__RelatedProposalId__c: @new_proposal}).to_a
                   .map { |obj| obj.to_h }
                   .each { |obj| obj.delete('attributes') }.first
  visit_object(@agreement['Id'])
  generate_agreement
  attachments = NjSalesforce::Agreement.agreement_documents(@agreement['Id'])
  downloaded_agreement = NjSalesforce::AttachmentNotes
                             .download(attachments.first['Id'], File.dirname(__FILE__) << '/../../downloads')

  @agreement_doc = Docx::Document.open(File.dirname(__FILE__) << '/../../downloads/' << downloaded_agreement)
  @schedule_1 = parse_standard_agreement_doc(@agreement_doc)
  expect(@schedule_1[:pretax_purchase_price] - @schedule_1[:total_purchase_price]).to eq(0)
end

And(/^the document is generated with non\-fet flights exhibit\-a clause$/) do
  @expected_content = YAML.load_file("features/support/data/agreement_document_content.yml")
  doc = @agreement_doc.text.encode
  expect(doc).to include(@expected_content[:global][:exhibit_a][:fet_clause])
end

And(/^the closing statement has the the fet line item with zero$/) do
  parsed_agreement = parse_agreement_doc(@agreement_doc)

  expect(parsed_agreement[:closing_statement][:federal_excise_tax]).to eq @agreement['Tax_Amount__c']
end