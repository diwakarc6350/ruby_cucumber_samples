require 'uri'
class WatirHelper

  def self.current_base_url(url)
    uri = URI.parse(url)
    "#{uri.scheme}://#{uri.host}"
  end

  def self.get_id(url)
    return url[url.index(".com/")+5..url.length]
  end
end