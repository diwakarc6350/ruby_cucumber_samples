require 'watir-webdriver'
require 'scenario_context'

prefs = {
    :plugins => {
        :always_authorize => true,
        :allow_outdated => true
    }
}

browser = Watir::Browser.new :chrome, :prefs => prefs, :switches => ['--ignore-certificate-errors']
browser.driver.manage.window.maximize
@browser = browser

Before do
  begin
    @browser = browser
    @scenario_context = ScenarioContext
    @data = YAML.load_file("features/support/data/data.yml")
    @agreement_content = YAML.load_file("features/support/data/agreement_document_content.yml")
  rescue => e
    puts e
  end
end

After do |scenario|
  begin
    # @browser.cookies.clear
    if scenario.failed?
      Dir::mkdir('screenshots') if not File.directory?('screenshots')
      screenshot = "./screenshots/FAILED_#{scenario.name.gsub(' ', '_').gsub(/[^0-9A-Za-z_]/, '')}.png"
      @browser.screenshot.save(screenshot)
      embed screenshot, 'image/png'
    end
  rescue => e
    puts e
  end

  @browser.goto("#{WatirHelper.current_base_url(@browser.url)}/secur/logout.jsp")

end

at_exit do
  @browser.close
end