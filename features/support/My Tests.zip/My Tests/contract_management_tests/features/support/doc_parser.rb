class DocParser

  SCHEDULE_ONE_TABLE_IDX = 0

  attr_reader :file, :type, :full_text, :doc

  def initialize(file, type)
    @file = file
    @type = type
    @doc = Docx::Document.open(file)
    @full_text = @doc.text.to_ascii
  end

  def schedule_one
    schedule_one = {}
    table = doc.tables[SCHEDULE_ONE_TABLE_IDX]
    table.rows.each do |row|
      schedule_one[row.cells[0].text.delete(' ').tableize.to_sym] = row.cells[1].text.to_ascii.strip
    end
    schedule_one
  end

  def closing_statement
    @full_text[@full_text.index('CLOSING STATEMENT')...@full_text.index('PAYMENT INSTRUCTIONS')]
  end

  def payment_instructions
    @full_text[@full_text.index('PAYMENT INSTRUCTIONS')...@full_text.index('Please Reference:')]
  end

  def exhibit_a
    @full_text[@full_text.index('Exhibit A')+9...@full_text.index('Initialed:')]
  end

end