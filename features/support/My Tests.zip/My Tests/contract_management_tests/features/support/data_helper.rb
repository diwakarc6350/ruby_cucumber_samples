$LOAD_PATH << File.dirname(__FILE__) + '/../support'
require 'active_record'
require 'nj_salesforce'
require 'data_magic'
require 'patches/page_object'
require 'docx'

$CLASSPATH << "#{File.dirname(__FILE__)}/lib/ojdbc6-11.2.0.3.jar"

DataMagic.yml_directory = 'features/support/data'
DataMagic.load('data.yml')

case ENV['ENVIRONMENT'].to_sym
  when :qa, :gcmdemo
    ActiveRecord::Base.establish_connection(
        :adapter => 'jdbc',
        :username => 'aircraft_app_user',
        :password => 'pr0p4g4t3',
        :driver => 'oracle.jdbc.driver.OracleDriver',
        :url => "jdbc:oracle:thin:@
                   (DESCRIPTION_LIST=
                   (LOAD_BALANCE=off)
                   (FAILOVER=on)
                   (DESCRIPTION=
                   (ADDRESS_LIST=
                   (LOAD_BALANCE=on)
                   (ADDRESS=(PROTOCOL=TCP)(HOST=cexa-scan)(PORT=1521)))
                   (CONNECT_DATA=(SERVICE_NAME=EDRThinQAT.netjets.com))))")
  when :itg2, :local2, :ci2, :gcmqa, :gcmdev
    ActiveRecord::Base.establish_connection(
        :adapter => 'jdbc',
        :username => 'aircraft_app_user',
        :password => 'tr4nsm1t',
        :driver => 'oracle.jdbc.driver.OracleDriver',
        :url => "jdbc:oracle:thin:@
                 (DESCRIPTION_LIST=
                 (LOAD_BALANCE=off)
                 (FAILOVER=on)
                 (DESCRIPTION=
                 (ADDRESS_LIST=
                 (LOAD_BALANCE=on)
                 (ADDRESS=(PROTOCOL=TCP)(HOST=cexa-scan)(PORT=1521)))
                 (CONNECT_DATA=(SERVICE_NAME=Ijet2ThinDv5.netjets.com))))")
  when :itg, :ci, :local, :itg1
    ActiveRecord::Base.establish_connection(
        :adapter => 'jdbc',
        :username => 'aircraft_app_user',
        :password => 'tr4nsm1t',
        :driver => 'oracle.jdbc.driver.OracleDriver',
        :url => "jdbc:oracle:thin:@
                 (DESCRIPTION=(CONNECT_TIMEOUT=5)
                  (TRANSPORT_CONNECT_TIMEOUT=3)(RETRY_COUNT=3)
                  (LOAD_BALANCE=on)
                  (FAILOVER=on)
                  (ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=cexa-scan)(PORT=1521))
                  (ADDRESS=(PROTOCOL=TCP)(HOST=bexa-scan)(PORT=1521)))
                  (CONNECT_DATA=(SERVICE_NAME=EDRThinITG1.netjets.com))))
              ")
end

puts "Using #{ActiveRecord::Base.connection.current_database} as database"


$in_words = {
    3.5 => "Three and One Half",
    3 => "Tthree",
    2 => "Two",
    1.0 => "One",
    1 => "One"
}
