module ShoppingCartActions

  def get_card_types
    on(ShoppingCartPage) do |p|
      p.wait_for_ajax
      return p.what_type_of_card_list
    end
  end

  def add_product_to_cart(product = '')
    on(ShoppingCartPage).add_to_cart(product)
  end

  def add_enhancement_to_cart(enhancement)
    on(ShoppingCartPage).add_to_cart(enhancement)
  end

  def back_to_proposal
    on(ShoppingCartPage).back_to_proposal
  end

  def go_to_CDR
    sleep(2)
    patiently { on(ShoppingCartPage).go_to_cdr }
  end

  def open_card_catalog
    patiently { on(ShoppingCartPage).open_cards }
  end

  def open_enhancements_catalog
    patiently { on(ShoppingCartPage).open_enhancements }
  end

  def open_miscellaneous_catalog
    patiently { on(ShoppingCartPage).open_miscellaneous }
  end

  def configure_bonus_hours(hours)
    patiently do
      on(ShoppingCartPage).bonus_hours_configuration.bonus_hours = hours
      on(ShoppingCartPage).back_to_catalog
    end
  end

  def cdr_creation_error(error=false)
    if error
      on(ShoppingCartPage) do |p|
        p.wait_until { p.text.include?("Creating the CDR Record requires one Card Product.") }
      end
    end
    patiently { on(ShoppingCartPage).cdr_error_element }
  end
end
World(ShoppingCartActions) if File.basename($PROGRAM_NAME) == 'cucumber'