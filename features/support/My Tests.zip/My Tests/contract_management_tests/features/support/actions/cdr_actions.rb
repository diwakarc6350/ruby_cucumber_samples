module CDRActions

  def find_apttus_cdr_with_no_legal_entity
    NjSalesforce::Proposal.all.find { |proposal| proposal['Legal_Entity__c'].nil? && proposal['Record_Type_Name__c'] == 'CDR' }
  end

  def discount_amount_for_product(amount)
    on(ProposalEditPage).adjustment_type = 'Discount Amount'
    on(ProposalEditPage).adjustment_amount = amount
  end

  def discount_percentage_for_product(percentage)
    on(ProposalEditPage).adjustment_type = '% Discount'
    on(ProposalEditPage).adjustment_amount = percentage
  end

  def edit_cdr
    on(ProposalViewPage).edit
  end

  def save_cdr_changes
    on(ProposalEditPage).save
  end

  def all_approvals_needed_to_create_agreement
    on(ProposalViewPage).all_approvals_needed_to_create_agreement
  end

end

World(CDRActions) if File.basename($PROGRAM_NAME) == 'cucumber'