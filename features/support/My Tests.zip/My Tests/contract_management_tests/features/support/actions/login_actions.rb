require_relative '../enum'
require 'sync_tolerance'

module LoginActions
  include Enum
  include SyncTolerance

  def login_to_salesforce(username = Users::SALESFORCE_ADMIN, password = Users::DEFAULT_PASSWORD)
    visit_page(LoginPage)
    patiently do
      on(LoginPage).username = username
      on(LoginPage).password = password
      on(LoginPage).login
    end
  end

  #TODO: Refactor into nj_salesforce
  def use_salesforce_as_contract_admin
    admin_id = NjSalesforce::User.connection.query("select Id from User where Profile_Name__c = 'Netjets - Contract Administrator'").first['Id']
    visit_object("#{admin_id}?noredirect=1")
    on(UserPage).login
  end
end

World(LoginActions) if File.basename($PROGRAM_NAME) == 'cucumber'