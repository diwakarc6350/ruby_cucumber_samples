module AgreementActions

  def agreement_waived_premium_discount
    on(AgreementViewPage).waived_premium_discount.gsub(/([A-Z]* )|,/, '').to_f
  end

  def agreement_pre_tax_purchase_price
    patiently { on(AgreementViewPage).pre_tax_purchase_price.gsub(/([A-Z]* )|,/, '').to_f }
  end

  def agreement_tax_amount
    on(AgreementViewPage).tax_amount.gsub(/([A-Z]* )|,/, '').to_f
  end

  def agreement_adjustment_total
    patiently { on(AgreementViewPage).adjustment_total.gsub(/([A-Z]* )|,/, '').to_f }
  end

  def agreement_operating_expense_fund
    on(AgreementViewPage).operating_expense_fund.gsub(/([A-Z]* )|,/, '').to_f
  end

  def agreement_total_price
    on(AgreementViewPage).total_price.gsub(/([A-Z]* )|,/, '').to_f.round(2)
  end

  def total_agreement_value
    patiently { on(AgreementViewPage).total_agreement_value.gsub(/([A-Z]* )|,/, '').to_f }
  end

  def total_payment_amount
    patiently { on(AgreementViewPage).total_payment_amount.gsub(/([A-Z]* )|,/, '').to_f.round(2) }
  end

  def card_number
    patiently { on(AgreementViewPage).card_number.gsub(/([A-Z]* )|,/, '').to_i }
  end

  def generate_agreement
    patiently(60) do
      on(AgreementViewPage) do |p|
        @browser.iframe(:xpath => "//iframe[@title='CS_AgreementGeneration']").button(value: 'Generate').click
        p.wait_until(60) { (p.generated_chevron_element.visible?) }
      end
    end
  end

  def find_pending_funding_apttus_agreement
    NjSalesforce::Agreement.agreement_information.select { |x|
      x['Funding_State__c'] == 'Pending Funding' && x['Apttus__Status__c']!= 'Activated' && x['Apttus__Status__c']!= 'Cancelled' }
        .sort_by { |x| x['CreatedDate'].to_datetime }.last['Id']
  end

  def find_funded_contract_apttus_agreement
    NjSalesforce::Agreement.agreement_information.select { |x| x['Funding_State__c'] == 'Funded Contract' }.sort_by { |x| x['Apttus__Activated_Date__c'] }.last['Id']
  end

  def find_funded_needs_approval_apttus_agreement
    NjSalesforce::Agreement.agreement_information.select { |x| x['Funding_State__c'] == 'Funded, Needs Approval' }.sample['Id']
  end

  def fund_agreement(funding_amount=50)
    on(AgreementViewPage) do |p|
      p.new_payment
      p.payment_entries.payment_method = 'Check'
      p.payment_entries.payment_amount = funding_amount
      p.payment_entries.payment_date = Date.today.strftime('%m/%d/%Y')
      p.payment_entries.save
    end
  end

  def change_agreement_status_to_funded
    on(AgreementViewPage).edit_agreement
    patiently { on(AgreementEditPage).funding_state = 'Funded Contract' }
    on(AgreementEditPage).save_agreement
  end

  def funding_error
    on(AgreementViewPage).payment_entries.error
  end

  def most_recent_payment_date(funded_object)
    patiently { Date.strptime(on(AgreementViewPage).funding_date, "%m/%d/%Y") }
    payment_entries = NjSalesforce::PaymentEntry.where({Agreement__c: funded_object}).to_a
    funded_dates = payment_entries.map { |entry| entry['Payment_Date__c'] }
    Date.strptime(funded_dates.max)
  end

  def agreement_funding_date
    patiently { Date.strptime(on(AgreementViewPage).funding_date, "%m/%d/%Y") }
  end

  def delayed_start_amount
    delayed_start_amount = on(AgreementViewPage).delayed_start_amount.to_i
    delayed_start_uom = on(AgreementViewPage).delayed_start_amount_uom.downcase
    delayed_start_amount.send(delayed_start_uom)
  end

  def effective_delayed_start_date
    Date.strptime(on(AgreementViewPage).delayed_start_date, "%m/%d/%Y")
  end

  def initial_term_amount
    initial_term_amount = on(AgreementViewPage).initial_term.to_i
    initial_term_uom = on(AgreementViewPage).initial_term_amount_uom.downcase
    initial_term_amount.send(initial_term_uom)
  end

  def initial_term_expiration_date
    Date.strptime(on(AgreementViewPage).initial_term_expiration_date, "%m/%d/%Y")
  end

  def grace_period_amount
    grace_period_amount = on(AgreementViewPage).grace_period.to_i
    grace_period_uom = on(AgreementViewPage).grace_period_amount_uom.downcase
    grace_period_amount.send(grace_period_uom)
  end

  def grace_period_end_date
    Date.strptime(on(AgreementViewPage).grace_period_end_date, "%m/%d/%Y")
  end

  def extended_term_amount
    extended_term_amount = on(AgreementViewPage).extended_term_amount.to_i
    extended_term_amount_uom = on(AgreementViewPage).extended_term_amount_uom.downcase
    extended_term_amount.send(extended_term_amount_uom)
  end

  def extended_end_date
    Date.strptime(on(AgreementViewPage).extended_end_date, "%m/%d/%Y")
  end

  def parse_agreement_doc(agreement_doc)
    parsed_doc = {}
    parsed_doc[:aircraft] = agreement_doc.tables[0].rows[0].cells[1].text
    parsed_doc[:occupied_flight_hours] = agreement_doc.tables[0].rows[1].cells[1].text
    parsed_doc[:pretax_purchase_price] = agreement_doc.tables[0].rows[2].cells[1].text.tr('$,', '').to_f
    parsed_doc[:total_purchase_price] = agreement_doc.tables[0].rows[3].cells[1].text.delete('(includes Federal Excise Tax)')
                                            .tr('$,', '').to_f
    parsed_doc[:fuel_variable_rate] = agreement_doc.tables[0].rows[4].cells[1].text.to_f
    parsed_doc[:fuel_charge_per_hour] = agreement_doc.tables[0].rows[5].cells[1].text
    parsed_doc[:liability_insurance] = agreement_doc.tables[0].rows[6].cells[1].text.tr('$', '')
    minimum_advance_notice = {}
    minimum_advance_notice_text = agreement_doc.tables[0].rows[7].cells[1].text.split(':')
    minimum_advance_notice[:non_peak_period_day_domestic] = minimum_advance_notice_text[2][0..4].strip
    minimum_advance_notice[:non_peak_period_international] = minimum_advance_notice_text[3][0..4].strip
    minimum_advance_notice[:peak_period_days] = minimum_advance_notice_text[5][0..4].strip!
    parsed_doc[:minimum_advance_notice] = minimum_advance_notice
    additional_details = {}
    additional_details_text = agreement_doc.tables[0].rows[8].cells[1].text.split('(')
    additional_details[:minimum_flight_duration] = additional_details_text[1][0..2].tr(')', '').strip
    additional_details[:taxi_time] = additional_details_text[3][0..3].tr(')', '').to_r.to_f
    parsed_doc[:additional_details] = additional_details
    parsed_doc[:MQ_reservation_number] = agreement_doc.tables[0].rows[9].cells[1].text
    additional_details[:full_text] = agreement_doc.tables[0].rows[8].cells[1].text
    closing_statement = {}
    closing_statement[:purchase_price] = agreement_doc.tables[2].rows.first.cells.last.text.tr('$,', '').to_f
    closing_statement[:federal_excise_tax] = agreement_doc.tables[2].rows[1].cells[1].text.tr('$,', '').to_f
    closing_statement[:total_amount_due] = agreement_doc.tables[3].rows.first.cells[1].text.tr('$,', '').to_f
    parsed_doc[:closing_statement] = closing_statement
    parsed_doc
  end

  def parse_gateway_agreement_doc(agreement_doc)
    parsed_doc = parse_agreement_doc(agreement_doc)
    additional_details_text = agreement_doc.tables[0].rows[8].cells[1].text.split('%')
    parsed_doc[:additional_details][:peak_period_day_premium] = additional_details_text[0].split(//).last(3).join.strip.to_f
    parsed_doc[:additional_details][:flight_hours_multiplier] = additional_details_text[1].split(//).last(3).join.strip.to_f
    parsed_doc
  end

  def parse_standard_agreement_doc(agreement_doc)
    parsed_doc = parse_agreement_doc(agreement_doc)
    additional_details_text = agreement_doc.tables[0].rows[8].cells[1].text.split('%')
    parsed_doc[:additional_details][:peak_period_day_premium] = additional_details_text[0].split(//).last(3).join.strip.to_f
    parsed_doc
  end

  def make_agreement_changes(agreement_changes)
    if agreement_changes!= 'None'

    end
  end

end

World(AgreementActions) if File.basename($PROGRAM_NAME) == 'cucumber'