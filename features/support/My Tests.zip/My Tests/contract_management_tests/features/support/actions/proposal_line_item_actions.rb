module ProposalLineItemEditActions

  def proposal_aircraft_1
    patiently { on(ProposalLineItemEditPage).aircraft_1 }
  end

  def proposal_aircraft_2
    patiently { on(ProposalLineItemEditPage).aircraft_2 }
  end

  def edit_line_item(opts={})
    on(ProposalLineItemEditPage).cdr_checkbox.click if opts.delete(:cdr) && !on(ProposalLineItemEditPage).cdr_checkbox.checked?
    on(ProposalLineItemEditPage).waive_premium_checkbox.click if opts.delete(:waive_premium) && !on(ProposalLineItemEditPage).waive_premium_checkbox.checked?
    on(ProposalLineItemEditPage).waive_FET_checkbox.click if opts.delete(:waive_FET) && !on(ProposalLineItemEditPage).waive_FET_checkbox.checked?

    opts.each_pair do |k, v|
      on(ProposalLineItemEditPage).send("#{k}=", v)
    end

  end

  def proposal_line_pre_tax_purchase_price
    patiently { on(ProposalLineItemPage).pre_tax_purchase_price.gsub(/([A-Z]* )|,/, '').to_f }
  end

  def save_proposal_line_item(raise_error=false)
    patiently { on(ProposalLineItemEditPage).save }
    on(ProposalLineItemViewPage) do |p|
      if !raise_error
        p.wait_until { p.text.include? ("Proposal Line Item Detail") or p.text.include? ("Quote/Proposal Detail") }
      end
    end
  end

  def make_proposal_changes(proposal_changes)
    if proposal_changes!= 'Nothing'

    end
  end

end

World(ProposalLineItemEditActions) if File.basename($PROGRAM_NAME) == 'cucumber'