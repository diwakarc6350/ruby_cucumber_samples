module ProposalActions
  def change_proposal_to_CDR(opts={})
    on(ProposalViewPage).create_cdr
    required_fields = opts
    on(ProposalEditPage).wait_until(25) { on(ProposalEditPage).waive_premium_element.exists? }
    on(ProposalEditPage).check_waive_premium if required_fields.delete(:waive_premium)
    on(ProposalEditPage).populate_page_with(required_fields)
    patiently { on(ProposalEditPage).save }
    patiently { @browser.text.include?("Quote/Proposal Detail") }
  end

  def create_new_legal_entity_for_cdr(legal_entity_name, legal_entity_type, opts={})
    on(ProposalViewPage).new_legal_entity_element.click
    sleep(2)
    @browser.windows.last.use do
      patiently { on(LegalEntityRecordTypePage).record_type = legal_entity_type }
      patiently { on(LegalEntityRecordTypePage).continue }
      patiently { on(LegalEntityEditPage).legal_entity_name = legal_entity_name }
      patiently { on(LegalEntityEditPage).account = NjSalesforce::Account.all.sample['Name'] }
      patiently { on(LegalEntityEditPage).populate_page_with(opts) }
      patiently { on(LegalEntityEditPage).save }
    end
    @browser.windows.last.close
    @browser.windows.first.use
    sleep(5)
  end

  def add_legal_entity_to_cdr(legal_entity_name)
    patiently { on(ProposalViewPage).edit }
    patiently { on(ProposalEditPage).legal_entity = legal_entity_name }
    patiently { on(ProposalEditPage).delivery_email_1 = 'qatest1@netjets.com' if on(ProposalEditPage).delivery_email_1 == '' }
    patiently { on(ProposalEditPage).primary_phone = '123444566' if on(ProposalEditPage).primary_phone == '' }
    patiently { on(ProposalEditPage).save }
  end


  def clear_legal_entity
    patiently { on(ProposalViewPage).edit }
    patiently { on(ProposalEditPage).legal_entity = '' }
    patiently { on(ProposalEditPage).save }
  end

  def set_primary_product_for_cdr(product_name)
    on(ProposalViewPage).set_primary_product_for_cdr(product_name)
  end

  def edit_product_line_item(product_name)
    on(ProposalViewPage).edit_product_line_item(product_name)
  end

  def send_for_approval
    patiently { on(ProposalViewPage).send_for_approval_n_return }
  end

  def configure_products
    on(ProposalViewPage).open_product_config
  end

  def approve_all_requests
    on(ProposalViewPage).approve_all_requests
  end

  def open_first_agreement
    on(ProposalViewPage).open_first_agreement
  end

  def mark_all_postal_address_as_primary
    sleep(2)
    if @browser.iframe(title: 'CSPostalAddress').exists?
      @browser.iframe(title: 'CSPostalAddress').tbodys[-1].rows.each do |address|
        address.tds[1].double_click
        address.tds[1].checkbox.click unless address.tds[1].checkbox.checked?
      end
      @browser.iframe(title: 'CSPostalAddress').button(value: 'Save').click
    end
  end

  def generate_proposal
    patiently { @browser.iframe(:xpath => "//iframe[@title='CS_ProposalTemplateGenerate']").button(value: 'Generate Proposal').click }
    on(ProposalViewPage) do |p|
      p.wait_until { p.proposal_chevron_element.present? }
    end
  end

  def create_default_proposal(proposal_opts={})
    default_opts = {
        Apttus_Proposal__Account__c: TestDataFactory.account.first['Id'],
        Apttus_Proposal__Opportunity__c: TestDataFactory.opportunity.first['Id'],
        Apttus_Proposal__Primary_Contact__c: TestDataFactory.contact.first['Id'],
        Delivery_Email__c: 'qatest1@netjets.com'
    }
    default_opts.merge!(proposal_opts)

    NjSalesforce::Proposal.create(default_opts)
  end

  def world_check
    patiently { on(ProposalViewPage).edit }
    patiently { on(ProposalEditPage).check_world_check }
    patiently { on(ProposalEditPage).save }
  end
end

World(ProposalActions) if File.basename($PROGRAM_NAME) == 'cucumber'