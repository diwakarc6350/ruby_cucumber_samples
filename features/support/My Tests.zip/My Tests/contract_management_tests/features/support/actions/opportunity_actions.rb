module OpportunityActions

  def create_proposal
   patiently { on(OpportunityViewPage).create_proposal }
  end

end

World(OpportunityActions) if File.basename($PROGRAM_NAME) == 'cucumber'