module NavigationActions
  def visit_object(obj)
    patiently { on(LandingPage).goto_object(obj) }
  end

  def visit_uri(uri)
    patiently { on(LandingPage).goto_uri(uri) }
  end
end

World(NavigationActions) if File.basename($PROGRAM_NAME) == 'cucumber'