class PostalAddressRecordTypePage
  include PageObject

  select(:record_type, xpath: "//*[contains(. ,'Record Type of new record')]/following::td[1]//select")
  button(:continue, value: 'Continue')
end