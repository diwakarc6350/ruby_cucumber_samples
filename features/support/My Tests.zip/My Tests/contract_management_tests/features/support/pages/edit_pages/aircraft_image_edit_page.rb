require 'page-object'
require 'sync_tolerance'

class AircraftImageEditPage < BasePage
  include PageObject
  include PageObject::PageFactory
  include SyncTolerance

  text_field(:aircraft_type, xpath: "//*[text() = 'Aircraft Type']/following::span[1]//input")
  text_field(:product_image_name, xpath: "//*[text() = 'CS Product Image Name']/following::td[1]//input")
  checkbox(:netjets_logo, xpath: "//*[text() = 'NetJets logo']/following::td[1]//input")

  image(:search_aircraft, alt: 'Aircraft Type Lookup (New Window)')

end
