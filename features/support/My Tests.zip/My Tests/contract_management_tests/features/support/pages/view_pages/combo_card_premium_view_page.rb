require 'page-object'

class ComboCardPremiumViewPage < BasePage
  include PageObject
end