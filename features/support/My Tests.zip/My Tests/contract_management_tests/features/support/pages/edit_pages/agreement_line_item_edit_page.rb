require 'page-object'
require 'sync_tolerance'

class AgreementLineItemEditPage < BasePage
  include PageObject
  include PageObject::PageFactory
  include SyncTolerance

  select_list(:regulatory_stop_fee_1, xpath: "//*[contains(. ,'Regulatory Stop Fee 1')]/following::td[1]//select")
  select_list(:regulatory_stop_fee_2, xpath: "//*[contains(. ,'Regulatory Stop Fee 2')]/following::td[1]//select")

end
