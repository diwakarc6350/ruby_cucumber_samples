require 'page-object'

class PriceListItemEditPage < BasePage
  include PageObject
end