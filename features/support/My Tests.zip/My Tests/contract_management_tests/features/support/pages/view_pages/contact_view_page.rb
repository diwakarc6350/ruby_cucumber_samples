require 'page-object'
require 'sync_tolerance'

class ContactViewPage < BasePage
  include PageObject
  include PageObject::PageFactory
  include SyncTolerance

end