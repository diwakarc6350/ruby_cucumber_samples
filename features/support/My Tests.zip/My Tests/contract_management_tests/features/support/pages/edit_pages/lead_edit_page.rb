require 'page-object'

class LeadViewPage < BasePage
  include PageObject
  include PageObject::PageFactory

end