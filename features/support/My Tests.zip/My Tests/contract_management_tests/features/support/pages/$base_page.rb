require 'page-object'

class BasePage

  include PageObject
  include PageObject::PageFactory

  button(:new, xpath: "//input[@title='New' and @class='btn' and @type!='hidden']")
  button(:edit, xpath: "//input[@title='Edit' and @class='btn' and @type!='hidden']")
  button(:delete, xpath: "//input[@title='Delete' and @class='btn' and @type!='hidden']")
  button(:save, xpath: "//input[@title='Save' and @class='btn' and @type!='hidden']")
  button(:cancel, xpath: "//input[@title='Cancel' and @class='btn' and @type!='hidden']")

end