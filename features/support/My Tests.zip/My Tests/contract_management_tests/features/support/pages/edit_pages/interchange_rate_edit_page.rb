require 'page-object'

class InterchangeRateEditPage < BasePage
  include PageObject
  include PageObject::PageFactory

end