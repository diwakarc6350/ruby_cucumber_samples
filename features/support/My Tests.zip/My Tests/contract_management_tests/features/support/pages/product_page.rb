require 'page-object'

class ProductPage < BasePage
  include PageObject

  #Product Information
  select_list(:primary_aircraft_picklist, xpath: "//label[contains(. ,'What type of aircraft?')]/../following-sibling::*/*/*/select")
  select_list(:secondary_aircraft_picklist, xpath: "//label[contains(. ,'What type of second aircraft?')]/../following-sibling::*/*/select")
  text_field(:operating_expense_fund, xpath: "//*[contains(. ,'Operating Expense Fund')]/../following-sibling::*/input")

  #Product Term
  select_list(:delayed_start_amount, xpath: "//label[contains(. ,'Delayed Start Amount')]/../following-sibling::*/*/*/select")
  select_list(:delayed_start_uom, xpath: "//label[contains(. ,'Delayed Start Unit of Measure (UOM)')]/../following-sibling::*/*/*/select")
  select_list(:escalation_method, xpath: "//label[contains(. ,'Escalation Method')]/../following-sibling::*[1]//select")

  #Peak Period Days
  select_list(:peak_period_departure_adj, xpath: "//label[contains(. ,'Peak Period Day Departure Adjustment')]/../following-sibling::*/*/*/select")
  select_list(:peak_period_departure_adj_uom, xpath: "//label[contains(. ,'Peak Period Day Departure Adjustment UOM')]/../following-sibling::*/*/*/select")
  select_list(:peak_period_departure_adj, xpath: "//label[contains(. ,'Peak Period Day Departure Adjustment')]/../following-sibling::*/*/*/select")
  select_list(:peak_period_departure_adj_uom, xpath: "//label[contains(. ,'Peak Period Day Departure Adjustment UOM')]/../following-sibling::*/*/*/select")
  text_field(:ppd_premium_percent_amount, xpath: "//label[contains(. ,'PPD Premium % Amount')]/../following-sibling::*[1]//input")
  select_list(:ppd_premium_effective_date, xpath: "//label[contains(. ,'PPD Premium Effective Date')]/../following-sibling::*[1]//select")

  #Taxes and Fees
  select_list(:regulatory_stop_fee_1, xpath: "//label[contains(. ,'Regulatory Stop Fee 1')]/../following-sibling::*[1]//select")
  select_list(:regulatory_stop_fee_2, xpath: "//label[contains(. ,'Regulatory Stop Fee 2')]/../following-sibling::*[1]//select")
  text_field(:fuel_tax_percent_fet, xpath: "//label[contains(. ,'Fuel Tax % (FET)')]/../following-sibling::*/*/input")
  select_list(:excess_flying_prepay, xpath: "//*[contains(. ,'Excess Flying Prepay')]/../following-sibling::*/*/*/select")
  text_field(:ground_handling_fee, xpath: "//*[contains(. ,'Ground Handling Fee')]/../following-sibling::*/*/input")
  text_field(:excess_flying_hourly_tax, xpath: "//*[contains(. ,'Excess Flying Hourly Tax (FET)')]/../following-sibling::*/*/input")

  #Operational Information
  select_list(:same_day_usage_waiver_ac_1, xpath: "//label[contains(. ,'Same Day Usage Waiver AC 1')]/../following-sibling::*[1]//select")
  select_list(:same_day_usage_waiver_uom_ac_1, xpath: "//label[contains(. ,'Same Day Usage Waiver UOM AC 1')]/../following-sibling::*[1]//select")
  select_list(:same_day_usage_waiver_ac_2, xpath: "//label[contains(. ,'Same Day Usage Waiver AC 2')]/../following-sibling::*[1]//select")
  select_list(:same_day_usage_waiver_uom_ac_2, xpath: "//label[contains(. ,'Same Day Usage Waiver UOM AC 2')]/../following-sibling::*[1]//select")
  select_list(:customer_is_late_amount, xpath: "//label[contains(. ,'Customer is Late Amount')]/../following-sibling::*/*/*/select")
  select_list(:customer_is_late_uom, xpath: "//label[contains(. ,'Customer is Late UOM')]/../following-sibling::*/*/*/select")
  select_list(:netjets_is_late_amount, xpath: "//label[contains(. ,'NetJets is Late Amount')]/../following-sibling::*/*/*/select")
  select_list(:netjets_is_late_uom, xpath: "//label[contains(. ,'NetJets is Late UOM')]/../following-sibling::*/*/*/select")
  select_list(:aircraft_per_day, xpath: "//label[contains(. ,'Aircraft Per Day')]/../following-sibling::*/*/*/select")
  select_list(:upgrade_from_aircraft, xpath: "//label[contains(. ,'Upgrade from Aircraft')]/../following-sibling::*/*/*/select")
  select_list(:min_flight_segment_rules_amount_ac1, xpath: "//label[contains(. ,'Minimum Flight Segment Rules Amount AC1')]/../following-sibling::*[1]//select")
  select_list(:min_flight_segment_rules_uom_ac1, xpath: "//label[contains(. ,'Minimum Flight Segment Rules UOM AC1')]/../following-sibling::*[1]//select")
  select_list(:min_flight_segment_rules_amount_ac2, xpath: "//label[contains(. ,'Minimum Flight Segment Rules Amount AC2')]/../following-sibling::*[1]//select")
  select_list(:min_flight_segment_rules_uom_ac2, xpath: "//label[contains(. ,'Minimum Flight Segment Rules UOM AC2')]/../following-sibling::*[1]//select")
  select_list(:nja_accounting_company, xpath: "//label[text() ='Accounting Company']/../following-sibling::*[1]//select")
  select_list(:flight_rules, xpath: "//*[contains(. ,'Flight Rule')]/../following-sibling::*/*/*/*/select")
  text_field(:liability_for_delay_max_amount, xpath: "//*[contains(. ,'Liability for Flight Delay Max Amount')]/../following-sibling::*/*/input")
  select_list(:liability_for_delay_credit_type, xpath: "//label[contains(. ,'Liability for Flight Delay Credit Type')]/../following-sibling::*/*/*/select")

  def expected_values
    {:same_day_usage_waiver_amount => %w[4 N/A],
     :same_day_usage_waiver_uom => %w[hours],
     :custom_stops_fees => %w[--None-- $0 $200 $500],
     :min_flight_segment_rules_amount => %w[--None-- 1.0 2.0 2.5 3.5],
     :min_flight_segment_rules_uom => %w[hours],
     :upgrade_from_aircraft => ['No Restrictions'],
     :aircraft_per_day => ['1'],
     :netjets_is_late => %w[60 90 120],
     :netjets_is_late_uom => %w[minutes],
     :customer_is_late => %w[60 90 120],
     :customer_is_late_uom => %w[minutes],
     :delayed_start_amount => %w[6 7 8 9 10 11 12 0],
     :delayed_start_uom => ['months'],
     :excess_flying_prepay => %w[Yes No],
     :peak_period_departure_adj => %w[3.0 2.5 2.0 1.5 1.0],
     :peak_period_departure_adj_uom => %w[hours],
     :nja_accounting_companies => ['MJP'],
     :nja_flight_rules => ['Part 135'],
     :nje_flight_rules => ['EU-OPS'],
     :ppd_premium_effective_date => ['--None--', 'Start Date', '1 Year After Start Date'],
     :escalation_method => ['--None--', 'Rolling 12 Month Average CPI', 'The Greater of 2.75% or OECD']
    }
  end

  def expected_default_value
    {:same_day_usage_waiver_uom => 'hours',
     :same_day_usage_waiver_amount => '4',
     :custom_stops_fees => '$0',
     :min_flight_segment_rules_amount => '1.0',
     :min_flight_segment_rules_uom => 'hours',
     :aircraft_per_day => '1',
     :customer_is_late => '60',
     :customer_is_late_uom => 'minutes',
     :netjets_is_late => '60',
     :netjets_is_late_uom => 'minutes',
     :peak_period_departure_adj => '1.0',
     :peak_period_departure_adj_uom => 'hours',
     :delayed_start_amount => '6',
     :delayed_start_uom => 'months'}
  end

  def edit_product
    self.edit
    self.wait_until { (self.text.include? "Product Edit") &&
        (self.text.include? "Product Information") }
  end

end