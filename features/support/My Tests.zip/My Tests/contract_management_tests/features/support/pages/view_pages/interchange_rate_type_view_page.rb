require 'page-object'
require 'sync_tolerance'

class InterchangeRateTypeViewPage < BasePage
  include PageObject
  include PageObject::PageFactory
  include SyncTolerance

end