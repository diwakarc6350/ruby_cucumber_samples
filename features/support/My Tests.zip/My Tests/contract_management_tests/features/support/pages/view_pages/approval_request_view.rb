require 'page-object'
require 'sync_tolerance'

class ApprovalRequestViewPage < BasePage
  include PageObject
  include PageObject::PageFactory
  include SyncTolerance

end