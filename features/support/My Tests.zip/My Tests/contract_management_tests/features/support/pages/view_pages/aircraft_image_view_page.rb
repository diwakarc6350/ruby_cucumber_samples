require 'page-object'
require 'sync_tolerance'

class AircraftImageViewPage < BasePage
  include PageObject
  include PageObject::PageFactory
  include SyncTolerance

  div(:aircraft_type, xpath: "//td[text()='Aircraft Type']/following::td[1]/div")
  div(:product_image_name, xpath: "//td[text()='CS Product Image Name']/following::td[1]/div")
  div(:netjets_logo, xpath: "//td[text()='NetJets logo']/following::td[1]/div")
  image(:image, xpath: "//td[text()='RTF Image']/following::td[1]//img")

  image(:upload, alt: 'Upload Image')
end
