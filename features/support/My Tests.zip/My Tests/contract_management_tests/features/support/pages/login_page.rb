require 'page-object'
class LoginPage
  include PageObject
  include PageObject::PageFactory

  page_url 'test.salesforce.com'

  text_field(:username, id:"username")
  text_field(:password, id:"password")
  button(:login, id:"Login")
  link(:continue, xpath: '//*[@id="box"]/form/p/a')

end
