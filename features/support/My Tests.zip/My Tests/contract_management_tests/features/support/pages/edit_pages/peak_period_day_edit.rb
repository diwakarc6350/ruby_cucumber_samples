require 'page-object'
require 'sync_tolerance'

class PeakPeriodDayEditPage < BasePage
  include PageObject
  include PageObject::PageFactory
  include SyncTolerance

end