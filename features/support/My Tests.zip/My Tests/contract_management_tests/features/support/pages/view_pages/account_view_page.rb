require 'page-object'
require 'features/support/patches/table'
require 'sync_tolerance'

class AccountViewPage < BasePage
  include PageObject
  include PageObject::PageFactory
  include SyncTolerance

  #Asset Line Items
  table(:asset_line_items, xpath: "//table//h3[text()='Asset Line Items (Account)']/../../../following::*[1]/table")
end
