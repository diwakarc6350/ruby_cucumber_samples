require 'page-object'
require 'features/support/watir_helper'

class LegalEntityViewPage < BasePage
  include PageObject
  include PageObject::PageFactory

  #Actions
  button(:edit, title: 'Edit')
  button(:delete, title: 'Delete')
  button(:new_account_legal_entity, xpath: "//input[@value='New Account Legal Entity']")
  button(:new_postal_address, xpath: "//input[@value='New Postal Address']")

  div(:legal_entity_name, xpath: "//td[text()='Legal Entity Name']/following::td[1]/div")
  div(:legal_entity_type, xpath: "//td[text()='Record Type']/following::td[1]/div")
  div(:legal_phone_number, xpath: "//td[text()='Legal Phone Number']/following::td[1]/div")
  div(:legal_email_address, xpath: "//td[text()='Legal Email Address']/following::td[1]/div")
  div(:associated_legal_entity, xpath: "//td[text()='Associated Legal Entity']/following::td[1]/div")

  #Account Legal Entities
  table(:account_legal_entities, xpath: "//table//h3[text()='Account Legal Entities']/../../../following::*[1]/table")

  #Asset Line Items
  table(:asset_line_items, xpath: "//table//h3[text()='Asset Line Items']/../../../following::*[1]/table")

  #Agreements
  table(:agreements, xpath: "//table//h3[text()='Asset Line Items']/../../../following::*[1]/table")

  #Postal Address
  table(:postal_addresses, xpath: "//table//h3[text()='Postal Addresses']/../../../following::*[1]/table")

end