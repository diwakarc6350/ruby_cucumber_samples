require 'page-object'

class OpportunityViewPage < BasePage
  include PageObject

  #Opportunity Detail
  button(:create_proposal, name: 'create_proposal')
  div(:owner_is, xpath: "//span[text()='Owner Is']/../following-sibling::*[1]/div")

end