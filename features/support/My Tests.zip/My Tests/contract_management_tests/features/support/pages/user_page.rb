require 'page-object'

class UserPage
  include PageObject

  button(:login, name: 'login')

end