class AgreementsSection
  include PageObject

  element(:agreement_name_heading, xpath: "./th[@class=' dataCell  ']")

end