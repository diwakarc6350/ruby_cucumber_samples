require 'page-object'

class TemplateViewPage < BasePage
  include PageObject
end