require 'page-object'
class ProposalLineItemViewPage < BasePage
  include PageObject


end


