require 'page-object'
require 'sync_tolerance'

class AssetLineItemViewPage < BasePage
  include PageObject
  include PageObject::PageFactory
  include SyncTolerance

  #Asset Line Item Detail Left Column
  div(:asset_name, xpath: "//td[text()='Asset Name']/following::td[1]/div")
  div(:product_line, xpath: "//td[text()='Product Line']/following::td[1]/div")
  div(:operational_company, xpath: "//td[text()='Operational Company']/following::td[1]/div")
  div(:card_type, xpath: "//td[text()='Card Type']/following::td[1]/div")
  div(:aircraft_type_1, xpath: "//td[text()='Aircraft 1']/following::td[1]/div")
  div(:aircraft_type_2, xpath: "//td[text()='Aircraft 2']/following::td[1]/div")
  div(:hours_purchased, xpath: "//td[text()='Hours Purchased']/following::td[1]/div")
  div(:bonus_hours, xpath: "//td[text()='Bonus Hours']/following::td[1]/div")
  div(:referral_hours, xpath: "//td[text()='Referral Hours']/following::td[1]/div")
  div(:financial_partnership_hour, xpath: "//td[text()='Financial Partnership Hour']/following::td[1]/div")
  div(:total_hour, xpath: "//td[text()='Total Hours']/following::td[1]/div")

  #Asset Line Item Detail Right Column
  div(:agreement, xpath: "//td[text()='Agreement']/following::td[1]/div")
  link(:sold_to, xpath: "//span[text()='Sold To']/../following::a[1]")
  div(:legal_entity, xpath: "//td[text()='Legal Entity']/following::td[1]/div")
  div(:payment_date, xpath: "//td[text()='Payment Date']/following::td[1]/div")
  div(:grace_period_start_date, xpath: "//td[text()='Grace Period Start Date']/following::td[1]/div")
  div(:contract_end_date, xpath: "//td[text()='Contract End Date']/following::td[1]/div")

end