class UpgradeAtOneToOneSection
  include PageObject

  text_field(:to_aircraft, xpath: "//label[contains(. ,'To Aircraft')]/../following-sibling::*[1]//input[@type != 'hidden']")
  text_field(:number_of_upgrades, xpath: "//*[contains(. ,'# of Upgrades')]/../following-sibling::*/input")
  select_list(:upgrade_type, xpath: "//label[text() ='Upgrade Type']/../following-sibling::*[1]//select")
  checkbox(:use_contract_start_date, xpath: "//label[contains(. ,'Use Contract Start Date')]/../following-sibling::*[1]//input")
  text_field(:effective_start_date, xpath: "//label[contains(. ,'Effective Start Date')]/../following-sibling::*[1]//input")
  select_list(:blackout_days, xpath: "//label[text() ='Blackout Days']/../following-sibling::*[1]//select")
  text_field(:total_hours, xpath: "//*[contains(. ,'Total Hours (Not To Exceed)')]/../following-sibling::*/input")
  select_list(:available_upgrade_service_area, xpath: "//label[text() ='Upgrade Service Area']/../following-sibling::*[1]//select[@title = 'Upgrade Service Area - Available']")
  select_list(:chosen_upgrade_service_area, xpath: "//label[text() ='Upgrade Service Area']/../following-sibling::*[1]//select[@title = 'Upgrade Service Area - Chosen']")
  checkbox(:use_contract_end_date, xpath: "//label[contains(. ,'Use Contract End Date')]/../following-sibling::*[1]//input")
  text_field(:effective_end_date, xpath: "//label[contains(. ,'Effective End Date')]/../following-sibling::*[1]//input")
  select_list(:peak_period_days, xpath: "//label[text() ='Peak Period Days']/../following-sibling::*[1]//select")
end