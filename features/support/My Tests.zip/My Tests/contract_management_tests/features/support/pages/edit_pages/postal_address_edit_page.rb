class PostalAddressEditPage
  include PageObject

  #Information
  td(:record_type, xpath: "//*[contains(. ,'Record Type')]/following-sibling::td")

  #Address Information
  text_field(:street, xpath: "//*[contains(. ,'Street')]/following-sibling::td//input[@type='text']")
  text_field(:city, xpath: "//*[contains(. ,'City')]/following-sibling::td//input[@type='text']")
  text_field(:state_province, xpath: "//*[contains(. ,'State')]/following-sibling::td//input[@type='text']")
  text_field(:postal_code, xpath: "//*[contains(. ,'Postal Code')]/following-sibling::td//input[@type='text']")
  text_field(:country, xpath: "//*[contains(. ,'Country')]/following-sibling::td//input[@type='text']")
  text_field(:associated_proposal, xpath: "//*[contains(. ,'Associated')]/following-sibling::td//input[@type='text']")
  select(:address_type, xpath: "//*[contains(. ,'Address Source')]/following-sibling::td//select")
  select(:address_source, xpath: "//*[contains(. ,'Address Source')]/following-sibling::td//select")
end