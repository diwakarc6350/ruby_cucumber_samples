require 'page-object'

class LeadEditPage < BasePage
  include PageObject
  include PageObject::PageFactory

end