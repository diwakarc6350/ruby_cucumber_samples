class BonusHoursSection
  include PageObject

  text_field(:bonus_hours, xpath: "//*[contains(. ,'Bonus Hours')]/following::td[1]//input[@type='text']")
end