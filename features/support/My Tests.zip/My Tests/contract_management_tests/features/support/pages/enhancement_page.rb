require 'page-object'
class EnhancementPage
  include PageObject


end