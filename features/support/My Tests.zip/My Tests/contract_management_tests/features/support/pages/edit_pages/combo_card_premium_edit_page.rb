require 'page-object'

class ComboCardPremiumEditPage < BasePage
  include PageObject
end