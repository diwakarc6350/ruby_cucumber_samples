require 'page-object'

class PriceListViewPage < BasePage
  include PageObject
end