class ApprovalRequestsSection
  include PageObject

  td(:approval_action, index: 2)
  td(:asssigned_to, index: 5)

end