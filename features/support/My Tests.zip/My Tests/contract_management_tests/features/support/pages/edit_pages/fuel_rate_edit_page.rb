require 'page-object'
require 'sync_tolerance'

class FuelRateViewPage < BasePage
  include PageObject
  include PageObject::PageFactory
  include SyncTolerance

end