require 'page-object'
require 'sync_tolerance'

class ProposalLineItemPage < BasePage
  include PageObject
  include SyncTolerance

  #information left column
  cell(:quote_proposal, xpath: "//td[text()='Quote/Proposal']/following-sibling::*[1]")
  cell(:product_line, xpath: "//td[text()='Product Line']/following-sibling::*[1]")
  cell(:card_type, xpath: "//td[text()='Card Type']/following-sibling::*[1]")
  cell(:product, xpath: "//td[text()='Product']/following-sibling::*[1]")
  cell(:product_name, xpath: "//td[text()='Product Name']/following-sibling::*[1]")
  cell(:cdr, xpath: "//td[text()='CDR']/following-sibling::*[1]")
  cell(:waive_premium, xpath: "//td[text()='Waive Premium']/following-sibling::*[1]")
  cell(:escalation_amount, xpath: "//td[text()='Escalation Amount']/following-sibling::*[1]")
  cell(:peak_period_day_premium_amount, xpath: "//td[text()='Peak Period Day Premium Amount']/following-sibling::*[1]")
  cell(:specialty_cards, xpath: "//td[text()='Specialty Cards']/following-sibling::*[1]")
  cell(:escalation_method, xpath: "//td[text()='Escalation Method']/following-sibling::*[1]")
  cell(:regulatory_stop_fee_1, xpath: "//td[text()='Regulatory Stop Fee 1']/following-sibling::*[1]")
  cell(:regulatory_stop_fee_2, xpath: "//td[text()='Regulatory Stop Fee 2']/following-sibling::*[1]")

  #information right column
  cell(:product_hours, xpath: "//td[text()='Product Hours']/following-sibling::*[1]")
  cell(:aircraft_1, xpath: "//td[text()='Aircraft 1']/following-sibling::*[1]")
  cell(:aircraft_2, xpath: "//td[text()='Aircraft 2']/following-sibling::*[1]")
  cell(:bonus_hours, xpath: "//td[text()='Bonus Hours']/following-sibling::*[1]")
  cell(:upgrade_hours, xpath: "//td[text()='Upgrade Hours']/following-sibling::*[1]")
  cell(:upgrade_from_aircraft, xpath: "//td[text()='Upgrade from Aircraft']/following-sibling::*[1]")
  cell(:liability_for_delay_max_amount, xpath: "//td[text()='Max Amount']/following-sibling::*[1]")
  cell(:liability_for_delay_credit_type, xpath: "//td[text()='Credit Type']/following-sibling::*[1]")


  #term left column
  cell(:delayed_start_amount, xpath: "//td[text()='Delayed Start Amount']/following-sibling::*[1]")
  cell(:delayed_start_amount_uom, xpath: "//td[text()='Delayed Start Unit of Measure (UOM)']/following-sibling::*[1]")
  cell(:initial_term_amount, xpath: "//td[text()='Initial Term Amount']/following-sibling::*[1]")
  cell(:initial_term_amount_uom, xpath: "//td[text()='Initial Term Unit of Measure (UOM)']/following-sibling::*[1]")
  cell(:grace_period_amount, xpath: "//td[text()='Grace Period Amount']/following-sibling::*[1]")
  cell(:grace_period_amount_uom, xpath: "//td[text()='Grace Period Unit of Measure (UOM)']/following-sibling::*[1]")

  #term right column
  cell(:three_month_avg_fuel_cost, xpath: "//td[text()='3 Month Average Fuel Cost']/following-sibling::*[1]")
  cell(:fuel_annual, xpath: "//td[text()='Fuel Annual']/following-sibling::*[1]")
  cell(:aircraft_1_hours, xpath: "//td[text()='Aircraft 1 Hours']/following-sibling::*[1]")
  cell(:aircraft_2_hours, xpath: "//td[text()='Aircraft 2 Hours']/following-sibling::*[1]")
  cell(:occupied_flight_hours, xpath: "//td[text()='Occupied Flight Hours']/following-sibling::*[1]")

  #payment information left column
  cell(:pre_tax_purchase_price, xpath: "//td[text()='Pre-Tax Purchase Price']/following-sibling::*[1]")
  cell(:adjustment_total, xpath: "//td[text()='Adjustment Total']/following-sibling::*[1]")
  cell(:net_adjustment_percent, xpath: "//td[text()='Net Adjustment (%)']/following-sibling::*[1]")
  cell(:waived_premium_discount, xpath: "//td[text()='Waived Premium Discount']/following-sibling::*[1]")
  cell(:tax_amount, xpath: "//td[text()='Tax Amount']/following-sibling::*[1]")
  cell(:total_price, xpath: "//td[text()='Total Price']/following-sibling::*[1]")
  cell(:prepaid_fuel_type, xpath: "//td[text()='Prepaid Fuel Type']/following-sibling::*[1]")
  cell(:prepaid_fuel_amount, xpath: "//td[text()='Prepaid Fuel Amount']/following-sibling::*[1]")
  cell(:prepaid_incidentals, xpath: "//td[text()='Prepaid Incidentals']/following-sibling::*[1]")
  cell(:operating_expense_fund, xpath: "//td[text()='Operating Expense Fund']/following-sibling::*[1]")
  cell(:total_agreement_value, xpath: "//td[text()='Total Agreement Value']/following-sibling::*[1]")

  #payment information right column
  cell(:program, xpath: "//td[text()='Program']/following-sibling::*[1]")
  cell(:accounting_company, xpath: "//td[text()='Accounting Company']/following-sibling::*[1]")
  cell(:preferred_bank, xpath: "//td[text()='Preferred Bank']/following-sibling::*[1]")
  cell(:payment_terms, xpath: "//td[text()='Payment Terms']/following-sibling::*[1]")
  cell(:payment_terms_uom, xpath: "//td[text()='Payment Terms UOM']/following-sibling::*[1]")

  def edit_proposal_line_item
    patiently { self.edit }
    patiently { self.wait_until { (self.text.include? "Proposal Line Item Edit") }}
  end

end
