require 'page-object'
require_relative '../watir_helper'
class LandingPage
  include PageObject
  include PageObject::PageFactory

  def goto_object(object_id)
    sleep 3
    @browser.goto("#{WatirHelper.current_base_url(@browser.url)}/#{object_id}")
  end

  def goto_uri(uri)
    @browser.goto(uri)
  end

end
