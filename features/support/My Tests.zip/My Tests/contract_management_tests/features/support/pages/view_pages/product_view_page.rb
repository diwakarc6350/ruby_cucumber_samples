require 'page-object'

class ProductViewPage < BasePage
  include PageObject

  #product information left column
  cell(:product_name, xpath: "//td[text()='Product Name']/following-sibling::*[1]")
  cell(:what_type_of_card, xpath: "//td[text()='What type of card?']/following-sibling::*[1]")
  cell(:how_many_hours, xpath: "//td[text()='How many hours?']/following-sibling::*[1]")
  cell(:what_type_of_aircraft, xpath: "//td[text()='What type of aircraft?']/following-sibling::*[1]")
  cell(:what_type_of_second_aircraft, xpath: "//td[text()='What type of second aircraft?']/following-sibling::*[1]")
  cell(:fuel_type_ac_1, xpath: "//td[text()='Fuel Type AC1']/following-sibling::*[1]")
  cell(:fuel_type_ac_2, xpath: "//td[text()='Fuel Type AC2']/following-sibling::*[1]")
  cell(:min_flight_seg_rules_ac_1, xpath: "//td[text()='Minimum Flight Segment Rules Amount AC1']/following-sibling::*[1]")
  cell(:min_flight_seg_rules_ac_2, xpath: "//td[text()='Minimum Flight Segment Rules Amount AC2']/following-sibling::*[1]")
  cell(:min_flight_seg_rules__uom_ac_1, xpath: "//td[text()='Minimum Flight Segment Rules UOM AC1']/following-sibling::*[1]")
  cell(:min_flight_seg_rules__uom_ac_2, xpath: "//td[text()='Minimum Flight Segment Rules UOM AC2']/following-sibling::*[1]")

  #product information right column
  cell(:record_type, xpath: "//td[text()='Record Type']/following-sibling::*[1]")
  cell(:active, xpath: "//td[text()='Active']/following-sibling::*[1]")
  cell(:product_number, xpath: "//td[text()='Product Number']/following-sibling::*[1]")
  cell(:configuration_type, xpath: "//td[text()='Configuration Type']/following-sibling::*[1]")
  cell(:product_line, xpath: "//td[text()='Product Line']/following-sibling::*[1]")
  cell(:specialty_cards, xpath: "//td[text()='Specialty Cards']/following-sibling::*[1]")

  #product term left column
  cell(:effective_date, xpath: "//td[text()='Effective Date']/following-sibling::*[1]")
  cell(:expiration_date, xpath: "//td[text()='Expiration Date']/following-sibling::*[1]")
  cell(:initial_term_amount, xpath: "//td[text()='Initial Term Amount']/following-sibling::*[1]")
  cell(:initial_term_amount_uom, xpath: "//td[text()='Initial Term Unit of Measure (UOM)']/following-sibling::*[1]")
  cell(:escalation_amount, xpath: "//td[text()='Description']/following-sibling::*[1]")

  #product term right column
  cell(:delayed_start_amount, xpath: "//td[text()='Delayed Start Amount']/following-sibling::*[1]")
  cell(:delayed_start_amount_uom, xpath: "//td[text()='Delayed Start Unit of Measure (UOM)']/following-sibling::*[1]")
  cell(:grace_period_amount, xpath: "//td[text()='Grace Period Amount']/following-sibling::*[1]")
  cell(:grace_period_amount_uom, xpath: "//td[text()='Grace Period Unit of Measure (UOM)']/following-sibling::*[1]")

  #payment information left column
  cell(:program, xpath: "//td[text()='Program']/following-sibling::*[1]")
  cell(:bank_account, xpath: "//td[text()='Bank Account']/following-sibling::*[1]")
  cell(:payment_terms_amount, xpath: "//td[text()='Payment Terms Amount']/following-sibling::*[1]")
  cell(:payment_terms_uom, xpath: "//td[text()='Payment Terms UOM']/following-sibling::*[1]")

  #payment information right column
  cell(:purchase_price_tax_percentage, xpath: "//td[text()='Purchase Price Tax Percentage']/following-sibling::*[1]")
  cell(:prepaid_incidentals, xpath: "//td[text()='Prepaid Incidentals']/following-sibling::*[1]")
  cell(:operating_expense_fund, xpath: "//td[text()='Operating Expense Fund']/following-sibling::*[1]")

  #taxes and fees information left column
  cell(:excess_flying_prepay, xpath: "//td[text()='Excess Flying Prepay']/following-sibling::*[1]")
  cell(:excess_flying_hourly_tax, xpath: "//td[text()='Excess Flying Hourly Tax (FET)']/following-sibling::*[1]")
  cell(:fuel_tax, xpath: "//td[text()='Fuel Tax % (FET)']/following-sibling::*[1]")

  #taxes and fees information right column
  cell(:description, xpath: "//td[text()='Ground Handling Fee']/following-sibling::*[1]")
  cell(:regulatory_stop_fee_1, xpath: "//td[text()='Regulatory Stop Fee 1']/following-sibling::*[1]")
  cell(:regulatory_stop_fee_2, xpath: "//td[text()='Regulatory Stop Fee 2']/following-sibling::*[1]")
  cell(:applicable_cpi_escalation, xpath: "//td[text()='Applicable CPI Escalation	']/following-sibling::*[1]")

  #peak period days information left column
  cell(:peak_period_day_departure_adjustment, xpath: "//td[text()='Peak Period Day Departure Adjustment']/following-sibling::*[1]")
  cell(:peak_period_day_departure_adjustment_uom, xpath: "//td[text()='Peak Period Day Departure Adjustment UOM']/following-sibling::*[1]")

  #peak period days information left column
  cell(:ppd_premium_amount, xpath: "//td[text()='PPD Premium % Amount']/following-sibling::*[1]")
  cell(:ppd_premium_effective_date, xpath: "//td[text()='PPD Premium Effective Date']/following-sibling::*[1]")

  cell(:description, xpath: "//td[text()='Description']/following-sibling::*[1]")


  #operational information right column
  cell(:liability_for_delay_max_amount, xpath: "//td[text()='Liability for Flight Delay Max Amount']/following-sibling::*[1]")
  cell(:liability_for_delay_credit_type, xpath: "//td[text()='Liability for Flight Delay Credit Type']/following-sibling::*[1]")
end
