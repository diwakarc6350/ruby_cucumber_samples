require 'page-object'
class ProposalEditPage
  include PageObject

  img(:configure_products, alt: 'Configure Products')
  img(:send_proposal_to_customer, alt: 'Present')
  img(:new_legal_entity, alt: 'New Legal Entity')
  link(:change_document, text: '[Change]')
  select_list(:document_types, id: 'p3')
  button(:continue, value: 'Continue')
  img(:chevrons, alt: 'Draft_Proposal_Chevrons')
  button(:save, name: 'save')
  text_field(:signatory, xpath: "//*[contains(. ,'Signatory')]/following::td[1]//input[@type='text']")
  text_field(:lead_passenger, xpath: "//label[contains(. ,'Lead Passenger')]/following::td[1]//input[@type='text']")
  text_field(:legal_entity, xpath: "//label[contains(. ,'Legal Entity')]/following::td[1]//input[@type='text']")
  text_field(:primary_phone, xpath: "//label[text()='Primary Phone']/following::td[1]//input[@type='text']")
  text_field(:email, xpath: "//*[contains(. ,'Email')]/following::td[1]//input[@type='text']")
  text_field(:secondary_phone, xpath: "//*[contains(. ,'Secondary Phone')]/following::td[1]//input[@type='text']")
  text_field(:billing_city, xpath: "//*[contains(. ,'Billing City')]/following::td[1]//input[@type='text']")
  text_area(:billing_street, xpath: "//*[contains(. ,'Billing Street')]/following::td[1]//textarea")
  text_field(:billing_state, xpath: "//*[contains(. ,'Billing State')]/following::td[1]//input[@type='text']")
  text_field(:billing_postal_code, xpath: "//*[contains(. ,'Billing Postal Code')]/following::td[1]//input[@type='text']")
  text_field(:billing_country, xpath: "//*[contains(. ,'Billing Country')]/following::td[1]//input[@type='text']")
  select_list(:method_of_delivery, xpath: "//*[contains(. ,'Method of Delivery')]/following::td[1]//select")
  text_field(:fuel_rate_to_use, xpath: "//label[text()='Fuel Rate']/following::td[1]//input[@type='text']")
  text_field(:delivery_email_1, xpath: "//label[text()='Delivery Email 1']/following::td[1]//input[@type='text']")
  text_field(:delivery_email_2, xpath: "//label[text()='Delivery Email 2']/following::td[1]//input[@type='text']")
  text_field(:delivery_cc_email_1, xpath: "//label[text()='Delivery CC Email 1']/following::td[1]//input[@type='text']")
  text_field(:delivery_cc_email_2, xpath: "//label[text()='Delivery CC Email 2']/following::td[1]//input[@type='text']")

  #Actions
  select_list(:adjustment_type, xpath: "//*[contains(. ,'Adjustment Type')]/following::td[1]//select")
  text_field(:adjustment_amount, xpath: "//*[contains(. ,'Adjustment Amount')]/following::td[1]//input[@type='text']")
  checkbox(:waive_premium, xpath: "//*[contains(. ,'Waive Premium')]/following-sibling::*[1]/input")
  checkbox(:world_check, xpath: "//*[contains(. ,'World Check')]/following-sibling::*[1]/input")

  def open_product_config
    patiently { self.configure_products_element.click }
  end

  def save_document_type
    self.continue
  end

end