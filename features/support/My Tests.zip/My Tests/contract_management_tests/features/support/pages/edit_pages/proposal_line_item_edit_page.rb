require 'page-object'
class ProposalLineItemEditPage < BasePage
  include PageObject

  checkbox(:cdr, xpath: "//*[contains(. ,'CDR')]/following::td[1]//input")
  checkbox(:waive_premium, xpath: "//*[contains(. ,'Waive Premium')]/following::td[1]//input")
  checkbox(:waive_FET, xpath: "//*[contains(. ,'Waive FET')]/following::td[1]//input")
  text_field(:aircraft_1, xpath: "//*[contains(. ,'Aircraft 1')]/following::td[1]//input[@type='text']")
  text_field(:aircraft_2, xpath: "//*[contains(. ,'Aircraft 2')]/following::td[1]//input[@type='text']")
  select_list(:regulatory_stop_fee_1, xpath: "//*[text()='Regulatory Stop Fee 1']/following::td[1]//select")
  select_list(:regulatory_stop_fee_2, xpath: "//*[text()='Regulatory Stop Fee 2']/following::td[1]//select")

  select_list(:delayed_start_amount, xpath: "//*[text()='Delayed Start Amount']/following::td[1]//select")
  select_list(:initial_term_amount, xpath: "//*[text()='Initial Term Amount']/following::td[1]//select")
  select_list(:initial_term_amount_uom, xpath: "//*[text()='Initial Term Unit of Measure (UOM)']/following::td[1]//select")
  select_list(:grace_period_amount, xpath: "//*[text()='Grace Period Amount']/following::td[1]//select")
  select_list(:esclation_method, xpath: "//*[text()='Escalation Method']/following::td[1]//select")
  select_list(:prepaid_fuel_type, xpath: "//*[text()='Prepaid Fuel Type']/following::td[1]//select")
  text_field(:prepaid_incidentals, xpath: "//*[text()='Prepaid Incidentals']/following::td[1]//input[@type='text']")
  text_field(:aircraft_1_hours, xpath: "//*[text()='Aircraft 1 Hours']/following::td[1]//input[@type='text']")
  text_field(:aircraft_2_hours, xpath: "//*[text()='Aircraft 2 Hours']/following::td[1]//input[@type='text']")
  text_field(:occupied_flight_hours, xpath: "//*[text()='Occupied Flight Hours']/following::td[1]//input[@type='text']")

  text_field(:liability_for_delay_max_amount, xpath: "//*[text()='Max Amount']/following::td[1]//input[@type='text']")
  select_list(:liability_for_delay_credit_type, xpath: "//*[text()='Credit Type']/following::td[1]//select")

  def cdr_checkbox
    @browser.checkbox(xpath: "//*[contains(. ,'CDR')]/following::td[1]//input")
  end

  def waive_premium_checkbox
    @browser.checkbox(xpath: "//*[contains(. ,'Waive Premium')]/following::td[1]//input")
  end

  def waive_FET_checkbox
    @browser.checkbox(xpath: "//*[contains(. ,'Waive FET')]/following::td[1]//input")
  end

end


