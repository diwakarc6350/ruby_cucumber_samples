require 'page-object'

class ProductConfigurationViewPage < BasePage
  include PageObject
end