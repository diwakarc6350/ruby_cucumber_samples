require 'page-object'
require 'sync_tolerance'

class AgreementEditPage < BasePage
  include PageObject
  include PageObject::PageFactory
  include SyncTolerance

  #Actions
  select_list(:status_category, xpath: "//label[text() ='Status Category']/../following-sibling::*[1]//select")
  select_list(:status, xpath: "//label[text() ='Status']/../following-sibling::*[1]//select")
  select_list(:signing_state, xpath: "//label[text() ='Signing State']/../following-sibling::*[1]//select")
  select_list(:approval_status, xpath: "//label[text() ='Approval Status']/../following-sibling::*[1]//select")

  #Product Information
  text_field(:card_type, xpath: "//label[contains(. ,'Card Type')]/../following-sibling::*[1]//input")
  text_field(:occupied_flight_hours, xpath: "//label[contains(. ,'Occupied Flight Hours')]/../following-sibling::*[1]//input")
  text_field(:aircraft_type_1, xpath: "//label[contains(. ,'Aircraft Type 1')]/../following-sibling::*[1]//input")
  text_field(:aircraft_type_2, xpath: "//label[contains(. ,'Aircraft Type 2')]/../following-sibling::*[1]//input")
  select_list(:product_sub_type, xpath: "//label[contains(. ,'Product Sub-Type')]/../following-sibling::*[1]//select")
  text_field(:ppd_premium, xpath: "//label[text() ='Peak Period Day Premium']/../following-sibling::*[1]//input")

  #Term
  select_list(:delayed_start_amount, xpath: "//label[text()='Delayed Start Amount']/../following-sibling::*[1]//select")
  select_list(:delayed_start_amount_uom, xpath: "//label[text()='Delayed Start Unit of Measure (UOM)']/../following-sibling::*[1]//select")
  select_list(:initial_term_amount, xpath: "//label[text()='Initial Term Amount']/../following-sibling::*[1]//select")
  select_list(:initial_term_amount_uom, xpath: "//label[text()='Initial Term Unit of Measure (UOM)']/../following-sibling::*[1]//select")
  select_list(:grace_period_amount, xpath: "//label[text()='Grace Period Amount']/../following-sibling::*[1]//select")
  select_list(:grace_period_amount_uom, xpath: "//label[text()='Grace Period Unit of Measure (UOM)')]/../following-sibling::*[1]//select")
  text_field(:extended_term_amount, xpath: "//label[text()='Extended Term Amount']/../following-sibling::*[1]//input")
  select_list(:extended_term_amount_uom, xpath: "//label[text()='Extended Term UOM']/../following-sibling::*[1]//select")

  text_field(:funding_date, xpath: "//label[text()='Funding Date']/../following-sibling::*[1]//input")
  text_field(:first_flight_date, xpath: "//label[text()='First Flight Date']/../following-sibling::*[1]//input")
  text_field(:delayed_start_date, xpath: "//label[text()='Effective / Delayed Start Date']/../following-sibling::*[1]//input")
  text_field(:initial_term_expiration_date, xpath: "//label[text()='Initial Term Expiration Date']/../following-sibling::*[1]//input")
  text_field(:grace_period_end_date, xpath: "//label[text()='Grace Period End Date']/../following-sibling::*[1]//input")
  text_field(:termination_date, xpath: "//label[text()='Termination Date']/../following-sibling::*[1]//input")

  #Entity Information
  text_field(:card_number, xpath: "//label[text()='Card Number']/../following-sibling::*[1]//input")
  text_field(:agreement_name, xpath: "//label[text()='Agreement Name']/../following-sibling::*[1]//input")
  text_field(:account, xpath: "//label[text()='Account']/../following-sibling::*[1]//input[@type!='hidden']")
  text_field(:legal_entity, xpath: "//label[text()='Legal Entity']/../following-sibling::*[1]//input[@type!='hidden']")
  text_field(:signatory, xpath: "//label[text()='Signatory']/../following-sibling::*[1]//input[@type!='hidden']")
  text_field(:related_quote_proposal, xpath: "//label[text()='Related Quote/Proposal']/../following-sibling::*[1]//input[@type!='hidden']")
  text_field(:related_oportunity, xpath: "//label[text()='Related Opportunity']/../following-sibling::*[1]//input[@type!='hidden']")
  text_field(:requestor, xpath: "//label[text()='Requestor']/../following-sibling::*[1]//input[@type!='hidden']")

  text_field(:delivery_email_1, xpath: "//label[text()='Delivery Email 1']/../following-sibling::*[1]//input[@type!='hidden']")
  text_field(:delivery_email_2, xpath: "//label[text()='Delivery Email 2']/../following-sibling::*[1]//input[@type!='hidden']")
  text_field(:delivery_cc_email_1, xpath: "//label[text()='Delivery CC Email 1']/../following-sibling::*[1]//input[@type!='hidden']")
  text_field(:delivery_cc_email_2, xpath: "//label[text()='Delivery CC Email 2']/../following-sibling::*[1]//input[@type!='hidden']")

  #Payment Information
  text_field(:credit, xpath: "//label[text() ='Credit']/../following-sibling::*[1]//input")
  checkbox(:waive_fet, xpath: "//label[text()='Waive FET	']/../following-sibling::*[1]//input")
  select_list(:prepaid_fuel_type, xpath: "//label[text() ='Prepaid Fuel Type']/../following-sibling::*[1]//select")
  text_field(:prepaid_incidentals, xpath: "//label[text() ='Prepaid incidentals']/../following-sibling::*[1]//input")
  text_field(:operating_expense_fund, xpath: "//label[text() ='Operating Expense Fund']/../following-sibling::*[1]//input")

  select_list(:funding_state, xpath: "//label[text() ='Funding State']/../following-sibling::*[1]//select")
  text_field(:payment_terms, xpath: "//label[text() ='Payment Terms']/../following-sibling::*[1]//input")
  select_list(:payment_terms_uom, xpath: "//label[text() ='Payment Terms UOM']/../following-sibling::*[1]//select")
  text_field(:ar_number, xpath: "//label[text() ='AR Number']/../following-sibling::*[1]//input")

  #operational information
  text_field(:fuel_variable_rate_1, xpath: "//label[text() = 'Fuel Variable Rate 1']/../following-sibling::*[1]//input")
  text_field(:fuel_variable_rate_2, xpath: "//label[text() = 'Fuel Variable Rate 2']/../following-sibling::*[1]//input")
  select_list(:ppd_departure_adjustment_amount, xpath: "//label[contains(. ,'PPD Departure Adjustment Amount')]/../following-sibling::*[1]//select")
  select_list(:ppd_departure_adjustment_amount_uom, xpath: "//label[contains(. ,'PPD Departure Adjustment UOM')]/../following-sibling::*[1]//select")
  select_list(:customer_is_late_amount, xpath: "//label[text()='Customer is Late Amount']/../following-sibling::*[1]//select")
  select_list(:customer_is_late_amount_uom, xpath: "//label[text() = 'Customer is Late UOM]/../following-sibling::*[1]//select")
  select_list(:netjets_is_late_amount, xpath: "//label[text()='NetJets is Late Amount']/../following-sibling::*[1]//select")
  select_list(:netjets_is_late_amount_uom, xpath: "//label[text()='NetJets is Late UOM']/../following-sibling::*[1]//select")
  text_field(:liability_for_flight_delay_max_amount, xpath: "//label[text()='Liability for Flight Delay Max Amount']/../following-sibling::*[1]//input")
  select_list(:liability_for_flight_delay_credit_type, xpath: "//label[text()='Liability for Flight Delay Credit Type']/../following-sibling::*[1]//select")
  checkbox(:can_sub_contract, xpath: "//label[text()='Can Sub-Contract']/../following-sibling::*[1]//input")

  def save_agreement
    patiently { self.save }
    patiently { self.wait_until { (self.text.include? "Agreement Detail") } }
  end

  def expected_values
    {:status_category => ['--None--', 'Request', 'In Authoring', 'In Signatures', 'In Filing', 'In Effect',
                          'Expired', 'Terminated', 'Amended', 'Cancelled'],
     :status => ['--None--', 'Request', 'Request Approval', 'Submitted Request',
                 'Approved Request', 'Cancelled Request', 'In Amendment'],
     :signing_state => ['--None--', 'Pending Signature', 'Pending Countersignature (accepted by payment)',
                        'Owner Signature Received', 'Owner Signed and Countersigned',
                        'Countersigned (accepted by payment)'],

     :approval_status => ['--None--', 'None', 'Approval Required', 'Not Submitted',
                          'Pending Approval', 'Approved', 'Rejected', 'Cancelled'],
     :delayed_start_amount => %w[--None-- 0 6 7 8 9 10 11 12],
     :extended_term_amount => %w[--None-- 6 12 0],
     :grace_period_amount => %w[--None-- 6 12 0],
     :initial_term_amount => %w[--None-- 12 18 24 36 0],
     :ppd_departure_adjustment_amount => %w[--None-- 3.0 2.5 2.0 1.5 1.0],
     :peak_period_departure_adj_uom => %w[hours],
     :customer_is_late_amount => %w[--None-- 60 90 120],
     :customer_is_late_uom => %w[minutes],
     :netjets_is_late_amount => %w[--None-- 60 90 120],
     :netjets_is_late_uom => %w[minutes]
    }
  end

end


