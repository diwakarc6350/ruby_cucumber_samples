require 'page-object'
require 'features/support/watir_helper'

class LegalEntityEditPage
  include PageObject
  include PageObject::PageFactory

  #Actions
  button(:save, value: 'Save')

  #Legal Entity Information
  text_field(:legal_entity_name, xpath: "//*[contains(.,'Legal Entity Name')]/../following-sibling::*[1]/div/input[@type = 'text']")
  text_field(:legal_email_address, xpath: "//*[contains(.,'Legal Email Address')]/../following-sibling::*[1]/div/input[@type = 'text']")
  text_field(:account, xpath: "//*[contains(.,'Account')]/../following-sibling::*[1]/div/span/input[@type = 'text']")
  text_field(:legal_phone_number, xpath: "//*[contains(.,'Legal Phone Number')]/../following-sibling::*[1]/div/input[@type = 'text']")

  #Legal Entity Information EUR
  text_field(:authorized_signatory_name, xpath: "//*[contains(.,'Authorized Signatory Name')]/../following-sibling::*[1]/div/input[@type = 'text']")
  text_field(:authorized_signatory_title, xpath: "//*[contains(.,'Authorized Signatory Title')]/../following-sibling::*[1]/div/input[@type = 'text']")
  text_field(:VAT_number, xpath: "//*[contains(.,'VAT Number')]/../following-sibling::*[1]/div/input[@type = 'text']")

  #Legal Entity Address
  text_area(:legal_entity_address_street, xpath: "//h3[contains(.,'Legal Entity Address')]/following::label[contains(., 'Street')]/following::textarea")
  text_field(:legal_entity_address_city, xpath: "//h3[contains(.,'Legal Entity Address')]/following::label[contains(., 'City')]/following::input")
  text_field(:legal_entity_address_state, xpath: "//h3[contains(.,'Legal Entity Address')]/following::label[contains(., 'State')]/following::input")
  text_field(:legal_entity_address_postal_code, xpath: "//h3[contains(.,'Legal Entity Address')]/following::label[contains(., 'Postal Code')]/following::input")
  text_field(:legal_entity_address_country, xpath: "//h3[contains(.,'Legal Entity Address')]/following::label[contains(., 'Country')]/following::input")

  #Legal Notice Address US
  text_area(:legal_notice_address_street, xpath: "//h3[contains(.,'Legal Notice Address')]/following::label[contains(., 'Street')]/following::textarea")
  text_field(:legal_notice_address_city, xpath: "//h3[contains(.,'Legal Notice Address')]/following::label[contains(., 'City')]/following::input")
  text_field(:legal_notice_address_state, xpath: "//h3[contains(.,'Legal Notice Address')]/following::label[contains(., 'State')]/following::input")
  text_field(:legal_notice_address_postal_code, xpath: "//h3[contains(.,'Legal Notice Address')]/following::label[contains(., 'Postal Code')]/following::input")
  text_field(:legal_notice_address_country, xpath: "//h3[contains(.,'Legal Notice Address')]/following::label[contains(., 'Country')]/following::input")

  #Correspondence Address EUR
  text_area(:correspondence_address_street, xpath: "//h3[contains(.,'Correspondence Address')]/following::label[contains(., 'Street')]/following::textarea")
  text_field(:correspondence_address_city, xpath: "//h3[contains(.,'Correspondence Address')]/following::label[contains(., 'City')]/following::input")
  text_field(:correspondence_address_state, xpath: "//h3[contains(.,'Correspondence Address')]/following::label[contains(., 'State')]/following::input")
  text_field(:correspondence_address_postal_code, xpath: "//h3[contains(.,'Correspondence Address')]/following::label[contains(., 'Postal Code')]/following::input")
  text_field(:correspondence_address_country, xpath: "//h3[contains(.,'Correspondence Address')]/following::label[contains(., 'Country')]/following::input")

  #Billing Address EUR
  text_area(:billing_address_street, xpath: "//h3[contains(.,'Billing Address')]/following::label[contains(., 'Street')]/following::textarea")
  text_field(:billing_address_city, xpath: "//h3[contains(.,'Billing Address')]/following::label[contains(., 'City')]/following::input")
  text_field(:billing_address_state, xpath: "//h3[contains(.,'Billing Address')]/following::label[contains(., 'State')]/following::input")
  text_field(:billing_address_postal_code, xpath: "//h3[contains(.,'Billing Address')]/following::label[contains(., 'Postal Code')]/following::input")
  text_field(:billing_address_country, xpath: "//h3[contains(.,'Billing Address')]/following::label[contains(., 'Country')]/following::input")

end
