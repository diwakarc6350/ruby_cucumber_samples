require 'page-object'

class PaymentEntryViewPage < BasePage
  include PageObject
end