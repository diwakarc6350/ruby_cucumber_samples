require 'page-object'
class ShoppingCartPage
  include PageObject
  include SyncTolerance

  img(:chevrons, alt: 'Draft_Proposal_Chevrons')
  link(:update_pricing, text: 'Update Price')
  link(:back_to_catalog, text: 'Back To Catalog')
  img(:miscellaneous_products, xpath: "//div[text()='Miscellaneous']/preceding-sibling::*//img")
  img(:card_products, xpath: "//div[text()='Card']/preceding-sibling::*//img")
  img(:enhancement_products, xpath: "//div[text()='Enhancement']/preceding-sibling::*//img")
  link(:what_type_of_card_filter, xpath: "//a[text()='What type of card?']")
  unordered_list(:what_type_of_card_list, xpath: "//a[text()='What type of card?']/following::*[1]")
  link(:what_type_of_aircraft_filter, xpath: "//a[text()='What type of aircraft?']")
  link(:how_many_hours_filter, xpath: "//a[text()='How many hours?']")
  text_field(:product_search, xpath: "//input[@type='text' and @placeholder='Search here']")
  span(:cdr_error, xpath: '//div[@class="content"]/span')

  div(:miscellaneous, text: 'Miscellaneous')
  div(:enhancement, text: 'Enhancement')
  div(:card, text: 'Card')

  link(:go_to_proposal, text: 'Go To Proposal')
  link(:go_to_cdr, text: 'Go To CDR')

  page_section(:bonus_hours_configuration, BonusHoursSection, xpath: '//*[@id="Bonus Hours"]/..')
  page_section(:upgrade_at_1_to_1, UpgradeAtOneToOneSection, xpath: '//*[@id="Upgrade at 1:1"]/..')
  spans(:products, xpath: '//span[@class="aptSearchProductName"]')

  def open_miscellaneous
    patiently { self.miscellaneous_element.click }
    self.wait_until { (self.text.include? 'Demo') || (self.text.include? 'Promo') || (self.text.include? 'Redemption') }
  end

  def open_enhancements
    patiently { self.enhancement_element.click }
  end

  def open_cards
    patiently { self.card_element.click }
    self.wait_until { patiently { self.products_elements.count > 0 } }
  end

  def back_to_proposal
    patiently { self.go_to_proposal }
    patiently { wait_until { @browser.text.include?("Quote/Proposal Detail") } }
  end

  def add_to_cart(product_name)
    sleep(5)
    patiently { self.products_elements.first.exists? }
    product = self.products_elements.find { |product| product.text =~ /#{product_name}/ }
    # self.wait_until {product.a(xpath: './following::a').exists?}
    product_setup_required = product.a(xpath: './following::a').text == 'Configure'
    product.a(xpath: './following::a').click
    patiently { product.label(xpath: './following::label[text()="Selected"]').visible? } unless product_setup_required
    sleep(5)
  end

end
