require 'page-object'
require 'sync_tolerance'

class ApprovalRequestEditPage < BasePage
  include PageObject
  include PageObject::PageFactory
  include SyncTolerance

end