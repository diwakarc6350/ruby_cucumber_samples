require 'page-object'

class InterchangeRateViewPage < BasePage
  include PageObject
  include PageObject::PageFactory

end