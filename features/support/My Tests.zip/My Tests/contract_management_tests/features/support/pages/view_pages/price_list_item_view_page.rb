require 'page-object'

class PriceListItemViewPage < BasePage
  include PageObject
end