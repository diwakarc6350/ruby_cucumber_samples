require 'page-object'
require_relative "#{File.dirname(__FILE__)}/sections/approval_requests_section"
require_relative "#{File.dirname(__FILE__)}/sections/agreements_section"

class ProposalViewPage < BasePage
  include PageObject
  include DataMagic
  include SyncTolerance

  LineItemInfo = Struct.new(:product_line, :product_name, :pretax_price, :tax_amount, :total_price)

  img(:chevrons, alt: 'Draft_Proposal_Chevrons')
  #Actions
  img(:configure_products, alt: 'Configure Products')
  img(:send_proposal_to_customer, alt: 'Present')
  select_list(:document_types, id: 'p3')
  button(:continue, value: 'Continue')
  button(:return, value: 'Return')
  button(:send_for_approval, title: 'Send for Approval')
  button(:save, title: 'Save')

  cell(:fuel_rate_to_use, xpath: "//td[text()='Fuel Rate to Use']/following-sibling::*")
  div(:proposal_type, xpath: "//td[text()='Proposal Type']/following::td[1]/div")
  div(:proposal_language, xpath: "//td/span[text()='Proposal Language']/following::td[1]/div")
  div(:proposal_line_item, xpath: "//td[text()='Proposal Line Item']/following::td[1]/div")
  div(:signatory, xpath: "//td[text()='Signatory']/following::td[1]/div")
  div(:world_check, xpath: "//td[text()='World Check']/following::td[1]/div")
  #CDR page 
  #div(:configure_products, xpath:  "//td[text()='Configure Products']/following::td[1]/div")
  cell(:send_for_approval, xpath: "//td[text()='Send for Approval']/following::td[1]")
  div(:waive_premium, xpath: "//td[text()='Waive Premium']/following::td[1]/div")
  div(:waive_fet, xpath: "//td/span[text()='Waive FET']/following::td[1]/div")
  div(:adjustment_type, xpath: "//td[text()='Adjustment Type']/following::td[1]/div")
  div(:adjustment_amount, xpath: "//td[text()='Adjustment Amount']/following::td[1]/div")
  # div(:world_check, xpath:  "//td[text()='World Check']/following::td[1]/div")
  cell(:create_proposal, xpath: "//td[text()='Create Proposal']/following::td[1]")


  #Information
  cell(:proposal_name, xpath: "//td[text()='Proposal Name']/following-sibling::*[1]")
  cell(:what_type_of_card, xpath: "//td[text()='What type of card?']/following-sibling::*[1]")
  div(:approval_stage, xpath: "//td[text()='Approval Stage']/following::td[1]/div")
  div(:approval_status, xpath: "//td[text()='Approval Status']/following::td[1]/div")
  div(:record_type, xpath: "//td[text()='Record Type']/following::td[1]/div")

  #Entity Information
  cell(:account, xpath: "//td[text()='Account']/following-sibling::*[1]")
  cell(:opportunity, xpath: "//td[text()='Opportunity']/following-sibling::*[1]")
  cell(:primary_contact, xpath: "//td[text()='Primary Contact']/following-sibling::*[1]")
  cell(:owner_is, xpath: "//td[text()='Owner Is']/following-sibling::*[1]")
  cell(:lead_passenger, xpath: "//td[text()='Lead Passenger']/following-sibling::*[1]")
  cell(:legal_entity, xpath: "//td[text()='Legal Entity']/following-sibling::*[1]")
  img(:new_legal_entity, alt: 'New Legal Entity')
  cell(:signatory, xpath: "//td[text()='Signatory']/following-sibling::*[1]")
  cell(:method_of_delivery, xpath: "//td[text()='Method of Delivery']/following-sibling::*[1]")
  cell(:primary_phone, xpath: "//td[text()='Primary Phone']/following-sibling::*[1]")
  cell(:secondary_phone, xpath: "//td[text()='Secondary Phone']/following-sibling::*[1]")
  cell(:fax, xpath: "//td[text()='Fax']/following-sibling::*")
  cell(:delivery_email_1, xpath: "//td[text()='Delivery Email 1']/following-sibling::*")
  cell(:delivery_email_2, xpath: "//td[text()='Delivery Email 2']/following-sibling::*")
  cell(:delivery_cc_email_1, xpath: "//td[text()='Delivery CC Email 1']/following-sibling::*")
  cell(:delivery_cc_email_2, xpath: "//td[text()='Delivery CC Email 2']/following-sibling::*")

  #Comments
  cell(:proposal_comments, xpath: "//td[text()='Proposal Comments']/following-sibling::*[1]")

  #System Information
  cell(:created_by, xpath: "//td[text()='Created By']/following-sibling::*[1]")
  cell(:last_modified_by, xpath: "//td[text()='Last Modified By']/following-sibling::*[1]")
  #CDR
  div(:price_list_name, xpath:  "//td[text()='Price List Name']/following::td[1]/div")
  div(:price_list, xpath:  "//td[text()='Price List']/following::td[1]/div")
  div(:initial_term_amount, xpath:  "//td[text()='Initial Term Amount']/following::td[1]/div")
  div(:specialty_cards, xpath:  "//td[text()='Specialty Cards']/following::td[1]/div")


  img(:draft_chevron, alt: 'Draft_Proposal_Chevrons')
  img(:proposal_chevron, alt: 'Proposal_Proposal_Chevrons')
  img(:cdr_created_chevron, alt: 'CDR_Created_Proposal_Chevrons')
  img(:waiting_for_approval_chevron, alt: 'Waiting_on_Approval_Proposal_Chevrons')
  img(:cdr_approved_chevron, alt: 'CDR_Approved_Proposal_Chevrons')

  cell(:proposal_total, xpath: "//td[text()='Proposal Total']/following-sibling::*[1]")
  cell(:fuel_rate, xpath: "//td[text()='Fuel Rate']/following-sibling::*[1]")
  link(:change_document, text: '[Change]')


  cell(:internal_comments, xpath: "//td[text()='Internal Comments']/following-sibling::*")

  table(:postal_addresses_line_items, xpath: "//table//h3[text()='Postal Addresses']/../../../following::*[1]/table")

  #text_field(:signatory, xpath: "//*[contains(. ,'Signatory')]/../following-sibling::*/*/*/input")
  #text_field(:lead_passenger, xpath: "//*[contains(. ,'Lead Passenger')]/../following-sibling::*/*/*/input")
  #text_field(:primary_phone, xpath: "//label[text()='Primary Phone']/../following-sibling::*//input")
  text_field(:email, xpath: "//*[contains(. ,'Email')]/../following-sibling::td/*/input")
  #text_field(:secondary_phone, xpath: "//*[contains(. ,'Secondary Phone')]/../following-sibling::*/input")
  text_field(:billing_city, xpath: "//*[contains(. ,'Billing City')]/../following-sibling::*/*/input")
  text_field(:billing_street, xpath: "//*[contains(. ,'Billing Street')]/following-sibling::*/*/textarea")
  text_field(:billing_state, xpath: "//*[contains(. ,'Billing State')]/../following-sibling::*/*/input")
  text_field(:billing_postal_code, xpath: "//*[contains(. ,'Billing Postal Code')]/../following-sibling::*/*/input")
  text_field(:billing_country, xpath: "//*[contains(. ,'Billing Country')]/../following-sibling::*/*/input")
  #select_list(:method_of_delivery, xpath: "//*[contains(. ,'Method of Delivery')]/following-sibling::*/*/*/select")

  cell(:waive_FET, xpath: "//span[text()='Waive FET']/following::td[1]")
  checkbox(:waive_FET_checkbox, xpath: "//span[text()='Waive FET']/following::input[1]")

  # in_frame(index: 1) do |frame|
  #   table(:line_items, xpath: '//table[@class="list"]', frame: frame)
  #   sections(:proposal_line_items, ApprovalRequestsSection, xpath: '//table[@class="list"]/tbody/tr', frame: frame )
  # end

  page_sections(:approval_requests, ApprovalRequestsSection, xpath: "//h3[contains(.,'Approval')]//following::table[1]//tr[position() > 1]")
  page_sections(:agreements, AgreementsSection, xpath: "//h3[contains(.,'Agreements')]//following::table[1]//tr[position() > 1]")

  def proposal_line_items
    patiently do
      table = @browser.iframe(xpath: "//h3[text()='Items']/following::iframe[1]").table(class: 'list').tbody.trs
      self.wait_until { table[0].exist? }
      table.each do |row|
        row.define_singleton_method(:cdr) { row.td(index: 1) }
        row.define_singleton_method(:product_line) { row.td(index: 2) }
        row.define_singleton_method(:product_name) { row.td(index: 3) }
        row.define_singleton_method(:edit) { row.td(index: 0).as[1] }
        table
      end
    end
  end

  def proposal_line_items_struct
    self.proposal_line_items.map do |line_item|
      product = LineItemInfo.new
      product[:product_line] = line_item[2].text
      product[:product_name] = line_item[3].text
      product[:pretax_price] = line_item[4].text
      product[:tax_amount] = line_item[5].text
      product[:total_price] = line_item[6].text
      product
    end
  end

  def create_cdr
    patiently do
      @browser.iframe(xpath: "//*[contains(. ,'Create CDR')]/following::td[1]//iframe").button(value: 'Create CDR').click
    end
    self.wait_until { @browser.button(title: 'Save').exist? }
  end

  def open_first_agreement
    patiently { @browser.a(xpath: "//h3[contains(.,'Agreements')]//following::table[1]//tr[position() > 1]/th/a").click }
  end

  def approve_all_requests
    sleep(5)
    patiently do
      check_for_approvals = lambda { |link| link.text =~ /Approve/ }
      approvals_needed = approvals_needed?

      while approvals_needed
        sections = self.approval_requests.select { |row| row.approval_action_element.links.find(&check_for_approvals) }
        link = sections[0].approval_action_element.links.find(&check_for_approvals)

        unless link.nil?
          link.click
          @browser.button(value: 'Approve').click
        end

        sleep(5)
        approvals_needed = approvals_needed?
      end

    end
  end

  def all_approvals_needed_to_create_agreement
    sleep(5)
    patiently { self.approval_requests.map { |approval| approval.asssigned_to } }
  end

  def approvals_needed?
    approvals = self.approval_requests.select { |row| row.approval_action_element.links.find { |link| link.text =~ /Approve/ } }
    !approvals.empty?
  end

  def save_line_item_changes
    @browser.iframe(xpath: "//h3[text()='Line Item']/following::iframe[1]").button(value: 'Save').click
  end

  def set_primary_product_for_cdr(product_name)
    line_item = self.proposal_line_items.find { |item| item.text =~ /#{product_name}/ }

    line_item.cdr.image.double_click
    line_item.cdr.checkbox.click
    save_line_item_changes
  end

  def edit_product_line_item(product_name)
    line_item = self.proposal_line_items.find { |item| item.text =~ /#{product_name}/ }
    patiently { line_item.edit.click }
  end

  def open_product_config
    patiently { self.configure_products_element.click }
  end

  def save_document_type
    self.continue
  end

  def send_for_approval_n_return
    patiently do
      @browser.iframe(xpath: "//iframe[@title='CS_Send_for_Approval']").button(value: 'Send for Approval').click
    end
    patiently { self.wait_until { (self.text.include? "Submit Quote/Proposal") } }
    patiently { self.return }
    patiently { self.wait_until { self.cdr_approved_chevron_element.present? } }
  end

  def waive_FET
    self.waive_FET_element.double_click
    self.check_waive_FET_checkbox
    self.save
    self.wait_until { !@browser.button(title: 'Cancel').visible? }
  end

end
