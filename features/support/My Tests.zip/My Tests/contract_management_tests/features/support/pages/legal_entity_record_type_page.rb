require 'page-object'
require_relative '../watir_helper'

class LegalEntityRecordTypePage
  include PageObject
  include PageObject::PageFactory

  #Actions
  button(:continue, title: 'Continue')

  #Elements
  select_list(:record_type, xpath: "//*[contains(. ,'Record Type of new record')]/following::td[1]//select")
end