require 'page-object'
require 'sync_tolerance'

class AgreementLineItemViewPage < BasePage
  include PageObject
  include PageObject::PageFactory
  include SyncTolerance

  button(:edit, title: 'Edit')

  #information left column
  # div(:regulatory_stop_fee_1, xpath: "//td[text()='Regulatory Stop Fee 1']/following::td[1]/div")
  # div(:regulatory_stop_fee_2, xpath: "//td[text()='Regulatory Stop Fee 2']/following::td[1]/div")

  #information 
  div(:line_item_id, xpath:  "//td[text()='Line Item Id']/following::td[1]/div")
  div(:description, xpath:  "//td[text()='Description']/following::td[1]/div")
  div(:product, xpath:  "//td[text()='Product']/following::td[1]/div")
  div(:quantity, xpath:  "//td[text()='Quantity']/following::td[1]/div")
  div(:product_line, xpath:  "//td[text()='Product Line']/following::td[1]/div")
  div(:card_type, xpath:  "//td[text()='Card Type']/following::td[1]/div")
  div(:aircraft_1_hours, xpath:  "//td[text()='Aircraft 1 Hours']/following::td[1]/div")
  div(:aircraft_2_hours, xpath:  "//td[text()='Aircraft 2 Hours']/following::td[1]/div")
  div(:occupied_flight_hours, xpath:  "//td[text()='Occupied Flight Hours']/following::td[1]/div")
  div(:product_hours, xpath:  "//td[text()='Product Hours']/following::td[1]/div")
  div(:aircraft_1, xpath:  "//td[text()='Aircraft 1']/following::td[1]/div")
  div(:aircraft_2, xpath:  "//td[text()='Aircraft 2']/following::td[1]/div")
  div(:annual_cost, xpath:  "//td[text()='Annual Cost']/following::td[1]/div")
  div(:interchange_rate, xpath:  "//td[text()='Interchange Rate']/following::td[1]/div")
  div(:partnership, xpath:  "//td[text()='Partnership']/following::td[1]/div")
  div(:usage, xpath:  "//td[text()='Usage']/following::td[1]/div")
  div(:program, xpath:  "//td[text()='Program']/following::td[1]/div")
  div(:accounting_company, xpath:  "//td[text()='Accounting Company']/following::td[1]/div")
  div(:operational_company, xpath:  "//td[text()='Operational Company']/following::td[1]/div")
  div(:can_sub_contract, xpath:  "//td[text()='Can Sub-Contract']/following::td[1]/div")
  div(:payment_terms, xpath:  "//td[text()='Payment Terms']/following::td[1]/div")
  div(:payment_terms_uom, xpath:  "//td[text()='Payment Terms UOM']/following::td[1]/div")
  div(:preferred_bank, xpath:  "//td[text()='Preferred Bank']/following::td[1]/div")
  div(:excess_flying_hourly_tax_fet, xpath:  "//td[text()='Excess Flying Hourly Tax (FET)']/following::td[1]/div")
  div(:excess_flying_prepay, xpath:  "//td[text()='Excess Flying Prepay']/following::td[1]/div")
  div(:flight_rule, xpath:  "//td[text()='Flight Rule']/following::td[1]/div")
  div(:ground_handling_fee, xpath:  "//td[text()='Ground Handling Fee']/following::td[1]/div")
  div(:tax_percentage, xpath:  "//td[text()='Tax Percentage']/following::td[1]/div")
  div(:bank_account, xpath:  "//td[text()='Bank Account']/following::td[1]/div")
  div(:delayed_start_amount, xpath:  "//td[text()='Delayed Start Amount']/following::td[1]/div")
  div(:delayed_start_unit_of_measure_uom, xpath:  "//td[text()='Delayed Start Unit of Measure (UOM)']/following::td[1]/div")
  div(:fuel_tax_fet, xpath:  "//td[text()='Fuel Tax % (FET)']/following::td[1]/div")
  div(:peak_period_day_departure_adjustment, xpath:  "//td[text()='Peak Period Day Departure Adjustment']/following::td[1]/div")
  div(:peak_period_day_departure_adjustment_uom, xpath:  "//td[text()='Peak Period Day Departure Adjustment UOM']/following::td[1]/div")
  div(:customer_is_late_amount, xpath:  "//td[text()='Customer is Late Amount']/following::td[1]/div")
  div(:customer_is_late_uom, xpath:  "//td[text()='Customer is Late UOM']/following::td[1]/div")
  div(:netjets_is_late_amount, xpath:  "//td[text()='NetJets is Late Amount']/following::td[1]/div")
  div(:netjets_is_late_uom, xpath:  "//td[text()='NetJets is Late UOM']/following::td[1]/div")
  div(:aircraft_per_day, xpath:  "//td[text()='Aircraft Per Day']/following::td[1]/div")
  div(:upgrade_from_aircraft, xpath:  "//td[text()='Upgrade from Aircraft']/following::td[1]/div")
  div(:derived_from, xpath:  "//td[text()='Derived From']/following::td[1]/div")
  div(:fuel_rate, xpath:  "//td[text()='Fuel Rate']/following::td[1]/div")
  div(:fuel_rate_1, xpath:  "//td[text()='Fuel Rate 1']/following::td[1]/div")
  div(:fuel_rate_2, xpath:  "//td[text()='Fuel Rate 2']/following::td[1]/div")
  div(:prepaid_fuel_type, xpath:  "//td[text()='Prepaid Fuel Type']/following::td[1]/div")
  div(:prepaid_incidentals, xpath:  "//td[text()='Prepaid incidentals']/following::td[1]/div")
  div(:operating_expense_fund, xpath:  "//td[text()='Operating Expense Fund']/following::td[1]/div")
  div(:prepaid_fuel_amount, xpath:  "//td[text()='Prepaid Fuel Amount']/following::td[1]/div")
  div(:three_month_average_fuel_cost, xpath:  "//td[text()='3 Month Average Fuel Cost']/following::td[1]/div")
  div(:peak_period_day_premium, xpath:  "//td[text()='Peak Period Day Premium']/following::td[1]/div")
  div(:non_qualifying_premium, xpath:  "//td[text()='Non-Qualifying Premium']/following::td[1]/div")
  div(:minimum_flight_segment_rules_amount_ac1, xpath:  "//td[text()='Minimum Flight Segment Rules Amount AC1']/following::td[1]/div")
  div(:minimum_flight_segment_rules_amount_ac2, xpath:  "//td[text()='Minimum Flight Segment Rules Amount AC2']/following::td[1]/div")
  div(:minimum_flight_segment_rules_uom_ac1, xpath:  "//td[text()='Minimum Flight Segment Rules UOM AC1']/following::td[1]/div")
  div(:minimum_flight_segment_rules_uom_ac2, xpath:  "//td[text()='Minimum Flight Segment Rules UOM AC2']/following::td[1]/div")
  div(:escalation_method, xpath:  "//td[text()='Escalation Method']/following::td[1]/div")
  div(:fuel_type_ac1, xpath:  "//td[text()='Fuel Type AC1']/following::td[1]/div")
  div(:fuel_type_ac2, xpath:  "//td[text()='Fuel Type AC2']/following::td[1]/div")
  div(:regulatory_stop_fee_1, xpath:  "//td[text()='Regulatory Stop Fee 1']/following::td[1]/div")
  div(:regulatory_stop_fee_2, xpath:  "//td[text()='Regulatory Stop Fee 2']/following::td[1]/div")
  div(:fuel_rate_id_1, xpath:  "//td[text()='Fuel Rate Id 1']/following::td[1]/div")
  div(:fuel_rate_id_2, xpath:  "//td[text()='Fuel Rate Id 2']/following::td[1]/div")
  div(:agreement, xpath:  "//td[text()='Agreement']/following::td[1]/div")
  div(:item_sequence, xpath:  "//td[text()='Item Sequence']/following::td[1]/div")
  div(:line_number, xpath:  "//td[text()='Line Number']/following::td[1]/div")
  div(:blackout_days, xpath:  "//td[text()='Blackout Days']/following::td[1]/div")
  div(:peak_period_days, xpath:  "//td[text()='Peak Period Days']/following::td[1]/div")
  div(:bonus_hours, xpath:  "//td[text()='Bonus Hours']/following::td[1]/div")
  div(:non_standard, xpath:  "//td[text()='Non-Standard']/following::td[1]/div")
  div(:to_aircraft, xpath:  "//td[text()='To Aircraft']/following::td[1]/div")
  div(:upgrade_service_area, xpath:  "//td[text()='Upgrade Service Area']/following::td[1]/div")
  div(:upgrade_segments, xpath:  "//td[text()='Upgrade Segments']/following::td[1]/div")
  div(:upgrade_hours, xpath:  "//td[text()='Upgrade Hours']/following::td[1]/div")
  div(:initial_term_amount, xpath:  "//td[text()='Initial Term Amount']/following::td[1]/div")
  div(:initial_term_unit_of_measure_uom, xpath:  "//td[text()='Initial Term Unit of Measure (UOM)']/following::td[1]/div")
  div(:grace_period_amount, xpath:  "//td[text()='Grace Period Amount']/following::td[1]/div")
  div(:grace_period_unit_of_measure_uom, xpath:  "//td[text()='Grace Period Unit of Measure (UOM)']/following::td[1]/div")
  div(:taxi_time, xpath:  "//td[text()='Taxi Time']/following::td[1]/div")

#payment information
  div(:pre_tax_purchase_price, xpath:  "//td[text()='Pre-Tax Purchase Price']/following::td[1]/div")
  div(:adjustment_total, xpath:  "//td[text()='Adjustment Total']/following::td[1]/div")
  div(:waived_premium_discount, xpath:  "//td[text()='Waived Premium Discount']/following::td[1]/div")
  div(:tax_amount, xpath:  "//td[text()='Tax Amount']/following::td[1]/div")
  div(:total_price, xpath:  "//td[text()='Total Price']/following::td[1]/div")
  
#system information
  div(:created_by, xpath:  "//td[text()='Created By']/following::td[1]/div")
  div(:last_modified_by, xpath:  "//td[text()='Last Modified By']/following::td[1]/div")



  def edit_agreement_line_item
    patiently { self.edit }
    self.wait_until { (self.text.include? "Agreement Line Item Edit") }
  end
end
