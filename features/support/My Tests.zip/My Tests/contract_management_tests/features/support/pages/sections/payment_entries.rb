require 'sync_tolerance'
class PaymentEntriesSection
  include PageObject
  include SyncTolerance

  select_list(:payment_method, xpath: "//label[text() ='Payment Method']/../following-sibling::*[1]//select")
  text_field(:payment_amount, xpath: "//label[text() ='Payment Amount']/../following-sibling::*[1]//input")
  text_field(:payment_date, xpath: "//label[text() ='Payment Date']/../following-sibling::*[1]//input")
  text_area(:comments, xpath: "//label[text() ='Comments']/../following-sibling::*[1]//textarea")
  select_list(:currency, xpath: "//label[text() ='Currency']/../following-sibling::*[1]//select")
  div(:error, id: 'errorDiv_ep')
  button(:save, name: 'save')

  def save_payment_entry
    patiently { self.save }
  end
end