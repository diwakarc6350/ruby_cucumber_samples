module ScenarioContext

  def self.method_missing(name, *args)
    attribute = name.to_s
    if attribute =~ /=$/
      self.add_attribute(attribute.chop.to_sym, args[0])
    else
      self.context_attributes.fetch(attribute.to_sym) { raise AttributeNotFoundException, attribute }
    end
  end

  def self.empty
    @context_methods.clear unless @context_methods.nil?
  end

  private
  def self.add_attribute(attr, value)
    self.context_attributes[attr] = value
  end

  def self.context_attributes
    @context_methods ||= {}
  end

end

class AttributeNotFoundException < StandardError
  def initialize(attr=nil)
    @attribute = attr
  end

  def message
    "Attribute `#{@attribute}' not found in Scenario Context."
  end
end

