module PageObject
  module Elements
    class Table < Element
      def to_h
        header, data=[], []
        header = self.first_row.map(&:text)
        self.entries[1..-1].map do |row|
          data << row.map(&:text)
        end
        results = []
        data.each do |d|
          hash = Hash.new
          d.each_with_index { |item, index|
            hash[header[index]] = item
          }
          results << hash
        end
        results
      end
    end
  end
end
