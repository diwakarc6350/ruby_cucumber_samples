$LOAD_PATH << Dir.pwd

require 'active_support'
require 'active_support/number_helper'
require 'test_data_factory'
require 'page-object'
require 'faker'
require 'unidecoder'

include PageObject::PageFactory
PageObject.javascript_framework = :jquery

puts "Test Environment : #{ENV['ENVIRONMENT']}"

def login_info(role)
  info = YAML.load_file('user.yml')
  info[ENV['ENVIRONMENT'].to_sym][role]
end