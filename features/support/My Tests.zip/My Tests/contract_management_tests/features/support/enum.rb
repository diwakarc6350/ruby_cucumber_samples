module Enum
  class Users
    SALESFORCE_ADMIN ||= YAML.load_file('user.yml')[ENV['ENVIRONMENT'].strip.to_sym][:salesforce_administrator][:username]
    DEFAULT_PASSWORD ||= 'Winter15'
  end
end

World(Enum) if File.basename($PROGRAM_NAME) == 'cucumber'