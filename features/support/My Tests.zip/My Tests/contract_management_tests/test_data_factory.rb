require 'nj_salesforce'
require 'yaml'

class TestDataFactory

  @data = YAML.load_file("features/support/data/data.yml")

  def self.account
    self.clean(NjSalesforce::Account.where({Name: @data[:accounts][:account_name]}))
  end

  def self.contact
    self.clean(NjSalesforce::Contact.where({LastName: @data[:contacts][:last_name]}))
  end

  def self.opportunity
    self.clean(NjSalesforce::Opportunity.where({Name: @data[:opportunity][:opportunity_name]}))
  end

  def self.open_apttus_opportunity
    record_type_id = NjSalesforce::RecordType.all.find { |opp| opp.fetch('Name') == 'New Business - Apttus' }.fetch('Id')
    NjSalesforce::Opportunity.all.select { |opp| opp.fetch('StageName') == 'Open' && opp.fetch('RecordTypeId') == record_type_id }.sample.fetch('Id')
  end

  def self.inactive_agreement
    self.clean(NjSalesforce::Agreement.all.select { |x| x['Funding_State__c'] != 'Funded Contract' &&
                   x['Apttus__Status_Category__c'] != 'Cancelled' })
  end

  def self.active_agreement
    self.clean(NjSalesforce::Agreement.all.select { |x| x['Funding_State__c'] == 'Funded Contract' &&
                   x['Apttus__Status_Category__c'] != 'Cancelled' })
  end

  def self.related_agreements(proposal_id)
    self.clean(NjSalesforce::Agreement.where({Apttus_QPComply__RelatedProposalId__c: proposal_id}))
  end

  def self.save_generated_agreement(agreement_id)
    save_dir = Dir.pwd << '/downloads'
    attachments = NjSalesforce::Agreement.agreement_documents(agreement_id)
    downloaded_agreement = NjSalesforce::AttachmentNotes.download(attachments.first['Id'], save_dir)
    return save_dir
  end

  def self.clean(data)
    data.to_a.map { |obj| obj.to_h }.each { |obj| obj.delete(' attributes ') }
  end

end