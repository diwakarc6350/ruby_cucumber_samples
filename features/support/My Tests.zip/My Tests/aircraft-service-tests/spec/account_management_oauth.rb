require 'oauth2'
require 'host_names'

class AccountManagementOauth

  attr_reader :oauth

  OAUTH_CLIENT_ID = 'c07c2302-4cf4-4c7c-b6a5-fa82cd6f380d'
  OAUTH_CLIENT_SECRET = '8df6b00e-4cf3-4302-888c-a4a073cab132'

  OAUTH_SSL_OPTIONS = {
      ca_file: File.dirname(__FILE__)+"/../resources/cacert.pem",
      verify: true
  }

  def initialize
    @oauth = OAuth2::Client.new(OAUTH_CLIENT_ID, OAUTH_CLIENT_SECRET,
                                :token_url => "https://#{oauth_host}/auth/oauth/v2/token",
                                :ssl => OAUTH_SSL_OPTIONS)
  end

  def oauth_header_template(oauth_token)
    {headers: {'Authorization' => "Bearer #{oauth_token}"}}
  end

  def invalid_oauth_header
    oauth_header_template '123-456'
  end

  USER_MAP = {
      local: {
          authorized: 'qatest1',
          unauthorized: 'qatest5'
      },
      ci: {
          authorized: 'qatest1',
          unauthorized: 'qatest5'
      },
      itg: {
          authorized: 'qatest1',
          unauthorized: 'qatest5'
      },
      itg2: {
          authorized: 'qatest1',
          unauthorized: 'qatest5'
      },
      qa: {
          authorized: 'qatest3',
          unauthorized: 'qatest1'
      },
      patch: {
          authorized: 'qatest3',
          unauthorized: 'qatest5'
      },
      cat: {
          authorized: 'qatest3',
          unauthorized: 'qatest5'
      },
      clone: {
          authorized: 'qatest3',
          unauthorized: 'qatest5'
      },
      train: {
          authorized: 'qatest3',
          unauthorized: 'qatest5'
      },
  }

  def unauthorized_oauth_header
    token = oauth.password.get_token(USER_MAP[environment][:unauthorized], 'Aut0P1l0t!')
    oauth_header_template token.token
  end

  def authorized_oauth_header(force_user='')
    if force_user.empty?
      token = oauth.password.get_token(USER_MAP[environment][:authorized], 'Aut0P1l0t!')
      oauth_header_template token.token
    else
      token = oauth.password.get_token(force_user, 'Aut0P1l0t!')
      oauth_header_template token.token
    end
  end

end