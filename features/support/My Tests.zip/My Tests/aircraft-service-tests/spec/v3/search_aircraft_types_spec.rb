require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'

=begin
  In this test we make sure the aircraft types are displayed correctly
  by the aircraft service. We validate this with the data present in the
  ais aircraft type table.
=end

describe 'aircraft inventory service', :ignore => true  do
  context "version 3" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'search aircraft types' do
      it 'gets the aircraft types' do
        response = response_as_json "#{AIRCRAFT_TYPES_V3_URL}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
        actual_aircraft_type = response
        expect(actual_aircraft_type).to have_at_least(1).items
      end

      it 'has all aircraft types attributes in the response' , :ignore => true do
        response = response_as_json "#{AIRCRAFT_TYPES_V3_URL}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
        actual_aircraft_types = response
        expect(actual_aircraft_types[0].has_key?('id')).to be_true
        expect(actual_aircraft_types[0].has_key?('legalModelName')).to be_true
        expect(actual_aircraft_types[0].has_key?('legalManufacturerName')).to be_true
        expect(actual_aircraft_types[0].has_key?('sellingShares')).to be_true
        expect(actual_aircraft_types[0].has_key?('sellingAddOns')).to be_true
        expect(actual_aircraft_types[0].has_key?('notes')).to be_true
        expect(actual_aircraft_types[0].has_key?('isActive')).to be_true
      end

      it 'gets the aircraft type model, manufacturer and notes information correctly' , :ignore => true do
        expected_aircraft_types = db_conn_ais.connection.execute(get_all_ais_ac_type_sql)
        .sort_by { |x| x['legalmodelname'] }
        response = response_as_json "#{AIRCRAFT_TYPES_V3_URL}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
        actual_aircraft_types = response.sort_by { |row| row['legalModelName'] }
        actual_aircraft_types.length.times do |i|
          expect(actual_aircraft_types[i]['legalModelName']).to eq(expected_aircraft_types[i]['legalmodelname'])
          expect(actual_aircraft_types[i]['legalManufacturerName']).to eq(expected_aircraft_types[i]['manufacturer'])
          expect(actual_aircraft_types[i]['notes']).to eq(expected_aircraft_types[i]['notes'])
        end
      end

      it 'get the isActive as false' , :ignore => true  do
        expected_aircraft_types = db_conn_ais.connection.execute(get_ais_ac_type_status_sql('F'))
        if expected_aircraft_types.length > 0
          response = response_as_json "#{AIRCRAFT_TYPES_V3_URL}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          actual_aircraft_types = response.select { |row| row['id']==expected_aircraft_types[0]['acft_aircraft_type_id'].to_i }
          expect(actual_aircraft_types[0]['isActive']).to be_false
        else
          log.info 'cannot find data with isActive as false'
        end
      end

      it 'get the isActive as true' , :ignore => true do
        expected_aircraft_types = db_conn_ais.connection.execute(get_ais_ac_type_status_sql('T'))
        if expected_aircraft_types.length > 0
          response = response_as_json "#{AIRCRAFT_TYPES_V3_URL}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          actual_aircraft_types = response.select { |row| row['id']==expected_aircraft_types[0]['acft_aircraft_type_id'].to_i }
          expect(actual_aircraft_types[0]['isActive']).to be_true
        else
          log.info 'cannot find data with isActive as true'
        end
      end

      it 'get the sellingShares as false' , :ignore => true do
        expected_aircraft_types = db_conn_ais.connection.execute(get_ais_ac_type_shares_sql('F'))
        if expected_aircraft_types.length > 0
          response = response_as_json "#{AIRCRAFT_TYPES_V3_URL}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          actual_aircraft_types = response.select { |row| row['id']==expected_aircraft_types[0]['acft_aircraft_type_id'].to_i }
          expect(actual_aircraft_types[0]['sellingShares']).to be_false
        else
          log.info 'cannot find data with sellingShares as false'
        end
      end

      it 'get the sellingShares as true' , :ignore => true do
        expected_aircraft_types = db_conn_ais.connection.execute(get_ais_ac_type_shares_sql('T'))
        if expected_aircraft_types.length > 0
          response = response_as_json "#{AIRCRAFT_TYPES_V3_URL}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          actual_aircraft_types = response.select { |row| row['id']==expected_aircraft_types[0]['acft_aircraft_type_id'].to_i }
          expect(actual_aircraft_types[0]['sellingShares']).to be_true
        else
          log.info 'cannot find data with sellingShares as true'
        end
      end

      it 'get the sellingAddOns as false' , :ignore => true  do
        expected_aircraft_types = db_conn_ais.connection.execute(get_ais_ac_type_addon_sql('F'))
        if expected_aircraft_types.length > 0
          response = response_as_json "#{AIRCRAFT_TYPES_V3_URL}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          actual_aircraft_types = response.select { |row| row['id']==expected_aircraft_types[0]['acft_aircraft_type_id'].to_i }
          expect(actual_aircraft_types[0]['sellingAddOns']).to be_false
        else
          log.info 'cannot find data with sellingAddOns as false'
        end
      end

      it 'get the sellingAddOns as true'  , :ignore => true do
        expected_aircraft_types = db_conn_ais.connection.execute(get_ais_ac_type_addon_sql('T'))
        if expected_aircraft_types.length > 0
          response = response_as_json "#{AIRCRAFT_TYPES_V3_URL}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          actual_aircraft_types = response.select { |row| row['id']==expected_aircraft_types[0]['acft_aircraft_type_id'].to_i }
          expect(actual_aircraft_types[0]['sellingAddOns']).to be_true
        else
          log.info 'cannot find data with sellingAddOns as true'
        end
      end
    end

    def get_all_ais_ac_type_sql
      <<-SQL.gsub(/^ {6}/, '')
        select legal_model_name as legalModelName, legal_manufacturer_name as manufacturer,
        active_status_flg as status, selling_shares_flg as sellingShares,
        notes_txt as notes, selling_add_ons_flg as sellingAddOns
        from acft_aircraft_type
      SQL
    end

    def get_ais_ac_type_status_sql(status='T')
      <<-SQL.gsub(/^ {6}/, '')
        select acft_aircraft_type_id
        from acft_aircraft_type
        where active_status_flg = '#{status}'
      SQL
    end

    def get_ais_ac_type_shares_sql(selling_shares='T')
      <<-SQL.gsub(/^ {6}/, '')
        select acft_aircraft_type_id
        from acft_aircraft_type
        where selling_shares_flg = '#{selling_shares}'
      SQL
    end

    def get_ais_ac_type_addon_sql(add_ons='T')
      <<-SQL.gsub(/^ {6}/, '')
        select acft_aircraft_type_id
        from acft_aircraft_type
        where selling_add_ons_flg = '#{add_ons}'
      SQL
    end

  end
end