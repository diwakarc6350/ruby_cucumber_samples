require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'

=begin
  In this test we make sure the aircraft types are displayed correctly
  by the aircraft service. We validate this with the data present in the
  ais aircraft type table.
=end

describe 'aircraft inventory service' do
  context "version 3" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'get aircraft type' do
      it 'gets aircraft type', :ignore => true do
        # get a valid key from the db
        aircraft_types = db_conn_ais.connection.execute(get_all_ac_type_ids_sql)
        if aircraft_types.length > 0
          id = aircraft_types[0]['acft_aircraft_type_id'].to_i
          response = response_as_json "#{AIRCRAFT_TYPES_V3_URL}/#{id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          actual_aircraft_types = response
          expect(actual_aircraft_types).to have_at_least(1).items
        else
          log.info 'cannot find data for aircraft types'
        end
      end

      it 'has all aircraft type attributes in the response', :ignore => true do
        # get a valid key from the db
        aircraft_types = db_conn_ais.connection.execute(get_all_ac_type_ids_sql)
        if aircraft_types.length > 0
          id = aircraft_types[0]['acft_aircraft_type_id'].to_i
          actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V3_URL}/#{id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(actual_aircraft_type.has_key?('id')).to be_true
          expect(actual_aircraft_type.has_key?('legalModelName')).to be_true
          expect(actual_aircraft_type.has_key?('legalManufacturerName')).to be_true
          expect(actual_aircraft_type.has_key?('sellingShares')).to be_true
          expect(actual_aircraft_type.has_key?('sellingAddOns')).to be_true
          expect(actual_aircraft_type.has_key?('isActive')).to be_true
        else
          log.info 'cannot find data for aircraft types'
          A
        end
      end

      it 'gets aircraft type - model, manufacturer and notes information correctly', :ignore => true do
        expected_aircraft_type = db_conn_ais.connection.execute(get_all_ais_ac_type_sql)[0]
        if expected_aircraft_type != NIL
          id = expected_aircraft_type['acft_aircraft_type_id'].to_i
          actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V3_URL}/#{id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(actual_aircraft_type['legalModelName']).to eq(expected_aircraft_type['legalmodelname'])
          expect(actual_aircraft_type['legalManufacturerName']).to eq(expected_aircraft_type['manufacturer'])
          expect(actual_aircraft_type['notes']).to eq(expected_aircraft_type['notes'])
        else
          log.info 'cannot find data for aircraft types'
        end
      end

      it 'get isActive as false', :ignore => true do
        expected_aircraft_type = db_conn_ais.connection.execute(get_ais_ac_type_status_sql('F'))[0]
        if expected_aircraft_type != NIL
          id = expected_aircraft_type['acft_aircraft_type_id'].to_i
          actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V3_URL}/#{id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(actual_aircraft_type['isActive']).to be_false
        else
          log.info 'cannot find data with isActive as false'
        end
      end

      it 'get isActive as true', :ignore => true do
        expected_aircraft_type = db_conn_ais.connection.execute(get_ais_ac_type_status_sql('T'))[0]
        if expected_aircraft_type != NIL
          id = expected_aircraft_type['acft_aircraft_type_id'].to_i
          actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V3_URL}/#{id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(actual_aircraft_type['isActive']).to be_true
        else
          log.info 'cannot find data with isActive as true'
        end
      end

      it 'get sellingShares as false', :ignore => true do
        expected_aircraft_type = db_conn_ais.connection.execute(get_ais_ac_type_shares_sql('F'))[0]
        if expected_aircraft_type != NIL
          id = expected_aircraft_type['acft_aircraft_type_id'].to_i
          actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V3_URL}/#{id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(actual_aircraft_type['sellingShares']).to be_false
        else
          log.info 'cannot find data with sellingShares as false'
        end
      end

      it 'get sellingShares as true', :ignore => true do
        expected_aircraft_type = db_conn_ais.connection.execute(get_ais_ac_type_shares_sql('T'))[0]
        if expected_aircraft_type != NIL
          id = expected_aircraft_type['acft_aircraft_type_id'].to_i
          actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V3_URL}/#{id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(actual_aircraft_type['sellingShares']).to be_true
        else
          log.info 'cannot find data with sellingShares as true'
        end
      end

      it 'get sellingAddOns as false', :ignore => true do
        expected_aircraft_type = db_conn_ais.connection.execute(get_ais_ac_type_addon_sql('F'))[0]
        if expected_aircraft_type != NIL
          id = expected_aircraft_type['acft_aircraft_type_id'].to_i
          actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V3_URL}/#{id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(actual_aircraft_type['sellingAddOns']).to be_false
        else
          log.info 'cannot find data with sellingAddOns as false'
        end
      end

      it 'get sellingAddOns as true', :ignore => true do
        expected_aircraft_type = db_conn_ais.connection.execute(get_ais_ac_type_addon_sql('T'))[0]
        if expected_aircraft_type != NIL
          id = expected_aircraft_type['acft_aircraft_type_id'].to_i
          actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V3_URL}/#{id}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
          expect(actual_aircraft_type['sellingAddOns']).to be_true
        else
          log.info 'cannot find data with sellingAddOns as true'
        end
      end

      it 'gets aircraft type information when no id is given', :ignore => true do
        response = response_as_json "#{AIRCRAFT_TYPES_V3_URL}?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
        expect(response.length).to have_at_least(1).items
      end

      it 'gets invalid id error when id is negative', :ignore => true do
        response = response_as_json "#{AIRCRAFT_TYPES_V3_URL}/-1?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(400)
        expect(response['errors'][0]['description']).to eq("Invalid id '\-1\' in request to look up AisAircraftType")
      end

      it 'gets invalid id error when id is invalid', :ignore => true do
        response = response_as_json "#{AIRCRAFT_TYPES_V3_URL}/abn*90?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(400)
        expect(response['errors'][0]['description']).to eq("Invalid id 'abn*90' in request to look up AisAircraftType")
      end

      it 'gets id does not exist error when no id is non-existent', :ignore => true do
        response = response_as_json "#{AIRCRAFT_TYPES_V3_URL}/999999999?#{APP_AGENT_PARAM}", @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(404)
        expect(response['errors'][0]['description']).to eq("No row with the given identifier exists: [com.netjets.aircraft.AisAircraftType#999999999]")
      end
    end

    def get_all_ac_type_ids_sql
      <<-SQL.gsub(/^ {6}/, '')
        select acft_aircraft_type_id
        from acft_aircraft_type
      SQL
    end

    def get_all_ais_ac_type_sql
      <<-SQL.gsub(/^ {6}/, '')
        select acft_aircraft_type_id, legal_model_name as legalModelName, legal_manufacturer_name as manufacturer,
        active_status_flg as status, selling_shares_flg as sellingShares,
        notes_txt as notes, selling_add_ons_flg as sellingAddOns
        from acft_aircraft_type
      SQL
    end

    def get_ais_ac_type_status_sql(status='T')
      <<-SQL.gsub(/^ {6}/, '')
        select acft_aircraft_type_id
        from acft_aircraft_type
        where active_status_flg = '#{status}'
      SQL
    end

    def get_ais_ac_type_shares_sql(selling_shares='T')
      <<-SQL.gsub(/^ {6}/, '')
        select acft_aircraft_type_id
        from acft_aircraft_type
        where selling_shares_flg = '#{selling_shares}'
      SQL
    end

    def get_ais_ac_type_addon_sql(add_ons='T')
      <<-SQL.gsub(/^ {6}/, '')
        select acft_aircraft_type_id
        from acft_aircraft_type
        where selling_add_ons_flg = '#{add_ons}'
      SQL
    end
  end
end
