require 'active_record'
$CLASSPATH << "#{Dir.pwd}/lib/ojdbc6-11.2.0.3.jar"

$CLASSPATH << "#{Dir.pwd}/lib/ojdbc6-11.2.0.3.jar"

APP_AGENT_PARAM = "appAgent=OwnersPortalUSer"
APP_AGENT_PARAM_NONE = "appAgent="
APP_AGENT_PARAM_NOT_ALLOWED = "appAgent=AppNotAllowed"

case ENV['ENVIRONMENT'].to_sym
  when :qa
    $ais_con = ActiveRecord::Base.establish_connection(
        :adapter => 'jdbc',
        :username => 'aircraft_app_user',
        :password => 'pr0p4g4t3',
        :driver => 'oracle.jdbc.driver.OracleDriver',
        :url => "jdbc:oracle:thin:@
                (DESCRIPTION=
                (CONNECT_TIMEOUT=5)
                (TRANSPORT_CONNECT_TIMEOUT=3)
                (RETRY_COUNT=3)
                (LOAD_BALANCE=on)
                (FAILOVER=on)
                (ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=cexa-scan)(PORT=1521))
                (ADDRESS=(PROTOCOL=TCP)(HOST=bexa-scan)(PORT=1521)))
                (CONNECT_DATA=(SERVICE_NAME=EDRThinQAT.netjets.com)))")
  when :itg2
    $ais_con = ActiveRecord::Base.establish_connection(
        :adapter => 'jdbc',
        :username => 'aircraft_app_user',
        :password => 'tr4nsm1t',
        :driver => 'oracle.jdbc.driver.OracleDriver',
        :url => "jdbc:oracle:thin:@
                 (DESCRIPTION_LIST=
                 (LOAD_BALANCE=off)
                 (FAILOVER=on)
                 (DESCRIPTION=
                 (ADDRESS_LIST=
                 (LOAD_BALANCE=on)
                 (ADDRESS=(PROTOCOL=TCP)(HOST=cexa-scan)(PORT=1521)))
                 (CONNECT_DATA=(SERVICE_NAME=Ijet2ThinDv5.netjets.com))))")
  when :itg, :ci, :local, :itg1
    $ais_con = ActiveRecord::Base.establish_connection(
        :adapter => 'jdbc',
        :username => 'aircraft_app_user',
        :password => 'tr4nsm1t',
        :driver => 'oracle.jdbc.driver.OracleDriver',
        :url => "jdbc:oracle:thin:@
                 (DESCRIPTION=(CONNECT_TIMEOUT=5)
                  (TRANSPORT_CONNECT_TIMEOUT=3)(RETRY_COUNT=3)
                  (LOAD_BALANCE=on)
                  (FAILOVER=on)
                  (ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=cexa-scan)(PORT=1521))
                  (ADDRESS=(PROTOCOL=TCP)(HOST=bexa-scan)(PORT=1521)))
                  (CONNECT_DATA=(SERVICE_NAME=EDRThinITG1.netjets.com))))")
    #puts ($ais_con.connection.methods - Object.methods).sort
    puts "Using #{$ais_con.connection.current_database} as database"
end

def db_conn_ais
  $ais_con
end

require 'models/acft_cabin_class'
cabin_classes = {}
AcftCabinClass.all.each do |cabin_class|
  cabin_classes[:"#{cabin_class.cabin_class_name.downcase}"] = [cabin_class.cabin_class_cd, cabin_class.cabin_class_name]
end
AIRCRAFT_CABIN_SIZE_CODES = cabin_classes


USER_MAP ={
    :'AIS Insurance Administrator' => {:user => "qatest4", :password => "Aut0P1l0t!"},
    :'AIS Administrator' => {:user => "qatest1", :password => "Aut0P1l0t!"},
    :'AIS Sales User' => {:user => "qatest20", :password => "Aut0P1l0t!"},
    :'AIS User' => {:user => "qatest2", :password => "Aut0P1l0t!"}
}