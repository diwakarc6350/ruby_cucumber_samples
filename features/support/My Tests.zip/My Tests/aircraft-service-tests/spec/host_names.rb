LAYER7_HOSTS = {
    local: 'localhost:8080/aircraft-service-web',
    ci: 'bcsdev01:9780/aircraft-service-web',
    itg: 'servicesdev.netjets.com',
    itg2: 'servicesdev2.netjets.com',
    qa: 'servicesqareg.netjets.com',
    clone: 'servicesclone.netjets.com',
    train: 'servicestrain.netjets.com',
    cat: 'servicescat.netjets.com',
    patch: 'servicespatch.netjets.com'
}

SERVICE_HOSTS = {
    local: 'localhost:8080/aircraft-service-web',
    ci: '',
    itg: 'bdla6711:9080',
    itg2: 'bdla6771:9083',
    qa: 'bqla6714:9080',
    clone: '',
    train: '',
    cat: '',
    patch: 'bdla6721:9083'
}

OAUTH_HOSTS = {
    local: 'servicesdev.netjets.com',
    ci: 'servicesdev.netjets.com',
    itg: 'servicesdev.netjets.com',
    itg2: 'servicesdev2.netjets.com',
    qa: 'servicesqareg.netjets.com',
    clone: 'servicesclone.netjets.com',
    train: 'servicestrain.netjets.com',
    cat: 'servicescat.netjets.com',
    patch: 'servicespatch.netjets.com'
}


def layer7_host
  LAYER7_HOSTS[environment]
end

def services_host
  SERVICE_HOSTS[environment]
end

def oauth_host
  OAUTH_HOSTS[environment]
end

AIRCRAFT_TYPES_V2_URL = "https://#{layer7_host}/aircraft/v2/aircraftTypes"
AIRCRAFT_TYPES_V3_URL = "http://#{layer7_host}/aircraft/v3/inventoryTypes"
AIRCRAFT_TAILS_V3_URL = "http://#{layer7_host}/aircraft/v3/inventoryTails"
AIRCRAFT_FLEET_GROUPS_V3_URL = "http://#{layer7_host}/aircraft/v3/fleetGroups"
AIRCRAFT_TYPES_V4_URL = "http://#{layer7_host}/aircraft/v4/inventoryTypes"
AIRCRAFT_TAILS_V4_URL = "http://#{layer7_host}/aircraft/v4/inventoryTails"
AIRCRAFT_FLEET_GROUPS_V4_URL = "http://#{layer7_host}/aircraft/v4/fleetGroups"
AIRCRAFT_HOLDS_V4_URL = "https://#{layer7_host}/aircraft/v4/holds"
