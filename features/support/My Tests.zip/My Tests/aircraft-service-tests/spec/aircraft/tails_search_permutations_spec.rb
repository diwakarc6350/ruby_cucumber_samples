require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/aircraft_data'

=begin
  In this test we make sure the aircraft tails are retrieved correctly
  by the by various search combinations.
=end

describe 'aircraft inventory service' do
  context "version 4" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @resource = AIRCRAFT_TAILS_V3_URL
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'search aircraft tails' do
      full_tails = db_conn_ais.connection.execute(get_aircraft_tail_numbers_sql)
      all_types = db_conn_ais.connection.execute(get_aircrafts_by_type_name_sql)
      .select { |rec| rec['fleet_group_id']!=nil }
      all_tails = db_conn_ais.connection.execute(get_aircraft_tail_numbers_sql)
      permutations = [
          {
              :search_id => 1,
              :aircraftStateCds => all_tails[rand(all_tails.length-1)]['code_type_class_id'].to_i,
              :aircraft_type_id => all_types[rand(all_types.length-1)]['acft_aircraft_type_id'].to_i,
              :fleet_group_id => '',
              :company_id => all_tails[rand(all_tails.length-1)]['ijet_ej_company_id'].to_i,
              :sales_status_ids => '',
              :tail => '',
          },
          {
              :search_id => 2,
              :aircraftStateCds => '',
              :aircraft_type_id => '',
              :fleet_group_id => all_types[rand(all_types.length-1)]['fleet_group_id'].to_i,
              :company_id => all_tails[rand(all_tails.length-1)]['ijet_ej_company_id'].to_i,
              :sales_status_ids => '',
              :tail => ''
          },
          {
              :search_id => 3,
              :aircraftStateCds => '',
              :aircraft_type_id => '',
              :fleet_group_id => '',
              :company_id => all_tails[rand(all_tails.length-1)]['ijet_ej_company_id'].to_i,
              :sales_status_ids => '',
              :tail => full_tails[rand(full_tails.length)]['aircraft_tail_nbr']
          },
          {
              :search_id => 4,
              :aircraftStateCds => '',
              :aircraft_type_id => '',
              :fleet_group_id => all_types[rand(all_types.length-1)]['fleet_group_id'].to_i,
              :company_id => '',
              :sales_status_ids => '1',
              :tail => ''
          },
          {
              :search_id => 5,
              :aircraftStateCds => all_tails[rand(all_tails.length-1)]['code_type_class_id'].to_i,
              :aircraft_type_id => all_types[rand(all_types.length-1)]['acft_aircraft_type_id'].to_i,
              :fleet_group_id => all_types[rand(all_types.length-1)]['fleet_group_id'].to_i,
              :company_id => all_tails[rand(all_tails.length-1)]['ijet_ej_company_id'].to_i,
              :sales_status_ids => '1',
              :tail => ''
          },
          {
              :search_id => 6,
              :aircraftStateCds => all_tails[rand(all_tails.length-1)]['code_type_class_id'].to_i,
              :aircraft_type_id => all_types[rand(all_types.length-1)]['acft_aircraft_type_id'].to_i,
              :fleet_group_id => all_types[rand(all_types.length-1)]['fleet_group_id'].to_i,
              :company_id => all_tails[rand(all_tails.length-1)]['ijet_ej_company_id'].to_i,
              :sales_status_ids => '',
              :tail => ''
          }
      ]

      permutations.each do |search_key|
        it "searches by #{search_key}" do
          query_string = "aircraftStateCds=#{search_key[:aircraftStateCds]}&"\
                          "aircraftTypeId=#{search_key[:aircraft_type_id]}&"\
                          "fleetGroupId=#{search_key[:fleet_group_id]}&"\
                          "companyId=#{search_key[:company_id]}&"\
                          "salesStatusCd=#{search_key[:sales_status_ids]}&"\
                          "tailNumberContains=#{search_key[:tail]}"
          actual_aircraft = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                             @account_mgmt_oauth.authorized_oauth_header
          if search_key[:search_id] == 1
            expected_aircraft = all_tails.select { |row| row['code_type_class_id'] == search_key[:aircraftStateCds] && \
                      row['acft_aircraft_type_id']==search_key[:aircraft_type_id] && \
                      row['ijet_ej_company_id']==search_key[:company_id] }

          elsif search_key[:search_id] == 2 then
            expected_aircraft = all_tails.select { |row| row['acft_fleet_group_id'] == search_key[:fleet_group_id] && \
                      row['ijet_ej_company_id']==search_key[:company_id] }

          elsif search_key[:search_id] == 3 then
            expected_aircraft = all_tails.select { |row| row['aircraft_tail_nbr'] == search_key[:tail] && \
                      row['ijet_ej_company_id']==search_key[:company_id] }

          elsif search_key[:search_id] == 4 then
            expected_aircraft = all_tails.select { |row| row['sales_status'] == 'Selling Fractionally' && \
                      row['acft_fleet_group_id']==search_key[:fleet_group_id] }


          elsif search_key[:search_id] == 5 then
            expected_aircraft = all_tails.select { |row| row['code_type_class_id'] == search_key[:aircraftStateCds] && \
                  row['acft_aircraft_type_id']==search_key[:aircraft_type_id] && \
                  row['acft_fleet_group_id'] == search_key[:fleet_group_id] && \
                  row['ijet_ej_company_id']==search_key[:company_id] && \
                  row['sales_status'] == 'Selling Fractionally'
            }
          elsif search_key[:search_id] == 6 then
            expected_aircraft = all_tails.select { |row| row['code_type_class_id'] == search_key[:aircraftStateCds] && \
                  row['acft_aircraft_type_id']==search_key[:aircraft_type_id] && \
                  row['acft_fleet_group_id'] == search_key[:fleet_group_id] && \
                  row['ijet_ej_company_id']==search_key[:company_id]
            }

          end
          if expected_aircraft.length > 0
            expect(actual_aircraft.length).to eq(expected_aircraft.length)
          else
            log.info('no data found to test')
          end
        end
      end
    end
  end
end
