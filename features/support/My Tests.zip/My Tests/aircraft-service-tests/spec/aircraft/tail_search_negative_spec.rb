require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/aircraft_data'

=begin
  In this test we make sure the aircraft tails are retrieved correctly
  by the aircraft service. We validate this with the data present in the
  ais aircraft type and aircraft tail table
=end

describe 'aircraft inventory service' do
  context "version 4" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @resource = AIRCRAFT_TAILS_V3_URL
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'search aircraft tails' do
      # negative tests for aircraftStateId
      it 'gets an error when aircraftStateCds is foobar' do
        query_string ="aircraftStateCds=foobar"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param aircraftStateCds value must be a valid number')
      end

      it 'gets an error when aircraftStateCds is a negative number' do
        query_string ="aircraftStateCds=-1"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param aircraftStateCds value -1 must not be less than 1')
      end

      it 'gets an error when aircraftStateCds is 0' do
        query_string ="aircraftStateCds=0"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param aircraftStateCds value 0 must not be less than 1')
      end

      it 'gets an error when aircraftStateCds is 99' do
        query_string ="aircraftStateCds=99"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param aircraftStateCds value 99 must be one of the following - [1, 2, 3, 4, 5]')
      end

      it 'gets an error when aircraftStateCds is > 99' do
        query_string ="aircraftStateCds=999999"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param aircraftStateCds value 999,999 must not be greater than 99')
      end

      it 'gets an error when aircraftStateCds has invalid characters' do
        query_string ="aircraftStateCds=!*()"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param aircraftStateCds value must be a valid number')
      end

      # negative tests for aircraftTypeId
      it 'gets an error when aircraftTypeId is foobar' do
        query_string ="aircraftTypeId=foobar"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param aircraftTypeId value must be a valid number')
      end

      it 'gets an error when aircraftTypeId has invalid characters' do
        query_string ="aircraftTypeId=!*()"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param aircraftTypeId value must be a valid number')
      end

      it 'gets an error when aircraftTypeId is a negative number' do
        query_string ="aircraftTypeId=-1"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param aircraftTypeId value must not be less than 1')
      end

      it 'gets an error when aircraftTypeId is 999999999' do
        query_string ="aircraftTypeId=999999999"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param aircraftTypeId value (999,999,999) does not reference a valid aircraft type')
      end

      # negative tests for fleetGroupId
      it 'gets an error when fleetGroupId is foobar' do
        query_string ="fleetGroupId=foobar"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param fleetGroupId value must be a valid number')
      end

      it 'gets an error when fleetGroupId is 999999999' do
        query_string ="fleetGroupId=999999999"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param fleetGroupId value (999,999,999) does not reference a valid fleet group')
      end

      it 'gets an error when fleetGroupId has invalid characters' do
        query_string ="fleetGroupId=!*()"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param fleetGroupId value must be a valid number')
      end

      it 'gets an error when fleetGroupId is a negative number' do
        query_string ="fleetGroupId=-1"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param fleetGroupId value must not be less than 1')
      end

      # negative tests for companyId
      it 'gets an error when companyId is foobar' do
        query_string ="companyId=foobar"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param companyId value must be a valid number')
      end

      it 'gets an error when companyId is 999999999' do
        query_string ="companyId=999999999"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param companyId value (999,999,999) does not reference a valid NJCompany')
      end

      it 'gets an error when companyId has invalid characters' do
        query_string ="companyId=!*()"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param companyId value must be a valid number')
      end

      it 'gets an error when companyId is a negative number' do
        query_string ="companyId=-1"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param companyId value must not be less than 1')
      end

      # negative tests for salesStatusCd
      it 'gets an error when salesStatusCd is foobar' do
        query_string ="salesStatusCd=foobar"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param salesStatusCd value must be a valid number')
      end

      it 'gets an error when salesStatusCd is 999999999' do
        query_string ="salesStatusCd=999999999"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param salesStatusCd value must not be greater than 99')
      end

      it 'gets an error when salesStatusCd has invalid characters' do
        query_string ="salesStatusCd=!*()"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param salesStatusCd value must be a valid number')
      end

      it 'gets an error when salesStatusCd is a negative number' do
        query_string ="salesStatusCd=-1"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param salesStatusCd value must not be less than 1')
      end

      # negative tests for tailNumberContains
      it 'gets http error for invalid tail number contains' do
        query_string ="tailNumberContains=123456789"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response).to eq([])
      end

      it 'gets error when length of tail number is > 22' do
        query_string ="tailNumberContains=123456789012345678901234567890"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param tailNumberContains value must not be more than 22 characters')
      end

      #invalid combinations
      it 'raises error for invalid companyId, fleetGroupId, aircraftTypeId, salesStatusCd & aircraftStateCds' do
        query_string = "aircraftStateCds=999&aircraftTypeId=!&fleetGroupId=--&companyId=xyz&salesStatusCd=99999&tailNumberContains=zzz"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        # expect(response['errors'][0]['description'])
        # .to eq('Param companyId value must be a valid number; Param fleetGroupId value must be a valid number; ' \
        #   'Param aircraftTypeId value must be a valid number; '\
        #   'Param aircraftStateCds value 999 must not be greater than 99; '\
        #   'Param salesStatusCd value must not be greater than 99')
        expect(response['errors'][0]['description']).to include("Param companyId value must be a valid number")
        expect(response['errors'][0]['description']).to include("Param fleetGroupId value must be a valid number")
        expect(response['errors'][0]['description']).to include("Param aircraftTypeId value must be a valid number")
        expect(response['errors'][0]['description']).to include("Param aircraftStateCds value 999 must not be greater than 99")
        expect(response['errors'][0]['description']).to include("Param salesStatusCd value must not be greater than 99")

      end

      it 'raises error for invalid companyId, fleetGroupId, aircraftTypeId& aircraftStateCds' do
        query_string = "aircraftStateCds=999&aircraftTypeId=!&fleetGroupId=--&companyId=xyz&salesStatusCd=&tailNumberContains=zzz"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        # expect(response['errors'][0]['description'])
        # .to eq('Param companyId value must be a valid number; '\
        #   'Param fleetGroupId value must be a valid number; '\
        #   'Param aircraftTypeId value must be a valid number; '\
        #   'Param aircraftStateCds value 999 must not be greater than 99')
        expect(response['errors'][0]['description']).to include("Param companyId value must be a valid number")
        expect(response['errors'][0]['description']).to include("Param fleetGroupId value must be a valid number")
        expect(response['errors'][0]['description']).to include("Param aircraftTypeId value must be a valid number")
        expect(response['errors'][0]['description']).to include("Param aircraftStateCds value 999 must not be greater than 99")
      end


      it 'raises error for invalid fleetGroupId, salesStatusIds & tailNumberContains' do
        query_string = "aircraftStateCds=2&aircraftTypeId=2&fleetGroupId=!&companyId=&salesStatusCd=9999&tailNumberContains=ZZZ"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param fleetGroupId value must be a valid number; '\
              'Param salesStatusCd value must not be greater than 99')
      end

      it 'raises error for invalid aircraftStateIds & companyId' do
        query_string = "aircraftStateCds=+()&aircraftTypeId=&fleetGroupId=&companyId=XXX&salesStatusCd=&tailNumberContains=1"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param aircraftStateCds value must be a valid number; '\
                    'Param companyId value must be a valid number')
      end

      it ' raises error for invalid fleetGroupId & aircraftTypeId' do
        query_string = "aircraftStateCds=2&aircraftTypeId=99999&fleetGroupId=!&companyId=&salesStatusCd=&tailNumberContains=1"
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{query_string}&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq('Param fleetGroupId value must be a valid number; '\
            'Param aircraftTypeId value (99,999) does not reference a valid aircraft type')
      end
    end
  end
end