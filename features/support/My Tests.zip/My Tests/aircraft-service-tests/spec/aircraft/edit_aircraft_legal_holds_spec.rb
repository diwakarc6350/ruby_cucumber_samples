require 'spec_helper'
require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/aircraft_data'
require 'time'

=begin
  Tests edit holds on aircraft.
=end

describe 'aircraft holds' do
  context "version 4" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @resource=AIRCRAFT_HOLDS_V4_URL
      @aircrafts = db_conn_ais.connection.execute(get_aircraft_tail_numbers_sql)
      @ais_user = USER_MAP[:'AIS User'][:user]
      @ais_admin = USER_MAP[:'AIS Administrator'][:user]
      @all_active_holds = db_conn_ais.connection.execute(get_all_holds_sql)

      #create legal hold for tests
      date_time = Time.now - (30)
      date_time = date_time.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
      ids = @aircrafts.select { |rec| rec['code_type_name']=='Active' }.map { |rec| rec['acft_aircraft_id'].to_i }
      chosen_id = ids[rand(ids.length)]
      data = {:aircraftId => chosen_id, :holdType => "Legal", :heldBy => "qatest2",
              :placedOn => date_time, :holdPercent => 3.125,
              :holdDurationInDays => 1, :note => "this is note created by automation tests."}
      post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
    end

    describe 'edit legal holds' do

      it 'raises errors when a hold is edited without holdId' do
        data = {:holdId => '', :holdPercent => '3.125',
                :holdDurationInDays => 2, :note => "this is note edited by automation tests. blah"}.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdId cannot be null')
      end

      it 'raises errors when a hold is edited without holdPercent when it is held by the same user' do
        active_holds = @all_active_holds.select { |rec| rec['is_deleted_flg']=='F' && rec['held_by_user_name']==@ais_user }
        hold_id = active_holds[0]['acft_hold_id'].to_i
        data = {:holdId => hold_id, :holdPercent => '',
                :holdDurationInDays => 2, :note => "this is note edited by automation tests. blah"}.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)

        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdPercent cannot be null')
      end

      it 'raises errors when a hold is edited without holdPercent when it is not held by the same user' do
        active_holds = @all_active_holds.select { |rec| rec['is_deleted_flg']=='F' && rec['held_by_user_name']!=@ais_user }
        hold_id = active_holds[0]['acft_hold_id'].to_i
        data = {:holdId => hold_id, :holdPercent => '3.125',
                :holdDurationInDays => 2, :note => "this is note edited by automation tests. blah"}.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(403)
        expect(response['errors'][0]['description']).to include('cannot be edited')
      end

      it 'raises errors when a hold is edited with an invalid hold id' do
        data = {:holdId => 99999999, :holdPercent => '3.125',
                :holdDurationInDays => 4, :note => "this is note edited by automation tests. blah"}.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(404)
        expect(response['errors'][0]['description']).to include('does not reference a valid hold')
      end

      it 'raises errors when a hold is edited without holdDurationInDays' do
        active_holds = @all_active_holds.select { |rec| rec['is_deleted_flg']=='F' && rec['held_by_user_name']==@ais_user && !rec['expiration_ts'].nil? && rec['expiration_ts'].to_datetime > Time.now}
        pending("No active holds available in environment!") if active_holds[0].nil?
        hold_id = active_holds[0]['acft_hold_id'].to_i
        data = {:holdId => hold_id, :holdPercent => '3.125',
                :holdDurationInDays => '', :note => "this is note edited by automation tests. blah"}.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdDurationInDays cannot be null')
      end

      it 'raises errors when a hold is edited without note > 500 characters' do
        active_holds = @all_active_holds.select { |rec| rec['is_deleted_flg']=='F' && rec['held_by_user_name']==@ais_user }
        hold_id = active_holds[0]['acft_hold_id'].to_i
        notes = (0..550).map { (65 + rand(26)).chr }.join
        data = {:holdId => hold_id, :holdPercent => '3.125',
                :holdDurationInDays => 3, :note => notes}.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('cannot have a length greater than 500')
      end


      it 'raises errors when holdPercent is invalid' do
        active_holds = @all_active_holds.select { |rec| rec['is_deleted_flg']=='F' && rec['held_by_user_name']==@ais_user}
        hold_id = active_holds[0]['acft_hold_id'].to_i
        data = {:holdId => hold_id, :holdPercent => 'invalid',
                :holdDurationInDays => 3, :note => 'some noted to edit'}.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdPercent value is not a valid hold percent')
      end

      it 'raises errors when holdPercent is not a 1/32 fraction' do
        active_holds = @all_active_holds.select { |rec| rec['is_deleted_flg']=='F' && rec['held_by_user_name']==@ais_user }
        hold_id = active_holds[0]['acft_hold_id'].to_i
        data = {:holdId => hold_id, :holdPercent => 3.99,
                :holdDurationInDays => 3, :note => 'some noted to edit'}.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('is not within the acceptable list of hold percent values')
      end

      it 'raises errors when holdPercent is more than 100' do
        active_holds = @all_active_holds.select { |rec| rec['is_deleted_flg']=='F' && rec['held_by_user_name']==@ais_user }
        hold_id = active_holds[0]['acft_hold_id'].to_i
        data = {:holdId => hold_id, :holdPercent => 101.5,
                :holdDurationInDays => 3, :note => 'some noted to edit'}.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('is not within the acceptable list of hold percent values')
      end

      it 'raises errors when holdPercent is negative' do
        active_holds = @all_active_holds.select { |rec| rec['is_deleted_flg']=='F' && rec['held_by_user_name']==@ais_user }
        hold_id = active_holds[0]['acft_hold_id'].to_i
        data = {:holdId => hold_id, :holdPercent => -3.125,
                :holdDurationInDays => 3, :note => 'some noted to edit'}.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('is not within the acceptable list of hold percent values')
      end

      it 'raises errors when holdDurationInDays is invalid' do
        active_holds = @all_active_holds.select { |rec| rec['is_deleted_flg']=='F' && rec['held_by_user_name']==@ais_user }
        hold_id = active_holds[0]['acft_hold_id'].to_i
        data = {:holdId => hold_id, :holdPercent => -3.125,
                :holdDurationInDays => 'invalid', :note => 'some noted to edit'}.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdDurationInDays value is not a valid number of days')
      end

      it 'raises errors when holdDurationInDays is above the threshold' do
        active_holds = @all_active_holds.select { |rec| rec['is_deleted_flg']=='F' && rec['held_by_user_name']==@ais_user && !rec['expiration_ts'].nil? && rec['expiration_ts'].to_datetime > Time.now}
        pending("No active holds available in environment!") if active_holds[0].nil?
            hold_id = active_holds[0]['acft_hold_id'].to_i
        data = {:holdId => hold_id, :holdPercent => 3.125,
                :holdDurationInDays => 999, :note => 'some noted to edit'}.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('cannot be greater than max global setting')
      end

      it 'raises error when a deleted hold is edited' do
        active_holds = @all_active_holds.select { |rec| rec['is_deleted_flg']=='T' }
        if active_holds != nil
          hold_id = active_holds[0]['acft_hold_id'].to_i
          data = {:holdId => hold_id, :holdPercent => 3.125,
                  :holdDurationInDays => 2, :note => 'some noted to edit'}.to_json
          response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_admin)
          expect(response['errors'][0]['code']).to eq(422)
          expect(response['errors'][0]['description']).to include('cannot be edited')
        else
          log.info("Unable to find deleted holds.")
        end
      end

      it 'raises error when a expired hold is edited' do
        active_holds = @all_active_holds.select { |rec| rec['expiration_ts']!= nil && rec['expiration_ts'].to_datetime < Time.now && rec['held_by_userid'] == 'qatest2' && rec['created_by'] == 'qatest2' }
        hold_id = active_holds[0]['acft_hold_id'].to_i
        data = {:holdId => hold_id, :holdPercent => 3.125,
                :holdDurationInDays => 2, :note => 'some noted to edit'}.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('references a hold that expired')
      end

      it 'raises error when the % hold exceeds the actual amount that can be placed' do

        date_time = Time.now - (30)
        date_time = date_time.utc.strftime("%Y-%m-%dT%H:%M:%SZ")

        ids = @aircrafts.select { |rec| rec['code_type_name']=='Active' }.map { |rec| rec['acft_aircraft_id'].to_i }
        chosen_id = ids[rand(ids.length)]
        data = {:aircraftId => chosen_id, :holdType => "Legal", :heldBy => "Automaton",
                :placedOn => date_time, :holdPercent => 6.25,
                :holdDurationInDays => 3, :note => "this is note created by automation tests."}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        first_hold_id = response['holdId']


        data = {:aircraftId => chosen_id, :holdType => "Legal", :heldBy => "Automaton",
                :placedOn => date_time, :holdPercent => 6.25,
                :holdDurationInDays => 2, :note => "this is note created by automation tests."}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        second_hold_id = response['holdId']

        data = {:holdId => second_hold_id, :holdPercent => 96.875,
                :holdDurationInDays => 1, :note => 'some noted to edit'}.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)

        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('is greater than the available percentage ')

        db_conn_ais.connection.execute(clean_holds_sql(chosen_id, 'Automaton'))

      end

      it 'edit legal hold percent, duration and notes for an active aircraft' do
        date_time = Time.now - (30)
        date_time = date_time.utc.strftime("%Y-%m-%dT%H:%M:%SZ")

        ids = @aircrafts.select { |rec| rec['code_type_name']=='Active' }.map { |rec| rec['acft_aircraft_id'].to_i }
        chosen_id = ids[rand(ids.length)]
        data = {:aircraftId => chosen_id, :holdType => "Legal", :heldBy => "Automaton",
                :placedOn => date_time, :holdPercent => 3.125,
                :holdDurationInDays => 1, :note => "this is note created by automation tests."}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        hold_id = response['holdId']
        edit_data = {:holdId => hold_id, :holdPercent => 3.125,
                     :holdDurationInDays => 2, :note => "this is note edited by automation tests. blah"}
        data = edit_data.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)

        hold_info = db_conn_ais.connection.execute(get_holds_sql(hold_id))[0]
        expect(response['holdId']).to satisfy { |x| x > 0 }
        expect(hold_info['hold_pct'].to_f).to eq(edit_data[:holdPercent])
        expect(hold_info['notes_txt']).to eq(edit_data[:note])
        actual_duration = (Date.parse(hold_info['expiration_ts']) - Date.parse(hold_info['placed_ts'])).round
        expect(actual_duration.to_i).to eq(edit_data[:holdDurationInDays])
        db_conn_ais.connection.execute(clean_holds_sql(chosen_id, 'Automaton'))
      end

      it 'edit core hold percent, duration and notes for an active aircraft', :critical => true do
        date_time = Time.now - (30)
        date_time = date_time.utc.strftime("%Y-%m-%dT%H:%M:%SZ")

        ids = @aircrafts.select { |rec| rec['code_type_name']=='Active' }.map { |rec| rec['acft_aircraft_id'].to_i }
        chosen_id = ids[rand(ids.length)]
        data = {:aircraftId => chosen_id, :holdType => "Core", :heldBy => "Automaton",
                :placedOn => date_time, :holdPercent => 3.125,
                :holdDurationInDays => 1, :note => "this is note created by automation tests."}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        hold_id = response['holdId']
        edit_data = {:holdId => hold_id, :holdPercent => 3.125,
                     :holdDurationInDays => 2, :note => "this is note edited by automation tests. blah"}
        data = edit_data.to_json
        response = put_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)

        hold_info = db_conn_ais.connection.execute(get_holds_sql(hold_id))[0]
        expect(response['holdId']).to satisfy { |x| x > 0 }
        expect(hold_info['hold_pct'].to_f).to eq(edit_data[:holdPercent])
        expect(hold_info['notes_txt']).to eq(edit_data[:note])
        actual_duration = (Date.parse(hold_info['expiration_ts']) - Date.parse(hold_info['placed_ts'])).round
        expect(actual_duration.to_i).to eq(edit_data[:holdDurationInDays])
        db_conn_ais.connection.execute(clean_holds_sql(chosen_id, 'Automaton'))
      end

    end
  end
end