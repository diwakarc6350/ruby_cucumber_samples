require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/aircraft_data'
require 'time'

=begin
  Tests edit holds on aircraft.
=end

describe 'aircraft holds' do
  context "version 4" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @resource=AIRCRAFT_HOLDS_V4_URL
      @aircrafts = db_conn_ais.connection.execute(get_aircraft_tail_numbers_sql)
      @ais_user = USER_MAP[:'AIS User'][:user]
      @all_active_holds = db_conn_ais.connection.execute(get_all_holds_sql)
    end

    describe 'delete legal holds' do

      it 'raises errors when a hold id is non-existent' do
        data = {:holdId => 9999}.to_json
        response = delete_as_json "#{@resource}/9999", data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['description']).to include('does not reference a valid hold')
        expect(response['errors'][0]['code']).to eq(404)
      end

      it 'raises errors when a hold id is invalid' do
        data = {:holdId => 'not a valid hold id'}.to_json
        response = delete_as_json "#{@resource}/not_a_valid_hold_id", data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdId value is not a valid hold id')
      end

      it 'raises errors when a hold id is null' do
        data = {:holdId => ''}.to_json
        response = delete_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdId cannot be null')
      end

      it 'raises error when a expired hold is deleted' do
        active_holds = @all_active_holds.select { |rec| rec['expiration_ts']!= nil && rec['expiration_ts'].to_datetime < Time.now && rec['held_by_userid'] == 'qatest2' && rec['created_by'] == 'qatest2' }
        pending("There are no expired holds in #{ENV['ENVIRONMENT']}. Please Load Data and Try Again!") if active_holds.empty?
        hold_id = active_holds[0]['acft_hold_id'].to_i
        data = {:holdId => hold_id}.to_json
        response = delete_as_json "#{@resource}/#{hold_id}?", data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('references a hold that expired')

      end

      it 'delete legal hold for an active aircraft', :critical => true do
        #create a hold before delete
        date_time = Time.now - (30)
        date_time = date_time.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        ids = @aircrafts.select { |rec| rec['code_type_name']=='Active' }.map { |rec| rec['acft_aircraft_id'].to_i }
        chosen_id = ids[rand(ids.length)]
        data = {:aircraftId => chosen_id, :holdType => "Legal", :heldBy => "Automaton",
                :placedOn => date_time, :holdPercent => 3.125,
                :holdDurationInDays => 1, :note => "this is note created by automation tests for delete test."}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)

        #delete the hold create before
        hold_id = response['holdId']
        data = {:holdId => hold_id}.to_json
        response = delete_as_json "#{@resource}/#{hold_id}?", data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)

        expect(response['holdId']).to satisfy { hold_id > 0 }
        hold_info = db_conn_ais.connection.execute(get_holds_sql(hold_id))[0]
        expect(hold_info['is_deleted_flg']).to eq('T')

        #clean-up holds created and deleted.
        db_conn_ais.connection.execute(clean_holds_sql(chosen_id, 'Automaton'))
      end

    end
  end
end