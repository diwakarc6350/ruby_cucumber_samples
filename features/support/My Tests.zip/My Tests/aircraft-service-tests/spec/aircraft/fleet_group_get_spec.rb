require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/aircraft_data'

=begin
  In this test we make sure that the fleet group get returns the needed infomation
  correctly.
=end

describe 'aircraft fleet groups service' do
  context "version 4" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @resource=AIRCRAFT_FLEET_GROUPS_V3_URL
      @fleet_groups= db_conn_ais.connection.execute(get_aircraft_tail_numbers_sql)
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'get fleet group' do

      it 'gets fleet group information correctly', :critical => true do
        length = @fleet_groups.length - 1
        chosen_fleet_group = @fleet_groups[rand(0..length)]
        id = chosen_fleet_group['acft_fleet_group_id'].to_i
        actual_fleet_group = response_as_json "#{AIRCRAFT_FLEET_GROUPS_V4_URL}/#{id}?#{APP_AGENT_PARAM}",
                                              @account_mgmt_oauth.authorized_oauth_header
        expected_fleet_group = chosen_fleet_group
        expect(actual_fleet_group['id'].to_i).to eq(expected_fleet_group['acft_fleet_group_id'].to_i)
        expect(actual_fleet_group['fleetGroupName']).to eq(expected_fleet_group['fleet_group_name'])
      end

      it 'gets all fleet groups when no id is given' do
        response = response_as_json "#{AIRCRAFT_FLEET_GROUPS_V4_URL}?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response.length).to be > 1
      end

      it 'gets invalid id error when id is negative' do
        response = response_as_json "#{AIRCRAFT_FLEET_GROUPS_V4_URL}/-1?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq("Invalid id \'-1\' in request to look up FleetGroup")
      end

      it 'gets invalid id error when id is invalid' do
        response = response_as_json "#{AIRCRAFT_FLEET_GROUPS_V4_URL}/abn*90?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq("Invalid id 'abn*90' in request to look up FleetGroup")
      end

      it 'gets id does not exist error when no id is non-existent' do
        response = response_as_json "#{AIRCRAFT_FLEET_GROUPS_V4_URL}/999999999?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(404)
        expect(response['errors'][0]['description']).to include("No row with the given identifier exists: ")
      end


    end
  end
end
