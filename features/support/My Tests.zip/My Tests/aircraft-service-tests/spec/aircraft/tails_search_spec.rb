require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/aircraft_data'

=begin
  In this test we make sure the aircraft tails are retrieved correctly
  by the aircraft service. We validate this with the data present in the
  ais aircraft type and aircraft tail table
=end

describe 'aircraft inventory service' do
  context "version 4" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @resource = AIRCRAFT_TAILS_V3_URL
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
      @all_tails = db_conn_ais.connection.execute(get_aircraft_tail_numbers_sql)
      @all_types = db_conn_ais.connection.execute(get_aircrafts_by_type_name_sql)
    end

    describe 'search aircraft tails', :critical => true do

      context 'searches by aircraftStateCds' do
        aircraft_states = db_conn_ais.connection.execute(get_aircrafts_code_types_sql(2))
        aircraft_states.each do |state|
          it "searches by #{state['code_type_name']} " do
            query_string = "aircraftStateCds=#{state['code_type_class_id'].to_i}"
            actual_aircrafts = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                                @account_mgmt_oauth.authorized_oauth_header
            expected_aircrafts = @all_tails.select { |rec| rec['aircraft_state_cd'] == state['acft_code_type_id'] }
            expect(actual_aircrafts.length).to eq(expected_aircrafts.length.to_i)
          end
        end
      end

      it 'gets the ranks in the correct order', :quarantine => true do
        query_string = ""
        actual_aircrafts = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                            @account_mgmt_oauth.authorized_oauth_header
        i=0
        actual_aircrafts.each do |actual_aircraft|
          if actual_aircraft.has_key?('rank')
            expect(actual_aircraft['rank']).to eq(@all_tails[i]['display_rnk'].to_i)
            i+=1
          end
        end
      end

      it 'searches by more than one aircraftStateCds' do
        states = db_conn_ais.connection.execute(get_aircrafts_code_types_sql(2))
        state1 = states[0]['code_type_class_id'].to_i
        state2 = states[1]['code_type_class_id'].to_i
        query_string = "aircraftStateCds=#{state1}&" +
            "aircraftStateCds=#{state2}"
        actual_aircrafts = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                            @account_mgmt_oauth.authorized_oauth_header
        state1 = states[0]['acft_code_type_id'].to_i
        state2 = states[1]['acft_code_type_id'].to_i
        expected_aircrafts = @all_tails.select { |rec| rec['aircraft_state_cd'].to_i==state1 || rec['aircraft_state_cd'].to_i==state2 }
        expect(actual_aircrafts.length).to eq(expected_aircrafts.length)
      end

      it 'searches by aircraftTypeId' do
        aircraft_type_ids = @all_tails
        .select { |rec| rec['acft_aircraft_type_id'] != nil }
        .map { |rec| rec['acft_aircraft_type_id'].to_i }
        aircraft_type_id = aircraft_type_ids[rand(aircraft_type_ids.length)]
        query_string = "aircraftTypeId=#{aircraft_type_id}"
        actual_aircrafts = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                            @account_mgmt_oauth.authorized_oauth_header
        expected_aircrafts = db_conn_ais.connection.execute(get_aircraft_info_by_type_id(aircraft_type_id))
        expect(actual_aircrafts.length).to eq(expected_aircrafts.length)
      end

      it 'searches by companyId' do
        company_ids = @all_tails
        .select { |rec| rec['ijet_ej_company_id'] != nil }
        .map { |rec| rec['ijet_ej_company_id'].to_i }
        company_id = company_ids[rand(company_ids.length)]
        query_string = "companyId=#{company_id}"
        actual_aircrafts = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                            @account_mgmt_oauth.authorized_oauth_header
        expected_aircrafts = @all_tails.select { |rec| rec['ijet_ej_company_id'].to_i==company_id }
        expect(actual_aircrafts.length).to eq(expected_aircrafts.length)
      end

      it 'searches by fleetGroupId' do
        fleet_group_ids = @all_types
        .select { |rec| rec['fleet_group_id'] != nil }
        .map { |rec| rec['fleet_group_id'].to_i }
        fleet_group_id = fleet_group_ids[rand(fleet_group_ids.length)]
        query_string = "fleetGroupId=#{fleet_group_id}"
        actual_aircrafts = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                            @account_mgmt_oauth.authorized_oauth_header
        expected_aircrafts = @all_tails.select { |rec| rec['acft_fleet_group_id'].to_i==fleet_group_id }

        expect(actual_aircrafts.length).to eq(expected_aircrafts.length)
      end

      it 'searches by salesStatusCd (Selling Fractional)' do
        query_string = "salesStatusCd=1"
        actual_aircrafts = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                            @account_mgmt_oauth.authorized_oauth_header
        expected_aircrafts = @all_tails.select { |rec| rec['sales_status']=='Selling Fractionally' }
        expect(actual_aircrafts.length).to eq(expected_aircrafts.length)
      end


      it 'searches by salesStatusCd (Selling Add-Ons)' do
        query_string = "salesStatusCd=2"
        actual_aircrafts = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                            @account_mgmt_oauth.authorized_oauth_header
        expected_aircrafts = @all_tails.select { |rec| rec['sales_status']=='Selling Add-Ons' }
        expect(actual_aircrafts.length).to eq(expected_aircrafts.length)
      end

      it 'searches by salesStatusCd (No Sales)' do
        query_string = "salesStatusCd=3"
        actual_aircrafts = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                            @account_mgmt_oauth.authorized_oauth_header
        expected_aircrafts = @all_tails.select { |rec| rec['sales_status']=='No Sales' }
        expect(actual_aircrafts.length).to eq(expected_aircrafts.length)
      end

      it 'gets the aircraft id and tail number correctly' do
        query_string = "aircraftStateIds=&aircraftTypeId=&fleetGroupId=&companyId=&salesStatusId=&tailNumberContains="
        actual_aircrafts = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                            @account_mgmt_oauth.authorized_oauth_header

        actual_aircraft = actual_aircrafts[0]
        tail_number = actual_aircraft['tailNumber']
        expected_aircraft = db_conn_ais.connection.execute(get_aircraft_info_by_tail_sql(tail_number))[0]
        expect(actual_aircraft['id']).to eq(expected_aircraft['acft_aircraft_id'].to_i)
        expect(actual_aircraft['tailNumber']).to eq(expected_aircraft['aircraft_tail_nbr'])
      end

      it 'gets the aircraft type id and name correctly' do
        query_string = "aircraftStateIds=&aircraftTypeId=&fleetGroupId=&companyId=&salesStatusId=&tailNumberContains="
        actual_aircrafts = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                            @account_mgmt_oauth.authorized_oauth_header
        actual_aircraft = actual_aircrafts[rand(actual_aircrafts.length)]
        tail_number = actual_aircraft['tailNumber']
        expected_aircraft = db_conn_ais.connection.execute(get_aircraft_info_by_tail_sql(tail_number))[0]
        expect(actual_aircraft['inventoryType']['id'].to_i).to eq(expected_aircraft['acft_aircraft_type_id'].to_i)
        expect(actual_aircraft['inventoryType']['aircraftTypeName']).to eq(expected_aircraft['aircraft_type_name'])
      end

      it 'gets manufactureDate when present' do
        tail = @all_tails.select { |rec| rec['manufacture_dt'] != nil }
        chosen_tail = tail[0]['aircraft_tail_nbr']

        query_string = "aircraftStateIds=&aircraftTypeId=&fleetGroupId=&companyId=&salesStatusId=&tailNumberContains=#{chosen_tail}"
        actual_aircraft = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                           @account_mgmt_oauth.authorized_oauth_header
        expect(actual_aircraft[0]['manufactureDate'].to_datetime).to eq(tail[0]['manufacture_dt'].to_datetime)
      end

      it 'does not get manufactureDate when not present' do
        tail = @all_tails.select { |rec| rec['manufacture_dt'] == nil }
        if tail.length >0
          chosen_tail = tail[0]['aircraft_tail_nbr']

          query_string = "aircraftStateIds=&aircraftTypeId=&fleetGroupId=&companyId=&salesStatusId=&tailNumberContains=#{chosen_tail}"
          actual_aircraft = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                             @account_mgmt_oauth.authorized_oauth_header
          expect(actual_aircraft[0].has_key?('manufactureDate')).to be false
        else
          log.info('cannot find test data with manufacture_dt as nil')
        end
      end

      it 'get warrantyExpirationDate when present' do
        tail = @all_tails.select { |rec| rec['warranty_expiration_dt'] != nil }
        chosen_tail = tail[0]['aircraft_tail_nbr']
        query_string = "aircraftStateIds=&aircraftTypeId=&fleetGroupId=&companyId=&salesStatusId=&tailNumberContains=#{chosen_tail}"
        actual_aircraft = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                           @account_mgmt_oauth.authorized_oauth_header
        expect(actual_aircraft[0]['warrantyExpirationDate'].to_datetime).to eq(tail[0]['warranty_expiration_dt'].to_datetime)
      end

      it 'does not get warrantyExpirationDate when not present' do
        tail = @all_tails.select { |rec| rec['warranty_expiration_dt'] == nil }
        if tail.length > 0
          chosen_tail = tail[0]['aircraft_tail_nbr']
          query_string = "aircraftStateIds=&aircraftTypeId=&fleetGroupId=&companyId=&salesStatusId=&tailNumberContains=#{chosen_tail}"
          actual_aircraft = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                             @account_mgmt_oauth.authorized_oauth_header
          expect(actual_aircraft[0].has_key?('warrantyExpirationDate')).to be false
        else
          log.info('cannot find test data with warrantyExpirationDate as nil')
        end
      end

      it 'gets contractsUntilDate when present' do
        tail = @all_tails.select { |rec| rec['contracts_until_dt'] != nil }

        chosen_tail = tail[0]['aircraft_tail_nbr']
        query_string = "aircraftStateIds=&aircraftTypeId=&fleetGroupId=&companyId=&salesStatusId=&tailNumberContains=#{chosen_tail}"
        actual_aircraft = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                           @account_mgmt_oauth.authorized_oauth_header
        expect(actual_aircraft[0]['contractsUntilDate'].to_datetime).to eq(tail[0]['contracts_until_dt'].to_datetime)
      end

      it 'does not get contractsUntilDate when not present' do
        tail = @all_tails.select { |rec| rec['contracts_until_dt'] == nil }
        if tail.length > 0
          chosen_tail = tail[0]['aircraft_tail_nbr']
          query_string = "aircraftStateIds=&aircraftTypeId=&fleetGroupId=&companyId=&salesStatusId=&tailNumberContains=#{chosen_tail}"
          actual_aircraft = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                             @account_mgmt_oauth.authorized_oauth_header
          expect(actual_aircraft[0].has_key?('contractsUntilDate')).to be false
        else
          log.info('cannot find test data with contracts_until_dt as nil')
        end
      end

      it 'gets aircraftStateCd and aircraftStateDesc' do
        chosen_tail = @all_tails[0]
        tail = chosen_tail['aircraft_tail_nbr']
        query_string = "aircraftStateIds=&aircraftTypeId=&fleetGroupId=&companyId=&salesStatusId=&tailNumberContains=#{tail}"
        actual_aircraft = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                           @account_mgmt_oauth.authorized_oauth_header
        expect(actual_aircraft[0].has_key?('aircraftStateCd')).to be true
        expect(actual_aircraft[0].has_key?('aircraftStateDesc')).to be true
        expect(actual_aircraft[0]['aircraftStateCd']).to eq(chosen_tail['aircraft_state_cd'].to_i)
        expect(actual_aircraft[0]['aircraftStateDesc']).to eq(chosen_tail['code_type_name'])
      end

      it 'get companyId and companyName when present' do
        tail = @all_tails.select { |rec| rec['ijet_ej_company_id'] != nil &&
            rec['company_name'] != nil }
        chosen_tail = tail[0]
        query_string = "aircraftStateIds=&aircraftTypeId=&fleetGroupId=&companyId=&salesStatusId=&tailNumberContains=#{chosen_tail['aircraft_tail_nbr']}"
        actual_aircraft = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                           @account_mgmt_oauth.authorized_oauth_header
        expect(actual_aircraft[0].has_key?('companyId')).to be true
        expect(actual_aircraft[0].has_key?('companyName')).to be true
        expect(actual_aircraft[0]['companyId']).to eq(chosen_tail['ijet_ej_company_id'].to_i)
        expect(actual_aircraft[0]['companyName']).to eq(chosen_tail['company_name'])
      end

      it 'does not get companyId and companyName when not present' do
        tail = @all_tails.select { |rec| rec['ijet_ej_company_id'] == nil &&
            rec['company_name'] == nil }
        if tail.length > 0
          chosen_tail = tail[0]['aircraft_tail_nbr']
          query_string = "aircraftStateIds=&aircraftTypeId=&fleetGroupId=&companyId=&salesStatusId=&tailNumberContains=#{chosen_tail}"
          actual_aircraft = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                             @account_mgmt_oauth.authorized_oauth_header
          expect(actual_aircraft[0].has_key?('companyId')).to be false
          expect(actual_aircraft[0].has_key?('companyName')).to be false
        else
          log.info('cannot find test data with companyId and companyName as nil')
        end
      end

      it 'searches by partial tail numbers' do
        get_partial_tail_numbers.each do |partial_tail|
          expected_aircrafts = db_conn_ais.connection.execute(get_aircraft_info_by_tail_sql(partial_tail))

          query_string ="activeStatus=true&aircraftTypename=&tailNumberContains=#{partial_tail}"
          actual_aircrafts = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?&#{query_string}&#{APP_AGENT_PARAM}",
                                              @account_mgmt_oauth.authorized_oauth_header
          actual_aircrafts = actual_aircrafts.find_all {|ac| ac['tailNumber'].include? partial_tail}
          expect(actual_aircrafts.length).to eq(expected_aircrafts.length)
        end
      end

    end
  end
end