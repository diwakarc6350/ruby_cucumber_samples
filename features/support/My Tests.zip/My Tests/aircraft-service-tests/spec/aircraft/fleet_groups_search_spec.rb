require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/aircraft_data'

=begin

=end

describe 'aircraft fleet groups service' do
  context "version 4" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'search fleet groups' do

      it 'gets fleet groups information correctly' do
        expected_fleet_groups= db_conn_ais.connection.execute(get_all_fleet_groups_sql)
        actual_fleet_groups = response_as_json "#{AIRCRAFT_FLEET_GROUPS_V4_URL}/?#{APP_AGENT_PARAM}",
                                                 @account_mgmt_oauth.authorized_oauth_header
          i=0
          actual_fleet_groups.each do |actual_fleet_group|
            expect(actual_fleet_group['id']).to eq(expected_fleet_groups[i]['acft_fleet_group_id'].to_i)
            expect(actual_fleet_group['fleetGroupName']).to eq(expected_fleet_groups[i]['fleet_group_name'])
            i+=1
          end
      end

    end
  end
end
