require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/aircraft_data'

=begin
    In this test we make sure we are able to get the aircraft tail for a given tail id.
=end

describe 'aircraft inventory service' do
  context "version 4" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @resource = AIRCRAFT_TAILS_V3_URL
      @all_tails = db_conn_ais.connection.execute(get_aircraft_tail_numbers_sql)
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'get aircraft tail' do
      it 'gets the tail information correctly' do
        id = @all_tails[rand(0..@all_tails.length-1)]['acft_aircraft_id'].to_i

        actual_tail_info = response_as_json "#{AIRCRAFT_TAILS_V4_URL}/#{id}?#{APP_AGENT_PARAM}",
                                            @account_mgmt_oauth.authorized_oauth_header
        expected_tail_info = @all_tails.select { |rec| rec['acft_aircraft_id'].to_i==id }
        expect(actual_tail_info['id']).to eq(expected_tail_info[0]['acft_aircraft_id'].to_i)
        expect(actual_tail_info['tailNumber']).to eq(expected_tail_info[0]['aircraft_tail_nbr'])
      end

      it 'gets aircraft tail information when no id is given' do
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response.length).to be > 1
      end

      it 'gets invalid id error when id is negative' do
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}/-1?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq("Param id value must not be less than 1")
      end

      it 'gets invalid id error when id is invalid' do
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}/abn*90?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq("Param id value must be a valid number")
      end

      it 'gets id does not exist error when no id is non-existent' do
        response = response_as_json "#{AIRCRAFT_TAILS_V4_URL}/999999999?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(404)
        expect(response['errors'][0]['description']).to include("No row with the given identifier exists: ")
      end
    end

  end
end
