require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/aircraft_data'
require 'time'

=begin
  Tests hold creation on aircraft.
=end

describe 'aircraft holds' do
  context "version 4" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @resource=AIRCRAFT_HOLDS_V4_URL
      @aircrafts = db_conn_ais.connection.execute(get_aircraft_tail_numbers_sql)
      @ais_user = USER_MAP[:'AIS User'][:user]
      #@resource="http://amdev01.netjets.com:9080/aircraft-service-web/aircraft/v4/holds?appAgent=AircraftInventoryUser"
    end

    describe 'create legal holds' do

      it 'raises errors when a hold is placed without holdType' do
        date_time = Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        data = {:holdType => "", :aircraftId => "12345678", :heldBy => "qatest1", :placedOn => date_time,
                :holdPercent => "25", :holdDurationInDays => "30", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdType cannot be null')
      end

      it 'raises errors when a hold is placed without aircraftId' do
        date_time = Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        data = {:holdType => "Legal", :aircraftId => "", :heldBy => "qatest1", :placedOn => date_time,
                :holdPercent => "50", :holdDurationInDays => "30", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param aircraftId cannot be null')
      end

      it 'raises errors when a hold is placed without heldBy' do
        date_time = Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        data = {:holdType => "Legal", :aircraftId => "12345678", :heldBy => "", :placedOn => date_time,
                :holdPercent => "75", :holdDurationInDays => "30", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param heldBy cannot be null')
      end

      it 'raises errors when a hold is placed without placedOn' do
        data = {:holdType => "Legal", :aircraftId => "12345678", :heldBy => "User", :placedOn => "",
                :holdPercent => "100", :holdDurationInDays => "30", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param placedOn cannot be null')
      end

      it 'raises errors when a hold is placed without holdPercent' do
        date_time = Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        data = {:holdType => "Legal", :aircraftId => "12345678", :heldBy => "User", :placedOn => date_time,
                :holdPercent => "", :holdDurationInDays => "30", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdPercent cannot be null')
      end

      it 'raises errors when a hold is placed without holdDurationInDays' do
        date_time = Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        ids = @aircrafts.select { |rec| rec['code_type_name']=='Active' }.map { |rec| rec['acft_aircraft_id'].to_i }
        chosen_id = ids[rand(ids.length)]
        data = {:holdType => "Legal", :aircraftId => chosen_id, :heldBy => "User", :placedOn => date_time,
                :holdPercent => "12.5", :holdDurationInDays => "", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdDurationInDays cannot be null')
      end

      it 'raises errors when a hold is placed without note > 500 characters' do
        date_time = Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        notes = (0...550).map { (65 + rand(26)).chr }.join
        data = {:holdType => "Legal", :aircraftId => "12345678", :heldBy => "User", :placedOn => date_time,
                :holdPercent => "12.5", :holdDurationInDays => "30", :note => notes}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('cannot have a length greater than 500')
      end

      it 'raises errors when holdType is invalid' do
        date_time = Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        data = {:holdType => "Not a Valid Hold Type", :aircraftId => "12345678", :heldBy => "User", :placedOn => date_time,
                :holdPercent => "25", :holdDurationInDays => "30", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdType value is not a valid hold type')
      end

      it 'raises errors when aircraftId is invalid' do
        date_time = Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        data = {:holdType => "Legal", :aircraftId => "invalid", :heldBy => "User", :placedOn => date_time,
                :holdPercent => "3.125", :holdDurationInDays => "30", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param aircraftId value is not a valid aircraft id')
      end

      it 'raises errors when placedOn is invalid' do
        data = {:holdType => "Legal", :aircraftId => "123", :heldBy => "User", :placedOn => "xyz",
                :holdPercent => "3.125", :holdDurationInDays => "30", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param placedOn value is not a valid date')
      end

      it 'raises errors when holdPercent is invalid' do
        date_time = Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        data = {:holdType => "Legal", :aircraftId => "12345678", :heldBy => "User", :placedOn => date_time,
                :holdPercent => "invalid", :holdDurationInDays => "30", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdPercent value is not a valid hold percent')
      end

      it 'raises errors when holdPercent is not a 1/32 fraction' do
        date_time = Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        data = {:holdType => "Legal", :aircraftId => "12345678", :heldBy => "User", :placedOn => date_time,
                :holdPercent => "8.992", :holdDurationInDays => "30", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdPercent with value 8.992 is not within the acceptable list of hold percent values')
      end

      it 'raises errors when holdPercent is more than 100' do
        date_time = Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        data = {:holdType => "Legal", :aircraftId => "12345678", :heldBy => "User", :placedOn => date_time,
                :holdPercent => "101", :holdDurationInDays => "30", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdPercent with value 101 is not within the acceptable list of hold percent values')
      end

      it 'raises errors when holdPercent is negative' do
        date_time = Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        data = {:holdType => "Legal", :aircraftId => "12345678", :heldBy => "User", :placedOn => date_time,
                :holdPercent => "-56", :holdDurationInDays => "30", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdPercent with value -56 is not within the acceptable list of hold percent values')
      end

      it 'raises errors when holdDurationInDays is invalid' do
        date_time = Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        data = {:holdType => "Legal", :aircraftId => "12345678", :heldBy => "User", :placedOn => date_time,
                :holdPercent => "3.125", :holdDurationInDays => "invalid", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdDurationInDays value is not a valid number of days')
      end

      it 'raises errors when holdDurationInDays is above the threshold' do
        date_time = Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        data = {:holdType => "Legal", :aircraftId => "12345678", :heldBy => "User", :placedOn => date_time,
                :holdPercent => "3.125", :holdDurationInDays => "999", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdDurationInDays value 999 cannot be greater than max global setting')
      end
=begin
      Negative duration raises error, will have to be fixed
      it 'raises errors when holdDurationInDays is negative' do
        date_time = Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        data = {:holdType => "Legal", :aircraftId => "12345678", :heldBy => "User", :placedOn => date_time,
                :holdPercent => "3.125", :holdDurationInDays => "-5", :note => "legal hold"}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header
        puts response
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to include('Param holdDurationInDays is invalid')
      end
=end
      it 'create legal hold for an active aircraft', :critical => true do
        date_time = Time.now - (30)
        date_time = date_time.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        ids = @aircrafts.select { |rec| rec['code_type_name']=='Active' }.map { |rec| rec['acft_aircraft_id'].to_i }
        chosen_id = ids[rand(ids.length)]
        data = {:aircraftId => chosen_id, :holdType => "Legal", :heldBy => "Automaton",
                :placedOn => date_time, :holdPercent => 3.125,
                :holdDurationInDays => 1, :note => "this is note created by automation tests."}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response.has_key?('holdId')).to eq(true)
        expect(response['holdId']).to satisfy { |x| x > 0 }
        db_conn_ais.connection.execute(clean_holds_sql(chosen_id, 'Automaton'))
      end

      it 'create Core hold for an active aircraft with duration' do
        date_time = Time.now - (30)
        date_time = date_time.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        ids = @aircrafts.select { |rec| rec['code_type_name']=='Active' }.map { |rec| rec['acft_aircraft_id'].to_i }
        chosen_id = ids[rand(ids.length)]
        data = {:aircraftId => chosen_id, :holdType => "Core", :heldBy => "Automaton",
                :placedOn => date_time, :holdPercent => 3.125,
                :holdDurationInDays => 1, :note => "this is note created by automation tests."}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response.has_key?('holdId')).to eq(true)
        expect(response['holdId']).to satisfy { |x| x > 0 }
        db_conn_ais.connection.execute(clean_holds_sql(chosen_id, 'Automaton'))
      end

      it 'create Core hold for an active aircraft without duration' do
        date_time = Time.now - (30)
        date_time = date_time.utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        ids = @aircrafts.select { |rec| rec['code_type_name']=='Active' }.map { |rec| rec['acft_aircraft_id'].to_i }
        chosen_id = ids[rand(ids.length)]
        data = {:aircraftId => chosen_id, :holdType => "Core", :heldBy => "Automaton",
                :placedOn => date_time, :holdPercent => 3.125,
                :holdDurationInDays => "", :note => "this is note created by automation tests."}
        response = post_as_json @resource, data, @account_mgmt_oauth.authorized_oauth_header(force_user = @ais_user)
        expect(response.has_key?('holdId')).to eq(true)
        expect(response['holdId']).to satisfy { |x| x > 0 }
        db_conn_ais.connection.execute(clean_holds_sql(chosen_id, 'Automaton'))
      end

    end
  end
end