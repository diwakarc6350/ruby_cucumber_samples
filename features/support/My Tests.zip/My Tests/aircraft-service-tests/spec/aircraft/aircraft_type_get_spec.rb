require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/aircraft_data'

=begin
  In this test we make sure the aircraft types are displayed correctly
  by the aircraft service. We validate this with the data present in the
  ais aircraft type table.
=end

describe 'aircraft inventory types service' do
  context "version 4" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @resource=AIRCRAFT_TYPES_V3_URL
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'get aircraft type', :critical => true do
      it 'gets aircraft type - model, manufacturer, aircraft_type_name, no of engines and notes information correctly' do
        aircraft_types_from_db = db_conn_ais.connection.execute(get_all_ais_ac_type_sql)
        expected_aircraft_type = aircraft_types_from_db[rand(aircraft_types_from_db.length)]
        if expected_aircraft_type != NIL
          id = expected_aircraft_type['acft_aircraft_type_id'].to_i
          actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V4_URL}/#{id}?#{APP_AGENT_PARAM}",
                                                  @account_mgmt_oauth.authorized_oauth_header
          expect(actual_aircraft_type['legalModelName']).to eq(expected_aircraft_type['legalmodelname'])
          expect(actual_aircraft_type['legalManufacturerName']).to eq(expected_aircraft_type['manufacturer'])
          expect(actual_aircraft_type['notes']).to eq(expected_aircraft_type['notes'])
          expect(actual_aircraft_type['numberOfEngines']).to eq(expected_aircraft_type['engines_cnt'].to_i)
          expect(actual_aircraft_type['aircraftTypeName']).to eq(expected_aircraft_type['aircraft_type_name'])
        else
          log.info 'cannot find data for aircraft types'
        end
      end

      it 'gets the rank if present' do
        aircraft_types_from_db = db_conn_ais.connection.execute(get_all_ais_ac_type_sql)
        aircraft_types = aircraft_types_from_db.select { |rec| rec['display_rnk']!=nil }
        expected_aircraft_type = aircraft_types[rand(aircraft_types.length)]
        id = expected_aircraft_type['acft_aircraft_type_id'].to_i
        actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V4_URL}/#{id}?#{APP_AGENT_PARAM}",
                                                @account_mgmt_oauth.authorized_oauth_header
        expect(actual_aircraft_type['rank'].to_i).to eq(expected_aircraft_type['display_rnk'].to_i)
      end

      it 'does not get rank if rank is not assigned' do
        aircraft_types_from_db = db_conn_ais.connection.execute(get_all_ais_ac_type_sql)
        aircraft_types_not_ranked = aircraft_types_from_db.select { |rec| rec['display_rnk']==nil }
        expected_aircraft_type = aircraft_types_not_ranked[rand(aircraft_types_not_ranked.length)]
        id = expected_aircraft_type['acft_aircraft_type_id'].to_i
        actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V4_URL}/#{id}?#{APP_AGENT_PARAM}",
                                                @account_mgmt_oauth.authorized_oauth_header
        expect(actual_aircraft_type.has_key?('rank')).to be false
      end

      it 'gets the fleet group information', :critical => true do
        aircraft_types_from_db = db_conn_ais.connection.execute(get_all_ais_ac_type_sql)
        aircraft_type_with_fleet_group = aircraft_types_from_db.select { |rec| rec['fleet_group_name']!=nil }
        expected_aircraft_type = aircraft_type_with_fleet_group[rand(aircraft_type_with_fleet_group.length)]
        if expected_aircraft_type != NIL
          id = expected_aircraft_type['acft_aircraft_type_id'].to_i
          actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V4_URL}/#{id}?#{APP_AGENT_PARAM}",
                                                  @account_mgmt_oauth.authorized_oauth_header
          actual_fleet_group = actual_aircraft_type['fleetGroup']
          expect(actual_fleet_group['id']).to eq(expected_aircraft_type['acft_fleet_group_id'].to_i)
          expect(actual_fleet_group['fleetGroupName']).to eq(expected_aircraft_type['fleet_group_name'])
        else
          log.info 'cannot find data for aircraft types'
        end
      end

      it 'gets isActive as false' do
        expected_aircraft_type = db_conn_ais.connection.execute(get_ais_ac_type_status_sql('F'))[0]
        if expected_aircraft_type != NIL
          id = expected_aircraft_type['acft_aircraft_type_id'].to_i
          actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V4_URL}/#{id}?#{APP_AGENT_PARAM}",
                                                  @account_mgmt_oauth.authorized_oauth_header
          expect(actual_aircraft_type['isActive']).to be false
        else
          log.info 'cannot find data with isActive as false'
        end
      end

      it 'gets isActive as true' do
        expected_aircraft_type = db_conn_ais.connection.execute(get_ais_ac_type_status_sql('T'))[0]
        if expected_aircraft_type != NIL
          id = expected_aircraft_type['acft_aircraft_type_id'].to_i
          actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V4_URL}/#{id}?#{APP_AGENT_PARAM}",
                                                  @account_mgmt_oauth.authorized_oauth_header
          expect(actual_aircraft_type['isActive']).to be true
        else
          log.info 'cannot find data with isActive as true'
        end
      end

      AIRCRAFT_CABIN_SIZE_CODES.each_pair do |code, cabin_info|
        it "gets the code and description correctly for #{cabin_info[1]} cabin" do
          expected_aircraft_type = db_conn_ais.connection.execute(get_ais_ac_type_cabin_sql(cabin_info[0]))
          if expected_aircraft_type != NIL && expected_aircraft_type.length >0
            id = expected_aircraft_type[0]['acft_aircraft_type_id'].to_i
            actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V4_URL}/#{id}?#{APP_AGENT_PARAM}",
                                                    @account_mgmt_oauth.authorized_oauth_header
            expect(actual_aircraft_type['cabinSizeDesc']).to eq(cabin_info[1])
          else
            log.info "cannot find data for #{desc}-cabin size"
          end
        end
      end


      describe 'sales status' do
        sales_status = db_conn_ais.connection.execute(sales_status_sql)
        sales_status.each do |sales_info|
          it "gets the right status description for #{sales_info['code_type_name']}", :critical => true do
            expected_aircraft_type = db_conn_ais.connection.execute(get_ais_ac_type_sales_sql(sales_info['acft_code_type_id']))[0]
            if expected_aircraft_type != NIL && expected_aircraft_type.length >0
              id = expected_aircraft_type['acft_aircraft_type_id'].to_i
              actual_aircraft_type = response_as_json "#{AIRCRAFT_TYPES_V4_URL}/#{id}?#{APP_AGENT_PARAM}",
                                                      @account_mgmt_oauth.authorized_oauth_header
              expect(actual_aircraft_type['salesStatusDesc']).to eq(sales_info['code_type_name'])
              expect(actual_aircraft_type['salesStatusCd']).to eq(sales_info['acft_code_type_id'].to_i)
            else
              log.info "cannot find data for #{sales_info['code_type_name']}-sales status"
            end
          end
        end
      end


      it 'gets aircraft type information when no id is given' do
        response = response_as_json "#{AIRCRAFT_TYPES_V4_URL}?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response.length).to be > 1
      end

      it 'gets invalid id error when id is negative' do
        response = response_as_json "#{AIRCRAFT_TYPES_V4_URL}/-1?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq("Invalid id '\-1\' in request to look up AisAircraftType")
      end

      it 'gets invalid id error when id is invalid' do
        response = response_as_json "#{AIRCRAFT_TYPES_V4_URL}/abn*90?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(422)
        expect(response['errors'][0]['description']).to eq("Invalid id 'abn*90' in request to look up AisAircraftType")
      end

      it 'gets id does not exist error when no id is non-existent' do
        response = response_as_json "#{AIRCRAFT_TYPES_V4_URL}/999999999?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        expect(response['errors'][0]['code']).to eq(404)
        expect(response['errors'][0]['description']).to include("No row with the given identifier exists: ")
      end
    end


  end
end

