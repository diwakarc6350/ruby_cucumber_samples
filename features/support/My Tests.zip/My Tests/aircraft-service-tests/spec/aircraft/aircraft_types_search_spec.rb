require 'spec_helper'
require 'data_helper'
require 'utility'
require 'host_names'
require 'account_management_oauth'
require 'data/aircraft_data'

=begin
  In this test we make sure the aircraft types are displayed correctly
  by the aircraft service. We validate this with the data present in the
  ais aircraft type table.
=end

describe 'aircraft inventory types service' do
  context "version 4" do
    include_context "rest client"

    before(:all) do
      @account_mgmt_oauth = AccountManagementOauth.new
      @resource=AIRCRAFT_TYPES_V3_URL
      #log.info "Access Token: #{@account_mgmt_oauth.authorized_oauth_header}"
    end

    describe 'search aircraft types' do

      it 'gets the legal model, legal manufacturer, aircraft_type_name, rank and notes information correctly', :critical => true do
        expected_aircraft_types = db_conn_ais.connection.execute(get_all_ais_ac_type_sql)
        .sort_by { |x| x['acft_aircraft_type_id'].to_i }
        response = response_as_json "#{AIRCRAFT_TYPES_V4_URL}?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        actual_aircraft_types = response.sort_by { |row| row['id'] }
        actual_aircraft_types.length.times do |i|
          expect(actual_aircraft_types[i]['legalModelName']).to eq(expected_aircraft_types[i]['legalmodelname'])
          expect(actual_aircraft_types[i]['legalManufacturerName']).to eq(expected_aircraft_types[i]['manufacturer'])
          expect(actual_aircraft_types[i]['notes']).to eq(expected_aircraft_types[i]['notes'])
          expect(actual_aircraft_types[i]['aircraftTypeName']).to eq(expected_aircraft_types[i]['aircraft_type_name'])
          if expected_aircraft_types[i]['display_rnk'] != nil
            expect(actual_aircraft_types[i]['rank']).to eq(expected_aircraft_types[i]['display_rnk'].to_i)
          end

        end
      end

      it 'gets the fleet group information correctly', :critical => true do
        aircraft_types = db_conn_ais.connection.execute(get_all_ais_ac_type_sql)
        expected_aircraft_types = aircraft_types.sort_by { |x| x['legalmodelname'] }
        response = response_as_json "#{AIRCRAFT_TYPES_V4_URL}?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        actual_aircraft_types = response.sort_by { |row| row['legalModelName'] }
        actual_aircraft_types.length.times do |i|
          if actual_aircraft_types[i].has_key?('fleetGroup')
            expect(actual_aircraft_types[i]['fleetGroup']['id'])
            .to eq(expected_aircraft_types[i]['acft_fleet_group_id'].to_i)
            expect(actual_aircraft_types[i]['fleetGroup']['fleetGroupName'])
            .to eq(expected_aircraft_types[i]['fleet_group_name'])
          end
        end
      end

      it 'gets only active aircraft types when activeStatus is true' do
        response = response_as_json "#{AIRCRAFT_TYPES_V4_URL}?&activeStatus=true&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        actual_aircraft_types = response.sort_by { |row| row['legalModelName'] }
        actual_aircraft_types.each do |aircraft_type|
          expect(aircraft_type['isActive']).to be true
        end
      end

      it 'gets only inactive aircraft types when activeStatus is false' do
        response = response_as_json "#{AIRCRAFT_TYPES_V4_URL}?&activeStatus=false&#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        actual_aircraft_types = response.sort_by { |row| row['legalModelName'] }
        actual_aircraft_types.each do |aircraft_type|
          expect(aircraft_type['isActive']).to be false
        end
      end

      it 'get the isActive as false' do
        expected_aircraft_types = db_conn_ais.connection.execute(get_ais_ac_type_status_sql('F'))
        if expected_aircraft_types.length > 0
          response = response_as_json "#{AIRCRAFT_TYPES_V4_URL}?#{APP_AGENT_PARAM}",
                                      @account_mgmt_oauth.authorized_oauth_header
          actual_aircraft_types = response
          .select { |row| row['id']==expected_aircraft_types[0]['acft_aircraft_type_id'].to_i }
          expect(actual_aircraft_types[0]['isActive']).to be false
        else
          log.info 'cannot find data with isActive as false'
        end
      end

      it 'get the isActive as true' do
        expected_aircraft_types = db_conn_ais.connection.execute(get_ais_ac_type_status_sql('T'))
        if expected_aircraft_types.length > 0
          response = response_as_json "#{AIRCRAFT_TYPES_V4_URL}?#{APP_AGENT_PARAM}",
                                      @account_mgmt_oauth.authorized_oauth_header
          actual_aircraft_types = response
          .select { |row| row['id']==expected_aircraft_types[0]['acft_aircraft_type_id'].to_i }
          expect(actual_aircraft_types[0]['isActive']).to be true
        else
          log.info 'cannot find data with isActive as true'
        end
      end

      it 'gets the number of engines' do
        expected_aircraft_types = db_conn_ais.connection.execute(get_all_ais_ac_type_sql)
        .sort_by { |x| x['legalmodelname'] }
        response = response_as_json "#{AIRCRAFT_TYPES_V4_URL}?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        actual_aircraft_types = response.sort_by { |row| row['legalModelName'] }
        actual_aircraft_types.length.times do |i|
          expect(actual_aircraft_types[i]['numberOfEngines']).to eq(expected_aircraft_types[i]['engines_cnt'].to_i)
        end
      end

      it 'gets the sales status' do
        expected_aircraft_types = db_conn_ais.connection.execute(get_all_ais_ac_type_sql)
        .sort_by { |x| x['legalmodelname'] }
        response = response_as_json "#{AIRCRAFT_TYPES_V4_URL}?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        actual_aircraft_types = response.sort_by { |row| row['legalModelName'] }
        actual_aircraft_types.length.times do |i|
          expect(actual_aircraft_types[i]['salesStatusDesc']).to eq(expected_aircraft_types[i]['sales_status'])
        end
      end

      it 'number of engines is always between 1 and 4' do
        response = response_as_json "#{AIRCRAFT_TYPES_V4_URL}?#{APP_AGENT_PARAM}",
                                    @account_mgmt_oauth.authorized_oauth_header
        actual_aircraft_types = response.sort_by { |row| row['legalModelName'] }
        actual_aircraft_types.length.times do |i|
          expect(actual_aircraft_types[i]['numberOfEngines']).to satisfy { |x| x>=1 && x<=4 }
        end
      end

      AIRCRAFT_CABIN_SIZE_CODES.each_pair do |code, cabin_info|
        it "gets the code and description correctly for #{cabin_info[1]} cabin" do
          response = response_as_json "#{AIRCRAFT_TYPES_V4_URL}?#{APP_AGENT_PARAM}",
                                      @account_mgmt_oauth.authorized_oauth_header
          actual_aircraft_types = response.sort_by { |row| row['legalModelName'] }
          .select { |row| row['cabinSizeDesc']==cabin_info[1] }
          expect(actual_aircraft_types[0]['cabinSizeCd']).to eq(cabin_info[0])
        end
      end
    end

  end
end