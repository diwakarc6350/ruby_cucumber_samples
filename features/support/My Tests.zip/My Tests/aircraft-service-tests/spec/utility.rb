require 'rest_shared_context'
require 'rest-client'

def response_as_json(request, auth)
  begin
    #log.info("Request : #{request}")
    response = rest.get(request, SSL_OPTIONS.merge(auth))
    JSON response.body
  rescue => rest_exception
    puts rest_exception.response.body
    JSON rest_exception.response.body
  end
end

def post_as_json(request, data, auth)
  begin
    headers = {
        'Content-Type' => 'application/json',
        'appAgent' => 'AircraftInventoryUser',
        'Authorization' => auth[:headers]['Authorization']
    }
    #log.info("Request : #{request}")
    #log.info("Data : #{data}")
    #log.info("auth : #{headers}")
    response = @rest
                   .post(request,
                         :body => data, :headers => headers, :verify_ssl => true, :ssl_version => "SSLv23"
                   )
    JSON response.body
  rescue => rest_exception
    JSON rest_exception.response.body
  end
end

def put_as_json(request, data, auth)
  begin
    headers = {
        'Content-Type' => 'application/json',
        'appAgent' => 'AircraftInventoryUser',
        'Authorization' => auth[:headers]['Authorization']
    }
    #log.info("Request : #{request}")
    #log.info("Data : #{data}")
    #log.info("auth : #{headers}")
    response = @rest
                   .put(request,
                        :body => data, :headers => headers, :verify_ssl => true, :ssl_version => "SSLv23"
                   )
    JSON response.body
  rescue => rest_exception
    JSON rest_exception.response.body
  end
end

def delete_as_json(request, data, auth)
  begin
    headers = {
        'Content-Type' => 'application/json',
        'appAgent' => 'AircraftInventoryUser',
        'Authorization' => auth[:headers]['Authorization']
    }
    # log.info("Request : #{request}")
    # log.info("Data : #{data}")
    # log.info("auth : #{headers}")
    response = @rest
                   .delete(request,
                           :body => data, :headers => headers, :verify_ssl => true, :ssl_version => "SSLv23"
                   )
    JSON response.body
  rescue => rest_exception
    JSON rest_exception.response.body
  end
end