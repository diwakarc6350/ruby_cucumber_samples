require 'rspec'
require 'logger'
require 'active_record'


SSL_OPTIONS = {
    verify_ssl: true,
    ssl_ca_file: File.dirname(__FILE__)+"/../resources/cacert.pem",
    ssl_version: 'SSLv23'
}

$logger = Logger.new STDOUT

def log
  $logger
end

def environment
  #:qa
  ENV['ENVIRONMENT'].to_sym
end

puts "Using #{environment} environment to test..."

