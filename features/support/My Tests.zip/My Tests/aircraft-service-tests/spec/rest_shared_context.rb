require 'rspec'
require 'rest'

shared_context "rest client" do
  before(:all) do
    @rest = Rest::Client.new
  end

  def rest
    @rest
  end
end