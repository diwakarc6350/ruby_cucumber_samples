def get_aircrafts_code_types_sql(category_id)
  <<-SQL.gsub(/^ {6}/, '')
    select acft_code_type_id, code_category_id, code_type_class_id, code_type_abbr, code_type_name
    from ACFT_CODE_TYPE
    where code_category_id = '#{category_id}'
  SQL
end

def get_all_fleet_groups_sql
  <<-SQL.gsub(/^ {6}/, '')
    select *
    from acft_fleet_group fg
    order by fleet_group_name
  SQL
end

def get_aircrafts_by_type_name_sql(aircraft_type_name='')
  <<-SQL.gsub(/^ {6}/, '')
        select at.aircraft_type_name, at.acft_aircraft_type_id, extract(year from a.manufacture_dt),
        a.aircraft_tail_nbr, a.contracts_until_dt, a.warranty_expiration_dt, at.fleet_group_id
        from acft_aircraft a
        join acft_aircraft_type at
        on a.acft_aircraft_type_id = at.acft_aircraft_type_id
        where at.aircraft_type_name like '%#{aircraft_type_name}%'
  SQL
end

def get_aircraft_info_by_type_id(type_id)
  <<-SQL.gsub(/^ {6}/, '')
        select at.aircraft_type_name, at.acft_aircraft_type_id, extract(year from a.manufacture_dt),
        a.aircraft_tail_nbr, a.contracts_until_dt, a.warranty_expiration_dt
        from acft_aircraft a
        join acft_aircraft_type at
        on a.acft_aircraft_type_id = at.acft_aircraft_type_id
        where a.acft_aircraft_type_id = '#{type_id}'
  SQL
end

def get_aircraft_tail_numbers_sql
  <<-SQL.gsub(/^ {4}/, '')
     select a.acft_aircraft_id, a.aircraft_tail_nbr, a.manufacture_dt, a.contracts_until_dt,
        a.warranty_expiration_dt, at.acft_aircraft_type_id, at.aircraft_type_name, fg.acft_fleet_group_id,
        fg.fleet_group_name, a.aircraft_state_cd, acode.code_type_name, acode.code_type_class_id, a.ijet_ej_company_id,
        ejm.company_name, ct.code_type_name as sales_status, at.display_rnk
        from acft_aircraft a
        join acft_aircraft_type at
        on a.acft_aircraft_type_id = at.acft_aircraft_type_id
        left outer join acft_fleet_group fg
        on at.fleet_group_id = fg.acft_fleet_group_id
        left outer join ej_company ejm
        on a.ijet_ej_company_id = ejm.ej_company_id
        join ACFT_CODE_TYPE acode
        on a.aircraft_state_cd = acode.acft_code_type_id
        join acft_code_type ct
        on a.sales_status_cd = ct.acft_code_type_id
        order by at.display_rnk asc,  a.manufacture_dt desc
  SQL
end


def get_aircraft_info_by_tail_sql(tail)
  <<-SQL.gsub(/^ {6}/, '')
        select at.aircraft_type_name, at.acft_aircraft_type_id, a.acft_aircraft_id, a.manufacture_dt,
        a.aircraft_tail_nbr, a.contracts_until_dt, a.warranty_expiration_dt
        from acft_aircraft a
        join acft_aircraft_type at
        on a.acft_aircraft_type_id = at.acft_aircraft_type_id
        where a.aircraft_tail_nbr like '%#{tail}%'
  SQL
end

def get_partial_tail_numbers
  tail_numbers = db_conn_ais.connection.execute(get_aircraft_tail_numbers_sql)
  the_chosen_tail = tail_numbers[rand(tail_numbers.length)]['aircraft_tail_nbr']
  partial_tail_numbers = []
  if the_chosen_tail.length >= 5
    partial_tail_numbers << the_chosen_tail[0, 2]
    partial_tail_numbers << the_chosen_tail[3, 5]
    partial_tail_numbers << the_chosen_tail[the_chosen_tail.length-2, the_chosen_tail.length]
  else
    3.times { tail_numbers << the_chosen_tail }
  end
  partial_tail_numbers
end

def get_ais_ac_type_status_sql(status='T')
  <<-SQL.gsub(/^ {6}/, '')
        select acft_aircraft_type_id
        from acft_aircraft_type
        where active_status_flg = '#{status}'
  SQL
end

def sales_status_sql
  <<-SQL.gsub(/^ {6}/, '')
        select acft_code_type_id, code_type_name
        from ACFT_CODE_TYPE
        where code_category_id = 3
  SQL
end

def get_ais_ac_type_sales_sql(code)
  <<-SQL.gsub(/^ {6}/, '')
        select acft_aircraft_type_id
        from acft_aircraft_type
        where sales_status_cd = '#{code}'
  SQL
end

def get_ais_ac_type_cabin_sql(cabin)
  <<-SQL.gsub(/^ {6}/, '')
       select * from ACFT_CABIN_CLASS cc join ACFT_Aircraft_type aat on cc.ACFT_CABIN_CLASS_ID = aat.ACFT_CABIN_CLASS_ID
        where cc.cabin_class_cd = '#{cabin}'
  SQL
end

def get_all_ais_ac_type_sql
  <<-SQL.gsub(/^ {6}/, '')
        select at.acft_aircraft_type_id, at.AIRCRAFT_TYPE_RANKING_NBR, at.legal_model_name as legalModelName,
        at.legal_manufacturer_name as manufacturer,
        at.active_status_flg as status, at.notes_txt as notes,
        ct.code_type_name as sales_status, at.engines_cnt, at.aircraft_type_name, fg.fleet_group_name,
        fg.acft_fleet_group_id, at.display_rnk
        from acft_aircraft_type at
        left outer join acft_fleet_group fg
        on at.fleet_group_id = fg.acft_fleet_group_id
        join acft_code_type ct
        on at.sales_status_cd = ct.acft_code_type_id
  SQL
end

def clean_holds_sql(id, by)
  <<-SQL.gsub(/^ {6}/, '')
    delete from acft_hold where acft_aircraft_id = '#{id}' and held_by_userid = '#{by}'
  SQL
end

def get_holds_sql(id)
  <<-SQL.gsub(/^ {6}/, '')
    select * from acft_hold where acft_hold_id = '#{id}'
  SQL
end

def get_all_holds_sql
  <<-SQL.gsub(/^ {6}/, '')
    select * from acft_hold
  SQL
end

def get_sum_of_hold
  <<-SQL.gsub(/^ {6}/, '')
    select acft_aircraft_id, sum(hold_pct) as placed_hold_sum
    from acft_hold where is_deleted_flg = 'F' and expiration_ts >=sysdate
    group by acft_aircraft_id
    order by acft_aircraft_id
  SQL
end